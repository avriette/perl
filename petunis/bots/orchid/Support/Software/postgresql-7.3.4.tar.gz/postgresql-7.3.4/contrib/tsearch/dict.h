#define TABLE_DICT_START	,{
#define TABLE_DICT_END		}

#include "dict/porter_english.dct"
#include "dict/russian_stemming.dct"

#undef TABLE_DICT_START
#undef TABLE_DICT_END
