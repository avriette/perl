#ifndef __REWRITE_H__
#define __REWRITE_H__

ITEM	   *clean_NOT(ITEM * ptr, int4 *len);
ITEM	   *clean_fakeval(ITEM * ptr, int4 *len);

#endif
