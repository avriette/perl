/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ABORT_TRANS = 258,
     ABSOLUTE = 259,
     ACCESS = 260,
     ACTION = 261,
     ADD = 262,
     AFTER = 263,
     AGGREGATE = 264,
     ALL = 265,
     ALTER = 266,
     ANALYSE = 267,
     ANALYZE = 268,
     AND = 269,
     ANY = 270,
     AS = 271,
     ASC = 272,
     ASSERTION = 273,
     ASSIGNMENT = 274,
     AT = 275,
     AUTHORIZATION = 276,
     BACKWARD = 277,
     BEFORE = 278,
     BEGIN_TRANS = 279,
     BETWEEN = 280,
     BIGINT = 281,
     BINARY = 282,
     BIT = 283,
     BOOLEAN = 284,
     BOTH = 285,
     BY = 286,
     CACHE = 287,
     CALLED = 288,
     CASCADE = 289,
     CASE = 290,
     CAST = 291,
     CHAIN = 292,
     CHAR_P = 293,
     CHARACTER = 294,
     CHARACTERISTICS = 295,
     CHECK = 296,
     CHECKPOINT = 297,
     CLASS = 298,
     CLOSE = 299,
     CLUSTER = 300,
     COALESCE = 301,
     COLLATE = 302,
     COLUMN = 303,
     COMMENT = 304,
     COMMIT = 305,
     COMMITTED = 306,
     CONSTRAINT = 307,
     CONSTRAINTS = 308,
     CONVERSION_P = 309,
     CONVERT = 310,
     COPY = 311,
     CREATE = 312,
     CREATEDB = 313,
     CREATEUSER = 314,
     CROSS = 315,
     CURRENT_DATE = 316,
     CURRENT_TIME = 317,
     CURRENT_TIMESTAMP = 318,
     CURRENT_USER = 319,
     CURSOR = 320,
     CYCLE = 321,
     DATABASE = 322,
     DAY_P = 323,
     DEALLOCATE = 324,
     DEC = 325,
     DECIMAL = 326,
     DECLARE = 327,
     DEFAULT = 328,
     DEFERRABLE = 329,
     DEFERRED = 330,
     DEFINER = 331,
     DELETE_P = 332,
     DELIMITER = 333,
     DELIMITERS = 334,
     DESC = 335,
     DISTINCT = 336,
     DO = 337,
     DOMAIN_P = 338,
     DOUBLE = 339,
     DROP = 340,
     EACH = 341,
     ELSE = 342,
     ENCODING = 343,
     ENCRYPTED = 344,
     END_TRANS = 345,
     ESCAPE = 346,
     EXCEPT = 347,
     EXCLUSIVE = 348,
     EXECUTE = 349,
     EXISTS = 350,
     EXPLAIN = 351,
     EXTERNAL = 352,
     EXTRACT = 353,
     FALSE_P = 354,
     FETCH = 355,
     FLOAT_P = 356,
     FOR = 357,
     FORCE = 358,
     FOREIGN = 359,
     FORWARD = 360,
     FREEZE = 361,
     FROM = 362,
     FULL = 363,
     FUNCTION = 364,
     GET = 365,
     GLOBAL = 366,
     GRANT = 367,
     GROUP_P = 368,
     HANDLER = 369,
     HAVING = 370,
     HOUR_P = 371,
     ILIKE = 372,
     IMMEDIATE = 373,
     IMMUTABLE = 374,
     IMPLICIT_P = 375,
     IN_P = 376,
     INCREMENT = 377,
     INDEX = 378,
     INHERITS = 379,
     INITIALLY = 380,
     INNER_P = 381,
     INOUT = 382,
     INPUT = 383,
     INSENSITIVE = 384,
     INSERT = 385,
     INSTEAD = 386,
     INT = 387,
     INTEGER = 388,
     INTERSECT = 389,
     INTERVAL = 390,
     INTO = 391,
     INVOKER = 392,
     IS = 393,
     ISNULL = 394,
     ISOLATION = 395,
     JOIN = 396,
     KEY = 397,
     LANCOMPILER = 398,
     LANGUAGE = 399,
     LEADING = 400,
     LEFT = 401,
     LEVEL = 402,
     LIKE = 403,
     LIMIT = 404,
     LISTEN = 405,
     LOAD = 406,
     LOCAL = 407,
     LOCALTIME = 408,
     LOCALTIMESTAMP = 409,
     LOCATION = 410,
     LOCK_P = 411,
     MATCH = 412,
     MAXVALUE = 413,
     MINUTE_P = 414,
     MINVALUE = 415,
     MODE = 416,
     MONTH_P = 417,
     MOVE = 418,
     NAMES = 419,
     NATIONAL = 420,
     NATURAL = 421,
     NCHAR = 422,
     NEW = 423,
     NEXT = 424,
     NO = 425,
     NOCREATEDB = 426,
     NOCREATEUSER = 427,
     NONE = 428,
     NOT = 429,
     NOTHING = 430,
     NOTIFY = 431,
     NOTNULL = 432,
     NULL_P = 433,
     NULLIF = 434,
     NUMERIC = 435,
     OF = 436,
     OFF = 437,
     OFFSET = 438,
     OIDS = 439,
     OLD = 440,
     ON = 441,
     ONLY = 442,
     OPERATOR = 443,
     OPTION = 444,
     OR = 445,
     ORDER = 446,
     OUT_P = 447,
     OUTER_P = 448,
     OVERLAPS = 449,
     OVERLAY = 450,
     OWNER = 451,
     PARTIAL = 452,
     PASSWORD = 453,
     PATH_P = 454,
     PENDANT = 455,
     PLACING = 456,
     POSITION = 457,
     PRECISION = 458,
     PREPARE = 459,
     PRIMARY = 460,
     PRIOR = 461,
     PRIVILEGES = 462,
     PROCEDURAL = 463,
     PROCEDURE = 464,
     READ = 465,
     REAL = 466,
     RECHECK = 467,
     REFERENCES = 468,
     REINDEX = 469,
     RELATIVE = 470,
     RENAME = 471,
     REPLACE = 472,
     RESET = 473,
     RESTRICT = 474,
     RETURNS = 475,
     REVOKE = 476,
     RIGHT = 477,
     ROLLBACK = 478,
     ROW = 479,
     RULE = 480,
     SCHEMA = 481,
     SCROLL = 482,
     SECOND_P = 483,
     SECURITY = 484,
     SELECT = 485,
     SEQUENCE = 486,
     SERIALIZABLE = 487,
     SESSION = 488,
     SESSION_USER = 489,
     SET = 490,
     SETOF = 491,
     SHARE = 492,
     SHOW = 493,
     SIMILAR = 494,
     SIMPLE = 495,
     SMALLINT = 496,
     SOME = 497,
     STABLE = 498,
     START = 499,
     STATEMENT = 500,
     STATISTICS = 501,
     STDIN = 502,
     STDOUT = 503,
     STORAGE = 504,
     STRICT = 505,
     SUBSTRING = 506,
     SYSID = 507,
     TABLE = 508,
     TEMP = 509,
     TEMPLATE = 510,
     TEMPORARY = 511,
     THEN = 512,
     TIME = 513,
     TIMESTAMP = 514,
     TO = 515,
     TOAST = 516,
     TRAILING = 517,
     TRANSACTION = 518,
     TREAT = 519,
     TRIGGER = 520,
     TRIM = 521,
     TRUE_P = 522,
     TRUNCATE = 523,
     TRUSTED = 524,
     TYPE_P = 525,
     UNENCRYPTED = 526,
     UNION = 527,
     UNIQUE = 528,
     UNKNOWN = 529,
     UNLISTEN = 530,
     UNTIL = 531,
     UPDATE = 532,
     USAGE = 533,
     USER = 534,
     USING = 535,
     VACUUM = 536,
     VALID = 537,
     VALIDATOR = 538,
     VALUES = 539,
     VARCHAR = 540,
     VARYING = 541,
     VERBOSE = 542,
     VERSION = 543,
     VIEW = 544,
     VOLATILE = 545,
     WHEN = 546,
     WHERE = 547,
     WITH = 548,
     WITHOUT = 549,
     WORK = 550,
     WRITE = 551,
     YEAR_P = 552,
     ZONE = 553,
     UNIONJOIN = 554,
     IDENT = 555,
     FCONST = 556,
     SCONST = 557,
     NCONST = 558,
     BCONST = 559,
     XCONST = 560,
     Op = 561,
     ICONST = 562,
     PARAM = 563,
     OP = 564,
     POSTFIXOP = 565,
     UMINUS = 566,
     TYPECAST = 567
   };
#endif
#define ABORT_TRANS 258
#define ABSOLUTE 259
#define ACCESS 260
#define ACTION 261
#define ADD 262
#define AFTER 263
#define AGGREGATE 264
#define ALL 265
#define ALTER 266
#define ANALYSE 267
#define ANALYZE 268
#define AND 269
#define ANY 270
#define AS 271
#define ASC 272
#define ASSERTION 273
#define ASSIGNMENT 274
#define AT 275
#define AUTHORIZATION 276
#define BACKWARD 277
#define BEFORE 278
#define BEGIN_TRANS 279
#define BETWEEN 280
#define BIGINT 281
#define BINARY 282
#define BIT 283
#define BOOLEAN 284
#define BOTH 285
#define BY 286
#define CACHE 287
#define CALLED 288
#define CASCADE 289
#define CASE 290
#define CAST 291
#define CHAIN 292
#define CHAR_P 293
#define CHARACTER 294
#define CHARACTERISTICS 295
#define CHECK 296
#define CHECKPOINT 297
#define CLASS 298
#define CLOSE 299
#define CLUSTER 300
#define COALESCE 301
#define COLLATE 302
#define COLUMN 303
#define COMMENT 304
#define COMMIT 305
#define COMMITTED 306
#define CONSTRAINT 307
#define CONSTRAINTS 308
#define CONVERSION_P 309
#define CONVERT 310
#define COPY 311
#define CREATE 312
#define CREATEDB 313
#define CREATEUSER 314
#define CROSS 315
#define CURRENT_DATE 316
#define CURRENT_TIME 317
#define CURRENT_TIMESTAMP 318
#define CURRENT_USER 319
#define CURSOR 320
#define CYCLE 321
#define DATABASE 322
#define DAY_P 323
#define DEALLOCATE 324
#define DEC 325
#define DECIMAL 326
#define DECLARE 327
#define DEFAULT 328
#define DEFERRABLE 329
#define DEFERRED 330
#define DEFINER 331
#define DELETE_P 332
#define DELIMITER 333
#define DELIMITERS 334
#define DESC 335
#define DISTINCT 336
#define DO 337
#define DOMAIN_P 338
#define DOUBLE 339
#define DROP 340
#define EACH 341
#define ELSE 342
#define ENCODING 343
#define ENCRYPTED 344
#define END_TRANS 345
#define ESCAPE 346
#define EXCEPT 347
#define EXCLUSIVE 348
#define EXECUTE 349
#define EXISTS 350
#define EXPLAIN 351
#define EXTERNAL 352
#define EXTRACT 353
#define FALSE_P 354
#define FETCH 355
#define FLOAT_P 356
#define FOR 357
#define FORCE 358
#define FOREIGN 359
#define FORWARD 360
#define FREEZE 361
#define FROM 362
#define FULL 363
#define FUNCTION 364
#define GET 365
#define GLOBAL 366
#define GRANT 367
#define GROUP_P 368
#define HANDLER 369
#define HAVING 370
#define HOUR_P 371
#define ILIKE 372
#define IMMEDIATE 373
#define IMMUTABLE 374
#define IMPLICIT_P 375
#define IN_P 376
#define INCREMENT 377
#define INDEX 378
#define INHERITS 379
#define INITIALLY 380
#define INNER_P 381
#define INOUT 382
#define INPUT 383
#define INSENSITIVE 384
#define INSERT 385
#define INSTEAD 386
#define INT 387
#define INTEGER 388
#define INTERSECT 389
#define INTERVAL 390
#define INTO 391
#define INVOKER 392
#define IS 393
#define ISNULL 394
#define ISOLATION 395
#define JOIN 396
#define KEY 397
#define LANCOMPILER 398
#define LANGUAGE 399
#define LEADING 400
#define LEFT 401
#define LEVEL 402
#define LIKE 403
#define LIMIT 404
#define LISTEN 405
#define LOAD 406
#define LOCAL 407
#define LOCALTIME 408
#define LOCALTIMESTAMP 409
#define LOCATION 410
#define LOCK_P 411
#define MATCH 412
#define MAXVALUE 413
#define MINUTE_P 414
#define MINVALUE 415
#define MODE 416
#define MONTH_P 417
#define MOVE 418
#define NAMES 419
#define NATIONAL 420
#define NATURAL 421
#define NCHAR 422
#define NEW 423
#define NEXT 424
#define NO 425
#define NOCREATEDB 426
#define NOCREATEUSER 427
#define NONE 428
#define NOT 429
#define NOTHING 430
#define NOTIFY 431
#define NOTNULL 432
#define NULL_P 433
#define NULLIF 434
#define NUMERIC 435
#define OF 436
#define OFF 437
#define OFFSET 438
#define OIDS 439
#define OLD 440
#define ON 441
#define ONLY 442
#define OPERATOR 443
#define OPTION 444
#define OR 445
#define ORDER 446
#define OUT_P 447
#define OUTER_P 448
#define OVERLAPS 449
#define OVERLAY 450
#define OWNER 451
#define PARTIAL 452
#define PASSWORD 453
#define PATH_P 454
#define PENDANT 455
#define PLACING 456
#define POSITION 457
#define PRECISION 458
#define PREPARE 459
#define PRIMARY 460
#define PRIOR 461
#define PRIVILEGES 462
#define PROCEDURAL 463
#define PROCEDURE 464
#define READ 465
#define REAL 466
#define RECHECK 467
#define REFERENCES 468
#define REINDEX 469
#define RELATIVE 470
#define RENAME 471
#define REPLACE 472
#define RESET 473
#define RESTRICT 474
#define RETURNS 475
#define REVOKE 476
#define RIGHT 477
#define ROLLBACK 478
#define ROW 479
#define RULE 480
#define SCHEMA 481
#define SCROLL 482
#define SECOND_P 483
#define SECURITY 484
#define SELECT 485
#define SEQUENCE 486
#define SERIALIZABLE 487
#define SESSION 488
#define SESSION_USER 489
#define SET 490
#define SETOF 491
#define SHARE 492
#define SHOW 493
#define SIMILAR 494
#define SIMPLE 495
#define SMALLINT 496
#define SOME 497
#define STABLE 498
#define START 499
#define STATEMENT 500
#define STATISTICS 501
#define STDIN 502
#define STDOUT 503
#define STORAGE 504
#define STRICT 505
#define SUBSTRING 506
#define SYSID 507
#define TABLE 508
#define TEMP 509
#define TEMPLATE 510
#define TEMPORARY 511
#define THEN 512
#define TIME 513
#define TIMESTAMP 514
#define TO 515
#define TOAST 516
#define TRAILING 517
#define TRANSACTION 518
#define TREAT 519
#define TRIGGER 520
#define TRIM 521
#define TRUE_P 522
#define TRUNCATE 523
#define TRUSTED 524
#define TYPE_P 525
#define UNENCRYPTED 526
#define UNION 527
#define UNIQUE 528
#define UNKNOWN 529
#define UNLISTEN 530
#define UNTIL 531
#define UPDATE 532
#define USAGE 533
#define USER 534
#define USING 535
#define VACUUM 536
#define VALID 537
#define VALIDATOR 538
#define VALUES 539
#define VARCHAR 540
#define VARYING 541
#define VERBOSE 542
#define VERSION 543
#define VIEW 544
#define VOLATILE 545
#define WHEN 546
#define WHERE 547
#define WITH 548
#define WITHOUT 549
#define WORK 550
#define WRITE 551
#define YEAR_P 552
#define ZONE 553
#define UNIONJOIN 554
#define IDENT 555
#define FCONST 556
#define SCONST 557
#define NCONST 558
#define BCONST 559
#define XCONST 560
#define Op 561
#define ICONST 562
#define PARAM 563
#define OP 564
#define POSTFIXOP 565
#define UMINUS 566
#define TYPECAST 567




/* Copy the first part of user declarations.  */
#line 1 "gram.y"


/*#define YYDEBUG 1*/
/*-------------------------------------------------------------------------
 *
 * gram.y
 *	  POSTGRES SQL YACC rules/actions
 *
 * Portions Copyright (c) 1996-2002, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 *
 * IDENTIFICATION
 *	  $Header: /cvsroot/pgsql-server/src/backend/parser/gram.y,v 2.373.2.2 2003/05/04 00:04:10 tgl Exp $
 *
 * HISTORY
 *	  AUTHOR			DATE			MAJOR EVENT
 *	  Andrew Yu			Sept, 1994		POSTQUEL to SQL conversion
 *	  Andrew Yu			Oct, 1994		lispy code conversion
 *
 * NOTES
 *	  CAPITALS are used to represent terminal symbols.
 *	  non-capitals are used to represent non-terminals.
 *	  SQL92-specific syntax is separated from plain SQL/Postgres syntax
 *	  to help isolate the non-extensible portions of the parser.
 *
 *	  In general, nothing in this file should initiate database accesses
 *	  nor depend on changeable state (such as SET variables).  If you do
 *	  database accesses, your code will fail when we have aborted the
 *	  current transaction and are just parsing commands to find the next
 *	  ROLLBACK or COMMIT.  If you make use of SET variables, then you
 *	  will do the wrong thing in multi-query strings like this:
 *			SET SQL_inheritance TO off; SELECT * FROM foo;
 *	  because the entire string is parsed by gram.y before the SET gets
 *	  executed.  Anything that depends on the database or changeable state
 *	  should be handled inside parse_analyze() so that it happens at the
 *	  right time not the wrong time.  The handling of SQL_inheritance is
 *	  a good example.
 *
 * WARNINGS
 *	  If you use a list, make sure the datum is a node so that the printing
 *	  routines work.
 *
 *	  Sometimes we assign constants to makeStrings. Make sure we don't free
 *	  those.
 *
 *-------------------------------------------------------------------------
 */
#include "postgres.h"

#include <ctype.h>

#include "access/htup.h"
#include "catalog/index.h"
#include "catalog/namespace.h"
#include "catalog/pg_type.h"
#include "nodes/makefuncs.h"
#include "nodes/params.h"
#include "nodes/parsenodes.h"
#include "parser/gramparse.h"
#include "storage/lmgr.h"
#include "utils/numeric.h"
#include "utils/datetime.h"
#include "utils/date.h"

extern List *parsetree;			/* final parse result is delivered here */

static bool QueryIsRule = FALSE;

/*
 * If you need access to certain yacc-generated variables and find that
 * they're static by default, uncomment the next line.  (this is not a
 * problem, yet.)
 */
/*#define __YYSCLASS*/

static Node *makeTypeCast(Node *arg, TypeName *typename);
static Node *makeStringConst(char *str, TypeName *typename);
static Node *makeIntConst(int val);
static Node *makeFloatConst(char *str);
static Node *makeAConst(Value *v);
static Node *makeRowExpr(List *opr, List *largs, List *rargs);
static Node *makeDistinctExpr(List *largs, List *rargs);
static Node *makeRowNullTest(NullTestType test, List *args);
static DefElem *makeDefElem(char *name, Node *arg);
static A_Const *makeBoolConst(bool state);
static FuncCall *makeOverlaps(List *largs, List *rargs);
static SelectStmt *findLeftmostSelect(SelectStmt *node);
static void insertSelectOptions(SelectStmt *stmt,
								List *sortClause, List *forUpdate,
								Node *limitOffset, Node *limitCount);
static Node *makeSetOp(SetOperation op, bool all, Node *larg, Node *rarg);
static Node *doNegate(Node *n);
static void doNegateFloat(Value *v);



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 100 "gram.y"
typedef union YYSTYPE {
	int					ival;
	char				chr;
	char				*str;
	const char			*keyword;
	bool				boolean;
	JoinType			jtype;
	DropBehavior		dbehavior;
	List				*list;
	Node				*node;
	Value				*value;
	ColumnRef			*columnref;

	TypeName			*typnam;
	DefElem				*defelt;
	SortGroupBy			*sortgroupby;
	JoinExpr			*jexpr;
	IndexElem			*ielem;
	Alias				*alias;
	RangeVar			*range;
	A_Indices			*aind;
	ResTarget			*target;
	PrivTarget			*privtarget;

	InsertStmt			*istmt;
	VariableSetStmt		*vsetstmt;
} YYSTYPE;
/* Line 191 of yacc.c.  */
#line 824 "y.tab.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 836 "y.tab.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  494
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   27064

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  330
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  356
/* YYNRULES -- Number of rules. */
#define YYNRULES  1400
/* YYNRULES -- Number of states. */
#define YYNSTATES  2357

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   567

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned short yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,   318,     2,     2,
     323,   324,   316,   314,   328,   315,   326,   317,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   329,   327,
     311,   310,   312,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   321,     2,   322,   319,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
     165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   186,   187,   188,   189,   190,   191,   192,   193,   194,
     195,   196,   197,   198,   199,   200,   201,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   211,   212,   213,   214,
     215,   216,   217,   218,   219,   220,   221,   222,   223,   224,
     225,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,   237,   238,   239,   240,   241,   242,   243,   244,
     245,   246,   247,   248,   249,   250,   251,   252,   253,   254,
     255,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   313,   320,   325
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     5,     9,    11,    13,    15,    17,    19,
      21,    23,    25,    27,    29,    31,    33,    35,    37,    39,
      41,    43,    45,    47,    49,    51,    53,    55,    57,    59,
      61,    63,    65,    67,    69,    71,    73,    75,    77,    79,
      81,    83,    85,    87,    89,    91,    93,    95,    97,    99,
     101,   103,   105,   107,   109,   111,   113,   115,   117,   119,
     121,   123,   125,   127,   129,   131,   133,   135,   137,   139,
     141,   142,   148,   150,   151,   157,   163,   168,   172,   175,
     176,   179,   183,   187,   190,   192,   194,   196,   198,   202,
     206,   210,   212,   218,   221,   222,   225,   228,   235,   237,
     239,   243,   250,   255,   257,   258,   261,   262,   264,   266,
     268,   271,   275,   279,   283,   287,   291,   297,   305,   308,
     312,   316,   318,   320,   322,   326,   328,   330,   332,   335,
     337,   340,   343,   344,   346,   348,   350,   352,   354,   356,
     360,   367,   369,   371,   373,   375,   377,   378,   380,   382,
     385,   389,   394,   398,   401,   404,   408,   413,   417,   420,
     425,   427,   429,   431,   433,   435,   442,   450,   460,   470,
     480,   490,   498,   504,   512,   519,   526,   530,   533,   535,
     537,   538,   541,   543,   544,   555,   557,   559,   561,   563,
     565,   568,   569,   571,   573,   577,   581,   583,   584,   587,
     588,   592,   593,   595,   596,   606,   617,   619,   621,   624,
     627,   630,   633,   634,   636,   637,   639,   643,   645,   647,
     649,   654,   657,   658,   662,   664,   666,   669,   671,   673,
     676,   681,   684,   690,   692,   695,   698,   701,   704,   708,
     710,   715,   720,   726,   738,   742,   743,   745,   749,   751,
     754,   757,   760,   761,   763,   765,   768,   771,   772,   776,
     780,   783,   785,   787,   790,   793,   798,   799,   802,   805,
     806,   814,   818,   819,   821,   825,   827,   833,   836,   837,
     840,   842,   845,   848,   851,   854,   856,   858,   860,   863,
     865,   868,   878,   880,   881,   883,   885,   888,   889,   892,
     893,   899,   901,   902,   917,   937,   939,   941,   943,   947,
     953,   955,   957,   959,   963,   965,   966,   968,   970,   972,
     976,   977,   979,   981,   983,   985,   987,   989,   992,   993,
     995,   998,  1000,  1003,  1004,  1007,  1009,  1012,  1015,  1022,
    1031,  1036,  1041,  1046,  1051,  1059,  1068,  1072,  1074,  1078,
    1082,  1084,  1086,  1088,  1090,  1092,  1105,  1107,  1111,  1116,
    1124,  1129,  1132,  1134,  1135,  1137,  1138,  1146,  1151,  1153,
    1155,  1157,  1159,  1161,  1163,  1165,  1167,  1169,  1173,  1175,
    1177,  1181,  1188,  1198,  1206,  1216,  1225,  1234,  1241,  1250,
    1252,  1254,  1256,  1258,  1260,  1262,  1264,  1266,  1268,  1270,
    1272,  1278,  1283,  1288,  1292,  1295,  1301,  1306,  1311,  1315,
    1318,  1320,  1322,  1324,  1326,  1328,  1331,  1333,  1335,  1337,
    1339,  1341,  1349,  1357,  1359,  1361,  1364,  1366,  1370,  1372,
    1374,  1376,  1378,  1380,  1382,  1384,  1386,  1388,  1390,  1392,
    1394,  1396,  1399,  1402,  1405,  1408,  1411,  1413,  1417,  1419,
    1422,  1426,  1427,  1431,  1432,  1434,  1438,  1441,  1453,  1455,
    1456,  1459,  1460,  1462,  1464,  1466,  1470,  1476,  1479,  1481,
    1484,  1485,  1495,  1498,  1499,  1503,  1506,  1508,  1512,  1515,
    1517,  1519,  1521,  1523,  1525,  1527,  1532,  1534,  1537,  1540,
    1543,  1545,  1547,  1549,  1554,  1560,  1562,  1566,  1570,  1573,
    1576,  1578,  1582,  1585,  1586,  1592,  1600,  1602,  1604,  1612,
    1614,  1618,  1622,  1626,  1628,  1632,  1644,  1655,  1658,  1661,
    1662,  1671,  1676,  1681,  1683,  1685,  1687,  1688,  1697,  1706,
    1708,  1709,  1711,  1712,  1713,  1728,  1730,  1732,  1736,  1740,
    1742,  1744,  1746,  1748,  1750,  1752,  1754,  1755,  1757,  1759,
    1761,  1763,  1765,  1766,  1773,  1776,  1779,  1782,  1785,  1788,
    1791,  1795,  1798,  1801,  1804,  1808,  1809,  1811,  1813,  1814,
    1822,  1825,  1831,  1834,  1835,  1839,  1843,  1847,  1851,  1855,
    1859,  1863,  1867,  1871,  1873,  1874,  1880,  1885,  1889,  1897,
    1899,  1900,  1911,  1916,  1921,  1927,  1933,  1936,  1941,  1943,
    1945,  1947,  1948,  1950,  1951,  1953,  1954,  1958,  1959,  1963,
    1968,  1974,  1978,  1979,  1981,  1985,  1990,  1994,  1995,  1998,
    2002,  2004,  2006,  2008,  2010,  2012,  2017,  2022,  2025,  2027,
    2035,  2040,  2042,  2046,  2049,  2054,  2059,  2063,  2064,  2067,
    2070,  2073,  2077,  2079,  2083,  2085,  2088,  2095,  2102,  2104,
    2106,  2108,  2111,  2112,  2114,  2116,  2120,  2124,  2126,  2129,
    2134,  2139,  2141,  2143,  2152,  2157,  2162,  2167,  2170,  2171,
    2175,  2179,  2184,  2189,  2194,  2199,  2202,  2204,  2206,  2207,
    2209,  2211,  2212,  2214,  2220,  2222,  2223,  2225,  2226,  2230,
    2232,  2236,  2239,  2242,  2244,  2246,  2247,  2252,  2257,  2260,
    2263,  2268,  2270,  2271,  2273,  2275,  2277,  2279,  2281,  2285,
    2286,  2289,  2290,  2294,  2298,  2300,  2301,  2304,  2305,  2308,
    2309,  2311,  2315,  2317,  2320,  2322,  2325,  2331,  2338,  2344,
    2346,  2349,  2351,  2356,  2360,  2365,  2369,  2375,  2380,  2386,
    2391,  2397,  2400,  2405,  2407,  2410,  2413,  2416,  2418,  2420,
    2421,  2426,  2429,  2431,  2434,  2437,  2442,  2446,  2451,  2454,
    2455,  2457,  2461,  2464,  2467,  2471,  2475,  2480,  2481,  2483,
    2485,  2487,  2489,  2491,  2494,  2500,  2503,  2505,  2507,  2509,
    2511,  2513,  2515,  2517,  2519,  2521,  2523,  2525,  2528,  2531,
    2534,  2537,  2540,  2542,  2546,  2547,  2553,  2557,  2558,  2564,
    2568,  2569,  2571,  2573,  2575,  2577,  2583,  2586,  2588,  2590,
    2592,  2594,  2600,  2603,  2606,  2609,  2611,  2615,  2619,  2622,
    2624,  2625,  2629,  2630,  2633,  2634,  2640,  2643,  2649,  2652,
    2654,  2658,  2662,  2663,  2665,  2667,  2669,  2671,  2673,  2675,
    2679,  2683,  2687,  2691,  2695,  2699,  2703,  2704,  2708,  2713,
    2718,  2722,  2726,  2730,  2735,  2739,  2745,  2750,  2755,  2759,
    2763,  2767,  2769,  2771,  2773,  2775,  2777,  2779,  2781,  2783,
    2785,  2787,  2789,  2791,  2793,  2795,  2797,  2802,  2804,  2809,
    2811,  2815,  2819,  2825,  2828,  2831,  2834,  2837,  2840,  2843,
    2847,  2851,  2855,  2859,  2863,  2867,  2871,  2875,  2879,  2883,
    2886,  2889,  2893,  2897,  2900,  2904,  2910,  2915,  2922,  2926,
    2932,  2937,  2944,  2949,  2956,  2962,  2970,  2973,  2977,  2980,
    2985,  2989,  2994,  2998,  3003,  3007,  3012,  3018,  3025,  3033,
    3039,  3046,  3050,  3055,  3060,  3063,  3065,  3067,  3071,  3074,
    3077,  3080,  3083,  3086,  3089,  3093,  3097,  3101,  3105,  3109,
    3113,  3117,  3121,  3125,  3129,  3132,  3135,  3141,  3148,  3156,
    3158,  3160,  3164,  3168,  3174,  3176,  3180,  3185,  3191,  3197,
    3202,  3204,  3206,  3211,  3213,  3218,  3220,  3225,  3227,  3232,
    3234,  3236,  3238,  3245,  3250,  3255,  3260,  3265,  3272,  3278,
    3284,  3290,  3295,  3302,  3307,  3309,  3312,  3317,  3324,  3325,
    3327,  3331,  3335,  3336,  3340,  3342,  3344,  3346,  3348,  3350,
    3352,  3354,  3356,  3358,  3363,  3367,  3370,  3374,  3375,  3379,
    3383,  3386,  3389,  3391,  3392,  3395,  3398,  3402,  3405,  3407,
    3409,  3413,  3419,  3426,  3431,  3433,  3436,  3441,  3444,  3445,
    3447,  3448,  3451,  3454,  3457,  3460,  3463,  3467,  3469,  3473,
    3477,  3479,  3481,  3483,  3487,  3492,  3494,  3498,  3500,  3502,
    3504,  3506,  3508,  3512,  3514,  3516,  3518,  3522,  3524,  3526,
    3528,  3530,  3532,  3534,  3536,  3538,  3540,  3542,  3544,  3546,
    3548,  3551,  3555,  3562,  3565,  3567,  3569,  3571,  3573,  3575,
    3577,  3579,  3581,  3583,  3585,  3587,  3589,  3591,  3593,  3595,
    3597,  3599,  3601,  3603,  3605,  3607,  3609,  3611,  3613,  3615,
    3617,  3619,  3621,  3623,  3625,  3627,  3629,  3631,  3633,  3635,
    3637,  3639,  3641,  3643,  3645,  3647,  3649,  3651,  3653,  3655,
    3657,  3659,  3661,  3663,  3665,  3667,  3669,  3671,  3673,  3675,
    3677,  3679,  3681,  3683,  3685,  3687,  3689,  3691,  3693,  3695,
    3697,  3699,  3701,  3703,  3705,  3707,  3709,  3711,  3713,  3715,
    3717,  3719,  3721,  3723,  3725,  3727,  3729,  3731,  3733,  3735,
    3737,  3739,  3741,  3743,  3745,  3747,  3749,  3751,  3753,  3755,
    3757,  3759,  3761,  3763,  3765,  3767,  3769,  3771,  3773,  3775,
    3777,  3779,  3781,  3783,  3785,  3787,  3789,  3791,  3793,  3795,
    3797,  3799,  3801,  3803,  3805,  3807,  3809,  3811,  3813,  3815,
    3817,  3819,  3821,  3823,  3825,  3827,  3829,  3831,  3833,  3835,
    3837,  3839,  3841,  3843,  3845,  3847,  3849,  3851,  3853,  3855,
    3857,  3859,  3861,  3863,  3865,  3867,  3869,  3871,  3873,  3875,
    3877,  3879,  3881,  3883,  3885,  3887,  3889,  3891,  3893,  3895,
    3897,  3899,  3901,  3903,  3905,  3907,  3909,  3911,  3913,  3915,
    3917,  3919,  3921,  3923,  3925,  3927,  3929,  3931,  3933,  3935,
    3937,  3939,  3941,  3943,  3945,  3947,  3949,  3951,  3953,  3955,
    3957,  3959,  3961,  3963,  3965,  3967,  3969,  3971,  3973,  3975,
    3977,  3979,  3981,  3983,  3985,  3987,  3989,  3991,  3993,  3995,
    3997,  3999,  4001,  4003,  4005,  4007,  4009,  4011,  4013,  4015,
    4017,  4019,  4021,  4023,  4025,  4027,  4029,  4031,  4033,  4035,
    4037,  4039,  4041,  4043,  4045,  4047,  4049,  4051,  4053,  4055,
    4057,  4059,  4061,  4063,  4065,  4067,  4069,  4071,  4073,  4075,
    4077,  4079,  4081,  4083,  4085,  4087,  4089,  4091,  4093,  4095,
    4097,  4099,  4101,  4103,  4105,  4107,  4109,  4111,  4113,  4115,
    4117,  4119,  4121,  4123,  4125,  4127,  4129,  4131,  4133,  4135,
    4137,  4139,  4141,  4143,  4145,  4147,  4149,  4151,  4153,  4155,
    4157,  4159,  4161,  4163,  4165,  4167,  4169,  4171,  4173,  4175,
    4177,  4179,  4181,  4183,  4185,  4187,  4189,  4191,  4193,  4195,
    4197
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short yyrhs[] =
{
     331,     0,    -1,   332,    -1,   332,   327,   333,    -1,   333,
      -1,   530,    -1,   345,    -1,   369,    -1,   336,    -1,   337,
      -1,   372,    -1,   374,    -1,   383,    -1,   406,    -1,   500,
      -1,   532,    -1,   482,    -1,   348,    -1,   342,    -1,   410,
      -1,   444,    -1,   416,    -1,   437,    -1,   423,    -1,   334,
      -1,   535,    -1,   549,    -1,   439,    -1,   450,    -1,   454,
      -1,   455,    -1,   502,    -1,   347,    -1,   449,    -1,   421,
      -1,   438,    -1,   436,    -1,   517,    -1,   338,    -1,   547,
      -1,   543,    -1,   458,    -1,   462,    -1,   474,    -1,   519,
      -1,   520,    -1,   556,    -1,   518,    -1,   544,    -1,   503,
      -1,   495,    -1,   497,    -1,   494,    -1,   506,    -1,   463,
      -1,   550,    -1,   509,    -1,   521,    -1,   524,    -1,   525,
      -1,   526,    -1,   531,    -1,   536,    -1,   537,    -1,   352,
      -1,   363,    -1,   364,    -1,   365,    -1,   368,    -1,   534,
      -1,    -1,    57,   279,   676,   335,   339,    -1,   293,    -1,
      -1,    11,   279,   676,   335,   339,    -1,    11,   279,   676,
     235,   353,    -1,    11,   279,   676,   364,    -1,    85,   279,
     341,    -1,   339,   340,    -1,    -1,   198,   675,    -1,    89,
     198,   675,    -1,   271,   198,   675,    -1,   252,   674,    -1,
      58,    -1,   171,    -1,    59,    -1,   172,    -1,   121,   113,
     341,    -1,   282,   276,   675,    -1,   341,   328,   676,    -1,
     676,    -1,    57,   113,   676,   335,   343,    -1,   343,   344,
      -1,    -1,   279,   341,    -1,   252,   674,    -1,    11,   113,
     676,   346,   279,   341,    -1,     7,    -1,    85,    -1,    85,
     113,   676,    -1,    57,   226,   349,    21,   676,   350,    -1,
      57,   226,   677,   350,    -1,   677,    -1,    -1,   350,   351,
      -1,    -1,   383,    -1,   462,    -1,   524,    -1,   235,   353,
      -1,   235,   152,   353,    -1,   235,   233,   353,    -1,   677,
     260,   354,    -1,   677,   310,   354,    -1,   258,   298,   360,
      -1,   263,   140,   147,   357,   358,    -1,   233,    40,    16,
     263,   140,   147,   357,    -1,   164,   361,    -1,   233,    21,
     362,    -1,   233,    21,    73,    -1,   355,    -1,    73,    -1,
     356,    -1,   355,   328,   356,    -1,   359,    -1,   362,    -1,
     413,    -1,   210,    51,    -1,   232,    -1,   210,   296,    -1,
     210,   187,    -1,    -1,   267,    -1,    99,    -1,   186,    -1,
     182,    -1,   675,    -1,   300,    -1,   621,   675,   623,    -1,
     621,   323,   674,   324,   675,   623,    -1,   413,    -1,    73,
      -1,   152,    -1,   675,    -1,    73,    -1,    -1,   677,    -1,
     302,    -1,   238,   677,    -1,   238,   258,   298,    -1,   238,
     263,   140,   147,    -1,   238,   233,    21,    -1,   238,    10,
      -1,   218,   677,    -1,   218,   258,   298,    -1,   218,   263,
     140,   147,    -1,   218,   233,    21,    -1,   218,    10,    -1,
     235,    53,   366,   367,    -1,    10,    -1,   665,    -1,    75,
      -1,   118,    -1,    42,    -1,    11,   253,   594,     7,   508,
     388,    -1,    11,   253,   594,    11,   508,   677,   370,    -1,
      11,   253,   594,    11,   508,   677,    85,   174,   178,    -1,
      11,   253,   594,    11,   508,   677,   235,   174,   178,    -1,
      11,   253,   594,    11,   508,   677,   235,   246,   415,    -1,
      11,   253,   594,    11,   508,   677,   235,   249,   677,    -1,
      11,   253,   594,    85,   508,   677,   371,    -1,    11,   253,
     594,     7,   394,    -1,    11,   253,   594,    85,    52,   666,
     371,    -1,    11,   253,   664,    57,   261,   253,    -1,    11,
     253,   664,   196,   260,   676,    -1,   235,    73,   632,    -1,
      85,    73,    -1,    34,    -1,   219,    -1,    -1,    44,   373,
      -1,   677,    -1,    -1,    56,   379,   664,   396,   380,   375,
     376,   381,   335,   377,    -1,   107,    -1,   260,    -1,   675,
      -1,   247,    -1,   248,    -1,   377,   378,    -1,    -1,    27,
      -1,   184,    -1,    78,   533,   675,    -1,   178,   533,   675,
      -1,    27,    -1,    -1,   293,   184,    -1,    -1,   382,    79,
     675,    -1,    -1,   280,    -1,    -1,    57,   384,   253,   664,
     323,   385,   324,   404,   405,    -1,    57,   384,   253,   664,
     181,   664,   323,   385,   324,   405,    -1,   256,    -1,   254,
      -1,   152,   256,    -1,   152,   254,    -1,   111,   256,    -1,
     111,   254,    -1,    -1,   386,    -1,    -1,   387,    -1,   386,
     328,   387,    -1,   388,    -1,   393,    -1,   394,    -1,   677,
     599,   389,   619,    -1,   389,   390,    -1,    -1,    52,   666,
     391,    -1,   391,    -1,   392,    -1,   174,   178,    -1,   178,
      -1,   273,    -1,   205,   142,    -1,    41,   323,   632,   324,
      -1,    73,   633,    -1,   213,   664,   396,   399,   400,    -1,
      74,    -1,   174,    74,    -1,   125,    75,    -1,   125,   118,
      -1,   148,   453,    -1,    52,   666,   395,    -1,   395,    -1,
      41,   323,   632,   324,    -1,   273,   323,   397,   324,    -1,
     205,   142,   323,   397,   324,    -1,   104,   142,   323,   397,
     324,   213,   664,   396,   399,   400,   433,    -1,   323,   397,
     324,    -1,    -1,   398,    -1,   397,   328,   398,    -1,   677,
      -1,   157,   108,    -1,   157,   197,    -1,   157,   240,    -1,
      -1,   401,    -1,   402,    -1,   401,   402,    -1,   402,   401,
      -1,    -1,   186,   277,   403,    -1,   186,    77,   403,    -1,
     170,     6,    -1,   219,    -1,    34,    -1,   235,   178,    -1,
     235,    73,    -1,   124,   323,   663,   324,    -1,    -1,   293,
     184,    -1,   294,   184,    -1,    -1,    57,   384,   253,   664,
     407,    16,   562,    -1,   323,   408,   324,    -1,    -1,   409,
      -1,   408,   328,   409,    -1,   677,    -1,    57,   384,   231,
     664,   411,    -1,   411,   412,    -1,    -1,    32,   413,    -1,
      66,    -1,   122,   413,    -1,   158,   413,    -1,   160,   413,
      -1,   244,   413,    -1,   414,    -1,   415,    -1,   301,    -1,
     315,   301,    -1,   674,    -1,   315,   674,    -1,    57,   417,
     422,   144,   362,   114,   418,   420,   419,    -1,   269,    -1,
      -1,   666,    -1,   654,    -1,   143,   675,    -1,    -1,   283,
     418,    -1,    -1,    85,   422,   144,   362,   371,    -1,   208,
      -1,    -1,    57,   265,   666,   424,   425,   186,   664,   427,
      94,   209,   672,   323,   430,   324,    -1,    57,    52,   265,
     666,     8,   425,   186,   664,   432,   433,   102,    86,   224,
      94,   209,   672,   323,   430,   324,    -1,    23,    -1,     8,
      -1,   426,    -1,   426,   190,   426,    -1,   426,   190,   426,
     190,   426,    -1,   130,    -1,    77,    -1,   277,    -1,   102,
     428,   429,    -1,    86,    -1,    -1,   224,    -1,   245,    -1,
     431,    -1,   430,   328,   431,    -1,    -1,   307,    -1,   301,
      -1,   675,    -1,   304,    -1,   305,    -1,   677,    -1,   107,
     664,    -1,    -1,   434,    -1,   434,   435,    -1,   435,    -1,
     435,   434,    -1,    -1,   174,    74,    -1,    74,    -1,   125,
     118,    -1,   125,    75,    -1,    85,   265,   666,   186,   664,
     371,    -1,    57,    18,   666,    41,   323,   632,   324,   433,
      -1,    85,    18,   666,   371,    -1,    57,     9,   672,   440,
      -1,    57,   188,   499,   440,    -1,    57,   270,   453,   440,
      -1,    57,   270,   453,    16,   323,   597,   324,    -1,    57,
      39,   235,   533,   453,   110,   440,   619,    -1,   323,   441,
     324,    -1,   442,    -1,   441,   328,   442,    -1,   680,   310,
     443,    -1,   680,    -1,   488,    -1,   631,    -1,   413,    -1,
     675,    -1,    57,   188,    43,   453,   447,   102,   270,   599,
     280,   668,    16,   445,    -1,   446,    -1,   445,   328,   446,
      -1,   188,   674,   499,   448,    -1,   188,   674,   499,   323,
     498,   324,   448,    -1,   109,   674,   672,   484,    -1,   249,
     599,    -1,    73,    -1,    -1,   212,    -1,    -1,    85,   188,
      43,   453,   280,   668,   371,    -1,    85,   451,   452,   371,
      -1,   253,    -1,   231,    -1,   289,    -1,   123,    -1,   270,
      -1,    83,    -1,    54,    -1,   226,    -1,   453,    -1,   452,
     328,   453,    -1,   677,    -1,   654,    -1,   268,   569,   664,
      -1,    49,   186,   456,   453,   138,   457,    -1,    49,   186,
       9,   672,   323,   496,   324,   138,   457,    -1,    49,   186,
     109,   672,   484,   138,   457,    -1,    49,   186,   188,   499,
     323,   498,   324,   138,   457,    -1,    49,   186,    52,   666,
     186,   453,   138,   457,    -1,    49,   186,   225,   666,   186,
     453,   138,   457,    -1,    49,   186,   225,   666,   138,   457,
      -1,    49,   186,   265,   666,   186,   453,   138,   457,    -1,
      48,    -1,    67,    -1,   226,    -1,   123,    -1,   231,    -1,
     253,    -1,    83,    -1,   270,    -1,   289,    -1,   675,    -1,
     178,    -1,   100,   459,   460,   461,   666,    -1,   100,   460,
     461,   666,    -1,   100,   459,   461,   666,    -1,   100,   461,
     666,    -1,   100,   666,    -1,   163,   459,   460,   461,   666,
      -1,   163,   460,   461,   666,    -1,   163,   459,   461,   666,
      -1,   163,   461,   666,    -1,   163,   666,    -1,   105,    -1,
      22,    -1,   215,    -1,     4,    -1,   674,    -1,   315,   674,
      -1,    10,    -1,   169,    -1,   206,    -1,   121,    -1,   107,
      -1,   112,   464,   186,   467,   260,   468,   470,    -1,   221,
     471,   464,   186,   467,   107,   468,    -1,   465,    -1,    10,
      -1,    10,   207,    -1,   466,    -1,   465,   328,   466,    -1,
     230,    -1,   130,    -1,   277,    -1,    77,    -1,   225,    -1,
     213,    -1,   265,    -1,    94,    -1,   278,    -1,    57,    -1,
     256,    -1,   254,    -1,   663,    -1,   253,   663,    -1,   109,
     472,    -1,    67,   665,    -1,   144,   665,    -1,   226,   665,
      -1,   469,    -1,   468,   328,   469,    -1,   677,    -1,   113,
     677,    -1,   293,   112,   189,    -1,    -1,   112,   189,   102,
      -1,    -1,   473,    -1,   472,   328,   473,    -1,   672,   484,
      -1,    57,   475,   123,   670,   186,   664,   476,   323,   477,
     324,   596,    -1,   273,    -1,    -1,   280,   668,    -1,    -1,
     478,    -1,   479,    -1,   480,    -1,   478,   328,   480,    -1,
     672,   323,   665,   324,   481,    -1,   669,   481,    -1,   453,
      -1,   280,   453,    -1,    -1,    57,   483,   109,   672,   484,
     220,   488,   490,   493,    -1,   190,   217,    -1,    -1,   323,
     485,   324,    -1,   323,   324,    -1,   486,    -1,   485,   328,
     486,    -1,   487,   489,    -1,   489,    -1,   121,    -1,   192,
      -1,   127,    -1,   489,    -1,   599,    -1,   678,   655,   318,
     270,    -1,   491,    -1,   490,   491,    -1,    16,   492,    -1,
     144,   362,    -1,   119,    -1,   243,    -1,   290,    -1,    33,
     186,   178,   128,    -1,   220,   178,   186,   178,   128,    -1,
     250,    -1,    97,   229,    76,    -1,    97,   229,   137,    -1,
     229,    76,    -1,   229,   137,    -1,   675,    -1,   675,   328,
     675,    -1,   293,   440,    -1,    -1,    85,   109,   672,   484,
     371,    -1,    85,     9,   672,   323,   496,   324,   371,    -1,
     599,    -1,   316,    -1,    85,   188,   499,   323,   498,   324,
     371,    -1,   599,    -1,   599,   328,   599,    -1,   173,   328,
     599,    -1,   599,   328,   173,    -1,   628,    -1,   677,   326,
     499,    -1,    57,    36,   323,   599,    16,   599,   324,   293,
     109,   473,   501,    -1,    57,    36,   323,   599,    16,   599,
     324,   294,   109,   501,    -1,    16,   120,    -1,    16,    19,
      -1,    -1,    85,    36,   323,   599,    16,   599,   324,   371,
      -1,   214,   504,   664,   505,    -1,   214,    67,   666,   505,
      -1,   123,    -1,   253,    -1,   103,    -1,    -1,    11,   253,
     594,   216,   508,   507,   260,   666,    -1,    11,   265,   666,
     186,   594,   216,   260,   666,    -1,   666,    -1,    -1,    48,
      -1,    -1,    -1,    57,   483,   225,   666,    16,   510,   186,
     515,   260,   664,   596,    82,   516,   511,    -1,   175,    -1,
     513,    -1,   323,   512,   324,    -1,   512,   327,   514,    -1,
     514,    -1,   562,    -1,   551,    -1,   559,    -1,   555,    -1,
     518,    -1,   513,    -1,    -1,   230,    -1,   277,    -1,    77,
      -1,   130,    -1,   131,    -1,    -1,    85,   225,   666,   186,
     664,   371,    -1,   176,   664,    -1,   150,   664,    -1,   275,
     664,    -1,   275,   316,    -1,     3,   523,    -1,    24,   523,
      -1,   244,   263,   522,    -1,    50,   523,    -1,    90,   523,
      -1,   223,   523,    -1,   140,   147,   357,    -1,    -1,   295,
      -1,   263,    -1,    -1,    57,   483,   289,   664,   396,    16,
     562,    -1,   151,   671,    -1,    57,    67,   667,   335,   527,
      -1,   527,   528,    -1,    -1,   155,   529,   675,    -1,   155,
     529,    73,    -1,   255,   529,   666,    -1,   255,   529,    73,
      -1,    88,   529,   675,    -1,    88,   529,   674,    -1,    88,
     529,    73,    -1,   196,   529,   666,    -1,   196,   529,    73,
      -1,   310,    -1,    -1,    11,    67,   667,   235,   353,    -1,
      11,    67,   667,   364,    -1,    85,    67,   667,    -1,    57,
      83,   453,   533,   599,   389,   619,    -1,    16,    -1,    -1,
      57,   447,    54,   453,   102,   675,   260,   675,   107,   453,
      -1,    45,   670,   186,   664,    -1,   281,   540,   541,   539,
      -1,   281,   540,   541,   539,   664,    -1,   281,   540,   541,
     539,   537,    -1,   538,   539,    -1,   538,   539,   664,   542,
      -1,    13,    -1,    12,    -1,   287,    -1,    -1,   108,    -1,
      -1,   106,    -1,    -1,   323,   665,   324,    -1,    -1,    96,
     539,   550,    -1,    96,   538,   539,   550,    -1,   204,   666,
     545,    16,   550,    -1,   323,   546,   324,    -1,    -1,   599,
      -1,   546,   328,   599,    -1,    94,   666,   548,   567,    -1,
     323,   636,   324,    -1,    -1,    69,   666,    -1,    69,   204,
     666,    -1,   562,    -1,   560,    -1,   559,    -1,   551,    -1,
     555,    -1,   130,   136,   664,   552,    -1,   284,   323,   660,
     324,    -1,    73,   284,    -1,   562,    -1,   323,   553,   324,
     284,   323,   660,   324,    -1,   323,   553,   324,   562,    -1,
     554,    -1,   553,   328,   554,    -1,   677,   635,    -1,    77,
     107,   594,   596,    -1,   156,   569,   663,   557,    -1,   121,
     558,   161,    -1,    -1,     5,   237,    -1,   224,   237,    -1,
     224,    93,    -1,   237,   277,    93,    -1,   237,    -1,   237,
     224,    93,    -1,    93,    -1,     5,    93,    -1,   277,   594,
     235,   658,   586,   596,    -1,    72,   666,   561,    65,   102,
     562,    -1,    27,    -1,   129,    -1,   227,    -1,   129,   227,
      -1,    -1,   564,    -1,   563,    -1,   323,   564,   324,    -1,
     323,   563,   324,    -1,   566,    -1,   565,   573,    -1,   565,
     572,   583,   578,    -1,   565,   572,   577,   584,    -1,   566,
      -1,   563,    -1,   230,   571,   656,   567,   586,   596,   581,
     582,    -1,   565,   272,   570,   565,    -1,   565,   134,   570,
     565,    -1,   565,    92,   570,   565,    -1,   136,   568,    -1,
      -1,   256,   569,   664,    -1,   254,   569,   664,    -1,   152,
     256,   569,   664,    -1,   152,   254,   569,   664,    -1,   111,
     256,   569,   664,    -1,   111,   254,   569,   664,    -1,   253,
     664,    -1,   664,    -1,   253,    -1,    -1,    10,    -1,    81,
      -1,    -1,    81,    -1,    81,   186,   323,   636,   324,    -1,
      10,    -1,    -1,   573,    -1,    -1,   191,    31,   574,    -1,
     575,    -1,   574,   328,   575,    -1,   632,   576,    -1,   280,
     631,    -1,    17,    -1,    80,    -1,    -1,   149,   579,   183,
     580,    -1,   183,   580,   149,   579,    -1,   149,   579,    -1,
     183,   580,    -1,   149,   579,   328,   580,    -1,   577,    -1,
      -1,   674,    -1,    10,    -1,   308,    -1,   674,    -1,   308,
      -1,   113,    31,   636,    -1,    -1,   115,   632,    -1,    -1,
     102,   277,   585,    -1,   102,   210,   187,    -1,   583,    -1,
      -1,   181,   665,    -1,    -1,   107,   587,    -1,    -1,   588,
      -1,   587,   328,   588,    -1,   594,    -1,   594,   590,    -1,
     595,    -1,   595,   590,    -1,   595,    16,   323,   597,   324,
      -1,   595,    16,   677,   323,   597,   324,    -1,   595,   677,
     323,   597,   324,    -1,   563,    -1,   563,   590,    -1,   589,
      -1,   323,   589,   324,   590,    -1,   323,   589,   324,    -1,
     588,    60,   141,   588,    -1,   588,   299,   588,    -1,   588,
     591,   141,   588,   593,    -1,   588,   141,   588,   593,    -1,
     588,   166,   591,   141,   588,    -1,   588,   166,   141,   588,
      -1,    16,   677,   323,   665,   324,    -1,    16,   677,    -1,
     677,   323,   665,   324,    -1,   677,    -1,   108,   592,    -1,
     146,   592,    -1,   222,   592,    -1,   126,    -1,   193,    -1,
      -1,   280,   323,   665,   324,    -1,   186,   632,    -1,   664,
      -1,   664,   316,    -1,   187,   664,    -1,   187,   323,   664,
     324,    -1,   672,   323,   324,    -1,   672,   323,   636,   324,
      -1,   292,   632,    -1,    -1,   598,    -1,   597,   328,   598,
      -1,   677,   599,    -1,   601,   600,    -1,   236,   601,   600,
      -1,   600,   321,   322,    -1,   600,   321,   674,   322,    -1,
      -1,   603,    -1,   604,    -1,   608,    -1,   612,    -1,   620,
      -1,   621,   623,    -1,   621,   323,   674,   324,   623,    -1,
     678,   655,    -1,   603,    -1,   604,    -1,   609,    -1,   613,
      -1,   620,    -1,   678,    -1,   132,    -1,   133,    -1,   241,
      -1,    26,    -1,   211,    -1,   101,   605,    -1,    84,   203,
      -1,    71,   607,    -1,    70,   607,    -1,   180,   606,    -1,
      29,    -1,   323,   674,   324,    -1,    -1,   323,   674,   328,
     674,   324,    -1,   323,   674,   324,    -1,    -1,   323,   674,
     328,   674,   324,    -1,   323,   674,   324,    -1,    -1,   610,
      -1,   611,    -1,   610,    -1,   611,    -1,    28,   617,   323,
     674,   324,    -1,    28,   617,    -1,   614,    -1,   615,    -1,
     614,    -1,   615,    -1,   616,   323,   674,   324,   618,    -1,
     616,   618,    -1,    39,   617,    -1,    38,   617,    -1,   285,
      -1,   165,    39,   617,    -1,   165,    38,   617,    -1,   167,
     617,    -1,   286,    -1,    -1,    39,   235,   677,    -1,    -1,
      47,   677,    -1,    -1,   259,   323,   674,   324,   622,    -1,
     259,   622,    -1,   258,   323,   674,   324,   622,    -1,   258,
     622,    -1,   135,    -1,   293,   258,   298,    -1,   294,   258,
     298,    -1,    -1,   297,    -1,   162,    -1,    68,    -1,   116,
      -1,   159,    -1,   228,    -1,   297,   260,   162,    -1,    68,
     260,   116,    -1,    68,   260,   159,    -1,    68,   260,   228,
      -1,   116,   260,   159,    -1,   116,   260,   228,    -1,   159,
     260,   228,    -1,    -1,   625,   121,   563,    -1,   625,   174,
     121,   563,    -1,   625,   631,   627,   563,    -1,   625,   631,
     563,    -1,   625,   631,   625,    -1,   625,   138,   178,    -1,
     625,   138,   174,   178,    -1,   625,   194,   625,    -1,   625,
     138,    81,   107,   625,    -1,   224,   323,   626,   324,    -1,
     224,   323,   632,   324,    -1,   224,   323,   324,    -1,   323,
     626,   324,    -1,   636,   328,   632,    -1,    15,    -1,   242,
      -1,    10,    -1,   306,    -1,   629,    -1,   314,    -1,   315,
      -1,   316,    -1,   317,    -1,   318,    -1,   319,    -1,   311,
      -1,   312,    -1,   310,    -1,   306,    -1,   188,   323,   499,
     324,    -1,   628,    -1,   188,   323,   499,   324,    -1,   634,
      -1,   632,   325,   599,    -1,   632,    47,   677,    -1,   632,
      20,   258,   298,   634,    -1,   314,   632,    -1,   315,   632,
      -1,   318,   632,    -1,   319,   632,    -1,   632,   318,    -1,
     632,   319,    -1,   632,   314,   632,    -1,   632,   315,   632,
      -1,   632,   316,   632,    -1,   632,   317,   632,    -1,   632,
     318,   632,    -1,   632,   319,   632,    -1,   632,   311,   632,
      -1,   632,   312,   632,    -1,   632,   310,   632,    -1,   632,
     630,   632,    -1,   630,   632,    -1,   632,   630,    -1,   632,
      14,   632,    -1,   632,   190,   632,    -1,   174,   632,    -1,
     632,   148,   632,    -1,   632,   148,   632,    91,   632,    -1,
     632,   174,   148,   632,    -1,   632,   174,   148,   632,    91,
     632,    -1,   632,   117,   632,    -1,   632,   117,   632,    91,
     632,    -1,   632,   174,   117,   632,    -1,   632,   174,   117,
     632,    91,   632,    -1,   632,   239,   260,   632,    -1,   632,
     239,   260,   632,    91,   632,    -1,   632,   174,   239,   260,
     632,    -1,   632,   174,   239,   260,   632,    91,   632,    -1,
     632,   139,    -1,   632,   138,   178,    -1,   632,   177,    -1,
     632,   138,   174,   178,    -1,   632,   138,   267,    -1,   632,
     138,   174,   267,    -1,   632,   138,    99,    -1,   632,   138,
     174,    99,    -1,   632,   138,   274,    -1,   632,   138,   174,
     274,    -1,   632,   138,    81,   107,   632,    -1,   632,   138,
     181,   323,   638,   324,    -1,   632,   138,   174,   181,   323,
     638,   324,    -1,   632,    25,   633,    14,   633,    -1,   632,
     174,    25,   633,    14,   633,    -1,   632,   121,   647,    -1,
     632,   174,   121,   647,    -1,   632,   631,   627,   563,    -1,
     273,   563,    -1,   624,    -1,   634,    -1,   633,   325,   599,
      -1,   314,   633,    -1,   315,   633,    -1,   318,   633,    -1,
     319,   633,    -1,   633,   318,    -1,   633,   319,    -1,   633,
     314,   633,    -1,   633,   315,   633,    -1,   633,   316,   633,
      -1,   633,   317,   633,    -1,   633,   318,   633,    -1,   633,
     319,   633,    -1,   633,   311,   633,    -1,   633,   312,   633,
      -1,   633,   310,   633,    -1,   633,   630,   633,    -1,   630,
     633,    -1,   633,   630,    -1,   633,   138,    81,   107,   633,
      -1,   633,   138,   181,   323,   638,   324,    -1,   633,   138,
     174,   181,   323,   638,   324,    -1,   653,    -1,   673,    -1,
     308,   655,   635,    -1,   323,   632,   324,    -1,   323,   632,
     324,   655,   635,    -1,   648,    -1,   672,   323,   324,    -1,
     672,   323,   636,   324,    -1,   672,   323,    10,   636,   324,
      -1,   672,   323,    81,   636,   324,    -1,   672,   323,   316,
     324,    -1,    61,    -1,    62,    -1,    62,   323,   674,   324,
      -1,    63,    -1,    63,   323,   674,   324,    -1,   153,    -1,
     153,   323,   674,   324,    -1,   154,    -1,   154,   323,   674,
     324,    -1,    64,    -1,   234,    -1,   279,    -1,    36,   323,
     632,    16,   599,   324,    -1,    98,   323,   637,   324,    -1,
     195,   323,   640,   324,    -1,   202,   323,   642,   324,    -1,
     251,   323,   643,   324,    -1,   264,   323,   632,    16,   599,
     324,    -1,   266,   323,    30,   646,   324,    -1,   266,   323,
     145,   646,   324,    -1,   266,   323,   262,   646,   324,    -1,
     266,   323,   646,   324,    -1,    55,   323,   632,   280,   453,
     324,    -1,    55,   323,   636,   324,    -1,   563,    -1,    95,
     563,    -1,   635,   321,   632,   322,    -1,   635,   321,   632,
     329,   632,   322,    -1,    -1,   632,    -1,   636,   328,   632,
      -1,   639,   107,   632,    -1,    -1,   638,   328,   599,    -1,
     599,    -1,   300,    -1,   297,    -1,   162,    -1,    68,    -1,
     116,    -1,   159,    -1,   228,    -1,   302,    -1,   632,   641,
     644,   645,    -1,   632,   641,   644,    -1,   201,   632,    -1,
     633,   121,   633,    -1,    -1,   632,   644,   645,    -1,   632,
     645,   644,    -1,   632,   644,    -1,   632,   645,    -1,   636,
      -1,    -1,   107,   632,    -1,   102,   632,    -1,   632,   107,
     636,    -1,   107,   636,    -1,   636,    -1,   563,    -1,   323,
     636,   324,    -1,    35,   652,   649,   651,    90,    -1,   179,
     323,   632,   328,   632,   324,    -1,    46,   323,   636,   324,
      -1,   650,    -1,   649,   650,    -1,   291,   632,   257,   632,
      -1,    87,   632,    -1,    -1,   632,    -1,    -1,   662,   635,
      -1,   654,   635,    -1,   662,   655,    -1,   326,   669,    -1,
     326,   316,    -1,   326,   669,   655,    -1,   657,    -1,   656,
     328,   657,    -1,   632,    16,   680,    -1,   632,    -1,   316,
      -1,   659,    -1,   658,   328,   659,    -1,   677,   635,   310,
     632,    -1,   661,    -1,   660,   328,   661,    -1,   657,    -1,
      73,    -1,   685,    -1,   677,    -1,   664,    -1,   663,   328,
     664,    -1,   662,    -1,   654,    -1,   666,    -1,   665,   328,
     666,    -1,   677,    -1,   677,    -1,   677,    -1,   677,    -1,
     677,    -1,   675,    -1,   679,    -1,   654,    -1,   674,    -1,
     301,    -1,   675,    -1,   304,    -1,   305,    -1,   602,   675,
      -1,   621,   675,   623,    -1,   621,   323,   674,   324,   675,
     623,    -1,   308,   635,    -1,   267,    -1,    99,    -1,   178,
      -1,   307,    -1,   302,    -1,   677,    -1,   300,    -1,   681,
      -1,   682,    -1,   300,    -1,   681,    -1,   300,    -1,   681,
      -1,   683,    -1,   300,    -1,   681,    -1,   682,    -1,   683,
      -1,   684,    -1,     3,    -1,     4,    -1,     5,    -1,     6,
      -1,     7,    -1,     8,    -1,     9,    -1,    11,    -1,    18,
      -1,    19,    -1,    20,    -1,    22,    -1,    23,    -1,    24,
      -1,    31,    -1,    32,    -1,    33,    -1,    34,    -1,    37,
      -1,    40,    -1,    42,    -1,    43,    -1,    44,    -1,    45,
      -1,    49,    -1,    50,    -1,    51,    -1,    53,    -1,    54,
      -1,    56,    -1,    58,    -1,    59,    -1,    65,    -1,    66,
      -1,    67,    -1,    68,    -1,    69,    -1,    72,    -1,    75,
      -1,    76,    -1,    77,    -1,    78,    -1,    79,    -1,    83,
      -1,    84,    -1,    85,    -1,    86,    -1,    88,    -1,    89,
      -1,    91,    -1,    93,    -1,    94,    -1,    96,    -1,    97,
      -1,   100,    -1,   103,    -1,   105,    -1,   109,    -1,   110,
      -1,   111,    -1,   114,    -1,   116,    -1,   118,    -1,   119,
      -1,   120,    -1,   122,    -1,   123,    -1,   124,    -1,   127,
      -1,   128,    -1,   129,    -1,   130,    -1,   131,    -1,   137,
      -1,   140,    -1,   142,    -1,   144,    -1,   143,    -1,   147,
      -1,   150,    -1,   151,    -1,   152,    -1,   155,    -1,   156,
      -1,   157,    -1,   158,    -1,   159,    -1,   160,    -1,   161,
      -1,   162,    -1,   163,    -1,   164,    -1,   165,    -1,   169,
      -1,   170,    -1,   171,    -1,   172,    -1,   175,    -1,   176,
      -1,   181,    -1,   184,    -1,   188,    -1,   189,    -1,   192,
      -1,   196,    -1,   197,    -1,   198,    -1,   199,    -1,   200,
      -1,   203,    -1,   204,    -1,   206,    -1,   207,    -1,   208,
      -1,   209,    -1,   210,    -1,   212,    -1,   214,    -1,   215,
      -1,   216,    -1,   217,    -1,   218,    -1,   219,    -1,   220,
      -1,   221,    -1,   223,    -1,   225,    -1,   226,    -1,   227,
      -1,   228,    -1,   229,    -1,   233,    -1,   231,    -1,   232,
      -1,   235,    -1,   237,    -1,   238,    -1,   240,    -1,   243,
      -1,   244,    -1,   245,    -1,   246,    -1,   247,    -1,   248,
      -1,   249,    -1,   250,    -1,   252,    -1,   254,    -1,   255,
      -1,   256,    -1,   261,    -1,   263,    -1,   265,    -1,   268,
      -1,   269,    -1,   270,    -1,   271,    -1,   274,    -1,   275,
      -1,   276,    -1,   277,    -1,   278,    -1,   281,    -1,   282,
      -1,   283,    -1,   284,    -1,   286,    -1,   288,    -1,   289,
      -1,   290,    -1,   293,    -1,   294,    -1,   296,    -1,   295,
      -1,   297,    -1,   298,    -1,    26,    -1,    28,    -1,    29,
      -1,    38,    -1,    39,    -1,    46,    -1,    55,    -1,    70,
      -1,    71,    -1,    95,    -1,    98,    -1,   101,    -1,   132,
      -1,   133,    -1,   135,    -1,   167,    -1,   173,    -1,   179,
      -1,   180,    -1,   195,    -1,   202,    -1,   211,    -1,   224,
      -1,   236,    -1,   241,    -1,   251,    -1,   258,    -1,   259,
      -1,   264,    -1,   266,    -1,   285,    -1,    21,    -1,    25,
      -1,    27,    -1,    60,    -1,   106,    -1,   108,    -1,   117,
      -1,   121,    -1,   126,    -1,   138,    -1,   139,    -1,   141,
      -1,   146,    -1,   148,    -1,   166,    -1,   177,    -1,   193,
      -1,   194,    -1,   222,    -1,   239,    -1,   287,    -1,    10,
      -1,    12,    -1,    13,    -1,    14,    -1,    15,    -1,    16,
      -1,    17,    -1,    30,    -1,    35,    -1,    36,    -1,    41,
      -1,    47,    -1,    48,    -1,    52,    -1,    57,    -1,    61,
      -1,    62,    -1,    63,    -1,    64,    -1,    73,    -1,    74,
      -1,    80,    -1,    81,    -1,    82,    -1,    87,    -1,    90,
      -1,    92,    -1,    99,    -1,   102,    -1,   104,    -1,   107,
      -1,   112,    -1,   113,    -1,   115,    -1,   125,    -1,   134,
      -1,   136,    -1,   145,    -1,   149,    -1,   153,    -1,   154,
      -1,   168,    -1,   174,    -1,   178,    -1,   182,    -1,   183,
      -1,   185,    -1,   186,    -1,   187,    -1,   190,    -1,   191,
      -1,   201,    -1,   205,    -1,   213,    -1,   230,    -1,   234,
      -1,   242,    -1,   253,    -1,   257,    -1,   260,    -1,   262,
      -1,   267,    -1,   272,    -1,   273,    -1,   279,    -1,   280,
      -1,   291,    -1,   292,    -1,   185,    -1,   168,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   458,   458,   462,   468,   477,   478,   479,   480,   481,
     482,   483,   484,   485,   486,   487,   488,   489,   490,   491,
     492,   493,   494,   495,   496,   497,   498,   499,   500,   501,
     502,   503,   504,   505,   506,   507,   508,   509,   510,   511,
     512,   513,   514,   515,   516,   517,   518,   519,   520,   521,
     522,   523,   524,   525,   526,   527,   528,   529,   530,   531,
     532,   533,   534,   535,   536,   537,   538,   539,   540,   541,
     543,   554,   564,   565,   576,   587,   595,   616,   628,   629,
     633,   637,   641,   645,   649,   653,   657,   661,   665,   669,
     675,   676,   689,   702,   703,   707,   711,   726,   736,   737,
     749,   765,   777,   789,   790,   794,   795,   803,   804,   805,
     819,   825,   831,   839,   846,   853,   861,   868,   875,   883,
     890,   900,   901,   904,   905,   908,   910,   912,   916,   917,
     920,   922,   927,   931,   932,   933,   934,   946,   950,   954,
     967,   992,   993,   994,   998,   999,  1000,  1004,  1005,  1010,
    1016,  1022,  1028,  1034,  1043,  1049,  1055,  1061,  1067,  1077,
    1087,  1088,  1092,  1093,  1101,  1117,  1126,  1136,  1145,  1154,
    1164,  1175,  1185,  1194,  1204,  1213,  1225,  1233,  1237,  1238,
    1239,  1252,  1260,  1261,  1275,  1299,  1300,  1309,  1310,  1311,
    1317,  1318,  1323,  1327,  1331,  1335,  1344,  1348,  1352,  1356,
    1361,  1365,  1369,  1370,  1381,  1393,  1417,  1418,  1419,  1420,
    1421,  1422,  1423,  1427,  1428,  1432,  1436,  1443,  1444,  1445,
    1448,  1466,  1467,  1471,  1492,  1493,  1512,  1522,  1532,  1542,
    1552,  1562,  1580,  1608,  1614,  1620,  1626,  1640,  1653,  1674,
    1678,  1687,  1697,  1707,  1725,  1726,  1730,  1731,  1734,  1740,
    1744,  1749,  1754,  1766,  1768,  1770,  1772,  1775,  1778,  1781,
    1785,  1786,  1787,  1788,  1789,  1792,  1793,  1797,  1798,  1799,
    1809,  1829,  1830,  1834,  1835,  1839,  1864,  1874,  1875,  1878,
    1882,  1886,  1890,  1894,  1898,  1905,  1906,  1909,  1910,  1918,
    1922,  1938,  1951,  1952,  1960,  1962,  1966,  1967,  1971,  1972,
    1976,  1986,  1987,  1999,  2022,  2051,  2052,  2056,  2061,  2066,
    2075,  2076,  2077,  2081,  2088,  2089,  2093,  2094,  2098,  2099,
    2100,  2104,  2110,  2111,  2112,  2113,  2114,  2118,  2119,  2123,
    2125,  2132,  2139,  2147,  2151,  2152,  2156,  2157,  2162,  2183,
    2200,  2221,  2229,  2237,  2245,  2278,  2288,  2291,  2292,  2295,
    2299,  2306,  2307,  2308,  2309,  2322,  2336,  2337,  2341,  2351,
    2361,  2370,  2379,  2380,  2383,  2384,  2389,  2408,  2418,  2419,
    2420,  2421,  2422,  2423,  2424,  2425,  2429,  2430,  2433,  2434,
    2445,  2467,  2476,  2486,  2495,  2505,  2514,  2523,  2533,  2545,
    2546,  2547,  2548,  2549,  2550,  2551,  2552,  2553,  2557,  2558,
    2570,  2591,  2608,  2621,  2630,  2639,  2653,  2670,  2679,  2688,
    2699,  2700,  2701,  2702,  2711,  2712,  2714,  2715,  2716,  2719,
    2720,  2730,  2743,  2758,  2759,  2760,  2764,  2765,  2771,  2772,
    2773,  2774,  2775,  2776,  2777,  2778,  2779,  2780,  2781,  2782,
    2789,  2796,  2803,  2810,  2817,  2824,  2835,  2836,  2839,  2850,
    2865,  2869,  2873,  2877,  2882,  2883,  2888,  2907,  2922,  2923,
    2927,  2929,  2933,  2934,  2937,  2938,  2941,  2951,  2961,  2992,
    2993,  3008,  3023,  3024,  3027,  3028,  3032,  3033,  3036,  3044,
    3047,  3048,  3054,  3063,  3077,  3078,  3090,  3091,  3095,  3099,
    3103,  3107,  3111,  3115,  3119,  3123,  3127,  3131,  3135,  3139,
    3145,  3146,  3153,  3154,  3169,  3180,  3191,  3192,  3196,  3207,
    3211,  3213,  3215,  3220,  3222,  3233,  3243,  3255,  3256,  3257,
    3261,  3282,  3291,  3303,  3304,  3307,  3308,  3320,  3332,  3343,
    3344,  3347,  3348,  3359,  3358,  3377,  3378,  3379,  3384,  3390,
    3399,  3400,  3401,  3402,  3403,  3407,  3408,  3412,  3413,  3414,
    3415,  3419,  3420,  3425,  3445,  3453,  3462,  3468,  3489,  3496,
    3503,  3510,  3517,  3524,  3533,  3535,  3538,  3539,  3540,  3550,
    3570,  3586,  3596,  3597,  3601,  3605,  3609,  3613,  3617,  3621,
    3625,  3629,  3633,  3644,  3645,  3656,  3664,  3682,  3698,  3712,
    3713,  3727,  3748,  3765,  3777,  3789,  3801,  3813,  3828,  3829,
    3833,  3834,  3837,  3838,  3841,  3842,  3846,  3847,  3860,  3868,
    3885,  3895,  3896,  3899,  3900,  3911,  3921,  3922,  3932,  3938,
    3958,  3959,  3960,  3961,  3962,  3974,  3982,  3989,  3996,  4003,
    4010,  4020,  4021,  4026,  4044,  4053,  4063,  4064,  4067,  4068,
    4069,  4070,  4071,  4072,  4073,  4074,  4085,  4106,  4115,  4116,
    4117,  4118,  4119,  4167,  4168,  4172,  4173,  4183,  4184,  4190,
    4196,  4205,  4206,  4233,  4248,  4252,  4256,  4263,  4264,  4272,
    4277,  4282,  4287,  4292,  4297,  4302,  4307,  4314,  4315,  4318,
    4319,  4320,  4327,  4328,  4329,  4330,  4334,  4335,  4339,  4343,
    4344,  4347,  4355,  4356,  4358,  4361,  4366,  4368,  4370,  4372,
    4374,  4382,  4384,  4388,  4404,  4418,  4430,  4446,  4466,  4467,
    4471,  4472,  4476,  4477,  4481,  4482,  4486,  4487,  4499,  4500,
    4504,  4505,  4515,  4519,  4524,  4531,  4539,  4546,  4556,  4566,
    4583,  4590,  4594,  4620,  4624,  4636,  4650,  4663,  4677,  4688,
    4703,  4709,  4714,  4720,  4727,  4728,  4729,  4730,  4734,  4735,
    4747,  4748,  4753,  4760,  4767,  4774,  4784,  4793,  4806,  4807,
    4812,  4816,  4822,  4843,  4848,  4857,  4859,  4862,  4874,  4875,
    4876,  4877,  4878,  4879,  4885,  4901,  4919,  4920,  4921,  4922,
    4923,  4927,  4938,  4942,  4946,  4950,  4954,  4958,  4962,  4966,
    4971,  4976,  4981,  4987,  5001,  5007,  5020,  5030,  5037,  5050,
    5060,  5071,  5075,  5083,  5087,  5095,  5112,  5133,  5137,  5143,
    5147,  5160,  5191,  5214,  5216,  5218,  5220,  5222,  5224,  5229,
    5230,  5234,  5235,  5239,  5240,  5244,  5268,  5287,  5307,  5322,
    5326,  5327,  5328,  5332,  5333,  5334,  5335,  5336,  5337,  5338,
    5340,  5342,  5345,  5348,  5350,  5353,  5355,  5370,  5380,  5390,
    5404,  5418,  5423,  5427,  5431,  5435,  5471,  5472,  5473,  5474,
    5477,  5480,  5481,  5482,  5485,  5486,  5489,  5490,  5491,  5492,
    5493,  5494,  5495,  5496,  5497,  5500,  5502,  5506,  5508,  5527,
    5528,  5530,  5539,  5557,  5559,  5561,  5563,  5565,  5567,  5569,
    5571,  5573,  5575,  5577,  5579,  5581,  5583,  5585,  5588,  5590,
    5592,  5595,  5597,  5599,  5602,  5604,  5613,  5615,  5624,  5626,
    5635,  5637,  5647,  5658,  5667,  5678,  5697,  5704,  5711,  5718,
    5725,  5732,  5739,  5746,  5753,  5760,  5767,  5769,  5773,  5777,
    5783,  5789,  5817,  5845,  5855,  5868,  5881,  5883,  5885,  5887,
    5889,  5891,  5893,  5895,  5897,  5899,  5901,  5903,  5905,  5907,
    5909,  5911,  5913,  5915,  5917,  5919,  5921,  5923,  5927,  5941,
    5942,  5943,  5955,  5956,  5964,  5966,  5975,  5984,  5997,  6006,
    6031,  6057,  6080,  6108,  6131,  6160,  6183,  6211,  6234,  6263,
    6272,  6281,  6290,  6292,  6301,  6315,  6325,  6337,  6353,  6365,
    6374,  6383,  6392,  6406,  6415,  6425,  6442,  6449,  6457,  6460,
    6461,  6465,  6472,  6475,  6479,  6490,  6491,  6492,  6493,  6494,
    6495,  6496,  6497,  6506,  6510,  6517,  6524,  6525,  6540,  6544,
    6548,  6552,  6559,  6564,  6568,  6571,  6574,  6575,  6576,  6579,
    6585,  6603,  6611,  6622,  6642,  6643,  6647,  6657,  6658,  6661,
    6662,  6670,  6676,  6685,  6689,  6691,  6693,  6707,  6708,  6712,
    6719,  6726,  6745,  6746,  6750,  6760,  6761,  6765,  6766,  6784,
    6785,  6789,  6790,  6794,  6801,  6826,  6828,  6833,  6836,  6839,
    6841,  6843,  6845,  6847,  6849,  6856,  6863,  6870,  6877,  6884,
    6896,  6904,  6915,  6936,  6944,  6948,  6952,  6960,  6961,  6962,
    6977,  6978,  6979,  6984,  6985,  6991,  6992,  6993,  6999,  7000,
    7001,  7002,  7003,  7019,  7020,  7021,  7022,  7023,  7024,  7025,
    7026,  7027,  7028,  7029,  7030,  7031,  7032,  7033,  7034,  7035,
    7036,  7037,  7038,  7039,  7040,  7041,  7042,  7043,  7044,  7045,
    7046,  7047,  7048,  7049,  7050,  7051,  7052,  7053,  7054,  7055,
    7056,  7057,  7058,  7059,  7060,  7061,  7062,  7063,  7064,  7065,
    7066,  7067,  7068,  7069,  7070,  7071,  7072,  7073,  7074,  7075,
    7076,  7077,  7078,  7079,  7080,  7081,  7082,  7083,  7084,  7085,
    7086,  7087,  7088,  7089,  7090,  7091,  7092,  7093,  7094,  7095,
    7096,  7097,  7098,  7099,  7100,  7101,  7102,  7103,  7104,  7105,
    7106,  7107,  7108,  7109,  7110,  7111,  7112,  7113,  7114,  7115,
    7116,  7117,  7118,  7119,  7120,  7121,  7122,  7123,  7124,  7125,
    7126,  7127,  7128,  7129,  7130,  7131,  7132,  7133,  7134,  7135,
    7136,  7137,  7138,  7139,  7140,  7141,  7142,  7143,  7144,  7145,
    7146,  7147,  7148,  7149,  7150,  7151,  7152,  7153,  7154,  7155,
    7156,  7157,  7158,  7159,  7160,  7161,  7162,  7163,  7164,  7165,
    7166,  7167,  7168,  7169,  7170,  7171,  7172,  7173,  7174,  7175,
    7176,  7177,  7178,  7179,  7180,  7181,  7182,  7183,  7184,  7185,
    7186,  7187,  7188,  7189,  7190,  7191,  7192,  7193,  7194,  7208,
    7209,  7210,  7211,  7212,  7213,  7214,  7215,  7216,  7217,  7218,
    7219,  7220,  7221,  7222,  7223,  7224,  7225,  7226,  7227,  7228,
    7229,  7230,  7231,  7232,  7233,  7234,  7235,  7236,  7237,  7238,
    7252,  7253,  7254,  7255,  7256,  7257,  7258,  7259,  7260,  7261,
    7262,  7263,  7264,  7265,  7266,  7267,  7268,  7269,  7270,  7271,
    7272,  7282,  7283,  7284,  7285,  7286,  7287,  7288,  7289,  7290,
    7291,  7292,  7293,  7294,  7295,  7296,  7297,  7298,  7299,  7300,
    7301,  7302,  7303,  7304,  7305,  7306,  7307,  7308,  7309,  7310,
    7311,  7312,  7313,  7314,  7315,  7316,  7317,  7318,  7319,  7320,
    7321,  7322,  7323,  7324,  7325,  7326,  7327,  7328,  7329,  7330,
    7331,  7332,  7333,  7334,  7335,  7336,  7337,  7338,  7339,  7340,
    7341,  7342,  7343,  7344,  7345,  7346,  7347,  7348,  7349,  7354,
    7361
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ABORT_TRANS", "ABSOLUTE", "ACCESS", 
  "ACTION", "ADD", "AFTER", "AGGREGATE", "ALL", "ALTER", "ANALYSE", 
  "ANALYZE", "AND", "ANY", "AS", "ASC", "ASSERTION", "ASSIGNMENT", "AT", 
  "AUTHORIZATION", "BACKWARD", "BEFORE", "BEGIN_TRANS", "BETWEEN", 
  "BIGINT", "BINARY", "BIT", "BOOLEAN", "BOTH", "BY", "CACHE", "CALLED", 
  "CASCADE", "CASE", "CAST", "CHAIN", "CHAR_P", "CHARACTER", 
  "CHARACTERISTICS", "CHECK", "CHECKPOINT", "CLASS", "CLOSE", "CLUSTER", 
  "COALESCE", "COLLATE", "COLUMN", "COMMENT", "COMMIT", "COMMITTED", 
  "CONSTRAINT", "CONSTRAINTS", "CONVERSION_P", "CONVERT", "COPY", 
  "CREATE", "CREATEDB", "CREATEUSER", "CROSS", "CURRENT_DATE", 
  "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR", "CYCLE", 
  "DATABASE", "DAY_P", "DEALLOCATE", "DEC", "DECIMAL", "DECLARE", 
  "DEFAULT", "DEFERRABLE", "DEFERRED", "DEFINER", "DELETE_P", "DELIMITER", 
  "DELIMITERS", "DESC", "DISTINCT", "DO", "DOMAIN_P", "DOUBLE", "DROP", 
  "EACH", "ELSE", "ENCODING", "ENCRYPTED", "END_TRANS", "ESCAPE", 
  "EXCEPT", "EXCLUSIVE", "EXECUTE", "EXISTS", "EXPLAIN", "EXTERNAL", 
  "EXTRACT", "FALSE_P", "FETCH", "FLOAT_P", "FOR", "FORCE", "FOREIGN", 
  "FORWARD", "FREEZE", "FROM", "FULL", "FUNCTION", "GET", "GLOBAL", 
  "GRANT", "GROUP_P", "HANDLER", "HAVING", "HOUR_P", "ILIKE", "IMMEDIATE", 
  "IMMUTABLE", "IMPLICIT_P", "IN_P", "INCREMENT", "INDEX", "INHERITS", 
  "INITIALLY", "INNER_P", "INOUT", "INPUT", "INSENSITIVE", "INSERT", 
  "INSTEAD", "INT", "INTEGER", "INTERSECT", "INTERVAL", "INTO", "INVOKER", 
  "IS", "ISNULL", "ISOLATION", "JOIN", "KEY", "LANCOMPILER", "LANGUAGE", 
  "LEADING", "LEFT", "LEVEL", "LIKE", "LIMIT", "LISTEN", "LOAD", "LOCAL", 
  "LOCALTIME", "LOCALTIMESTAMP", "LOCATION", "LOCK_P", "MATCH", 
  "MAXVALUE", "MINUTE_P", "MINVALUE", "MODE", "MONTH_P", "MOVE", "NAMES", 
  "NATIONAL", "NATURAL", "NCHAR", "NEW", "NEXT", "NO", "NOCREATEDB", 
  "NOCREATEUSER", "NONE", "NOT", "NOTHING", "NOTIFY", "NOTNULL", "NULL_P", 
  "NULLIF", "NUMERIC", "OF", "OFF", "OFFSET", "OIDS", "OLD", "ON", "ONLY", 
  "OPERATOR", "OPTION", "OR", "ORDER", "OUT_P", "OUTER_P", "OVERLAPS", 
  "OVERLAY", "OWNER", "PARTIAL", "PASSWORD", "PATH_P", "PENDANT", 
  "PLACING", "POSITION", "PRECISION", "PREPARE", "PRIMARY", "PRIOR", 
  "PRIVILEGES", "PROCEDURAL", "PROCEDURE", "READ", "REAL", "RECHECK", 
  "REFERENCES", "REINDEX", "RELATIVE", "RENAME", "REPLACE", "RESET", 
  "RESTRICT", "RETURNS", "REVOKE", "RIGHT", "ROLLBACK", "ROW", "RULE", 
  "SCHEMA", "SCROLL", "SECOND_P", "SECURITY", "SELECT", "SEQUENCE", 
  "SERIALIZABLE", "SESSION", "SESSION_USER", "SET", "SETOF", "SHARE", 
  "SHOW", "SIMILAR", "SIMPLE", "SMALLINT", "SOME", "STABLE", "START", 
  "STATEMENT", "STATISTICS", "STDIN", "STDOUT", "STORAGE", "STRICT", 
  "SUBSTRING", "SYSID", "TABLE", "TEMP", "TEMPLATE", "TEMPORARY", "THEN", 
  "TIME", "TIMESTAMP", "TO", "TOAST", "TRAILING", "TRANSACTION", "TREAT", 
  "TRIGGER", "TRIM", "TRUE_P", "TRUNCATE", "TRUSTED", "TYPE_P", 
  "UNENCRYPTED", "UNION", "UNIQUE", "UNKNOWN", "UNLISTEN", "UNTIL", 
  "UPDATE", "USAGE", "USER", "USING", "VACUUM", "VALID", "VALIDATOR", 
  "VALUES", "VARCHAR", "VARYING", "VERBOSE", "VERSION", "VIEW", 
  "VOLATILE", "WHEN", "WHERE", "WITH", "WITHOUT", "WORK", "WRITE", 
  "YEAR_P", "ZONE", "UNIONJOIN", "IDENT", "FCONST", "SCONST", "NCONST", 
  "BCONST", "XCONST", "Op", "ICONST", "PARAM", "OP", "'='", "'<'", "'>'", 
  "POSTFIXOP", "'+'", "'-'", "'*'", "'/'", "'%'", "'^'", "UMINUS", "'['", 
  "']'", "'('", "')'", "TYPECAST", "'.'", "';'", "','", "':'", "$accept", 
  "stmtblock", "stmtmulti", "stmt", "CreateUserStmt", "opt_with", 
  "AlterUserStmt", "AlterUserSetStmt", "DropUserStmt", "OptUserList", 
  "OptUserElem", "user_list", "CreateGroupStmt", "OptGroupList", 
  "OptGroupElem", "AlterGroupStmt", "add_drop", "DropGroupStmt", 
  "CreateSchemaStmt", "OptSchemaName", "OptSchemaEltList", "schema_stmt", 
  "VariableSetStmt", "set_rest", "var_list_or_default", "var_list", 
  "var_value", "iso_level", "opt_mode", "opt_boolean", "zone_value", 
  "opt_encoding", "ColId_or_Sconst", "VariableShowStmt", 
  "VariableResetStmt", "ConstraintsSetStmt", "constraints_set_list", 
  "constraints_set_mode", "CheckPointStmt", "AlterTableStmt", 
  "alter_column_default", "opt_drop_behavior", "ClosePortalStmt", 
  "opt_id", "CopyStmt", "copy_from", "copy_file_name", "copy_opt_list", 
  "copy_opt_item", "opt_binary", "opt_oids", "copy_delimiter", 
  "opt_using", "CreateStmt", "OptTemp", "OptTableElementList", 
  "TableElementList", "TableElement", "columnDef", "ColQualList", 
  "ColConstraint", "ColConstraintElem", "ConstraintAttr", 
  "TableLikeClause", "TableConstraint", "ConstraintElem", 
  "opt_column_list", "columnList", "columnElem", "key_match", 
  "key_actions", "key_update", "key_delete", "key_action", "OptInherit", 
  "OptWithOids", "CreateAsStmt", "OptCreateAs", "CreateAsList", 
  "CreateAsElement", "CreateSeqStmt", "OptSeqList", "OptSeqElem", 
  "NumericOnly", "FloatOnly", "IntegerOnly", "CreatePLangStmt", 
  "opt_trusted", "handler_name", "opt_lancompiler", "opt_validator", 
  "DropPLangStmt", "opt_procedural", "CreateTrigStmt", 
  "TriggerActionTime", "TriggerEvents", "TriggerOneEvent", 
  "TriggerForSpec", "TriggerForOpt", "TriggerForType", "TriggerFuncArgs", 
  "TriggerFuncArg", "OptConstrFromTable", "ConstraintAttributeSpec", 
  "ConstraintDeferrabilitySpec", "ConstraintTimeSpec", "DropTrigStmt", 
  "CreateAssertStmt", "DropAssertStmt", "DefineStmt", "definition", 
  "def_list", "def_elem", "def_arg", "CreateOpClassStmt", 
  "opclass_item_list", "opclass_item", "opt_default", "opt_recheck", 
  "DropOpClassStmt", "DropStmt", "drop_type", "any_name_list", "any_name", 
  "TruncateStmt", "CommentStmt", "comment_type", "comment_text", 
  "FetchStmt", "direction", "fetch_how_many", "from_in", "GrantStmt", 
  "RevokeStmt", "privileges", "privilege_list", "privilege", 
  "privilege_target", "grantee_list", "grantee", "opt_grant_grant_option", 
  "opt_revoke_grant_option", "function_with_argtypes_list", 
  "function_with_argtypes", "IndexStmt", "index_opt_unique", 
  "access_method_clause", "index_params", "index_list", "func_index", 
  "index_elem", "opt_class", "CreateFunctionStmt", "opt_or_replace", 
  "func_args", "func_args_list", "func_arg", "opt_arg", "func_return", 
  "func_type", "createfunc_opt_list", "createfunc_opt_item", "func_as", 
  "opt_definition", "RemoveFuncStmt", "RemoveAggrStmt", "aggr_argtype", 
  "RemoveOperStmt", "oper_argtypes", "any_operator", "CreateCastStmt", 
  "cast_context", "DropCastStmt", "ReindexStmt", "reindex_type", 
  "opt_force", "RenameStmt", "opt_name", "opt_column", "RuleStmt", "@1", 
  "RuleActionList", "RuleActionMulti", "RuleActionStmt", 
  "RuleActionStmtOrEmpty", "event", "opt_instead", "DropRuleStmt", 
  "NotifyStmt", "ListenStmt", "UnlistenStmt", "TransactionStmt", 
  "trans_options", "opt_trans", "ViewStmt", "LoadStmt", "CreatedbStmt", 
  "createdb_opt_list", "createdb_opt_item", "opt_equal", 
  "AlterDatabaseSetStmt", "DropdbStmt", "CreateDomainStmt", "opt_as", 
  "CreateConversionStmt", "ClusterStmt", "VacuumStmt", "AnalyzeStmt", 
  "analyze_keyword", "opt_verbose", "opt_full", "opt_freeze", 
  "opt_name_list", "ExplainStmt", "PrepareStmt", "prep_type_clause", 
  "prep_type_list", "ExecuteStmt", "execute_param_clause", 
  "DeallocateStmt", "OptimizableStmt", "InsertStmt", "insert_rest", 
  "insert_column_list", "insert_column_item", "DeleteStmt", "LockStmt", 
  "opt_lock", "lock_type", "UpdateStmt", "CursorStmt", "opt_cursor", 
  "SelectStmt", "select_with_parens", "select_no_parens", "select_clause", 
  "simple_select", "into_clause", "OptTempTableName", "opt_table", 
  "opt_all", "opt_distinct", "opt_sort_clause", "sort_clause", 
  "sortby_list", "sortby", "OptUseOp", "select_limit", "opt_select_limit", 
  "select_limit_value", "select_offset_value", "group_clause", 
  "having_clause", "for_update_clause", "opt_for_update_clause", 
  "update_list", "from_clause", "from_list", "table_ref", "joined_table", 
  "alias_clause", "join_type", "join_outer", "join_qual", "relation_expr", 
  "func_table", "where_clause", "TableFuncElementList", 
  "TableFuncElement", "Typename", "opt_array_bounds", "SimpleTypename", 
  "ConstTypename", "GenericType", "Numeric", "opt_float", "opt_numeric", 
  "opt_decimal", "Bit", "ConstBit", "BitWithLength", "BitWithoutLength", 
  "Character", "ConstCharacter", "CharacterWithLength", 
  "CharacterWithoutLength", "character", "opt_varying", "opt_charset", 
  "opt_collate", "ConstDatetime", "ConstInterval", "opt_timezone", 
  "opt_interval", "r_expr", "row", "row_descriptor", "sub_type", "all_Op", 
  "MathOp", "qual_Op", "qual_all_Op", "a_expr", "b_expr", "c_expr", 
  "opt_indirection", "expr_list", "extract_list", "type_list", 
  "extract_arg", "overlay_list", "overlay_placing", "position_list", 
  "substr_list", "substr_from", "substr_for", "trim_list", "in_expr", 
  "case_expr", "when_clause_list", "when_clause", "case_default", 
  "case_arg", "columnref", "dotted_name", "attrs", "target_list", 
  "target_el", "update_target_list", "update_target_el", 
  "insert_target_list", "insert_target_el", "relation_name", 
  "qualified_name_list", "qualified_name", "name_list", "name", 
  "database_name", "access_method", "attr_name", "index_name", 
  "file_name", "func_name", "AexprConst", "Iconst", "Sconst", "UserId", 
  "ColId", "type_name", "function_name", "ColLabel", "unreserved_keyword", 
  "col_name_keyword", "func_name_keyword", "reserved_keyword", 
  "SpecialRuleRelation", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   406,   407,   408,   409,   410,   411,   412,   413,   414,
     415,   416,   417,   418,   419,   420,   421,   422,   423,   424,
     425,   426,   427,   428,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,   439,   440,   441,   442,   443,   444,
     445,   446,   447,   448,   449,   450,   451,   452,   453,   454,
     455,   456,   457,   458,   459,   460,   461,   462,   463,   464,
     465,   466,   467,   468,   469,   470,   471,   472,   473,   474,
     475,   476,   477,   478,   479,   480,   481,   482,   483,   484,
     485,   486,   487,   488,   489,   490,   491,   492,   493,   494,
     495,   496,   497,   498,   499,   500,   501,   502,   503,   504,
     505,   506,   507,   508,   509,   510,   511,   512,   513,   514,
     515,   516,   517,   518,   519,   520,   521,   522,   523,   524,
     525,   526,   527,   528,   529,   530,   531,   532,   533,   534,
     535,   536,   537,   538,   539,   540,   541,   542,   543,   544,
     545,   546,   547,   548,   549,   550,   551,   552,   553,   554,
     555,   556,   557,   558,   559,   560,   561,   562,   563,   564,
      61,    60,    62,   565,    43,    45,    42,    47,    37,    94,
     566,    91,    93,    40,    41,   567,    46,    59,    44,    58
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned short yyr1[] =
{
       0,   330,   331,   332,   332,   333,   333,   333,   333,   333,
     333,   333,   333,   333,   333,   333,   333,   333,   333,   333,
     333,   333,   333,   333,   333,   333,   333,   333,   333,   333,
     333,   333,   333,   333,   333,   333,   333,   333,   333,   333,
     333,   333,   333,   333,   333,   333,   333,   333,   333,   333,
     333,   333,   333,   333,   333,   333,   333,   333,   333,   333,
     333,   333,   333,   333,   333,   333,   333,   333,   333,   333,
     333,   334,   335,   335,   336,   337,   337,   338,   339,   339,
     340,   340,   340,   340,   340,   340,   340,   340,   340,   340,
     341,   341,   342,   343,   343,   344,   344,   345,   346,   346,
     347,   348,   348,   349,   349,   350,   350,   351,   351,   351,
     352,   352,   352,   353,   353,   353,   353,   353,   353,   353,
     353,   354,   354,   355,   355,   356,   356,   356,   357,   357,
     358,   358,   358,   359,   359,   359,   359,   360,   360,   360,
     360,   360,   360,   360,   361,   361,   361,   362,   362,   363,
     363,   363,   363,   363,   364,   364,   364,   364,   364,   365,
     366,   366,   367,   367,   368,   369,   369,   369,   369,   369,
     369,   369,   369,   369,   369,   369,   370,   370,   371,   371,
     371,   372,   373,   373,   374,   375,   375,   376,   376,   376,
     377,   377,   378,   378,   378,   378,   379,   379,   380,   380,
     381,   381,   382,   382,   383,   383,   384,   384,   384,   384,
     384,   384,   384,   385,   385,   386,   386,   387,   387,   387,
     388,   389,   389,   390,   390,   390,   391,   391,   391,   391,
     391,   391,   391,   392,   392,   392,   392,   393,   394,   394,
     395,   395,   395,   395,   396,   396,   397,   397,   398,   399,
     399,   399,   399,   400,   400,   400,   400,   400,   401,   402,
     403,   403,   403,   403,   403,   404,   404,   405,   405,   405,
     406,   407,   407,   408,   408,   409,   410,   411,   411,   412,
     412,   412,   412,   412,   412,   413,   413,   414,   414,   415,
     415,   416,   417,   417,   418,   418,   419,   419,   420,   420,
     421,   422,   422,   423,   423,   424,   424,   425,   425,   425,
     426,   426,   426,   427,   428,   428,   429,   429,   430,   430,
     430,   431,   431,   431,   431,   431,   431,   432,   432,   433,
     433,   433,   433,   433,   434,   434,   435,   435,   436,   437,
     438,   439,   439,   439,   439,   439,   440,   441,   441,   442,
     442,   443,   443,   443,   443,   444,   445,   445,   446,   446,
     446,   446,   447,   447,   448,   448,   449,   450,   451,   451,
     451,   451,   451,   451,   451,   451,   452,   452,   453,   453,
     454,   455,   455,   455,   455,   455,   455,   455,   455,   456,
     456,   456,   456,   456,   456,   456,   456,   456,   457,   457,
     458,   458,   458,   458,   458,   458,   458,   458,   458,   458,
     459,   459,   459,   459,   460,   460,   460,   460,   460,   461,
     461,   462,   463,   464,   464,   464,   465,   465,   466,   466,
     466,   466,   466,   466,   466,   466,   466,   466,   466,   466,
     467,   467,   467,   467,   467,   467,   468,   468,   469,   469,
     470,   470,   471,   471,   472,   472,   473,   474,   475,   475,
     476,   476,   477,   477,   478,   478,   479,   480,   481,   481,
     481,   482,   483,   483,   484,   484,   485,   485,   486,   486,
     487,   487,   487,   488,   489,   489,   490,   490,   491,   491,
     491,   491,   491,   491,   491,   491,   491,   491,   491,   491,
     492,   492,   493,   493,   494,   495,   496,   496,   497,   498,
     498,   498,   498,   499,   499,   500,   500,   501,   501,   501,
     502,   503,   503,   504,   504,   505,   505,   506,   506,   507,
     507,   508,   508,   510,   509,   511,   511,   511,   512,   512,
     513,   513,   513,   513,   513,   514,   514,   515,   515,   515,
     515,   516,   516,   517,   518,   519,   520,   520,   521,   521,
     521,   521,   521,   521,   522,   522,   523,   523,   523,   524,
     525,   526,   527,   527,   528,   528,   528,   528,   528,   528,
     528,   528,   528,   529,   529,   530,   530,   531,   532,   533,
     533,   534,   535,   536,   536,   536,   537,   537,   538,   538,
     539,   539,   540,   540,   541,   541,   542,   542,   543,   543,
     544,   545,   545,   546,   546,   547,   548,   548,   549,   549,
     550,   550,   550,   550,   550,   551,   552,   552,   552,   552,
     552,   553,   553,   554,   555,   556,   557,   557,   558,   558,
     558,   558,   558,   558,   558,   558,   559,   560,   561,   561,
     561,   561,   561,   562,   562,   563,   563,   564,   564,   564,
     564,   565,   565,   566,   566,   566,   566,   567,   567,   568,
     568,   568,   568,   568,   568,   568,   568,   569,   569,   570,
     570,   570,   571,   571,   571,   571,   572,   572,   573,   574,
     574,   575,   576,   576,   576,   576,   577,   577,   577,   577,
     577,   578,   578,   579,   579,   579,   580,   580,   581,   581,
     582,   582,   583,   583,   584,   584,   585,   585,   586,   586,
     587,   587,   588,   588,   588,   588,   588,   588,   588,   588,
     588,   588,   588,   589,   589,   589,   589,   589,   589,   589,
     590,   590,   590,   590,   591,   591,   591,   591,   592,   592,
     593,   593,   594,   594,   594,   594,   595,   595,   596,   596,
     597,   597,   598,   599,   599,   600,   600,   600,   601,   601,
     601,   601,   601,   601,   601,   601,   602,   602,   602,   602,
     602,   603,   604,   604,   604,   604,   604,   604,   604,   604,
     604,   604,   604,   605,   605,   606,   606,   606,   607,   607,
     607,   608,   608,   609,   609,   610,   611,   612,   612,   613,
     613,   614,   615,   616,   616,   616,   616,   616,   616,   617,
     617,   618,   618,   619,   619,   620,   620,   620,   620,   621,
     622,   622,   622,   623,   623,   623,   623,   623,   623,   623,
     623,   623,   623,   623,   623,   623,   623,   624,   624,   624,
     624,   624,   624,   624,   624,   624,   625,   625,   625,   625,
     626,   627,   627,   627,   628,   628,   629,   629,   629,   629,
     629,   629,   629,   629,   629,   630,   630,   631,   631,   632,
     632,   632,   632,   632,   632,   632,   632,   632,   632,   632,
     632,   632,   632,   632,   632,   632,   632,   632,   632,   632,
     632,   632,   632,   632,   632,   632,   632,   632,   632,   632,
     632,   632,   632,   632,   632,   632,   632,   632,   632,   632,
     632,   632,   632,   632,   632,   632,   632,   632,   632,   632,
     632,   632,   632,   632,   632,   632,   633,   633,   633,   633,
     633,   633,   633,   633,   633,   633,   633,   633,   633,   633,
     633,   633,   633,   633,   633,   633,   633,   633,   633,   634,
     634,   634,   634,   634,   634,   634,   634,   634,   634,   634,
     634,   634,   634,   634,   634,   634,   634,   634,   634,   634,
     634,   634,   634,   634,   634,   634,   634,   634,   634,   634,
     634,   634,   634,   634,   634,   634,   635,   635,   635,   636,
     636,   637,   637,   638,   638,   639,   639,   639,   639,   639,
     639,   639,   639,   640,   640,   641,   642,   642,   643,   643,
     643,   643,   643,   643,   644,   645,   646,   646,   646,   647,
     647,   648,   648,   648,   649,   649,   650,   651,   651,   652,
     652,   653,   653,   654,   655,   655,   655,   656,   656,   657,
     657,   657,   658,   658,   659,   660,   660,   661,   661,   662,
     662,   663,   663,   664,   664,   665,   665,   666,   667,   668,
     669,   670,   671,   672,   672,   673,   673,   673,   673,   673,
     673,   673,   673,   673,   673,   673,   673,   674,   675,   676,
     677,   677,   677,   678,   678,   679,   679,   679,   680,   680,
     680,   680,   680,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   681,
     681,   681,   681,   681,   681,   681,   681,   681,   681,   682,
     682,   682,   682,   682,   682,   682,   682,   682,   682,   682,
     682,   682,   682,   682,   682,   682,   682,   682,   682,   682,
     682,   682,   682,   682,   682,   682,   682,   682,   682,   682,
     683,   683,   683,   683,   683,   683,   683,   683,   683,   683,
     683,   683,   683,   683,   683,   683,   683,   683,   683,   683,
     683,   684,   684,   684,   684,   684,   684,   684,   684,   684,
     684,   684,   684,   684,   684,   684,   684,   684,   684,   684,
     684,   684,   684,   684,   684,   684,   684,   684,   684,   684,
     684,   684,   684,   684,   684,   684,   684,   684,   684,   684,
     684,   684,   684,   684,   684,   684,   684,   684,   684,   684,
     684,   684,   684,   684,   684,   684,   684,   684,   684,   684,
     684,   684,   684,   684,   684,   684,   684,   684,   684,   685,
     685
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     1,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       0,     5,     1,     0,     5,     5,     4,     3,     2,     0,
       2,     3,     3,     2,     1,     1,     1,     1,     3,     3,
       3,     1,     5,     2,     0,     2,     2,     6,     1,     1,
       3,     6,     4,     1,     0,     2,     0,     1,     1,     1,
       2,     3,     3,     3,     3,     3,     5,     7,     2,     3,
       3,     1,     1,     1,     3,     1,     1,     1,     2,     1,
       2,     2,     0,     1,     1,     1,     1,     1,     1,     3,
       6,     1,     1,     1,     1,     1,     0,     1,     1,     2,
       3,     4,     3,     2,     2,     3,     4,     3,     2,     4,
       1,     1,     1,     1,     1,     6,     7,     9,     9,     9,
       9,     7,     5,     7,     6,     6,     3,     2,     1,     1,
       0,     2,     1,     0,    10,     1,     1,     1,     1,     1,
       2,     0,     1,     1,     3,     3,     1,     0,     2,     0,
       3,     0,     1,     0,     9,    10,     1,     1,     2,     2,
       2,     2,     0,     1,     0,     1,     3,     1,     1,     1,
       4,     2,     0,     3,     1,     1,     2,     1,     1,     2,
       4,     2,     5,     1,     2,     2,     2,     2,     3,     1,
       4,     4,     5,    11,     3,     0,     1,     3,     1,     2,
       2,     2,     0,     1,     1,     2,     2,     0,     3,     3,
       2,     1,     1,     2,     2,     4,     0,     2,     2,     0,
       7,     3,     0,     1,     3,     1,     5,     2,     0,     2,
       1,     2,     2,     2,     2,     1,     1,     1,     2,     1,
       2,     9,     1,     0,     1,     1,     2,     0,     2,     0,
       5,     1,     0,    14,    19,     1,     1,     1,     3,     5,
       1,     1,     1,     3,     1,     0,     1,     1,     1,     3,
       0,     1,     1,     1,     1,     1,     1,     2,     0,     1,
       2,     1,     2,     0,     2,     1,     2,     2,     6,     8,
       4,     4,     4,     4,     7,     8,     3,     1,     3,     3,
       1,     1,     1,     1,     1,    12,     1,     3,     4,     7,
       4,     2,     1,     0,     1,     0,     7,     4,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     1,     1,
       3,     6,     9,     7,     9,     8,     8,     6,     8,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       5,     4,     4,     3,     2,     5,     4,     4,     3,     2,
       1,     1,     1,     1,     1,     2,     1,     1,     1,     1,
       1,     7,     7,     1,     1,     2,     1,     3,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     2,     2,     2,     2,     1,     3,     1,     2,
       3,     0,     3,     0,     1,     3,     2,    11,     1,     0,
       2,     0,     1,     1,     1,     3,     5,     2,     1,     2,
       0,     9,     2,     0,     3,     2,     1,     3,     2,     1,
       1,     1,     1,     1,     1,     4,     1,     2,     2,     2,
       1,     1,     1,     4,     5,     1,     3,     3,     2,     2,
       1,     3,     2,     0,     5,     7,     1,     1,     7,     1,
       3,     3,     3,     1,     3,    11,    10,     2,     2,     0,
       8,     4,     4,     1,     1,     1,     0,     8,     8,     1,
       0,     1,     0,     0,    14,     1,     1,     3,     3,     1,
       1,     1,     1,     1,     1,     1,     0,     1,     1,     1,
       1,     1,     0,     6,     2,     2,     2,     2,     2,     2,
       3,     2,     2,     2,     3,     0,     1,     1,     0,     7,
       2,     5,     2,     0,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     1,     0,     5,     4,     3,     7,     1,
       0,    10,     4,     4,     5,     5,     2,     4,     1,     1,
       1,     0,     1,     0,     1,     0,     3,     0,     3,     4,
       5,     3,     0,     1,     3,     4,     3,     0,     2,     3,
       1,     1,     1,     1,     1,     4,     4,     2,     1,     7,
       4,     1,     3,     2,     4,     4,     3,     0,     2,     2,
       2,     3,     1,     3,     1,     2,     6,     6,     1,     1,
       1,     2,     0,     1,     1,     3,     3,     1,     2,     4,
       4,     1,     1,     8,     4,     4,     4,     2,     0,     3,
       3,     4,     4,     4,     4,     2,     1,     1,     0,     1,
       1,     0,     1,     5,     1,     0,     1,     0,     3,     1,
       3,     2,     2,     1,     1,     0,     4,     4,     2,     2,
       4,     1,     0,     1,     1,     1,     1,     1,     3,     0,
       2,     0,     3,     3,     1,     0,     2,     0,     2,     0,
       1,     3,     1,     2,     1,     2,     5,     6,     5,     1,
       2,     1,     4,     3,     4,     3,     5,     4,     5,     4,
       5,     2,     4,     1,     2,     2,     2,     1,     1,     0,
       4,     2,     1,     2,     2,     4,     3,     4,     2,     0,
       1,     3,     2,     2,     3,     3,     4,     0,     1,     1,
       1,     1,     1,     2,     5,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     2,     2,
       2,     2,     1,     3,     0,     5,     3,     0,     5,     3,
       0,     1,     1,     1,     1,     5,     2,     1,     1,     1,
       1,     5,     2,     2,     2,     1,     3,     3,     2,     1,
       0,     3,     0,     2,     0,     5,     2,     5,     2,     1,
       3,     3,     0,     1,     1,     1,     1,     1,     1,     3,
       3,     3,     3,     3,     3,     3,     0,     3,     4,     4,
       3,     3,     3,     4,     3,     5,     4,     4,     3,     3,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     4,     1,     4,     1,
       3,     3,     5,     2,     2,     2,     2,     2,     2,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     2,
       2,     3,     3,     2,     3,     5,     4,     6,     3,     5,
       4,     6,     4,     6,     5,     7,     2,     3,     2,     4,
       3,     4,     3,     4,     3,     4,     5,     6,     7,     5,
       6,     3,     4,     4,     2,     1,     1,     3,     2,     2,
       2,     2,     2,     2,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     2,     2,     5,     6,     7,     1,
       1,     3,     3,     5,     1,     3,     4,     5,     5,     4,
       1,     1,     4,     1,     4,     1,     4,     1,     4,     1,
       1,     1,     6,     4,     4,     4,     4,     6,     5,     5,
       5,     4,     6,     4,     1,     2,     4,     6,     0,     1,
       3,     3,     0,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     4,     3,     2,     3,     0,     3,     3,
       2,     2,     1,     0,     2,     2,     3,     2,     1,     1,
       3,     5,     6,     4,     1,     2,     4,     2,     0,     1,
       0,     2,     2,     2,     2,     2,     3,     1,     3,     3,
       1,     1,     1,     3,     4,     1,     3,     1,     1,     1,
       1,     1,     3,     1,     1,     1,     3,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       2,     3,     6,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned short yydefact[] =
{
      70,   568,     0,   599,   598,   568,   164,   183,     0,     0,
     568,   197,   473,     0,     0,     0,   302,   568,     0,   601,
       0,     0,     0,     0,     0,   678,     0,     0,     0,     0,
       0,   453,   568,   685,     0,     0,     0,   678,     0,     0,
     603,     0,     0,     2,     4,    24,     8,     9,    38,    18,
       6,    32,    17,    64,    65,    66,    67,    68,     7,    10,
      11,    12,    13,    19,    21,    34,    23,    36,    22,    35,
      27,    20,    33,    28,    29,    30,    41,    42,    54,    43,
      16,    52,    50,    51,    14,    31,    49,    53,    56,    37,
      47,    44,    45,    57,    58,    59,    60,     5,    61,    15,
      69,    25,    62,    63,   601,    40,    48,    39,    26,    55,
     623,   624,    46,   622,   621,   620,   662,   653,   687,   661,
     567,   566,   558,     0,     0,     0,     0,     0,   559,  1103,
    1104,  1105,  1106,  1107,  1108,  1109,  1110,  1111,  1112,  1113,
    1114,  1115,  1116,  1279,  1280,  1281,  1117,  1118,  1119,  1120,
    1121,  1282,  1283,  1122,  1123,  1124,  1125,  1126,  1284,  1127,
    1128,  1129,  1130,  1131,  1285,  1132,  1133,  1134,  1135,  1136,
    1137,  1138,  1139,  1286,  1287,  1140,  1141,  1142,  1143,  1144,
    1145,  1146,  1147,  1148,  1149,  1150,  1151,  1152,  1153,  1154,
    1288,  1155,  1156,  1289,  1157,  1290,  1158,  1159,  1160,  1161,
    1162,  1163,  1164,  1165,  1166,  1167,  1168,  1169,  1170,  1171,
    1172,  1173,  1174,  1175,  1291,  1292,  1293,  1176,  1177,  1178,
    1180,  1179,  1181,  1182,  1183,  1184,  1185,  1186,  1187,  1188,
    1189,  1190,  1191,  1192,  1193,  1194,  1195,  1294,  1196,  1197,
    1198,  1199,  1295,  1200,  1201,  1296,  1297,  1202,  1203,  1204,
    1205,  1206,  1298,  1207,  1208,  1209,  1210,  1211,  1299,  1212,
    1213,  1214,  1215,  1216,  1217,  1218,  1300,  1219,  1220,  1221,
    1222,  1223,  1224,  1225,  1226,  1227,  1228,  1301,  1229,  1230,
    1231,  1232,  1233,  1235,  1236,  1234,  1237,  1302,  1238,  1239,
    1240,  1303,  1241,  1242,  1243,  1244,  1245,  1246,  1247,  1248,
    1304,  1249,  1250,  1251,  1252,  1305,  1306,  1253,  1254,  1307,
    1255,  1308,  1256,  1257,  1258,  1259,  1260,  1261,  1262,  1263,
    1264,  1265,  1266,  1267,  1268,  1309,  1269,  1270,  1271,  1272,
    1273,  1274,  1276,  1275,  1277,  1278,  1090,   181,   182,  1091,
    1092,     0,  1071,     0,   561,   196,     0,     0,     0,     0,
       0,     0,     0,   362,     0,     0,     0,     0,     0,     0,
     104,   207,   206,     0,   292,     0,   458,     0,     0,   302,
       0,     0,     0,  1213,   618,  1067,   652,     0,     0,     0,
       0,   374,     0,   373,     0,     0,   371,     0,   301,     0,
     375,   369,   368,     0,   372,     0,   370,     0,     0,   562,
     617,   600,   601,     0,   413,   416,   411,   410,   420,   419,
     417,   418,   412,  1087,     0,     0,     0,     0,   404,   414,
     424,   437,   431,   435,   429,   433,   432,   428,   439,   438,
     434,   430,   436,     0,   423,   426,     0,  1400,  1399,  1064,
    1063,   555,  1060,  1059,  1088,   570,  1072,   677,     0,     0,
       0,     0,   409,   554,   612,     0,   523,   524,     0,   158,
    1234,  1305,  1254,   154,     0,     0,   563,   684,   682,     0,
    1130,  1184,   146,  1234,  1305,  1254,   110,     0,   153,  1234,
    1305,  1254,   149,   565,     0,   557,   556,     0,     0,   752,
     602,   605,   662,     0,     1,    70,   596,   681,   681,     0,
     681,     0,   658,     0,  1068,     0,  1089,     0,   752,     0,
      73,     0,     0,   389,     0,   390,   395,     0,   392,     0,
       0,   391,   393,   394,     0,   396,   397,     0,   245,  1310,
    1311,  1312,  1313,  1314,  1315,  1316,  1317,  1318,  1319,  1320,
    1321,  1322,  1323,  1324,  1325,  1326,  1327,  1328,  1329,  1330,
    1090,  1074,     0,     0,  1073,  1091,  1097,     0,     0,   590,
       0,    73,   590,   379,   378,   211,   210,    73,   209,   208,
    1124,   864,   874,   872,   873,   866,   867,   868,   869,   870,
     871,     0,   513,   865,     0,   472,     0,   106,     0,     0,
      73,     0,     0,     0,     0,     0,     0,     0,     0,   619,
     648,   649,   650,     0,   759,     0,   180,     0,   587,     0,
     100,  1124,     0,     0,     0,    77,    91,     0,   180,   376,
       0,   668,     0,   608,   415,   417,   418,     0,     0,     0,
     403,   425,     0,     0,     0,     0,  1043,   637,  1061,     0,
       0,     0,   408,     0,     0,   526,   526,   157,   155,     0,
       0,     0,     0,  1279,  1280,  1281,  1040,     0,  1282,  1283,
    1284,  1285,   970,   971,   973,   979,  1286,  1287,  1147,  1288,
    1289,  1085,  1290,  1291,  1292,  1293,   975,   977,  1195,  1294,
       0,  1086,  1296,  1297,  1204,  1298,  1299,  1300,  1301,   980,
    1303,  1304,  1305,  1306,  1307,  1308,  1084,     0,   981,  1309,
    1090,  1076,  1078,  1079,   875,   998,     0,     0,  1051,     0,
       0,     0,   994,     0,   776,   777,   778,   803,   804,   779,
     809,   810,   822,   780,     0,   935,     0,     0,  1050,   879,
     964,   959,   998,   668,  1047,   998,     0,   960,  1075,  1077,
     781,  1091,   160,     0,   161,  1065,  1234,   111,   145,   118,
     144,     0,  1122,   112,     0,     0,     0,     0,   152,   150,
       0,     0,   560,   380,     0,   754,     0,   753,   604,   601,
     656,   655,     3,   607,   679,   680,     0,     0,     0,     0,
       0,     0,     0,   715,   702,     0,   586,    98,    99,     0,
     532,   532,   532,   532,     0,     0,     0,     0,    72,    79,
      76,   592,     0,     0,     0,     0,     0,     0,     0,     0,
     199,     0,   341,     0,   785,   820,   792,   820,   820,   800,
     800,   794,   782,   783,   829,   820,   797,   786,     0,   784,
     832,   832,   815,  1093,     0,   767,   768,   769,   770,   801,
     802,   771,   807,   808,   772,   846,   781,  1094,   589,     0,
       0,   573,     0,    94,   363,   342,     0,     0,   102,   306,
     305,     0,     0,   343,    79,   278,   272,     0,     0,     0,
       0,     0,   245,   651,     0,     0,   634,     0,   178,   179,
     340,     0,     0,   180,     0,     0,     0,     0,     0,   148,
     180,   147,     0,   367,   999,     0,     0,   615,   609,     0,
     402,   401,  1137,  1160,  1179,  1230,     0,     0,   440,   427,
       0,     0,     0,   625,   628,  1045,  1044,  1070,     0,     0,
     635,     0,   407,   406,     0,   613,     0,   525,   522,   521,
     156,   452,     0,     0,   819,   806,  1039,     0,     0,   814,
     813,     0,     0,     0,     0,     0,   790,   789,   788,   995,
    1002,     0,   787,     0,     0,   820,   820,   818,   903,     0,
       0,   791,     0,     0,  1017,     0,  1023,     0,     0,     0,
     828,     0,   826,     0,     0,   934,  1083,   998,   883,   884,
     885,   886,   994,     0,   999,     0,  1080,     0,     0,   812,
       0,   846,     0,     0,     0,     0,     0,   877,     0,   899,
       0,     0,     0,     0,     0,     0,     0,     0,   916,     0,
       0,   918,     0,     0,     0,   875,   874,   872,   873,   866,
     867,   868,   869,   887,   888,     0,   900,     0,  1042,     0,
     719,  1041,     0,   162,   163,   159,     0,     0,   120,   119,
       0,   142,   143,   138,   287,     0,   115,   141,   285,   286,
       0,   289,   137,     0,   122,   134,   136,   135,   133,   113,
     121,   123,   125,   126,   127,   114,   151,     0,     0,   719,
    1052,   998,   593,     0,   597,   662,   666,   661,   665,   688,
     689,   695,   664,     0,   717,   704,   705,   698,   703,   707,
     699,   706,   714,   660,   701,   659,   585,     0,     0,   531,
       0,     0,     0,     0,   172,   239,     0,     0,     0,     0,
     530,     0,     0,     0,    75,    74,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   246,   248,     0,     0,  1331,
    1332,  1333,  1334,  1335,  1336,  1337,  1338,  1339,  1340,  1341,
    1342,  1343,  1344,  1345,  1346,  1347,  1348,  1349,  1350,  1351,
    1352,  1353,  1354,  1355,  1356,  1357,  1358,  1359,  1360,  1361,
    1362,  1363,  1364,  1365,  1366,  1367,  1368,  1369,  1370,  1371,
    1372,  1373,  1374,  1375,  1376,  1377,  1378,  1379,  1380,  1381,
    1382,  1383,  1384,  1385,  1386,  1387,  1388,  1389,  1390,  1391,
    1392,  1393,  1394,  1395,  1396,  1397,  1398,  1098,     0,   347,
     350,  1099,  1100,  1101,  1102,     0,   767,     0,   763,   835,
     836,   837,   834,   838,   833,     0,   773,   775,     0,     0,
     571,   222,    92,     0,   514,   106,   212,   105,   107,   108,
     109,   311,   310,   312,     0,   307,     0,    71,   276,     0,
     214,     0,     0,     0,     0,     0,   533,     0,     0,   758,
     507,     0,   506,     0,   480,   482,   481,   475,     0,   476,
       0,   479,   484,   781,   504,     0,     0,     0,   509,   180,
     180,    90,   300,   377,   616,     0,  1162,  1184,     0,   678,
     678,   667,   676,   400,   443,   442,   454,     0,   444,   445,
     441,     0,   627,     0,     0,   631,   998,  1046,     0,   644,
       0,   642,     0,  1062,   405,   611,     0,   610,     0,     0,
       0,     0,  1038,  1034,     0,     0,   999,     0,     0,     0,
       0,  1008,  1009,  1010,  1007,  1011,  1006,  1005,  1012,     0,
       0,     0,     0,     0,   817,   816,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   936,     0,
     858,     0,   999,   999,  1022,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   999,  1028,     0,     0,   961,
     859,   962,     0,     0,     0,     0,  1081,   847,     0,     0,
     852,     0,     0,     0,     0,   854,   863,   861,   862,     0,
     850,   851,     0,   901,  1049,     0,     0,   881,   908,     0,
    1029,   931,     0,   922,     0,   917,     0,   920,   924,   904,
       0,     0,     0,     0,     0,     0,   902,     0,   897,   895,
     896,   889,   890,   891,   892,   893,   894,   880,   898,     0,
    1048,     0,   759,     0,     0,     0,   965,     0,  1066,     0,
     288,   290,     0,   846,     0,   129,   132,     0,   564,   755,
       0,   759,     0,   595,   594,     0,     0,   693,   694,     0,
     691,   713,     0,   712,     0,     0,     0,    97,     0,     0,
       0,     0,     0,   165,     0,     0,   180,   180,     0,   529,
     174,   175,     0,    84,    86,     0,     0,    85,    87,     0,
       0,     0,     0,    78,     0,     0,     0,     0,   399,   387,
     398,     0,     0,   381,   244,     0,   198,   185,   186,     0,
     346,     0,     0,     0,   764,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   584,   584,   584,   584,   572,   824,
       0,     0,    93,     0,   101,     0,     0,     0,     0,     0,
     760,     0,     0,   280,     0,     0,     0,     0,   277,     0,
       0,     0,   213,   215,   217,   218,   219,     0,   273,   275,
       0,     0,     0,   461,     0,     0,     0,   647,   180,     0,
     474,     0,   478,   775,   180,  1069,     0,   180,     0,   553,
     338,  1000,   678,   678,   678,   678,   675,     0,     0,     0,
     456,     0,   451,   446,   448,  1058,  1057,     0,  1055,     0,
       0,   633,   645,   638,   640,   639,     0,     0,   636,   614,
       0,   683,     0,     0,     0,  1035,     0,     0,  1033,     0,
     993,   972,   974,   799,     0,   983,     0,   793,   976,   978,
       0,   796,     0,   876,     0,     0,   984,   938,   939,   940,
     941,     0,   954,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   942,   943,     0,   955,   985,   856,   857,
       0,     0,  1020,  1021,   986,   830,   831,   832,   832,     0,
       0,  1027,     0,     0,     0,   991,     0,   998,   860,   821,
     822,     0,     0,   853,   848,     0,   849,     0,     0,     0,
       0,     0,   923,   919,     0,   921,   925,     0,     0,     0,
     910,   932,   906,     0,     0,   912,   933,     0,   729,   718,
     720,   731,   722,   724,  1064,     0,   709,     0,     0,   969,
     966,     0,     0,   139,   128,     0,   116,   124,  1053,   646,
       0,   606,   690,   692,   716,   696,   700,   697,     0,   238,
       0,     0,     0,   222,     0,     0,   166,   173,   171,     0,
       0,     0,     0,    80,    83,     0,     0,     0,     0,   383,
       0,     0,     0,   247,   188,   189,   201,   187,   348,  1204,
     867,   353,   349,   351,   483,   352,   354,   333,     0,   765,
       0,   840,   841,   842,   843,   844,   845,   839,   846,   824,
       0,   583,     0,     0,     0,     0,     0,     0,     0,     0,
     233,     0,     0,   227,     0,     0,   228,   221,   224,   225,
     588,    96,    95,     0,     0,     0,   308,   344,     0,   762,
     279,   281,   282,   283,   284,   214,   237,   266,     0,   271,
       0,   270,   299,   295,   294,  1067,     0,     0,     0,     0,
       0,   569,   505,   180,   477,     0,   366,   511,   508,   512,
     510,     0,     0,     0,     0,   670,   669,   455,   449,     0,
       0,   421,   626,     0,     0,   630,   632,   643,   641,   422,
     805,     0,  1037,  1031,     0,     0,     0,  1001,     0,     0,
    1015,  1014,  1016,     0,     0,     0,   952,   950,   951,   944,
     945,   946,   947,   948,   949,   937,   953,  1025,  1024,  1018,
    1019,   827,   825,     0,   988,   989,   990,  1026,   996,     0,
     963,   811,   846,   855,   878,   882,   929,   909,  1030,   926,
       0,  1004,     0,   905,     0,     0,     0,   914,   876,     0,
     729,     0,   731,     0,   730,   743,     0,     0,   749,   747,
       0,   749,     0,   749,     0,     0,   723,     0,   725,   743,
       0,     0,   711,   967,   968,     0,     0,   131,   130,  1054,
     240,     0,     0,   241,   824,   177,     0,     0,     0,     0,
       0,   527,   528,    81,    88,    82,    89,     0,   385,     0,
     386,   388,   202,    73,     0,   335,     0,     0,   339,   329,
     331,     0,     0,   766,   774,   345,   328,   580,   579,   578,
     575,   574,   582,   581,   577,   576,     0,   823,     0,   231,
     235,   236,   234,   226,   229,   245,     0,     0,   315,     0,
       0,   761,     0,     0,   269,   216,   274,   275,     0,   297,
       0,   460,     0,     0,     0,     0,   490,     0,     0,     0,
     491,   495,   492,   503,   486,   549,   550,   547,   548,     0,
     520,   485,   674,   673,   672,   671,     0,   447,  1056,     0,
    1036,   982,   992,   798,  1032,   795,  1013,     0,     0,     0,
     987,     0,  1082,     0,   927,     0,   930,   911,   907,     0,
     913,   733,   741,     0,   721,     0,   748,   744,     0,   745,
       0,     0,   746,   735,     0,     0,   741,     0,   756,     0,
       0,     0,   663,   117,   846,     0,   242,   220,   167,   176,
     168,     0,   169,   170,   382,   384,   191,     0,   337,   336,
     334,   330,   332,     0,   519,     0,   333,     0,     0,   223,
     252,     0,   214,   314,     0,     0,   309,   269,     0,     0,
       0,   204,   298,     0,   291,     0,     0,   462,   463,   464,
     470,     0,  1070,   488,   500,     0,     0,   489,     0,   498,
     499,     0,   487,   471,     0,   450,     0,   956,     0,     0,
     997,   928,  1003,   915,   732,     0,     0,   734,     0,     0,
     737,   739,     0,     0,     0,     0,     0,  1067,   757,   708,
     710,   140,     0,   184,   200,   519,     0,   516,   327,     0,
     230,     0,   257,     0,   316,   317,   313,     0,   205,     0,
     267,   268,   296,   591,   759,     0,     0,   468,   467,     0,
       0,     0,   496,   497,     0,   502,   759,   629,     0,   957,
       0,   742,   751,     0,   738,   736,   726,     0,   728,   245,
     192,   590,   590,   193,   190,   515,   518,   517,     0,   249,
     250,   251,     0,   232,   253,   254,     0,     0,   265,   457,
     465,   469,     0,   501,   493,     0,     0,   958,   740,     0,
     727,   252,     0,     0,     0,     0,     0,     0,   255,     0,
     256,     0,     0,     0,   355,   356,   320,   470,   494,   552,
     750,   257,   194,   195,     0,   262,     0,   261,     0,   259,
     258,     0,     0,   361,     0,   322,   324,   325,   321,     0,
     318,   323,   326,   466,   551,     0,   333,     0,   260,   264,
     263,     0,   365,   357,   303,     0,   535,   546,   534,   536,
     544,   541,   543,   542,   540,   243,     0,   360,   364,     0,
     358,   319,     0,   545,   539,   662,   653,     0,     0,   537,
     546,   320,   365,   538,     0,   359,   304
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,    42,    43,    44,    45,   799,    46,    47,    48,  1115,
    1493,   615,    49,  1222,  1532,    50,   789,    51,    52,   586,
     858,  1227,    53,   476,  1059,  1060,  1061,  1446,  1726,  1062,
    1046,   749,  1063,    54,    55,    56,   743,  1035,    57,    58,
    1746,   880,    59,   337,    60,  1509,  1766,  2193,  2244,   346,
    1128,  1983,  1984,    61,   368,  1551,  1552,  1553,  1554,  1529,
    1807,  1808,  1809,  1555,  1556,  1105,   810,  1124,  1125,  2202,
    2253,  2254,  2255,  2299,  2024,  2141,    62,  1241,  1557,  1558,
      63,  1238,  1548,  1064,  1048,  1049,    64,   369,  1832,  2144,
    2029,    65,   397,    66,   861,  1234,  1235,  2019,  2134,  2206,
    2309,  2310,  2126,  1988,  1989,  1990,    67,    68,    69,    70,
     812,  1198,  1199,  1772,    71,  2284,  2285,   370,  2340,    72,
      73,   398,   618,  2217,    74,    75,   527,  1499,    76,   415,
     416,   417,    77,    78,   433,   434,   435,   907,  1592,  1593,
    1861,   465,  1285,  1286,    79,   371,  1838,  2146,  2147,  2148,
    2149,  2218,    80,   372,   883,  1258,  1259,  1260,  1773,  1261,
    2043,  2044,  2153,  2163,    81,    82,  1251,    83,  1267,   581,
      84,  2197,    85,    86,   458,   928,    87,  1478,  1106,    88,
    1565,  2328,  2342,  2343,  2344,  2049,  2315,    89,  2330,    91,
      92,    93,   762,   122,    94,    95,    96,  1220,  1528,  1792,
      97,    98,    99,   849,   100,   101,   102,   103,   104,   403,
     491,   769,  1074,   105,   106,   644,   924,   107,   621,   108,
     109,   110,   913,  1294,  1295,   111,   112,   920,  1302,   113,
     114,   603,   115,   712,   117,   118,   119,   897,  1281,   448,
     776,   469,   501,   502,  1079,  1080,  1460,   783,  1095,  1087,
    1090,  1952,  2102,   784,  1093,  1463,  1432,  1709,  1710,  1711,
    1934,  1945,  2087,  2180,  1712,  1713,   876,  1539,  1540,  1262,
    1208,   835,   713,   714,   715,   952,   961,   946,   838,   716,
     717,   718,   841,   719,   720,   721,   722,   935,   989,  1810,
     723,   724,   970,  1216,   725,   726,   983,  1392,   997,   583,
     727,  1027,   894,  1347,   729,   976,   985,  1329,  1922,  1330,
    1340,  1635,  1349,  1355,  1662,  1663,  1367,  1401,   730,  1312,
    1313,  1616,   937,   731,   732,   636,   733,  1596,  1069,  1070,
    1597,  1598,   735,   908,   489,  2176,   745,   503,  1574,  2150,
     341,   445,   736,   737,   738,   739,   616,   442,   740,   554,
    1200,   339,   340,   556,  1204,   443
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -2124
static const short yypact[] =
{
    2407,   -76,   436, -2124, -2124,   -76, -2124, 24118, 24118,   276,
     -76,   447, 26785, 24416, 24118,   394,  1259,   -76, 24118,    90,
   16536,   867,   370, 21138,   209,   297, 16536, 21138, 24118,   376,
   21436,   464,   -76,   176, 24714, 21734,   365,   297, 15021, 19946,
     530,   -55,   694,   398, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124,   487, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124,    68, -2124,   492,    69,
   -2124, -2124, -2124, 24118, 24118, 19946, 24118, 24118, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124,   481, -2124,  1405, -2124, -2124, 21138, 19052, 24118,   465,
     563,   562, 24118, -2124, 21138,   682, 24118,   802, 13753,   590,
   24118, -2124, -2124, 24118, -2124, 21138, -2124, 24118,   460,   626,
     788,   731,   271, 24118, -2124, -2124,    97, 19946, 19052, 24118,
     524, -2124, 24118, -2124, 19052, 24118, -2124, 14070, -2124, 24118,
   -2124, -2124, -2124, 24118, -2124, 24118, -2124,   725, 21138, -2124,
     551, -2124,   487,    22,    70, -2124,    71,    72, -2124, -2124,
      73,    74,    75, -2124,   574,   102,   586, 24118, -2124, -2124,
     678, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124,   707,   624, -2124, 21138, -2124, -2124, -2124,
     634, -2124, -2124, -2124, -2124, -2124, -2124, -2124, 21138,   102,
     586, 24118, -2124, -2124,   642, 24118, -2124, -2124, 21138, -2124,
     972,   722,   859, -2124,   845,   867, -2124, -2124,   842,  8478,
   22032, 25012,    25, 22330,   741,   910, -2124,   -71, -2124,  1039,
     768,   949, -2124,   955, 21138, -2124, -2124, 12859,   890,   827,
   -2124,  1050,   868,   875, -2124,  2407, 21138,   490,   490,  1165,
     490,    64,   391,   533, -2124,   441, -2124,   106,    26,  1029,
     327, 21138, 19052, -2124, 24118, -2124, -2124, 19052, -2124, 14387,
   24118, -2124, -2124, -2124, 24118, -2124, -2124, 21138,   898, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
     904, -2124,   634,   906, -2124,   911, -2124,  1177, 26204,  1217,
   24118,   945,  1217, -2124,   914, -2124, -2124,   945, -2124, -2124,
   21138, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124,   906, -2124, -2124,   915, -2124,  1221,  1223,   195,    63,
     945, 21138, 21138,  1105, 21138, 24118, 19052, 24118, 21138, -2124,
   -2124,  1031, -2124,  1180,   970,   941,   107, 26204, -2124,   942,
   -2124, 21138,   943,  1081,  1083,   944, -2124, 18454,    44, -2124,
    9441,  1137,    22, -2124, -2124, -2124, -2124,   586, 24118, 24118,
   -2124, -2124, 20244,   834,    28, 15320, -2124,   -10, -2124,   586,
   24118, 24118, -2124, 26204,  1258,  1173,  1173, -2124, -2124,  1131,
    1179,  1093,   959,   981,   294,   983,  9441,   963,    45,    45,
     965,   966, -2124,   967,   968, -2124,  -108,  -108,  1090,   973,
     976, -2124,  -102,   998,  1001,   377,   984,   985,   881,    45,
    9441, -2124,   986,   396,   987,   989,   991,  1004,   993, -2124,
    1015,   995,   461,   528,   996,   999, -2124,   973, -2124,    47,
     403, -2124, -2124, -2124, -2124,   634,  9441,  9441, -2124,  9441,
    9441,  8799, -2124,   209, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124,    48, -2124,   410, -2124,  1820,  9441,  4985, -2124,
   -2124, -2124,  1005,   -15, -2124,   634,  1006, -2124, -2124, -2124,
   -2124,   457, -2124,   118,   992, -2124,   473, -2124, -2124, -2124,
   -2124, 18154,  1305, -2124,   182,  1183, 15918, 15918, -2124, -2124,
    1187,  1196, -2124, -2124, 21138, -2124, 24118, -2124, -2124,   487,
   -2124, -2124, -2124,  1024, -2124, -2124,   -55,   -55,  9441,   -55,
     -57,   125,   675,  1222,    33, 25012, -2124, -2124, -2124,  1069,
      56,  1302,   557,  1302,  1092,  1091, 19946, 25012, -2124, -2124,
   -2124, -2124,  1032,  1170,   942,  1034,   335,  1172,  1224, 24118,
    1067, 18754, -2124,  1038, -2124,  1077, -2124,  1077,  1077,  1041,
    1041,  1042, -2124, -2124, -2124,  1077,  1043, -2124, 26502, -2124,
     -98,   437, -2124, -2124,  1351, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124,   115,   634, -2124, -2124, 21138,
    1363, -2124, 26204, -2124,  1301, -2124, 14387, 24118,   380, -2124,
   -2124,   165,  1052, -2124, -2124, -2124,   -22, 18454,  1274,  1191,
     942,  1364,   898, -2124,  1277,  9441, -2124, 15619, -2124, -2124,
   -2124,  1367,  7529,   107,  1104, 25310, 21138, 21138, 24118, -2124,
     107, -2124, 21138, -2124, 17280,   390, 20542, -2124, -2124, 24118,
   -2124, -2124, 24118, 19052, 24118, 24118, 21138,  1126,  1059, -2124,
    1106,  1065, 13157, -2124, -2124, -2124,   634, -2124,    91, 21138,
   -2124, 24118, -2124, -2124,   542, -2124,    22, -2124, -2124, -2124,
   -2124, -2124, 20244,  9441, -2124,  1072, 17280,  1107,  9441, -2124,
   -2124,  9441,  9441,   574,   574,   574, -2124, -2124, -2124, -2124,
     402,   574, -2124,   574,   574,  1077,  1077, -2124,  5726,  9441,
     574, -2124, 14387,  9441,  9762,  6586,  9441,  1138,  1139,   574,
   -2124,   574, -2124,  9441,  7836, -2124,  1079, -2124,    42,    42,
      96,    85,   420,  1078,  5008,  1075, -2124,  1169,   574, -2124,
     574,   544,   973,    82,  1284,  1084,   244, -2124,    67,   111,
    9441, 18754,  1150,  9762, 24118,  9441,  1086,   609, -2124,  9441,
     526, -2124,  1087,  9441,  1153,    78,  9441,  9441,  9441,  9441,
    9441,  9441,  9441, 11031, 11337, 26204, 10083,   134,  1079,  8478,
    1310,  1079,  6264, -2124, -2124, -2124, 24118,  1305, -2124, -2124,
    1155, -2124, -2124, -2124, -2124,   442, -2124, -2124, -2124, -2124,
     469, -2124, -2124,   535, -2124, -2124, -2124, -2124, -2124, -2124,
    1094, -2124, -2124, -2124, -2124, -2124, -2124,   535,  1097,   -12,
   -2124, -2124, 19648, 24118, -2124, -2124,  1289, -2124, -2124,  1096,
   -2124,  4229,  1289,  1239,  1249, -2124, -2124,   -45, -2124, -2124,
    1285, -2124, -2124, -2124, -2124, -2124, -2124, 24118,  1110, -2124,
   24118,  1293,  1294,  1114, -2124, -2124, 24118, 24118, 24118, 24118,
   24118,  1185, 24118,  1228, -2124,  1720, 15619, 21138,  1311, 25310,
     -36, 21138, 21138,   -36,   543, -2124, -2124,  1255,    27, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,   558, -2124,
    1130, -2124, -2124, -2124, -2124,  9441, -2124, 26204,  1129,  1192,
    1195,  1199, -2124, -2124,  1200,   574, -2124, -2124,  1341,   165,
     593, -2124,   -78,  1359, -2124, -2124,   667, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124,  1276,  1273, 24118,  1720,   493, 21138,
   19350,  1448,  1352,   209, 21138,  1245, -2124,  1455,   -55, 17280,
   -2124,  1149, -2124, 26204, -2124,   663,   698, -2124,   578, -2124,
   26204, -2124, -2124,   634, -2124, 24118,  1158,  1163,  1166,   107,
     107, -2124, -2124, -2124, -2124,  9441,   844,   872, 21138,   716,
    1101, -2124, -2124, -2124,   992,  1167, -2124,   942,   992,   992,
    1059, 22628, -2124,  8157,   613, -2124, -2124, -2124,    61, -2124,
      95,   -39,  1316, -2124, -2124, -2124, 26204, -2124,  1384,   621,
     574,  9441,   120, -2124,  5214,   629,  5520,   635,  1168,  1174,
     638, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,  1175,
    1390,  1178,  1181,  1182, -2124, -2124,  4024,   646,  1184,  5632,
    1186,  9762,  9762,  9762,  9762,  8799,  9762,  1746, -2124,  1193,
   -2124,  1194,  5872,  4801,  1176,  1197,  1205,  1211,  1201,  1202,
   16821,  9120,  9441,  9120,  9120, 16841,  1176,  1206,  9441,  1079,
   -2124,   634,  9441, 24118,  1207,  1209, -2124, -2124,  1408,  1356,
   -2124,   973, 14387,   993,  9441, -2124, -2124, -2124, -2124,  8799,
   -2124, -2124,   973,  5726, -2124,  1237,  1021, -2124,  2452,  8799,
   -2124, -2124,  1412, -2124,   483, -2124,  1213, -2124, -2124,  3922,
    9762,  9441,  1086,  9441,  1279, 14387, 17308,  9441,  2736, 17338,
   17338,    89,    89,    96,    96,    96,    85, -2124,   111,   973,
   -2124, 12561,   970,  9441,  9441,  1219, -2124,   666, -2124,  1401,
   -2124, -2124,   574,   544,  1493, -2124,  1337, 16223, -2124, -2124,
   24118,   970,   554, -2124, -2124,   701,  9441, -2124, -2124,   699,
   -2124, -2124, 24118, -2124,   675,   675,   125,   944,  9441,    65,
    1229,  1231, 24118, -2124, 26204,   105,   107,   107,  1291, -2124,
   -2124, -2124,  1295, -2124, -2124,  1360,  1446, -2124, -2124,   209,
     574,  1375,  1299, -2124,  1256,  1423,   -36,  1257, -2124, -2124,
   -2124,  1439,  1441, -2124, -2124, 24118, -2124, -2124, -2124,   325,
   -2124, 18754, 14704, 16864,  1129,  1260,   484,    39,    12,  1354,
    1421,  1262,   906,  1402,  1281,  1281,  1281,  1281, -2124,   997,
     574, 24118, -2124,  1319,   380,  1339,  1306, 21138,   165,   703,
   -2124, 26204,   603, -2124,   603,   603,   603,   603, -2124,  1271,
   21138,  1278,  1269, -2124, -2124, -2124, -2124,   709, -2124, 26204,
     -55, 21138,  1340,  1321, 26204,  1417,   -55, -2124,   107,  1280,
   -2124, 25608, -2124,  1287,   107, -2124, 26204,   107, 25906, -2124,
   -2124, 17280,   297,   297,   297,   297, -2124, 21138, 21138, 19052,
   -2124, 24118,   349, -2124, -2124, -2124, -2124,   717, -2124,   245,
   24118,  1079, -2124, -2124, -2124, -2124,  1514,  1515, -2124, -2124,
   22628, -2124,  1286, 16884,  9441, -2124,  1521, 26204, -2124, 21138,
   -2124, -2124, -2124, -2124,   574, -2124,  9441, -2124, -2124, -2124,
    9441, -2124,   574, -2124,  9441,  1505, -2124,  1288,  1288,   610,
    1288,  5008,   938,  9762,   384,   987,  9762,  9762,  9762,  9762,
    9762,  9762,  9762, 11643, 11949, 26204, 10710, -2124, -2124, -2124,
    9441,  9441,  1512,  1505, -2124, -2124, -2124,   887,   887, 26204,
    1292,  1176,  1296,  1297,  9441, -2124,  2853, -2124,  4476, -2124,
    1578,   209,   244, -2124, -2124,  1298, -2124, 10404,  9762,  9441,
     724,  9441, -2124, -2124,  1300, -2124, -2124, 26204,  9441,  1164,
   16925, -2124, 17433,  9441,  1303, 17492, -2124, 12255, 22926,  1290,
     411, -2124, 22926, 23224,  1005,  1309,  1506,   727,   729, -2124,
   -2124,  1477,  1313, -2124, -2124,   -50, -2124, -2124, -2124, -2124,
    9441, -2124, -2124, -2124,   992, -2124, -2124, -2124, 16909, -2124,
   24118, 24118,   737, -2124,   129,   567, -2124, -2124, -2124, 24118,
   24118,   209, 24118, -2124, -2124,   209,   209,  1487,   -36, -2124,
    1488,   -36,   -36, -2124, -2124, -2124,    66, -2124, -2124,  1084,
     442, -2124, -2124, -2124, -2124, -2124, -2124,    99,   895, -2124,
    1307, -2124, -2124, -2124, -2124, -2124, -2124, -2124,   544,  1587,
   21138, -2124,    55,    37, 23522, 23820,  1312, 24118, 24118,  9762,
   -2124,   468,    76, -2124,  1496, 21138, -2124, -2124, -2124, -2124,
   -2124, -2124,   944, 26204, 21138,  1537,  1450, -2124, 24118, -2124,
   -2124, -2124, -2124, -2124, -2124, 19350, -2124,  1517, 19350, -2124,
   24118, -2124,  1361, -2124, -2124,   914,   209, 24118,  1320,   705,
     228, -2124, -2124,   107, -2124,  1372, -2124, -2124, -2124, -2124,
   -2124, 21138, 21138, 21138, 21138, -2124, -2124, -2124, -2124,  1533,
   22628, -2124, -2124,  8157,  1323, -2124, -2124, -2124, -2124,  1325,
   -2124,  9441, 17280, -2124,  1324,  1330,  1331, 17280, 17097,  1332,
   17280,  1512,  1728,  1540,  1468,  1334,  1728,  1589,  1589,   597,
     597,   610,   610,   610,  1288, -2124,   938, 17280, 17280, -2124,
   -2124, -2124, -2124,  1335, -2124, -2124, -2124,  1176, -2124,  9441,
    1079, -2124,   544, -2124, -2124, -2124,   835,   340, -2124,   217,
   26204, -2124,   744,   340,  9762,  9441,  9441, 17526,   146,  9441,
    7230,   411,  1336, 24118, -2124,  1338, 12561,  1522,  1469, -2124,
   12561,  1469,   732,  1469, 12561,  1523, -2124, 13455, -2124,  1342,
    6908,  1635,  1553, -2124, -2124,   535,   209, -2124, -2124, 17280,
   -2124,   749,   750, -2124,   997, -2124,  1491,  9441,  1494,   454,
   24118, -2124, -2124, -2124,   944, -2124, -2124,   -36, -2124,   -36,
   -2124, -2124, -2124,   945,  1592, -2124,   471,  1599, -2124,  1549,
     136,  1568,  1569, -2124, -2124, -2124,  1572, -2124, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124,  9441, -2124,   773,  1728,
   -2124, -2124, -2124, -2124, -2124,   898,  1400,   -19,  1595,  1588,
     165, -2124,  1362,  1366,   918, -2124, -2124, -2124, 21138,  1541,
    1576, -2124, 19052,   209,  1501,  1466, -2124, 18454,  1518,   348,
   -2124, -2124, -2124,  1051, -2124, -2124, -2124, -2124, -2124,  1437,
   -2124, -2124, -2124, -2124, -2124, -2124,  1510, -2124, -2124,  8157,
   17280, -2124, -2124, -2124, -2124, -2124, -2124,  9762,  1378, 26204,
   -2124, 17191, -2124,   751, -2124, 26204,   835,   340,   340,  9441,
     340, 22926,  1380, 24118,   411, 12561, -2124, -2124,    31, -2124,
   12561,  1564, -2124, -2124, 12561, 24118,  1383, 24118, -2124,   757,
    9441,  9441, -2124, -2124,   544,  1497, -2124, -2124, -2124, 17280,
   -2124,   574, -2124, -2124, -2124, -2124, -2124,   209, -2124, -2124,
   -2124, -2124, -2124, 19052,  1695, 21138,    99, 17250,  1534, -2124,
    1556, 24118, 19350, -2124,   572,  1508, -2124,   918, 21138,  1530,
    1531, -2124, -2124,   209, -2124, 21138,  1394,  1391, -2124, -2124,
   20840,  1397,   914, -2124,  1393,  1546,   404, -2124,  1548, -2124,
   -2124,   906, -2124, -2124, 21138, -2124,   758,  1253, 26204,   763,
   -2124, -2124, -2124,   340, -2124, 24118,   791, -2124,  9441,  1403,
   -2124, -2124, 12561,    31,   792, 24118,   810, 26204, -2124,  1176,
   17280, -2124, 21138,   100, -2124,  1695,   160, -2124, -2124,  1636,
   -2124,    62,  1554,  1723, -2124, -2124, -2124, 19052, -2124,   838,
   -2124, -2124, -2124, -2124,   970, 24118, 21138, -2124, -2124, 24118,
     209,  1613, -2124, -2124,  1565, -2124,   970, -2124,   839, -2124,
     840, -2124, 17280, 24118, -2124, -2124, -2124,   841, -2124,   898,
   -2124,  1217,  1217, -2124, -2124, -2124, -2124, -2124,  1656, -2124,
   -2124, -2124,    87, -2124,  1558,  1561,   326,  1426, -2124, -2124,
   -2124, -2124,   849, -2124, -2124,  1622,  1669, -2124, -2124,   855,
   -2124,  1556,   209,   209,  1528,   289,   289,  1676, -2124,  1479,
   -2124,   574,   574, 26204,  1429, -2124, 17849, 20840, -2124,  1623,
   -2124,  1554, -2124, -2124,  1664, -2124,  1755, -2124,   103, -2124,
   -2124, 19052, 14387, -2124,   326, -2124, -2124, -2124, -2124,   858,
   -2124, -2124, -2124, -2124, -2124,   372,    99,  1555, -2124, -2124,
   -2124,   942,   -79, -2124, -2124, 17849, -2124,   409, -2124, -2124,
   -2124, -2124, -2124, -2124, -2124, -2124, 19052, -2124, -2124, 25310,
   -2124, -2124,  -116, -2124, -2124,   680,   875,  1440,  1443, -2124,
     409, 17849,  1559, -2124,   863, -2124, -2124
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
   -2124, -2124, -2124,  1275, -2124,  -542, -2124, -2124, -2124,   908,
   -2124, -1043, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
     548, -2124, -2124,  -381,  1011, -2124,   328, -1028, -2124, -2124,
   -2124, -2124,  -605, -2124,   301, -2124, -2124, -2124, -2124, -2124,
   -2124,  -597, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
   -2124, -2124, -2124,  -812,   555,   -51, -2124,   -48,   676,    43,
   -2124,  -223, -2124, -2124,  1002,   319,  -854, -1321,   284,  -476,
    -493,  -456,  -454,  -475, -2124,  -335, -2124, -2124, -2124,   -26,
   -2124, -2124, -2124,  -709, -2124,  -164, -2124, -2124,  -222, -2124,
   -2124, -2124,  1444, -2124, -2124,   589, -1476, -2124, -2124, -2124,
    -539,  -510, -2124, -2019,  -174,  -172, -2124, -2124, -2124, -2124,
    -576, -2124,   308, -2124, -2124, -2124,  -484,   971,  -530, -2124,
   -2124, -2124, -2124,  -322, -2124, -2124, -2124, -1074, -2124,  1801,
      38,    41,  -811, -2124,  1369, -2124,  1203,   896,   219,   -28,
   -2124, -2124, -2124, -1528, -2124, -2124, -2124, -2124, -2124, -2124,
    -378,  -448, -2124,   616,  -789, -2124,   272, -2124,   282, -1146,
   -2124,  -196, -2124, -2124, -2124, -2124,   734, -2124, -1096,  -379,
   -2124,  -344, -2124, -2124, -2124,  1212, -2124, -2124,   414, -2124,
   -2124, -2124, -2124,  -463,  -497, -2124, -2124, -2124,    60, -2124,
   -2124, -2124, -2124,   582,  -807, -2124, -2124, -2124, -2124,  -302,
   -2124, -2124, -2124,  -551, -2124, -2124, -2124,   783,  1838,   -49,
   -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124, -2124,
    -347, -2123, -2124, -2124,   260, -1709, -2124, -2124, -2124, -1665,
   -2124, -2124,  -627,     0,   -40,   421,   443,  1132, -2124,   -20,
     739, -2124, -2124, -2124, -2124,   407, -2124,  1085, -2124,   405,
    -489, -2124, -2124,  1089, -2124, -2124,   801, -2124, -1644,   166,
   -1647,   -68,  -808,  -307,     5, -2124, -1394, -1588,    79,   668,
     683,  1060, -2124,  2101,  2390, -2124, -2124,  -538, -2124, -2124,
    2616,  2816, -2124, -2124,  2898,  2911, -2124,  -511,   213, -1674,
    3296,  1750,  -666,  -962, -2124,  -946,   931,   871,  -352, -2124,
    4089,  -673,  3995,   537,  1018,  -698,  -502, -2124, -1835, -2124,
   -2124, -2124, -2124, -2124, -1082, -1562,  -254,   497, -2124, -2124,
     598, -2124, -2124, -2124,   298,  -647, -2124,  -410, -2124,   452,
    -148,    49,  1484,  -446,   958,  -450,   215,   296, -1757,  1304,
    1318, -2124,  -133, -2124,   186,     4,   -91,    -4,  3297, -2124,
     921,  2183,  -771,  -769, -2124, -2124
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1253
static const short yytable[] =
{
     116,   493,   637,   338,   342,   855,   582,   914,   612,   375,
     375,   852,   890,   863,   375,  1118,   375,   484,  1247,   851,
     744,   893,   375,  1497,   375,   853,   463,   972,   446,  1376,
     477,   482,   562,   505,  1028,   582,   510,  1031,  1716,  1448,
    1202,   492,  1203,   589,   488,  1047,  1228,  1229,   864,  1503,
    1385,  1230,  1391,   998,  1467,   496,   623,  1729,   977,   734,
      90,  1857,  1816,  1931,   450,  1946,  1948,   451,  -654,  -657,
   -1104, -1114, -1159, -1196, -1214, -1221,   619,  1386,   878,   862,
    2031,  1245,  1387,   794,  -820,  2073,  -815,   987,  -864,  1004,
     747,  1937,   753,  -864,    14,  1431,  1298,  1098,   748,    15,
    1899,   910,     3,     4,  1099,  1002,  1098,  2199,  1100,  1002,
    2000,   918,   405,   790,  1572,  1995,  1002,   791,   895,   504,
     506,   896,   375,   506,   600,  -654,  -657,  2240,  1997,   947,
     507,  1002,  1004,  2338,  1507,  1085,  1004,  1957,  1464,  1938,
     805,   878,  1498,  1004,  1386,  -203,  1039,   939,   940,  1387,
    2012,  1742,    22,  1083,  1602,  1781,  -878,  1939,  1004,  1239,
    1101,  -878,  1239,  1378,  2275,   972,   780,   582,   957,  1101,
    2249,  1784,  1940,  1985,  1530,    33,  2319,  1941,  2241,  2246,
    -654,  -657,   781,  1209,  1299,  1606,   467,   120,  1604,   756,
    1744,   792,  2331,  1033,  -800,   967,   968,  1942,  1782,  1217,
    -794,  1531,  1965,   859,  2331,   808,   419,  1614,  2349,   408,
    1985,  2350,   419,   781,   553,   945,   782,  2178,   860,   121,
    1084,   951,   795,   409,  1986,   969,   601,  2331,   374,   376,
    1202,  1210,  1203,   400,  2169,   418,  1034,  1002,  1607,   757,
    1785,   452,  1231,   454,  2339,   605,  1958,   782,   854,  1007,
    1008,   609,    33,  1943,  2013,  1041,  1379,   468,    33,  2250,
    1380,  1102,  1242,   879,  1004,   567,   444,  1783,    41,  1297,
    1102,   625,   868,  1987,  1211,   898,   590,  1212,  2242,  1369,
    2247,  2320,   947,  1465,  2243, -1194,  1264,  1508,  1011,   884,
    2107,  1383,  2084,  1272,   610,  1232,  2088,  2335,  1603,    39,
    2093,  1240,  2251,  1966,  2132,  2045,   939,   940,   626,  1388,
    1987,  2179,   911,  1029,   957,  1300,  1450,   824,   919,  2066,
    -864,   439,   793,  2295,   602,   439,   879,   444,  1301,  1103,
    1944,   934,  1605,  2228,  1042, -1194,   439,   439,  1103,   444,
    1745,   509,   767,  1213,   375,    41,  1982,  -820,   504,  -815,
     564,   912,   506,   622,   584, -1253,   587,   444,  2046,   375,
    1002,   564,   413,   506,  2276,  1003,  1774,  1025,  -820,   375,
    -815,   988,   892,  1452,  2203,   375,  1388,   401,   504,   802,
     596,   506,   604,   584,   804,   375,   811,  1004,  -878,   375,
    1389,   506,  -654,  -657,   564,  -654,  -657, -1104, -1114, -1159,
   -1196, -1214, -1221,   116,  1096,  1021,  1022,  1023,  1024,   413,
    1025,  1311,  1214,   375,  1025,  1024,  1114,   414,  1774,  1961,
    1962,  1025,  1759,   439,  2159,  1019,  1020,  1021,  1022,  1023,
    1024,  1309,   413,  1086,  2174,  2281,  1025,  1226,  1215,  1315,
    1317,  2177,  1233,   455,  1334,  1335,  2181,   375,   787,    15,
    2183,   375,  1284,   627,  1288,  1289,   628,   629,  2047,  2296,
    1290,  1006,   343,   870,  1354,  1883,   375,   477,  1383,   477,
    1321,  1937,  1366,  1120,   345,    33,   750,  1224,  1007,  1008,
    2222,  1723,  1043,  1044,   444,  2160,    15,   639,  1812,   413,
     640,   641,    21,  -686,   751,   116,   597,  1045,  1590,   456,
     774,   377,    22,   123,   582,  2048,   436,  2184,  2297,  2186,
     375,   444,  -662,  1037,  2282,   584,   375,  1011,  1322,  1938,
     375,  1121,  -662,   564,  2298,  1542,   788,  1218,  1012,  1864,
    1437,  1019,  1020,  1021,  1022,  1023,  1024,  1939,  2234,    22,
    -686,  2223,  1025,  2010,  2136,    30,  2118,  2326,    27,   124,
     447,  1410,  1940,  1881,  -662,    90,   375,  1941,  1884,  1543,
     598,  1323,   797,   557,  1324,  1885,   564,  1384,    41,  -662,
    1273,   775,  1764,  1765,  -686,  2283,   464,  1942,   588,  1307,
     934,  1900,  1692,  1338,   497,    27,  2011,   128,   599,  2119,
     564,   342,   344,   375,   606,  2195,  -820,  2237,  1601,   399,
     624,   419,    33,  -662,   613,  1099,  2332,   564,   614,  1108,
     582,  -662,  1209,   891,   466,  1544,  1573,  -820,  2332,  1430,
     798,  1567,   116,  1455,   375,   375,   498,   444,   483,   457,
    1325,   917,   630,  1943,   116,   419,   375,   375,   490,    33,
    1967,  2332,  1859,  1411,   439,   551,  1015,  1412,   561,    39,
    2333,  1545,   563,  1546,  1019,  1020,  1021,  1022,  1023,  1024,
    1210,  1693,  2333,   563,  1694,  1025,   642,   511,   899,   949,
     645,   493,  1579,  1580,  1413,   439,   551,  1860,   608,  -829,
     921,  1524,   551,   499,  1978,  2333,    39,  1980,  1981,   125,
    1402,   591,  -662,   408,   494,  2327,   563,   975,  -797,  1326,
    -829,   126,  1327,  1211,  1328, -1093,  1212,   409,  1403,  1974,
    1944,   982,   444,   592,  1274,   127, -1250,   986,  1275,   960,
    1072,  2033,  1228,  1229,  1677,   495, -1095,  1230,   991,   803,
     967,   968,    41,   990,   439,   806,  1913,  1547,  2034,   807,
    1202,  1968,  1203,  1440,   770,  1444,   439,   891,  1525,   413,
    1695,    30,   891,   891,   967,   968,   439,  1696,  1052, -1094,
     971,   413,  1071,  -832,   500,  1414,  1225,  1445,   785,  2111,
    1287,   444,  1213, -1250,   401,   850,  1075,  1075,   355,  1075,
   -1096,   477,   439,  1404,   969,   439,  1733,  1405,   558,  1526,
    1406,   413,  1442,   477,   439,  1495,  2204,  1271,   559,  1501,
    1502,  1113,  2035,  1771,   786,  1126,  1779,   585, -1250,   439,
     551,   800,   871,  1969,  1796,   551,  1970,  2205, -1250,   357,
    2259,   967,   968, -1250,  2036,   563,  1994,   560, -1250, -1250,
    -832, -1250,  2266,  1820,   388,  1821,  1822,  1823,  1824,  1775,
    1938,  1214,   594,   900,   901,   564,  1799,   607,  1527,  2037,
   -1250,   971,   584,   506,   595,   922,   923,   359,  1939,  1366,
    1671,  1366,  1366,   891,  1730, -1250,  1305,  1504,   563,   617,
    1306,  1505,   493,  2090,   620,  1368,  1407,   420,  1941,  1747,
    1748,   413,  1510,  1408,   506,   631,  1511,   995,   564,   439,
     439,   421,   563,   632,   551,   375,   439,  1690,   375, -1250,
     375,   375,  1570,  2114,  1044,  2115,  1571, -1250,  1296,   563,
     413,   422,   492,  1651,  1652,  1653,  1654,   375,  1045,   955,
     956,   361,  1655,   362,   421,  2038,   116,  2103,   423,  1654,
     439,  1717,  1718,  1831,  2039,  1655,   565,  1599,   566,  1841,
    1051,  1600,  1051,  1051,   422,  1611,  1789,  2128,  2040,  1275,
    2072,  1803,   633,  1618,  1943,  2041,  -473,  1275,   584,  1620,
     635,   423,  1623,  1275,   424,   643,  1624,  1088,  1091,   447,
    1631,  1842,  1865,  1644,  1632,  1735,  1736,  1846,  1804,  1910,
    1848,   441,   413,  1089, -1171,   453,  1805, -1171, -1250, -1171,
    1720, -1171,  1377,   647,  1275,  2042,   486,   424,  1390,   649,
    1397,  1901,  1902,  1685,   770,   571,  1400,  -654, -1250,   572,
     573,   574,  1734,   575,   576,   577,   578,   579,   580, -1206,
     648,  1481, -1206,  1645, -1206,  1731, -1206,  1817,   652,  1036,
     582,  1818,   375,  1829,   650,  1688,  1704,  1830,  1796,   754,
   -1250,  1862, -1250, -1250,  1797,  1863,  1806,   425,  1918,  1798,
     755,  1953,  1275,  1954,  1443,  1275,   568,  1275,   569,   426,
     758,  1963,   439,   582,   427,  1505,   759,  2033,  2074,   375,
    1799,  1800,  2075,  2105,  2106,  2171,  1644,  1505,  1505,  2075,
     425,  2188,  2227,   508,  2034,  1275,  1863,  2229,   428,   760,
     429,  2075,   426,   506,   439,   761,   375,   427,  1582,   430,
    1583, -1252,  1474,  1475,   375,  1477,   375,  1670,   506,  1672,
    1673,   431,   432,   564,  1283,  2231,  2236,   564,   564,  1036,
    1818,   428,  1801,   429,  1500,   766,  1584,  1500,  1585,  1318,
    1319,  1320,   430,  2089,  2238,  2092,  1304,  1331,  1818,  1332,
    1333,   704,  2191,   767,   431,   432,  1337,   563,  2035,  1649,
    1650,  1651,  1652,  1653,  1654,  1358,   768,  1359, -1252,  1644,
    1655,  2130,  2258,  2267,  2268,  2270,   919,  2075,  1036,  1818,
    2036,  1802,  1907,  2287,  1374,  1803,  1375,  1036,  1924,  2290,
     967,   968,  2324,  1036,   439,   439,  2325,  2356,  1991,  1992,
     563,  2325,   770, -1252,   439,  2037,   778,  1076,  1078,   771,
    1082,   551,  1804, -1252,   439,  1107,  1109,  1110, -1252,  1645,
    1805,  2139,  2140, -1252, -1252,   796, -1252,   439,   813,  1077,
    1077,   809,  1077,  1793,  1794,  1795,   834, -1095,  1826,   811,
     439,  1441,  1541,   848, -1096, -1252,  1559,   777,   798,   779,
   -1060,   856,   857,  2348,  -103,   874,  2050,  1562,   116,   867,
   -1252,  1438,  1649,  1650,  1651,  1652,  1653,  1654,   873,  1587,
    1588,  1575,   875,  1655,   877,   882,   885,   886,   378,   887,
    1806,  2038,   888,   896,   926,   881,   927,   379,   930,   932,
    2039,   931,   933,  -785, -1252,  -792,   938,  1594,   941,   942,
     943,   944, -1252,   948,  2040,   380,    41,  1875,  1715,   950,
    -782,  2041,  1644,  -783,   528,   493,  -786,   953,   954,   959,
     962,   925,   963,   381,   964,  1469,   965,  -784,   966,   973,
    1036,  1040,   974,  1476,   780,  1479,   382,   704, -1074,  1032,
    1053,  1646,  1647,  1648,  1066,  1649,  1650,  1651,  1652,  1653,
    1654,  2042,   383,  1067,  2161,   982,  1655,  1073,  1097,   493,
    1099,  1112,  1645,  1111,   447,  1116,  1117,  1119,  1122,   493,
    1127,  1205,  1123,   934,   945,   951,   960,  1207,   384,  1679,
     439,  1219,   385, -1252,   353,  1236,  1243,  1244,   584,  1248,
    1246,  1684,   386,  1253,  1265,  2271,  1291,   919,  1293,   982,
    1292, -1253,  1686, -1252,   634,  1310,  1356,  1357,  1311,   982,
    1368,  1521,  1370,  1372,  1373,  1381,   638,  1382,  1395,  1399,
    1415,   584,  1400,  1417,   512,   563,   646,  1431,  1439,   563,
     563,  1449,  1447,   498,  1456, -1252,  1461, -1252, -1252,  1706,
    1462,  1708,  2157,  1468,  1466,  1470,  1471,  1472,  1480,  1506,
    1512,  2116,   763,   891,  1482,   765,  1071,   387,  2099,  1496,
    1516,  1522,  1517,   513,   773,  1518,  1287,   514,   375,  1519,
    1520,  1533,  1537,  1538,  1560,  1564,  1561,   388,  1126,   801,
     704,  1566,   515,  1568,  1646,  1647,  1648,  1608,  1649,  1650,
    1651,  1652,  1653,  1654,   389,   390,  1576,  1577,   516,  1655,
     391,  1610,  1621,  1753,  1578,  1589,  1612,  1626,  1622,  1625,
    1500,  1126,  1627,  1665,  1275,  1628,  1629,   440,  1633,  1666,
    1636,   440,   392,  1767,   517,  1682,  1776,  1657,  1658,  1691,
    1221,  1664,   440,   440,   393,  1667,  1668,   506,   518,   394,
    1675,  1680,  2337,  1681,  1683,  1687,  1697,   439,   395,  1703,
    1396,  1721,   439,  1719,  1724,  1252,   564,  1725,   396,   865,
     866,  1749,  1740,  1268,  1741,  1750,   872,  1835,  1751,  1752,
     116,  1758,  1851,  1852,  1853,  1854,   116,  1649,  1650,  1651,
    1652,  1653,  1654,  1755,  1715,  1756,   439,  1761,  1655,  1762,
    1757,  1760,  1786,  1787,  1778,  2225,  1788,  1858,  1790,  1813,
     638,  1791,  1814,   519,  1825,   598,  1296,  1828,  2189,   116,
    1836,  1837,  1827,  1840,  1843,  1845,  1594,  1867,  1868,   440,
    1870,  1873,  1661,  1655,  1660,   564,  1904,   987,  1936,  1951,
    1905,  1906,  1914,  1920,  1955,  1977,  1979,  1928,  1722,  1993,
     520,   521,  1950,  1051,  1797,  2006,   522,  1956,  2014,  2018,
    2020,  2023,  2051,  2032,  2028,  2056,  2059,  2067,  2061,  2068,
    1091,  1091,  1088,  1860,  2062,  2063,  2065,  2069,   523,  2070,
    2081,  2083,  2086,  2085,  2094,  2097,  2100,   493,  2101,  2108,
     524,  2117,  2110,  2120,  1986,   525,  1754,  2123,  2124,  2125,
    2131,  2133,  2135,  2145,  2143,  1912,  2137,  2155,  2334,  2138,
    2272,  2273,  2209,  1427,   526,  2156,  2158,  2164,  1051,  2165,
    2334,  2168,  1780,  2175,  1935,  2182,  2185,  1930,  1935,  1949,
    2192,  2196,  2013,  2201,  2210,  2211,  1811,  2207,  2214,  2215,
    2219,  2220,  1068,  2334,  2221,  2230,  2233,  1644,  1051,  1714,
    1051,  1051,  1051,  1051,  2224,  2230,  1126,  1126,  2248,  2256,
    2252,  2264,  2274,  2265,  2277,   375,   375,  2279,   506,  2286,
    2288,  2289,  2294,  2275,  2314,  1973,  2276,  2304,  2317,  1975,
    1976,  2318,  1500,  2351,  2336,  1500,  1500,  2352,  1065,  2262,
     772,  2338,  1237,  1534,  2022,  1727,  1834,  1645,  1483,  1484,
    2025,  1535,  1473,  2269,  1252,  2129,  1964,  1268,  1739,  1763,
     375,   375,  1104,  2007,   375,  2291,  1999,  2001,  2316,  2280,
    2278,  2300,  2208,  1715,  2026,  2112,  2142,  1715,  1523,  1485,
    1876,  1715,  2354,   593,  1541,  2341,  2122,  2121,  1879,  1768,
    2323,  1474,  2355,  2213,  1474,  1223,  2027,   449,  1308,  1869,
     440,   552,  2057,  1575,   651,   439,   909,  2260,   552,  2313,
    2030,  1486,  1536,  1844,  1269,  1270,  1839,  2162,   563,   552,
    1494,  2245,  2329,  2353,  1282,  1453,  1594,   402,   929,  1833,
    1866,   440,   552,  1732,   638,  1030,  1644,  1643,   552,  1094,
    1451,  1737,  1092,  1932,  2091,  1515,  2235,  1303,  1637,  1638,
    1639,  1640,   552,  1642,  1644,   439,   439,   551,  1206,  1514,
     638,  1487,  1488,  1911,  2261,   704,  1351,  2021,  1429,  2151,
   -1253, -1253,  1728,  1649,  1650,  1651,  1652,  1653,  1654,  1701,
    1615,  2166,  2058,   869,  1655,     0,  1645,   563,  1489,     0,
     440,  1569,  1394,  2322,     0,     0,  1935,     0,     0,  2082,
       0,     0,   440,     0,  1645,     0,  1708,     0,     0,   916,
    1708,   992,   440,  2096,  1708,     0,     0,  1699,     0,     0,
     582,     0,  1715,     0,     0,     0,  1441,  1715,   993,     0,
    2104,  1715,     0,     0,  1971,  1972,  2113,     0,   440,     0,
       0,   440,  1490,     0,  1609,     0,     0,     0,  1998,     0,
     440,  1500,  1348,  1500,     0,     0,     0,     0,     0,     0,
    1287,  1491,     0,     0,   994,   440,   552,     0,     0,     0,
       0,   552,  1492,     0,     0,  1714,     0,     0,   995,  2003,
    2005,   552,     0,  2008,   996,     0,     0,     0,     0,     0,
       0,  1348,     0,     0,  1835,     0,     0,     0,  2152,     0,
    1454,     0,     0,   891,   704,     0,     0,  2154,  1646,  1647,
    1648,     0,  1649,  1650,  1651,  1652,  1653,  1654,     0,  1715,
       0,     0,   704,  1655,   552,     0,  1646,  1647,  1648,     0,
    1649,  1650,  1651,  1652,  1653,  1654,     0,     0,     0,     0,
       0,  1655,     0,     0,  2257,   440,   440,  1935,   552,   375,
     552,     0,   440,     0,     0,  1708,     0,     0,   439,     0,
    1708,  1541,     0,  2187,  1708,   552,     0,     0,     0,     0,
       0,     0,     0,   439,     0,     0,     0,     0,     0,     0,
       0,     0,   439,     0,     0,     0,   440,     0,     0,     0,
       0,  2194,     0,     0,     0,     0,   571,  1575,  1474,     0,
     572,   573,   574,     0,   575,   576,   577,   578,   579,   580,
       0,   564,  1743,     0,     0,     0,   564,  2212,     0,   439,
     439,   439,   439,     0,     0,  1051,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  2321,     0,
       0,   375,     0,     0,     0,     0,     0,     0,     0,     0,
    1882,  2187,  1708,  1886,  1887,  1888,  1889,  1890,  1891,  1892,
    1893,  1894,     0,  1896,     0,     0,     0,  1549,     0,     0,
       0,     0,  1563,  2347,     0,     0,     0,     0,     0,  1819,
       0,   917,   564,     0,     0,   375,     0,     0,     0,     0,
       0,     0,     0,     0,  2263,  1916,     0,  1743,     0,   375,
       0,     0,     0,     0,  1714,     0,  1586,     0,  1714,     0,
       0,     0,  1714,  1834,  1847,     0,  1850,     0,   440,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  2292,  2293,     0,     0,
     440,     0,  2312,   564,     0,  1874,     0,  2346,     0,     0,
    2311,     0,     0,     0,     0,     0,     0,  1441,   584,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   845,     0,
       0,     0,     0,     0,     0,   116,     0,     0,     0,     0,
       0,  2312,     0,  1895,     0,     0,  1833,  2345,     0,  2311,
     551,     0,     0,   552,     0,     0,  2009,  1903,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  2312,     0,     0,
     116,     0,     0,     0,     0,  2311,     0,   845,     0,  1348,
    1348,  1348,  1348,     0,  1348,  1921,     0,     0,     0,     0,
     440,   440,     0,     0,     0,     0,   552,     0,     0,     0,
     440,     0,     0,  1714,     0,     0,     0,   552,  1714,     0,
     440,     0,  1714,   845,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   440,     0,     0,     0,     0,     0,     0,
       1,     0,     0,     0,     0,     0,   440,     0,     2,     3,
       4,   551,     0,   439,     0,     0,     0,     0,  1348,     0,
       0,     5,     0,     0,     0,     0,   439,     0,     0,     0,
       0,     0,     0,   563,     0,     0,     0,     0,   563,     6,
       0,     7,     8,     0,     0,     0,     9,    10,     0,     0,
       0,  2076,   439,    11,    12,     0,     0,  2301,  2302,     0,
       0,     0,  1002,     0,     0,     0,    13,  1003,     0,    14,
    1714,  2016,     0,     0,    15,     0,     0,     0,     0,     0,
     439,     0,    16,     0,     0,  1815,     0,    17,     0,  1004,
       0,    18,     0,    19,  1050,   551,     0,    20,     0,     0,
       0,     0,     0,     0,   563,     0,     0,     0,     0,    21,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     555,     0,     0,     0,     0,     0,     0,    22,     0,     0,
       0,     0,     0,  1689,     0,  1855,  1856,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   440,    23,    24,     0,
       0,   555,     0,    25,     0,     0,     0,   555,     0, -1253,
      26,     0,     0,  1006,     0,     0,     0,     0,   845,     0,
       0,     0,     0,    27,     0,   563,     0,     0,  1921,     0,
    1007,  1008,     0,     0,     0,     0,     0,     0,     0,   551,
   -1253,   552,   845,     0,  2167,   552,   552,     0,     0,     0,
       0,    28,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    29,     0,     0,     0,    30,     0,   845,    31,  1011,
      32,     0,   845,     0,   551,   845,     0,    33,     0,     0,
    1012,     0,    34,     0,     0,    35,     0,     0,     0,     0,
       0,    36,   741,     0,     0,     0,     0,     0,     0,   836,
       0,  1348,     0,     0,  1348,  1348,  1348,  1348,  1348,  1348,
    1348,  1348,  1348,     0,  1348,    37,     0,     0,     0,     0,
       0,     0,    38,     0,    39,     0,     0,     0,    40,     0,
       0, -1253,     0,     0,     0,   555,     0,     0,     0,     0,
     555,     0,     0,     0,     0,  1915,  1348,     0,   836,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   440,     0,     0,     0,     0,   440,     0,
      41,     0,     0,     0,     0,     0,     0,  1921,     0,     0,
       0,   847,     0,  2172,   836,     0,     0,     0,  1996,     0,
       0,     0,     0,     0,     0,     0,  1002,     0,  1015,     0,
       0,  1003,   440,  2015,     0,     0,  1019,  1020,  1021,  1022,
    1023,  1024,  2017,     0,     0,   845,     0,  1025,     0,   555,
       0,     0,     0,  1004,     0,     0,     0,     0,     0,     0,
     847,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   741,     0,     0,     0,     0,     0,  2052,
    2053,  2054,  2055,     0,     0,     0,     0,  1348,     0,     0,
       0,     0,     0,     0,     0,     0,   847,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1921,     0,     0,   741,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1005,     0,  1819,     0,  1006,     0,     0,
       0,     0,     0,   741,     0,     0,   845,  1000,     0,   845,
       0,     0,     0,  1002,  1007,  1008,     0,     0,  1003,     0,
       0,     0,     0,     0,  1009,     0,     0,     0,     0,   741,
     741,     0,   741,   741,   741,     0,     0,     0,     0,     0,
    1004,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     741,     0,     0,  1011,     0,   440,     0,     0,     0,     0,
       0,     0,     0,     0,  1012,     0,     0,     0,     0,   836,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1348,     0,     0,     0,     0,     0,   837,     0,
       0,  2303,     0,   836,     0,     0,     0,   845,     0,     0,
       0,   741,     0,     0,     0,     0,     0,     0,     0,     0,
    1005,     0,     0,     0,  1006,  1014,     0,     0,   836,     0,
       0,     0,     0,   836,     0,     0,   836,     0,     0,     0,
       0,  1007,  1008,     0,  1201,     0,     0,   837,     0,     0,
       0,  1009,     0,   845,     0,     0,     0,  1268,     0,     0,
     845,   847,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   440,     0,     0,     0,     0,     0,  1010,     0,     0,
    1011,     0,     0,   837,   552,   847,     0,     0,     0,     0,
       0,  1012,  1015,  1013,     0,   552,  1016,  1017,  1018,     0,
    1019,  1020,  1021,  1022,  1023,  1024,   845,     0,   741,     0,
     847,  1025,     0,     0,     0,   847,     0,     0,   847,     0,
       0,   440,   440,   552,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  2198,     0,  1348,   555,     0,     0,     0,
       0,     0,  1014,     0,     0,     0,   638,     0,     0,     0,
       0,     0,     0,   552,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   741,     0,     0,     0,
       0,   741,  2226,     0,   741,   741,   836,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   741,     0,     0,     0,   741,   741,   741,   741,
    2239,     0,     0,     0,     0,     0,   741,   741,     0,  1015,
       0,     0,     0,  1016,  1017,  1018,     0,  1019,  1020,  1021,
    1022,  1023,  1024,     0,   839,  1908,     0,     0,  1025,     0,
       0,     0,  1909,   741,  1201,     0,   741,     0,   741,     0,
       0,   440,   741,     0,     0,     0,   741,     0,     0,   741,
     741,   741,   741,   741,   741,   741,   741,   741,   847,   741,
       0,     0,   741,     0,     0,   741,     0,   836,   837,     0,
     836,     0,     0,   839,   845,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   837,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   839,
       0,     0,   845,     0,     0,     0,     0,   837,     0,     0,
       0,     0,   837,     0,   440,   837,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   440,
       0,   845,     0,     0,     0,     0,     0,     0,   440,   847,
       0,     0,   847,     0,     0,     0,     0,     0,   836,   845,
       0,     0,     0,     0,   845,     0,     0,     0,     0,     0,
       0,   845,     0,     0,     0,     0,   845,     0,   845,     0,
       0,     0,     0,     0,     0,   440,   440,   440,   440,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   836,     0,     0,     0,     0,     0,
       0,   836,     0,     0,     0,     0,     0,   845,     0,     0,
       0,     0,     0,     0,   840,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   741,     0,
     847,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   845,     0,   836,     0,     0,
       0,     0,     0,     0,     0,   837,     0,     0,     0,   845,
     440,     0,     0,   840,   440,     0,     0,     0,   440,     0,
       0,     0,     0,     0,     0,     0,   847,     0,     0,     0,
       0,     0,     0,   847,   839,     0,     0,   845,     0,     0,
       0,     0,     0,     0,     0,     0,   842,     0,   741,   840,
       0,     0,     0,     0,     0,     0,     0,     0,   839,   843,
       0,     0,     0,     0,     0,     0,   741,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   847,
       0,     0,     0,   839,   741,     0,     0,     0,   839,     0,
       0,   839,     0,     0,     0,   842,   837,     0,     0,   837,
       0,     0,   552,     0,     0,     0,   552,     0,   843,     0,
       0,     0,     0,     0,   741,   741,   741,   741,   741,   741,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   842,     0,     0,   741,   741,   741,   741,     0,     0,
       0,   741,     0,     0,   843,   741,     0,     0,     0,     0,
       0,     0,     0,   845,     0,     0,     0,   741,     0,   440,
       0,     0,   741,     0,   440,   836,     0,     0,   440,     0,
       0,     0,   741,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   741,   741,     0,   741,   837,     0,     0,
     741,     0,     0,     0,     0,     0,     0,   552,     0,   440,
       0,     0,     0,   836,   555,     0,   741,   741,     0,     0,
       0,     0,   440,     0,     0,     0,     0,     0,     0,   552,
       0,     0,     0,     0,   552,     0,     0,     0,     0,   741,
       0,   839,   836,   837,   840,     0,     0,     0,   440,     0,
     837,   741,     0,     0,     0,     0,     0,   847,     0,     0,
     836,     0,     0,     0,     0,   836,   440,     0,   840,     0,
     845,     0,   836,     0,     0,     0,   440,   836,     0,   836,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   552,     0,   840,  1201,   847,   837,     0,   840,     0,
     552,   840,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   836,     0,
       0,     0,     0,     0,   847,     0,   842,     0,     0,     0,
       0,     0,   839,     0,     0,   839,     0,     0,     0,   843,
       0,     0,   847,     0,     0,     0,     0,   847,     0,     0,
     842,     0,     0,     0,   847,     0,   836,     0,     0,   847,
       0,   847,     0,   843,     0,     0,     0,     0,     0,     0,
     836,   552,   555,     0,     0,   842,     0,     0,     0,     0,
     842,     0,     0,   842,     0,   552,     0,     0,   843,     0,
       0,     0,     0,   843,     0,     0,   843,   741,   836,     0,
     847,     0,     0,     0,     0,     0,     0,     0,     0,   741,
       0,     0,     0,   741,     0,     0,     0,   741,     0,   845,
     552,     0,     0,   839,     0,   845,   741,     0,     0,   741,
     741,   741,   741,   741,   741,   741,   741,   741,   847,   741,
       0,   840,     0,   741,   741,     0,     0,     0,     0,     0,
       0,     0,   847,     0,   844,   846,     0,   741,     0,     0,
       0,     0,     0,     0,   837,     0,     0,     0,     0,   839,
     741,   741,   741,     0,   741,     0,   839,     0,     0,     0,
     847,   741,     0,     0,     0,     0,   741,     0,     0,     0,
     555,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   837,   844,   846,     0,     0,     0,     0,     0,
       0,     0,     0,   741,   836,     0,     0,     0,   845,     0,
       0,     0,   839,   842,     0,     0,     0,     0,     0,     0,
       0,   837,   840,     0,     0,   840,   843,   845,     0,   844,
     846,     0,  1002,     0,     0,     0,     0,  1003,     0,   837,
       0,     0,     0,     0,   837,     0,     0,     0,     0,     0,
       0,   837,     0,     0,     0,     0,   837,     0,   837,  1004,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   741,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   847,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   837,     0,     0,
       0,     0,     0,  1698,   842,     0,     0,   842,     0,     0,
       0,   836,     0,   840,     0,     0,     0,   843,     0,     0,
     843,     0,     0,   845,     0,     0,     0,     0,  1000, -1253,
       0,     0,     0,  1006,  1002,   837,   741,     0,     0,  1003,
       0,     0,     0,     0,   741,     0,     0,     0,     0,   837,
    1007,  1008,     0,     0,     0,     0,     0,     0,     0,   840,
   -1253,  1004,     0,     0,     0,     0,   840,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   837,     0,   845,
     839,     0,   741,     0,     0,     0,     0,     0,     0,  1011,
       0,     0,     0,   847,     0,   842,     0,   741,   741,   741,
    1012,     0,   741,     0,     0,     0,     0,     0,   843,   555,
       0,     0,   840,   555,   844,   846,     0,   555,   839,     0,
       0,     0,     0,   741,     0,     0,     0,     0,     0,     0,
       0,  1005,     0,     0,     0,  1006,     0,     0,   844,   846,
     741,   842,     0,     0,     0,     0,     0,   839,   842,     0,
       0, -1253,  1007,  1008,   843,     0,     0,     0,     0,     0,
     836,   843,  1009,   844,   846,   839,   836,     0,   844,  1263,
     839,   844,   846,     0,     0,     0,     0,   839,     0,   741,
       0,     0,   839,     0,   839,     0,     0,     0,  1010,     0,
       0,  1011,     0,   837,   842,     0,     0,     0,     0,     0,
       0,     0,  1012,     0,  1013,   555,     0,   843,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1015,     0,
       0,     0,     0,   839,     0,     0,  1019,  1020,  1021,  1022,
    1023,  1024,   741,  1000,     0,     0,  1457,  1025,     0,  1002,
     741,     0,   847,     0,  1003,     0,     0,     0,   847,     0,
       0,     0,   741,  1014,     0,     0,     0,     0,   555,   836,
       0,   839,     0,   555,     0,     0,  1004,   555,     0,     0,
       0,     0,     0,   741,   741,   839,     0,     0,   836,     0,
     840,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   555,     0,     0,  1458,
     837,     0,     0,   839,     0,     0,     0,     0,     0,     0,
       0,   844,   846,     0,     0,     0,     0,     0,   840,     0,
    1015,     0,     0,     0,  1016,  1017,  1018,     0,  1019,  1020,
    1021,  1022,  1023,  1024,     0,     0,  1005,     0,     0,  1025,
    1006,   847,  1630,     0,     0,     0,     0,   840,     0,     0,
       0,   741,     0,     0,     0,   555,     0,  1007,  1008,     0,
     847,     0,   842,     0,     0,   840,     0,  1009,     0,     0,
     840,     0,     0,     0,   836,   843,     0,   840,     0,     0,
     555,     0,   840,     0,   840,     0,     0,     0,     0,     0,
       0,     0,     0,  1010,     0,     0,  1011,     0,     0,     0,
     842,     0,   844,   846,     0,   844,   846,  1012,     0,  1013,
       0,     0,     0,   843,     0,     0,     0,     0,     0,   839,
       0,     0,     0,   840,     0,     0,     0,     0,     0,   842,
     836,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   843,     0,     0,     0,     0,   842,     0,   837,
       0,     0,   842,     0,   728,   837,   847,     0,  1014,   842,
     843,   840,     0,     0,   842,   843,   842,     0,     0,     0,
       0,     0,   843,     0,   555,   840,     0,   843,     0,   843,
    1000,     0,     0,     0,     0,     0,  1002,     0,     0,     0,
       0,  1003,     0,   844,   846,     0,     0,     0,     0,  1459,
       0,     0,     0,   840,     0,   842,     0,     0,     0,   555,
       0,     0,   847,  1004,     0,     0,     0,     0,   843,     0,
       0,     0,     0,     0,     0,  1015,   839,     0,     0,  1016,
    1017,  1018,     0,  1019,  1020,  1021,  1022,  1023,  1024,   844,
     846,     0,     0,   842,  1025,     0,   844,  1263,   837,     0,
       0,     0,     0,     0,     0,     0,   843,   842,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   837,     0,     0,
     843,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1005,     0,   842,     0,  1006,     0,     0,
       0,     0,   844,   846,     0,     0,     0,     0,   843,     0,
       0,     0,     0,     0,  1007,  1008,     0,     0,     0,     0,
       0,     0,     0,     0,  1009,     0,     0,     0,     0,   840,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    1010,   936,     0,  1011,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1012,     0,  1013,     0,     0,     0,
       0,     0,     0,   837,     0,   958,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   839,     0,     0,     0,     0,
       0,   839,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   978,   979,     0,   980,   981,   984,     0,     0,     0,
       0,   842,     0,     0,     0,  1014,     0,     0,     0,     0,
       0,     0,   999,     0,   843,     0,     0,     0,     0,   837,
       0,     0,     0,     0,     0,     0,   840,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     844,   846,     0,  1081,     0,     0,     0,     0,     0,     0,
       0,     0,  1015,     0,   839,     0,  1016,  1017,  1018,     0,
    1019,  1020,  1021,  1022,  1023,  1024,     0,     0,     0,     0,
       0,  1025,     0,   839, -1000,     0,     0,     0,   844,  1263,
       0,     0,     0,     0,     0,  1000,     0,  1026,   842,     0,
       0,  1002,     0,     0,     0,     0,  1003,     0,     0,     0,
       0,   843,     0,     0,     0,     0,     0,   844,   846,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1004,     0,
       0,     0,     0,     0,     0,   844,   846,     0,     0,     0,
     844,  1263,     0,     0,     0,     0,     0,   844,  1263,     0,
    1249,     0,   844,   846,   844,   846,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   840,     0,     0,     0,     0,
       0,   840,     0,     0,     0,     0,     0,     0,     0,   839,
       0,     0,     0,  1660,     0,     0,     0,     0,  1661,     0,
       0,     0,     0,   844,   846,     0,     0,     0,  1005,     0,
       0,     0,  1006,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1314,     0,     0,     0,  1316,     0,  1007,
    1008,     0,     0,     0,     0,     0,     0,     0,     0,  1009,
       0,   844,   846,     0,  1336,   839,     0,     0,  1339,     0,
    1352,  1353,     0,     0,     0,   844,   846,   842,  1360,  1365,
       0,     0,     0,   842,     0,  1010,     0,     0,  1011,     0,
     843,     0,     0,  1026,   840,     0,   843,     0,     0,  1012,
       0,  1013,     0,   844,   846,  1393,     0,     0,     0,  1000,
    1398,  1001,     0,   840,  1409,  1002,     0,     0,  1416,     0,
    1003,  1418,  1419,  1420,  1421,  1422,  1423,  1424,  1425,  1426,
       0,  1428,  1000,     0,   728,  1026,     0,     0,  1002,     0,
       0,     0,  1004,  1003,     0,     0,     0,     0,     0,     0,
    1014,     0,     0,     0,     0,     0,     0,  1026,     0,     0,
       0,     0,     0,  1346,     0,  1004,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   842,  1026,  1026,  1026,
    1026,     0,     0,  1026,     0,     0,     0,     0,     0,   843,
       0,     0,     0,     0,     0,   842,     0,     0,  1026,     0,
       0,     0,  1346,     0,     0,     0,     0,     0,   843,   840,
       0,     0,  1005,     0,     0,     0,  1006,  1015,     0,   844,
     846,  1016,  1017,  1018,     0,  1019,  1020,  1021,  1022,  1023,
    1024,     0,     0,  1007,  1008,  1005,  1025,     0,     0,  1006,
       0,     0,     0,  1009,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1007,  1008,     0,     0,
       0,     0,     0,     0,     0,   840,  1009,     0,     0,  1010,
       0,     0,  1011,     0,     0,     0,     0,     0,     0,     0,
    1026,     0,     0,  1012,     0,  1013,     0,     0,     0,     0,
       0,   842,  1010,     0,     0,  1011,     0,     0,     0,     0,
       0,     0,     0,     0,   843,     0,  1012,     0,  1013,     0,
    1513,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   844,   846,     0,     0,
       0,     0,     0,     0,  1014,     0,     0,     0,  1000,     0,
    1617,     0,     0,     0,  1002,     0,     0,   842,     0,  1003,
       0,     0,     0,     0,     0,     0,     0,  1014,     0,     0,
     843,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  1004,     0,     0,     0,     0,     0,     0,     0,     0,
    1581,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   728,     0,
       0,  1015,     0,     0,     0,  1016,  1017,  1018,     0,  1019,
    1020,  1021,  1022,  1023,  1024,     0,  1613,     0,     0,     0,
    1025,     0,     0,     0,  1015,     0,     0,     0,  1016,  1017,
    1018,     0,  1019,  1020,  1021,  1022,  1023,  1024,     0,     0,
       0,  1005,  1371,  1025,     0,  1006,     0,     0,  1026,     0,
    1641,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1007,  1008,     0,     0,  1365,     0,  1365,  1365,
       0,     0,  1009,  1676,     0,   844,   846,  1678,     0,     0,
       0,   844,   846,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1010,     0,
       0,  1011,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1012,  1026,  1013,  1026,  1700,     0,  1702,     0,
       0,     0,  1705,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1026,     0,     0,  1026,     0,
    1346,  1346,  1346,  1346,     0,  1346,  1656,     0,     0,     0,
       0,  1026,  1026,     0,     0,     0,     0,     0,     0,  1026,
       0,  1081,     0,  1014,  1026,     0,     0,     0,     0,     0,
       0,     0,     0,  1738,   844,   846,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1026,   844,   846,  1656,     0,  1026,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1026,  1346,
       0,     0,     0,     0,     0,  1026,     0,  1026,  1026,  1026,
    1026,  1026,  1026,  1026,  1026,  1026,     0,  1026,     0,     0,
    1015,     0,     0,     0,  1016,  1017,  1018,     0,  1019,  1020,
    1021,  1022,  1023,  1024,  1000,     0,     0,     0,     0,  1025,
    1002,     0,     0,     0,     0,  1003,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  1004,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   844,
     846,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1026,     0,     0,     0,     0,     0,     0,  1872,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  1877,     0,     0,     0,  1878,     0,     0,     0,  1880,
       0,     0,     0,     0,     0,   844,   846,  1005,     0,     0,
       0,  1006,     0,     0,     0,     0,  1000,     0,     0,     0,
       0,     0,  1002,     0,     0,  1897,  1898,  1003,  1007,  1008,
       0,     0,     0,     0,     0,     0,     0,     0,  1009,     0,
    1026,     0,     0,     0,     0,     0,     0,     0,     0,  1004,
       0,     0,     0,     0,  1917,     0,  1919,     0,     0,     0,
       0,     0,     0,  1923,  1010,     0,     0,  1011,  1927,     0,
       0,     0,  1026,     0,     0,     0,     0,     0,  1012,     0,
    1013,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1959,  1656,  1656,  1656,  1656,
    1026,  1656,  1346,     0,     0,  1346,  1346,  1346,  1346,  1346,
    1346,  1346,  1346,  1346,     0,  1346,  1002,     0,     0,  1005,
       0,  1003,     0,  1006,     0,     0,     0,     0,     0,  1014,
       0,     0,     0,     0,     0,  1026,     0,  1026,     0,     0,
    1007,  1008,     0,  1004,     0,     0,     0,  1346,     0,     0,
    1009,     0,     0,     0,     0,     0,     0,     0,  1656,  1026,
       0,  1026,     0,     0,  1026,     0,     0,     0,     0,     0,
    1619,     0,     0,     0,     0,     0,  1010,     0,     0,  1011,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    1012,     0,  1013,     0,     0,     0,  1015,  1026,     0,     0,
    1016,  1017,  1018,  1634,  1019,  1020,  1021,  1022,  1023,  1024,
       0,     0,     0,  1005,     0,  1025,     0,  1006,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   728,     0,
       0,     0,     0,     0,  1007,  1008,  2060,     0,     0,     0,
       0,  1014,     0,     0,  1009,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1000,     0,  1346,     0,
       0,     0,  1002,     0,     0,     0,     0,  1003,     0,     0,
    1010,     0,     0,  1011,  2071,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1012,     0,     0,     0,     0,  1004,
    2077,  2078,     0,     0,  2080,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1015,     0,
       0,     0,  1016,  1017,  1018,     0,  1019,  1020,  1021,  1022,
    1023,  1024,     0,     0,     0,     0,     0,  1025,     0,     0,
       0,  1026,  2109,     0,     0,  1014,  1026,  1026,     0,  1026,
       0,  1656,     0,     0,     0,  1656,  1656,  1656,  1656,  1656,
    1656,  1656,  1656,  1656,     0,  1656,  1026,  1026,     0,  1005,
       0,     0,     0,  1006,     0,     0,     0,     0,     0,     0,
       0,  2127,     0,     0,     0,  1656,  1026,     0,  1026,     0,
    1007,  1008,  1026,  1346,     0,     0,  1026,     0,     0,     0,
    1009,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1015,     0,     0,     0,  1016,  1017,  1018,     0,
    1019,  1020,  1021,  1022,  1023,  1024,  1010,     0,  1026,  1011,
       0,  1025,     0,     0,   728,     0,     0,     0,     0,     0,
    1012,     0,  1013,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  2173,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  2190,     0,  1656,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  1014,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  1026,
       0,     0,     0,     0,     0,     0,  1346,     0,     0,     0,
    1026,     0,     0,     0,     0,  1656,  1026,  1026,     0,  1026,
       0,     0,     0,  2232,     0,     0,     0,     0,  1015,     0,
       0,     0,  1016,  1017,  1018,     0,  1019,  1020,  1021,  1022,
    1023,  1024,     0,     0,     0,     0,  1659,  1025,  1026,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1026,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1656,     0,     0,     0,
       0,     0,  1026,     0,     0,     0,     0,   129,   130,   131,
     132,   133,   134,   135,  1433,   136,     0,     0,     0,  1026,
       0,     0,   137,   138,   139,   529,   140,   141,   142,   530,
     653,   531,   654,   655,     0,   146,   147,   148,   149,   656,
     657,   150,   658,   659,   153,     0,   154,   155,   156,   157,
     660,     0,     0,   159,   160,   161,     0,   162,   163,   661,
     165,  1026,   166,   167,   532,   662,   663,   664,   665,   168,
     169,   170,   171,   172,   666,   667,   175,     0,     0,   176,
     177,   178,   179,   180,     0,  1434,     0,   181,   668,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,   669,
     191,   192,   670,   671,   194,   672,     0,   196,     0,   197,
     533,     0,   534,   198,   199,   200,     0,     0,   201,     0,
     202,   535,   203,   204,   205,   536,   206,   207,   208,     0,
     537,   209,   210,   211,   212,   213,   673,   674,     0,   675,
       0,   217,   538,   539,   218,   540,   219,   220,   221,     0,
     541,   222,   542,     0,   223,   224,   225,   676,   677,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   678,
     543,   679,   437,   238,   239,   240,   241,   242,   680,   243,
     244,   544,   681,   682,   683,   247,     0,     0,   248,   438,
       0,     0,   684,   250,     0,     0,   251,   545,   546,   685,
     253,   254,   255,   256,   257,     0,   686,   259,   260,     0,
     261,   262,   263,   264,   265,   687,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,   547,   276,   688,   278,
     279,   280,   281,   282,     0,   283,   284,   285,   689,   286,
     287,   288,   289,   548,   290,   690,     0,   292,   293,   294,
     295,   296,   297,   298,   299,   691,   301,     0,   302,   303,
     304,     0,   692,   693,     0,   307,     0,   308,   694,   310,
     695,   696,   312,   313,   314,   315,     0,   697,   316,   317,
     318,   319,   320,   698,     0,   321,   322,   323,   324,   699,
     326,   549,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   700,   701,   444,     0,   702,   703,
     704,   413,   705,     0,     0,     0,     0,     0,   706,   707,
    1435,     0,   709,   710,     0,     0,     0,   711,  1436,   129,
     130,   131,   132,   133,   134,   135,     0,   136,     0,     0,
       0,     0,     0,     0,   137,   138,   139,   529,   140,   141,
     142,   530,   653,   531,   654,   655,     0,   146,   147,   148,
     149,   656,   657,   150,   658,   659,   153,     0,   154,   155,
     156,   157,   660,     0,     0,   159,   160,   161,     0,   162,
     163,   661,   165,     0,   166,   167,   532,   662,   663,   664,
     665,   168,   169,   170,   171,   172,   666,   667,   175,     0,
       0,   176,   177,   178,   179,   180,     0,     0,     0,   181,
     668,   183,   184,     0,   185,   186,     0,   187,     0,   188,
     189,   669,   191,   192,   670,   671,   194,   672,     0,   196,
       0,   197,   533,     0,   534,   198,   199,   200,     0,     0,
     201,     0,   202,   535,   203,   204,   205,   536,   206,   207,
     208,     0,   537,   209,   210,   211,   212,   213,   673,   674,
       0,   675,     0,   217,   538,   539,   218,   540,   219,   220,
     221,     0,   541,   222,   542,     0,   223,   224,   225,   676,
     677,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   678,   543,   679,   437,   238,   239,   240,   241,   242,
     680,   243,   244,   544,   681,   682,   683,   247,     0,     0,
     248,   438,     0,     0,   684,   250,     0,     0,   251,   545,
     546,   685,   253,   254,   255,   256,   257,     0,   686,   259,
     260,     0,   261,   262,   263,   264,   265,   687,   267,     0,
     268,   269,   270,   271,   272,   273,   274,   275,   547,   276,
     688,   278,   279,   280,   281,   282,     0,   283,   284,   285,
     689,   286,   287,   288,   289,   548,   290,   690,     0,   292,
     293,   294,   295,   296,   297,   298,   299,   691,   301,     0,
     302,   303,   304,     0,   692,   693,     0,   307,     0,   308,
     694,   310,   695,   696,   312,   313,   314,   315,     0,   697,
     316,   317,   318,   319,   320,   698,     0,   321,   322,   323,
     324,   699,   326,   549,   327,   328,   329,     0,     0,   330,
     331,   332,   333,   334,   335,     0,   700,   701,   444,     0,
     702,   703,   704,   413,   705,     0,     0,     0,     0,     0,
     706,   707,     0,     0,   709,   710,     0,     0,     0,   711,
    1350,   129,   130,   131,   132,   133,   134,   135,     0,   136,
       0,     0,     0,     0,     0,     0,   137,   138,   139,   529,
     140,   141,   142,   530,   653,   531,   654,   655,     0,   146,
     147,   148,   149,   656,   657,   150,   658,   659,   153,     0,
     154,   155,   156,   157,   660,     0,     0,   159,   160,   161,
       0,   162,   163,   661,   165,     0,   166,   167,   532,   662,
     663,   664,   665,   168,   169,   170,   171,   172,   666,   667,
     175,     0,     0,   176,   177,   178,   179,   180,     0,     0,
       0,   181,   668,   183,   184,     0,   185,   186,     0,   187,
       0,   188,   189,   669,   191,   192,   670,   671,   194,   672,
       0,   196,     0,   197,   533,     0,   534,   198,   199,   200,
       0,     0,   201,     0,   202,   535,   203,   204,   205,   536,
     206,   207,   208,     0,   537,   209,   210,   211,   212,   213,
     673,   674,     0,   675,     0,   217,   538,   539,   218,   540,
     219,   220,   221,     0,   541,   222,   542,     0,   223,   224,
     225,   676,   677,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   678,   543,   679,   437,   238,   239,   240,
     241,   242,   680,   243,   244,   544,   681,   682,   683,   247,
       0,     0,   248,   438,     0,     0,   684,   250,     0,     0,
     251,   545,   546,   685,   253,   254,   255,   256,   257,     0,
     686,   259,   260,     0,   261,   262,   263,   264,   265,   687,
     267,     0,   268,   269,   270,   271,   272,   273,   274,   275,
     547,   276,   688,   278,   279,   280,   281,   282,     0,   283,
     284,   285,   689,   286,   287,   288,   289,   548,   290,   690,
       0,   292,   293,   294,   295,   296,   297,   298,   299,   691,
     301,     0,   302,   303,   304,     0,   692,   693,     0,   307,
       0,   308,   694,   310,   695,   696,   312,   313,   314,   315,
       0,   697,   316,   317,   318,   319,   320,   698,     0,   321,
     322,   323,   324,   699,   326,   549,   327,   328,   329,     0,
       0,   330,   331,   332,   333,   334,   335,     0,   700,   701,
     444,     0,   702,   703,   704,   413,   705,     0,     0,     0,
       0,     0,   706,   707,     0,     0,   709,   710,     0,     0,
       0,   711,  2098,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,  1933,     0,   137,   138,
     139,     0,   140,   141,   142,     0,   143,     0,   144,   145,
       0,   146,   147,   148,   149,     0,     0,   150,   151,   152,
     153,     0,   154,   155,   156,   157,   158,     0,     0,   159,
     160,   161,     0,   162,   163,   164,   165,     0,   166,   167,
       0,     0,     0,     0,     0,   168,   169,   170,   171,   172,
     173,   174,   175,     0,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   182,   183,   184,     0,   185,   186,
       0,   187,  -662,   188,   189,   190,   191,   192,   193,     0,
     194,   195,  -662,   196,     0,   197,     0,     0,     0,   198,
     199,   200,     0,     0,   201,     0,   202,     0,   203,   204,
     205,     0,   206,   207,   208,     0,     0,   209,   210,   211,
     212,   213,   214,   215,  -662,   216,     0,   217,     0,     0,
     218,     0,   219,   220,   221,     0,     0,   222,     0,  -662,
     223,   224,   225,     0,     0,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,     0,   237,     0,   238,
     239,   240,   241,   242,     0,   243,   244,     0,     0,   245,
     246,   247,     0,  -662,   248,     0,     0,     0,   249,   250,
       0,  -662,   251,     0,     0,   252,   253,   254,   255,   256,
     257,     0,   258,   259,   260,     0,   261,   262,   263,   264,
     265,   266,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,     0,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   285,     0,   286,   287,   288,   289,     0,
     290,   291,     0,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,     0,   302,   303,   304,     0,   305,   306,
       0,   307,     0,   308,   309,   310,   311,     0,   312,   313,
     314,   315,  -662,     0,   316,   317,   318,   319,   320,     0,
       0,   321,   322,   323,   324,   325,   326,     0,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     336,     0,   129,   130,   131,   132,   133,   134,   135,     0,
     136,     0,     0,     0,     0,     0,     0,   137,   138,   139,
       0,   140,   141,   142,   770,   814,     0,   815,   816,     0,
     146,   147,   148,   149,     0,     0,   150,   817,   818,   153,
       0,   154,   155,   156,   157,     0,     0,     0,   159,   160,
     161,     0,   162,   163,     0,   165,     0,   166,   167,     0,
       0,     0,     0,     0,   168,   169,   170,   171,   172,   819,
     820,   175,     0,     0,   176,   177,   178,   179,   180,     0,
       0,     0,   181,   668,   183,   184,     0,   185,   186,     0,
     187,     0,   188,   189,     0,   191,   192,     0,     0,   194,
     821,     0,   196,     0,   197,     0,     0,     0,   198,   199,
     200,     0,     0,   201,     0,   202,     0,   203,   204,   205,
    1254,   206,   207,   208,     0,     0,  1255,   210,   211,   212,
     213,   822,   823,     0,   824,     0,   217,     0,     0,   218,
       0,   219,   220,   221,     0,     0,   222,     0,     0,   223,
     224,   225,     0,     0,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   678,     0,   825,     0,   238,   239,
     240,   241,     0,     0,   243,   244,     0,     0,     0,   826,
     247,     0,     0,   248,     0,     0,     0,   249,   250,     0,
       0,  1256,     0,     0,     0,   253,   254,   255,   256,   257,
       0,     0,   259,   260,     0,   261,   262,   263,   264,   265,
     827,   267,     0,   268,   269,   270,   271,   272,   273,   274,
     275,     0,   276,     0,   278,   279,   280,   281,   282,     0,
     283,   284,   285,     0,   286,   828,   288,   289,     0,   290,
     829,     0,   292,   293,   294,   295,   296,   297,   298,   299,
       0,   301,     0,   302,   303,   304,     0,   830,   831,     0,
     307,     0,   308,     0,   310,     0,     0,   312,   313,   314,
     315,     0,     0,   316,   317,   318,   319,   320,     0,     0,
     321,   322,   323,   324,   832,   326,     0,   327,   328,   329,
       0,     0,   330,   331,   332,   333,   334,   335,     0,   833,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   129,
     130,   131,   132,   133,   134,   135,     0,   136,     0,     0,
       0,     0,     0,  1257,   137,   138,   139,   529,   140,   141,
     142,   530,   653,   531,   654,   655,  1361,   146,   147,   148,
     149,   656,   657,   150,   658,   659,   153,     0,   154,   155,
     156,   157,   660,     0,     0,   159,   160,   161,     0,   162,
     163,   661,   165,     0,   166,   167,   532,   662,   663,   664,
     665,   168,   169,   170,   171,   172,   666,   667,   175,     0,
       0,   176,   177,   178,   179,   180,     0,     0,     0,   181,
     668,   183,   184,     0,   185,   186,     0,   187,     0,   188,
     189,   669,   191,   192,   670,   671,   194,   672,     0,   196,
       0,   197,   533,  1362,   534,   198,   199,   200,     0,     0,
     201,     0,   202,   535,   203,   204,   205,   536,   206,   207,
     208,     0,   537,   209,   210,   211,   212,   213,   673,   674,
       0,   675,     0,   217,   538,   539,   218,   540,   219,   220,
     221,  1363,   541,   222,   542,     0,   223,   224,   225,   676,
     677,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   678,   543,   679,   437,   238,   239,   240,   241,   242,
     680,   243,   244,   544,   681,   682,   683,   247,     0,     0,
     248,   438,     0,     0,   684,   250,     0,     0,   251,   545,
     546,   685,   253,   254,   255,   256,   257,     0,   686,   259,
     260,     0,   261,   262,   263,   264,   265,   687,   267,     0,
     268,   269,   270,   271,   272,   273,   274,   275,   547,   276,
     688,   278,   279,   280,   281,   282,     0,   283,   284,   285,
     689,   286,   287,   288,   289,   548,   290,   690,     0,   292,
     293,   294,   295,   296,   297,   298,   299,   691,   301,     0,
     302,   303,   304,     0,   692,   693,     0,   307,  1364,   308,
     694,   310,   695,   696,   312,   313,   314,   315,     0,   697,
     316,   317,   318,   319,   320,   698,     0,   321,   322,   323,
     324,   699,   326,   549,   327,   328,   329,     0,     0,   330,
     331,   332,   333,   334,   335,     0,   700,   701,   444,     0,
     702,   703,   704,   413,   705,     0,     0,     0,     0,     0,
     706,   707,     0,     0,   709,   710,     0,     0,     0,   711,
     129,   130,   131,   132,   133,   134,   135,     0,   136,     0,
       0,     0,     0,     0,     0,   137,   138,   139,   529,   140,
     141,   142,   530,   653,   531,   654,   655,     0,   146,   147,
     148,   149,   656,   657,   150,   658,   659,   153,     0,   154,
     155,   156,   157,   660,     0,     0,   159,   160,   161,     0,
     162,   163,   661,   165,     0,   166,   167,   532,   662,   663,
     664,   665,   168,   169,   170,   171,   172,   666,   667,   175,
    1595,     0,   176,   177,   178,   179,   180,     0,     0,     0,
     181,   668,   183,   184,     0,   185,   186,     0,   187,     0,
     188,   189,   669,   191,   192,   670,   671,   194,   672,     0,
     196,     0,   197,   533,     0,   534,   198,   199,   200,     0,
       0,   201,     0,   202,   535,   203,   204,   205,   536,   206,
     207,   208,     0,   537,   209,   210,   211,   212,   213,   673,
     674,     0,   675,     0,   217,   538,   539,   218,   540,   219,
     220,   221,     0,   541,   222,   542,     0,   223,   224,   225,
     676,   677,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   678,   543,   679,   437,   238,   239,   240,   241,
     242,   680,   243,   244,   544,   681,   682,   683,   247,     0,
       0,   248,   438,     0,     0,   684,   250,     0,     0,   251,
     545,   546,   685,   253,   254,   255,   256,   257,     0,   686,
     259,   260,     0,   261,   262,   263,   264,   265,   687,   267,
       0,   268,   269,   270,   271,   272,   273,   274,   275,   547,
     276,   688,   278,   279,   280,   281,   282,     0,   283,   284,
     285,   689,   286,   287,   288,   289,   548,   290,   690,     0,
     292,   293,   294,   295,   296,   297,   298,   299,   691,   301,
       0,   302,   303,   304,     0,   692,   693,     0,   307,     0,
     308,   694,   310,   695,   696,   312,   313,   314,   315,     0,
     697,   316,   317,   318,   319,   320,   698,     0,   321,   322,
     323,   324,   699,   326,   549,   327,   328,   329,     0,     0,
     330,   331,   332,   333,   334,   335,     0,   700,   701,   444,
       0,   702,   703,   704,   413,   705,     0,     0,     0,     0,
       0,   706,   707,   708,     0,   709,   710,     0,     0,     0,
     711,   129,   130,   131,   132,   133,   134,   135,     0,   136,
       0,     0,     0,     0,     0,     0,   137,   138,   139,   529,
     140,   141,   142,   530,   653,   531,   654,   655,     0,   146,
     147,   148,   149,   656,   657,   150,   658,   659,   153,     0,
     154,   155,   156,   157,   660,     0,     0,   159,   160,   161,
       0,   162,   163,   661,   165,     0,   166,   167,   532,   662,
     663,   664,   665,   168,   169,   170,   171,   172,   666,   667,
     175,     0,     0,   176,   177,   178,   179,   180,     0,     0,
       0,   181,   668,   183,   184,     0,   185,   186,     0,   187,
       0,   188,   189,   669,   191,   192,   670,   671,   194,   672,
       0,   196,     0,   197,   533,     0,   534,   198,   199,   200,
       0,     0,   201,     0,   202,   535,   203,   204,   205,   536,
     206,   207,   208,     0,   537,   209,   210,   211,   212,   213,
     673,   674,     0,   675,     0,   217,   538,   539,   218,   540,
     219,   220,   221,     0,   541,   222,   542,     0,   223,   224,
     225,   676,   677,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   678,   543,   679,   437,   238,   239,   240,
     241,   242,   680,   243,   244,   544,   681,   682,   683,   247,
       0,     0,   248,   438,     0,     0,   684,   250,     0,     0,
     251,   545,   546,   685,   253,   254,   255,   256,   257,     0,
     686,   259,   260,     0,   261,   262,   263,   264,   265,   687,
     267,     0,   268,   269,   270,   271,   272,   273,   274,   275,
     547,   276,   688,   278,   279,   280,   281,   282,     0,   283,
     284,   285,   689,   286,   287,   288,   289,   548,   290,   690,
       0,   292,   293,   294,   295,   296,   297,   298,   299,   691,
     301,     0,   302,   303,   304,     0,   692,   693,     0,   307,
       0,   308,   694,   310,   695,   696,   312,   313,   314,   315,
       0,   697,   316,   317,   318,   319,   320,   698,     0,   321,
     322,   323,   324,   699,   326,   549,   327,   328,   329,     0,
       0,   330,   331,   332,   333,   334,   335,     0,   700,   701,
     444,     0,   702,   703,   704,   413,   705,     0,     0,     0,
       0,     0,   706,   707,   708,     0,   709,   710,     0,     0,
       0,   711,   129,   130,   131,   132,   133,   134,   135,     0,
     136,     0,     0,     0,     0,     0,     0,   137,   138,   139,
     529,   140,   141,   142,   530,   653,   531,   654,   655,     0,
     146,   147,   148,   149,   656,   657,   150,   658,   659,   153,
       0,   154,   155,   156,   157,   660,     0,     0,   159,   160,
     161,     0,   162,   163,   661,   165,     0,   166,   167,   532,
     662,   663,   664,   665,   168,   169,   170,   171,   172,   666,
     667,   175,     0,     0,   176,   177,   178,   179,   180,     0,
       0,     0,   181,   668,   183,   184,     0,   185,   186,     0,
     187,     0,   188,   189,   669,   191,   192,   670,   671,   194,
     672,     0,   196,     0,   197,   533,     0,   534,   198,   199,
     200,     0,     0,   201,     0,   202,   535,   203,   204,   205,
     536,   206,   207,   208,     0,   537,   209,   210,   211,   212,
     213,   673,   674,     0,   675,     0,   217,   538,   539,   218,
     540,   219,   220,   221,     0,   541,   222,   542,     0,   223,
     224,   225,   676,   677,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   678,   543,   679,   437,   238,   239,
     240,   241,   242,   680,   243,   244,   544,   681,   682,   683,
     247,     0,     0,   248,   438,     0,     0,   684,   250,     0,
       0,   251,   545,   546,   685,   253,   254,   255,   256,   257,
       0,   686,   259,   260,     0,   261,   262,   263,   264,   265,
     687,   267,     0,   268,   269,   270,   271,   272,   273,   274,
     275,   547,   276,   688,   278,   279,   280,   281,   282,    33,
     283,   284,   285,   689,   286,   287,   288,   289,   548,   290,
     690,     0,   292,   293,   294,   295,   296,   297,   298,   299,
     691,   301,     0,   302,   303,   304,     0,   692,   693,     0,
     307,     0,   308,   694,   310,   695,   696,   312,   313,   314,
     315,     0,   697,   316,   317,   318,   319,   320,   698,     0,
     321,   322,   323,   324,   699,   326,   549,   327,   328,   329,
       0,     0,   330,   331,   332,   333,   334,   335,     0,   700,
     701,   444,     0,   702,   703,   704,   413,   705,     0,     0,
       0,     0,     0,   706,   707,     0,     0,   709,   710,     0,
       0,     0,   711,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,     0,     0,   137,   138,
     139,   529,   140,   141,   142,   530,   653,   531,   654,   655,
       0,   146,   147,   148,   149,   656,   657,   150,   658,   659,
     153,     0,   154,   155,   156,   157,   660,     0,     0,   159,
     160,   161,     0,   162,   163,   661,   165,     0,   166,   167,
     532,   662,   663,   664,   665,   168,   169,   170,   171,   172,
     666,   667,   175,     0,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   668,   183,   184,     0,   185,   186,
       0,   187,     0,   188,   189,   669,   191,   192,   670,   671,
     194,   672,     0,   196,     0,   197,   533,  1362,   534,   198,
     199,   200,     0,     0,   201,     0,   202,   535,   203,   204,
     205,   536,   206,   207,   208,     0,   537,   209,   210,   211,
     212,   213,   673,   674,     0,   675,     0,   217,   538,   539,
     218,   540,   219,   220,   221,     0,   541,   222,   542,     0,
     223,   224,   225,   676,   677,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   678,   543,   679,   437,   238,
     239,   240,   241,   242,   680,   243,   244,   544,   681,   682,
     683,   247,     0,     0,   248,   438,     0,     0,   684,   250,
       0,     0,   251,   545,   546,   685,   253,   254,   255,   256,
     257,     0,   686,   259,   260,     0,   261,   262,   263,   264,
     265,   687,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,   547,   276,   688,   278,   279,   280,   281,   282,
       0,   283,   284,   285,   689,   286,   287,   288,   289,   548,
     290,   690,     0,   292,   293,   294,   295,   296,   297,   298,
     299,   691,   301,     0,   302,   303,   304,     0,   692,   693,
       0,   307,     0,   308,   694,   310,   695,   696,   312,   313,
     314,   315,     0,   697,   316,   317,   318,   319,   320,   698,
       0,   321,   322,   323,   324,   699,   326,   549,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     700,   701,   444,     0,   702,   703,   704,   413,   705,     0,
       0,     0,     0,     0,   706,   707,     0,     0,   709,   710,
       0,     0,     0,   711,   129,   130,   131,   132,   133,   134,
     135,     0,   136,     0,     0,     0,     0,     0,     0,   137,
     138,   139,   529,   140,   141,   142,   530,   653,   531,   654,
     655,     0,   146,   147,   148,   149,   656,   657,   150,   658,
     659,   153,     0,   154,   155,   156,   157,   660,     0,     0,
     159,   160,   161,     0,   162,   163,   661,   165,     0,   166,
     167,   532,   662,   663,   664,   665,   168,   169,   170,   171,
     172,   666,   667,   175,     0,     0,   176,   177,   178,   179,
     180,     0,     0,     0,   181,   668,   183,   184,     0,   185,
     186,     0,   187,     0,   188,   189,   669,   191,   192,   670,
     671,   194,   672,     0,   196,     0,   197,   533,     0,   534,
     198,   199,   200,     0,     0,   201,     0,   202,   535,   203,
     204,   205,   536,   206,   207,   208,     0,   537,   209,   210,
     211,   212,   213,   673,   674,     0,   675,     0,   217,   538,
     539,   218,   540,   219,   220,   221,     0,   541,   222,   542,
       0,   223,   224,   225,   676,   677,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   678,   543,   679,   437,
     238,   239,   240,   241,   242,   680,   243,   244,   544,   681,
     682,   683,   247,     0,     0,   248,   438,     0,     0,   684,
     250,     0,     0,   251,   545,   546,   685,   253,   254,   255,
     256,   257,     0,   686,   259,   260,     0,   261,   262,   263,
     264,   265,   687,   267,     0,   268,   269,   270,   271,   272,
     273,   274,   275,   547,   276,   688,   278,   279,   280,   281,
     282,     0,   283,   284,   285,   689,   286,   287,   288,   289,
     548,   290,   690,     0,   292,   293,   294,   295,   296,   297,
     298,   299,   691,   301,     0,   302,   303,   304,     0,   692,
     693,     0,   307,     0,   308,   694,   310,   695,   696,   312,
     313,   314,   315,     0,   697,   316,   317,   318,   319,   320,
     698,     0,   321,   322,   323,   324,   699,   326,   549,   327,
     328,   329,     0,     0,   330,   331,   332,   333,   334,   335,
       0,   700,   701,   444,     0,   702,   703,   704,   413,   705,
       0,     0,     0,     0,     0,   706,   707,     0,     0,   709,
     710,     0,     0,     0,   711,   129,   130,   131,   132,   133,
     134,   135,     0,   136,     0,     0,     0,     0,     0,     0,
     137,   138,   139,   529,   140,   141,   142,   530,   653,   531,
     654,   655,     0,   146,   147,   148,   149,   656,   657,   150,
     658,   659,   153,     0,   154,   155,   156,   157,   660,     0,
       0,   159,   160,   161,     0,   162,   163,   661,   165,     0,
     166,   167,   532,   662,   663,   664,   665,   168,   169,   170,
     171,   172,   666,   667,   175,     0,     0,   176,   177,   178,
     179,   180,     0,     0,     0,   181,   668,   183,   184,     0,
     185,   186,     0,   187,     0,   188,   189,   669,   191,   192,
     670,   671,   194,   672,     0,   196,     0,   197,   533,     0,
     534,   198,   199,   200,     0,     0,   201,     0,   202,   535,
     203,   204,   205,   536,   206,   207,   208,     0,   537,   209,
     210,   211,   212,   213,   673,   674,     0,   675,     0,   217,
     538,   539,   218,   540,   219,   220,   221,     0,   541,   222,
     542,     0,   223,   224,   225,   676,   677,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   678,   543,   679,
     437,   238,   239,   240,   241,   242,     0,   243,   244,   544,
     681,   682,   683,   247,     0,     0,   248,   438,     0,     0,
     684,   250,     0,     0,   251,   545,   546,   685,   253,   254,
     255,   256,   257,     0,   686,   259,   260,     0,   261,   262,
     263,   264,   265,   687,   267,     0,   268,   269,   270,   271,
     272,   273,   274,   275,   547,   276,   277,   278,   279,   280,
     281,   282,     0,   283,   284,   285,   689,   286,   287,   288,
     289,   548,   290,   690,     0,   292,   293,   294,   295,   296,
     297,   298,   299,   691,   301,     0,   302,   303,   304,     0,
     692,   693,     0,   307,     0,   308,   694,   310,   695,   696,
     312,   313,   314,   315,     0,     0,   316,   317,   318,   319,
     320,   698,     0,   321,   322,   323,   324,   699,   326,   549,
     327,   328,   329,     0,     0,   330,   331,   332,   333,   334,
     335,     0,   700,   701,   444,     0,   702,   703,   704,   413,
     705,     0,     0,     0,     0,     0,  1341,  1342,     0,     0,
    1343,  1344,     0,     0,     0,  1345,   129,   130,   131,   132,
     133,   134,   135,     0,   136,     0,     0,     0,     0,     0,
       0,   137,   138,   139,   529,   140,   141,   142,     0,   653,
     531,   654,   655,     0,   146,   147,   148,   149,   656,   657,
     150,   658,   659,   153,     0,   154,   155,   156,   157,   660,
       0,     0,   159,   160,   161,     0,   162,   163,   661,   165,
       0,   166,   167,   532,   662,   663,   664,   665,   168,   169,
     170,   171,   172,   666,   667,   175,     0,     0,   176,   177,
     178,   179,   180,     0,     0,     0,   181,   668,   183,   184,
       0,   185,   186,     0,     0,     0,   188,   189,   669,   191,
     192,   670,   671,   194,   672,     0,   196,     0,   197,   533,
       0,   534,   198,   199,   200,     0,     0,   201,     0,   202,
       0,   203,   204,   205,     0,   206,   207,   208,     0,   537,
     209,   210,   211,   212,   213,   673,   674,     0,   675,     0,
     217,   538,   539,   218,   540,   219,   220,   221,     0,   541,
     222,     0,     0,   223,   224,   225,   676,   677,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   678,   543,
     679,   437,   238,   239,   240,   241,   242,     0,   243,   244,
     544,   681,   682,   683,   247,     0,     0,   248,   438,     0,
       0,   684,   250,     0,     0,   251,   545,   546,   685,   253,
     254,   255,   256,   257,     0,   686,   259,   260,     0,   261,
     262,   263,   264,   265,   687,   267,     0,   268,   269,   270,
     271,   272,   273,   274,   275,   547,   276,   688,   278,   279,
     280,   281,   282,     0,   283,   284,   285,   689,   286,   287,
     288,   289,     0,   290,   690,     0,   292,   293,   294,   295,
     296,   297,   298,   299,   691,   301,     0,   302,   303,   304,
       0,   692,   693,     0,   307,     0,   308,   694,   310,   695,
     696,   312,   313,   314,   315,     0,   697,   316,   317,   318,
     319,   320,   698,     0,   321,   322,   323,   324,   699,   326,
     549,   327,   328,   329,     0,     0,   330,   331,   332,   333,
     334,   335,     0,   700,   701,   444,     0,   702,   703,   704,
     413,   705,     0,     0,     0,     0,     0,   706,   707,     0,
       0,   709,   710,     0,     0,     0,   711,   129,   130,   131,
     132,   133,   134,   135,     0,   136,     0,     0,     0,     0,
       0,     0,   137,   138,   139,   529,   140,   141,   142,   530,
     653,   531,   654,   655,     0,   146,   147,   148,   149,   656,
     657,   150,   658,   659,   153,     0,   154,   155,   156,   157,
     660,     0,     0,   159,   160,   161,     0,   162,   163,   661,
     165,     0,   166,   167,   532,   662,   663,   664,   665,   168,
     169,   170,   171,   172,   666,   667,   175,     0,     0,   176,
     177,   178,   179,   180,     0,     0,     0,   181,   668,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,   669,
     191,   192,   670,   671,   194,   672,     0,   196,     0,   197,
     533,     0,   534,   198,   199,   200,     0,     0,   201,     0,
     202,   535,   203,   204,   205,   536,   206,   207,   208,     0,
     537,   209,   210,   211,   212,   213,   673,   674,     0,   675,
       0,   217,   538,   539,   218,   540,   219,   220,   221,     0,
     541,   222,   542,     0,   223,   224,   225,   676,   677,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   678,
     543,   679,   437,   238,   239,   240,   241,   242,     0,   243,
     244,   544,   681,   682,   683,   247,     0,     0,   248,   438,
       0,     0,   249,   250,     0,     0,   251,   545,   546,   685,
     253,   254,   255,   256,   257,     0,   686,   259,   260,     0,
     261,   262,   263,   264,   265,   687,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,   547,   276,   277,   278,
     279,   280,   281,   282,     0,   283,   284,   285,   689,   286,
     287,   288,   289,   548,   290,   690,     0,   292,   293,   294,
     295,   296,   297,   298,   299,   691,   301,     0,   302,   303,
     304,     0,   692,   693,     0,   307,     0,   308,   694,   310,
     695,   696,   312,   313,   314,   315,     0,     0,   316,   317,
     318,   319,   320,   698,     0,   321,   322,   323,   324,   699,
     326,   549,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   700,   701,   444,     0,   702,   703,
       0,   413,   705,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,     0,  1345,   137,   138,
     139,   529,   140,   141,   142,     0,   653,   531,   654,   655,
       0,   146,   147,   148,   149,   656,   657,   150,   658,   659,
     153,     0,   154,   155,   156,   157,   660,     0,     0,   159,
     160,   161,     0,   162,   163,   661,   165,     0,   166,   167,
     532,   662,   663,   664,   665,   168,   169,   170,   171,   172,
     666,   667,   175,     0,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   668,   183,   184,     0,   185,   186,
       0,     0,     0,   188,   189,   669,   191,   192,   670,   671,
     194,   672,     0,   196,     0,   197,   533,     0,   534,   198,
     199,   200,     0,     0,   201,     0,   202,     0,   203,   204,
     205,     0,   206,   207,   208,     0,   537,   209,   210,   211,
     212,   213,   673,   674,     0,   675,     0,   217,   538,   539,
     218,   540,   219,   220,   221,     0,   541,   222,     0,     0,
     223,   224,   225,   676,   677,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   678,   543,   679,   437,   238,
     239,   240,   241,   242,     0,   243,   244,   544,   681,   682,
     683,   247,     0,     0,   248,   438,     0,     0,   684,   250,
       0,     0,   251,   545,   546,   685,   253,   254,   255,   256,
     257,     0,   686,   259,   260,     0,   261,   262,   263,   264,
     265,   687,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,   547,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   285,   689,   286,   287,   288,   289,     0,
     290,   690,     0,   292,   293,   294,   295,   296,   297,   298,
     299,   691,   301,     0,   302,   303,   304,     0,   692,   693,
       0,   307,     0,   308,   694,   310,   695,   696,   312,   313,
     314,   315,     0,     0,   316,   317,   318,   319,   320,   698,
       0,   321,   322,   323,   324,   699,   326,   549,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     700,   701,   444,     0,   702,   703,   704,   413,   705,     0,
       0,     0,     0,     0,  1341,  1342,     0,     0,  1343,  1344,
       0,     0,     0,  1345,   129,   130,   131,   132,   133,   134,
     135,  -870,   136,     0,     0,     0,  -870,     0,     0,   137,
     138,   139,   529,   140,   141,   142,     0,   653,   531,   654,
     655,     0,   146,   147,   148,   149,   656,   657,   150,   658,
     659,   153,     0,   154,   155,   156,   157,   660,     0,     0,
     159,   160,   161,     0,   162,   163,   661,   165,     0,   166,
     167,   532,   662,   663,   664,   665,   168,   169,   170,   171,
     172,   666,   667,   175,     0,     0,   176,   177,   178,   179,
     180,     0,     0,     0,   181,   668,   183,   184,     0,   185,
     186,     0,     0,     0,   188,   189,   669,   191,   192,   670,
     671,   194,   672,     0,   196,     0,   197,   533,     0,   534,
     198,   199,   200,     0,     0,   201,     0,   202,     0,   203,
     204,   205,     0,   206,   207,   208,     0,   537,   209,   210,
     211,   212,   213,   673,   674,     0,   675,     0,   217,     0,
       0,   218,   540,   219,   220,   221,     0,   541,   222,     0,
       0,   223,   224,   225,   676,   677,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   678,   543,   679,   437,
     238,   239,   240,   241,   242,     0,   243,   244,     0,   681,
     682,   683,   247,     0,     0,   248,   438,     0,     0,     0,
     250,     0,     0,   251,   545,   546,   685,   253,   254,   255,
     256,   257,     0,   686,   259,   260,     0,   261,   262,   263,
     264,   265,   687,   267,     0,   268,   269,   270,   271,   272,
     273,   274,   275,   547,   276,   688,   278,   279,   280,   281,
     282,     0,   283,   284,   285,   689,   286,   287,   288,   289,
       0,   290,   690,  -870,   292,   293,   294,   295,   296,   297,
     298,   299,   691,   301,     0,   302,   303,   304,     0,   692,
     693,     0,   307,     0,   308,   694,   310,   695,   696,   312,
     313,   314,   315,     0,   697,   316,   317,   318,   319,   320,
     698,     0,   321,   322,   323,   324,   699,   326,   549,   327,
     328,   329,     0,     0,   330,   331,   332,   333,   334,   335,
       0,   700,   701,   444,     0,   702,   703,     0,   413,   705,
     129,   130,   131,   132,   133,   134,   135,  -871,   136,     0,
     710,     0,  -871,     0,   711,   137,   138,   139,   529,   140,
     141,   142,     0,   653,   531,   654,   655,     0,   146,   147,
     148,   149,   656,   657,   150,   658,   659,   153,     0,   154,
     155,   156,   157,   660,     0,     0,   159,   160,   161,     0,
     162,   163,   661,   165,     0,   166,   167,   532,   662,   663,
     664,   665,   168,   169,   170,   171,   172,   666,   667,   175,
       0,     0,   176,   177,   178,   179,   180,     0,     0,     0,
     181,   668,   183,   184,     0,   185,   186,     0,     0,     0,
     188,   189,   669,   191,   192,   670,   671,   194,   672,     0,
     196,     0,   197,   533,     0,   534,   198,   199,   200,     0,
       0,   201,     0,   202,     0,   203,   204,   205,     0,   206,
     207,   208,     0,   537,   209,   210,   211,   212,   213,   673,
     674,     0,   675,     0,   217,     0,     0,   218,   540,   219,
     220,   221,     0,   541,   222,     0,     0,   223,   224,   225,
     676,   677,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   678,   543,   679,   437,   238,   239,   240,   241,
     242,     0,   243,   244,     0,   681,   682,   683,   247,     0,
       0,   248,   438,     0,     0,     0,   250,     0,     0,   251,
     545,   546,   685,   253,   254,   255,   256,   257,     0,   686,
     259,   260,     0,   261,   262,   263,   264,   265,   687,   267,
       0,   268,   269,   270,   271,   272,   273,   274,   275,   547,
     276,   688,   278,   279,   280,   281,   282,     0,   283,   284,
     285,   689,   286,   287,   288,   289,     0,   290,   690,  -871,
     292,   293,   294,   295,   296,   297,   298,   299,   691,   301,
       0,   302,   303,   304,     0,   692,   693,     0,   307,     0,
     308,   694,   310,   695,   696,   312,   313,   314,   315,     0,
     697,   316,   317,   318,   319,   320,   698,     0,   321,   322,
     323,   324,   699,   326,   549,   327,   328,   329,     0,     0,
     330,   331,   332,   333,   334,   335,     0,   700,   701,   444,
       0,   702,   703,     0,   413,   705,   129,   130,   131,   132,
     133,   134,   135,     0,   136,     0,     0,     0,     0,     0,
     711,   137,   138,   139,   529,   140,   141,   142,     0,   653,
     531,   654,   655,     0,   146,   147,   148,   149,   656,   657,
     150,   658,   659,   153,     0,   154,   155,   156,   157,   660,
       0,     0,   159,   160,   161,     0,   162,   163,   661,   165,
       0,   166,   167,   532,   662,   663,   664,   665,   168,   169,
     170,   171,   172,   666,   667,   175,     0,     0,   176,   177,
     178,   179,   180,     0,     0,     0,   181,   668,   183,   184,
       0,   185,   186,     0,     0,     0,   188,   189,   669,   191,
     192,   670,   671,   194,   672,     0,   196,     0,   197,   533,
       0,   534,   198,   199,   200,     0,     0,   201,     0,   202,
       0,   203,   204,   205,     0,   206,   207,   208,     0,   537,
     209,   210,   211,   212,   213,   673,   674,     0,   675,     0,
     217,     0,     0,   218,   540,   219,   220,   221,     0,   541,
     222,     0,     0,   223,   224,   225,   676,   677,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   678,   543,
     679,   437,   238,   239,   240,   241,   242,     0,   243,   244,
       0,     0,   682,   683,   247,     0,     0,   248,   438,     0,
       0,     0,   250,     0,     0,   251,   545,   546,   685,   253,
     254,   255,   256,   257,     0,   686,   259,   260,     0,   261,
     262,   263,   264,   265,   687,   267,     0,   268,   269,   270,
     271,   272,   273,   274,   275,   547,   276,   277,   278,   279,
     280,   281,   282,     0,   283,   284,   285,   689,   286,   287,
     288,   289,     0,   290,   690,     0,   292,   293,   294,   295,
     296,   297,   298,   299,   691,   301,     0,   302,   303,   304,
       0,   692,   693,     0,   307,     0,   308,   694,   310,   695,
     696,   312,   313,   314,   315,     0,     0,   316,   317,   318,
     319,   320,   698,     0,   321,   322,   323,   324,   699,   326,
     549,   327,   328,   329,     0,     0,   330,   331,   332,   333,
     334,   335,     0,   700,   701,   444,     0,   702,   703,     0,
     413,   705,   129,   130,   131,   132,   133,   134,   135,     0,
     136,     0,  1344,     0,     0,     0,  1345,   137,   138,   139,
     529,   140,   141,   142,     0,   653,   531,   654,   655,     0,
     146,   147,   148,   149,   656,   657,   150,   658,   659,   153,
       0,   154,   155,   156,   157,   660,     0,     0,   159,   160,
     161,     0,   162,   163,   661,   165,     0,   166,   167,   532,
     662,   663,   664,   665,   168,   169,   170,   171,   172,   666,
     667,   175,     0,     0,   176,   177,   178,   179,   180,     0,
       0,     0,   181,   668,   183,   184,     0,   185,   186,     0,
       0,     0,   188,   189,   669,   191,   192,   670,   671,   194,
     672,     0,   196,     0,   197,   533,     0,   534,   198,   199,
     200,     0,     0,   201,     0,   202,     0,   203,   204,   205,
       0,   206,   207,   208,     0,   537,   209,   210,   211,   212,
     213,   673,   674,     0,   675,     0,   217,     0,     0,   218,
     540,   219,   220,   221,     0,   541,   222,     0,     0,   223,
     224,   225,   676,   677,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   678,   543,   679,   437,   238,   239,
     240,   241,   242,     0,   243,   244,     0,     0,   682,   683,
     247,     0,     0,   248,   438,     0,     0,     0,   250,     0,
       0,   251,   545,   546,   685,   253,   254,   255,   256,   257,
       0,   686,   259,   260,     0,   261,   262,   263,   264,   265,
     687,   267,     0,   268,   269,   270,   271,   272,   273,   274,
     275,   547,   276,   277,   278,   279,   280,   281,   282,     0,
     283,   284,   285,   689,   286,   287,   288,   289,     0,   290,
     690,     0,   292,   293,   294,   295,   296,   297,   298,   299,
     691,   301,     0,   302,   303,   304,     0,   692,   693,     0,
     307,     0,   308,   694,   310,   695,   696,   312,   313,   314,
     315,     0,     0,   316,   317,   318,   319,   320,   698,     0,
     321,   322,   323,   324,   699,   326,   549,   327,   328,   329,
       0,     0,   330,   331,   332,   333,   334,   335,     0,   700,
     701,   444,     0,   702,   703,     0,   413,   705,   129,   130,
     131,   132,   133,   134,   135,     0,   136,     0,     0,     0,
       0,     0,  1345,   137,   138,   139,   529,   140,   141,   142,
     530,   143,   531,   144,   145,     0,   146,   147,   148,   149,
       0,     0,   150,   151,   152,   153,     0,   154,   155,   156,
     157,   158,     0,     0,   159,   160,   161,     0,   162,   163,
     164,   165,     0,   166,   167,   532,     0,     0,     0,     0,
     168,   169,   170,   171,   172,   173,   174,   175,     0,     0,
     176,   177,   178,   179,   180,     0,     0,     0,   181,   182,
     183,   184,     0,   185,   186,     0,   187,     0,   188,   189,
     190,   191,   192,   193,     0,   194,   195,     0,   196,     0,
     197,   533,     0,   534,   198,   199,   200,     0,     0,   201,
       0,   202,   535,   203,   204,   205,   536,   206,   207,   208,
       0,   537,   209,   210,   211,   212,   213,   214,   215,     0,
     216,     0,   217,   538,   539,   218,   540,   219,   220,   221,
       0,   541,   222,   542,     0,   223,   224,   225,     0,     0,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   543,   237,   437,   238,   239,   240,   241,   242,     0,
     243,   244,   544,     0,   245,   246,   247,     0,     0,   248,
     438,     0,   487,   249,   250,     0,     0,   251,   545,   546,
     252,   253,   254,   255,   256,   257,     0,   258,   259,   260,
       0,   261,   262,   263,   264,   265,   266,   267,     0,   268,
     269,   270,   271,   272,   273,   274,   275,   547,   276,   277,
     278,   279,   280,   281,   282,    33,   283,   284,   285,     0,
     286,   287,   288,   289,   548,   290,   291,     0,   292,   293,
     294,   295,   296,   297,   298,   299,   300,   301,     0,   302,
     303,   304,     0,   305,   306,     0,   307,     0,   308,   309,
     310,   311,     0,   312,   313,   314,   315,     0,     0,   316,
     317,   318,   319,   320,     0,     0,   321,   322,   323,   324,
     325,   326,   549,   327,   328,   329,     0,     0,   330,   331,
     332,   333,   334,   335,     0,   550,     0,     0,     0,     0,
       0,     0,     0,     0,   129,   130,   131,   132,   133,   134,
     135,     0,   136,     0,     0,     0,     0,     0,  1707,   137,
     138,   139,   529,   140,   141,   142,   530,   143,   531,   144,
     145,     0,   146,   147,   148,   149,     0,     0,   150,   151,
     152,   153,     0,   154,   155,   156,   157,   158,     0,     0,
     159,   160,   161,     0,   162,   163,   164,   165,     0,   166,
     167,   532,     0,     0,     0,     0,   168,   169,   170,   171,
     172,   173,   174,   175,     0,     0,   176,   177,   178,   179,
     180,     0,     0,     0,   181,   182,   183,   184,     0,   185,
     186,     0,   187,     0,   188,   189,   190,   191,   192,   193,
       0,   194,   195,     0,   196,     0,   197,   533,     0,   534,
     198,   199,   200,     0,     0,   201,     0,   202,   535,   203,
     204,   205,   536,   206,   207,   208,     0,   537,   209,   210,
     211,   212,   213,   214,   215,     0,   216,     0,   217,   538,
     539,   218,   540,   219,   220,   221,     0,   541,   222,   542,
       0,   223,   224,   225,     0,     0,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   543,   237,   437,
     238,   239,   240,   241,   242,     0,   243,   244,   544,     0,
     245,   246,   247,     0,     0,   248,   438,     0,   487,   249,
     250,     0,     0,   251,   545,   546,   252,   253,   254,   255,
     256,   257,     0,   258,   259,   260,     0,   261,   262,   263,
     264,   265,   266,   267,     0,   268,   269,   270,   271,   272,
     273,   274,   275,   547,   276,   277,   278,   279,   280,   281,
     282,     0,   283,   284,   285,     0,   286,   287,   288,   289,
     548,   290,   291,     0,   292,   293,   294,   295,   296,   297,
     298,   299,   300,   301,     0,   302,   303,   304,     0,   305,
     306,     0,   307,     0,   308,   309,   310,   311,     0,   312,
     313,   314,   315,     0,     0,   316,   317,   318,   319,   320,
       0,     0,   321,   322,   323,   324,   325,   326,   549,   327,
     328,   329,     0,     0,   330,   331,   332,   333,   334,   335,
       0,   550,   129,   130,   131,   132,   133,   134,   135,     0,
     136,     0,     0,     0,     0,     0,     0,   137,   138,   139,
       0,   140,   141,   142,  1707,   143,     0,   144,   145,     0,
     146,   147,   148,   149,     0,     0,   150,   151,   152,   153,
       0,   154,   155,   156,   157,   158,     0,     0,   159,   160,
     161,     0,   162,   163,   164,   165,     0,   166,   167,     0,
       0,     0,     0,     0,   168,   169,   170,   171,   172,   173,
     174,   175,     0,     0,   176,   177,   178,   179,   180,     0,
       0,     0,   181,   182,   183,   184,     0,   185,   186,     0,
     187,     0,   188,   189,   190,   191,   192,   193,     0,   194,
     195,     0,   196,     0,   197,     0,     0,     0,   198,   199,
     200,     0,     0,   201,     0,   202,     0,   203,   204,   205,
       0,   206,   207,   208,     0,     0,   209,   210,   211,   212,
     213,   214,   215,     0,   216,     0,   217,     0,     0,   218,
       0,   219,   220,   221,     0,     0,   222,     0,     0,   223,
     224,   225,     0,     0,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,     0,   237,   437,   238,   239,
     240,   241,   242,     0,   243,   244,     0,     0,   245,   246,
     247,     0,     0,   248,   438,     0,     0,   249,   250,     0,
       0,   251,     0,     0,   252,   253,   254,   255,   256,   257,
       0,   258,   259,   260,     0,   261,   262,   263,   264,   265,
     266,   267,     0,   268,   269,   270,   271,   272,   273,   274,
     275,     0,   276,   277,   278,   279,   280,   281,   282,     0,
     283,   284,   285,     0,   286,   287,   288,   289,     0,   290,
     291,     0,   292,   293,   294,   295,   296,   297,   298,   299,
     300,   301,     0,   302,   303,   304,     0,   305,   306,     0,
     307,     0,   308,   309,   310,   311,     0,   312,   313,   314,
     315,     0,     0,   316,   317,   318,   319,   320,     0,     0,
     321,   322,   323,   324,   325,   326,     0,   327,   328,   329,
       0,     0,   330,   331,   332,   333,   334,   335,     0,   336,
     129,   130,   131,   132,   133,   134,   135,     0,   136,     0,
       0,     0,     0,     0,     0,   137,   138,   139,     0,   140,
     141,   142,   764,   143,     0,   144,   145,     0,   146,   147,
     148,   149,     0,     0,   150,   151,   152,   153,     0,   154,
     155,   156,   157,   158,     0,     0,   159,   160,   161,     0,
     162,   163,   164,   165,     0,   166,   167,     0,     0,     0,
       0,     0,   168,   169,   170,   171,   172,   173,   174,   175,
       0,     0,   176,   177,   178,   179,   180,     0,     0,     0,
     181,   182,   183,   184,     0,   185,   186,     0,   187,     0,
     188,   189,   190,   191,   192,   193,     0,   194,   195,     0,
     196,     0,   197,     0,     0,     0,   198,   199,   200,     0,
       0,   201,     0,   202,     0,   203,   204,   205,     0,   206,
     207,   208,     0,     0,   209,   210,   211,   212,   213,   214,
     215,     0,   216,     0,   217,     0,     0,   218,     0,   219,
     220,   221,     0,     0,   222,     0,     0,   223,   224,   225,
       0,     0,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,     0,   237,     0,   238,   239,   240,   241,
     242,     0,   243,   244,     0,     0,   245,   246,   247,     0,
       0,   248,     0,     0,     0,   249,   250,     0,     0,   251,
       0,     0,   252,   253,   254,   255,   256,   257,     0,   258,
     259,   260,     0,   261,   262,   263,   264,   265,   266,   267,
       0,   268,   269,   270,   271,   272,   273,   274,   275,     0,
     276,   277,   278,   279,   280,   281,   282,    33,   283,   284,
     285,     0,   286,   287,   288,   289,     0,   290,   291,     0,
     292,   293,   294,   295,   296,   297,   298,   299,   300,   301,
       0,   302,   303,   304,     0,   305,   306,     0,   307,     0,
     308,   309,   310,   311,     0,   312,   313,   314,   315,     0,
       0,   316,   317,   318,   319,   320,     0,     0,   321,   322,
     323,   324,   325,   326,     0,   327,   328,   329,     0,     0,
     330,   331,   332,   333,   334,   335,     0,   336,   129,   130,
     131,   132,   133,   134,   135,     0,   136,     0,     0,     0,
       0,     0,     0,   137,   138,   139,     0,   140,   141,   142,
      41,   143,     0,   144,   145,     0,   146,   147,   148,   149,
       0,     0,   150,   151,   152,   153,     0,   154,   155,   156,
     157,   158,     0,     0,   159,   160,   161,     0,   162,   163,
     164,   165,     0,   166,   167,     0,     0,     0,     0,     0,
     168,   169,   170,   171,   172,   173,   174,   175,     0,     0,
     176,   177,   178,   179,   180,     0,     0,     0,   181,   182,
     183,   184,     0,   185,   186,     0,   187,     0,   188,   189,
     190,   191,   192,   193,     0,   194,   195,     0,   196,     0,
     197,     0,     0,     0,   198,   199,   200,     0,     0,   201,
       0,   202,     0,   203,   204,   205,     0,   206,   207,   208,
       0,     0,   209,   210,   211,   212,   213,   214,   215,     0,
     216,     0,   217,     0,     0,   218,     0,   219,   220,   221,
       0,     0,   222,     0,     0,   223,   224,   225,     0,     0,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,     0,   237,     0,   238,   239,   240,   241,   242,     0,
     243,   244,     0,     0,   245,   246,   247,     0,     0,   248,
       0,     0,     0,   249,   250,     0,     0,   251,     0,     0,
     252,   253,   254,   255,   256,   257,     0,   258,   259,   260,
       0,   261,   262,   263,   264,   265,   266,   267,     0,   268,
     269,   270,   271,   272,   273,   274,   275,     0,   276,   277,
     278,   279,   280,   281,   282,     0,   283,   284,   285,     0,
     286,   287,   288,   289,     0,   290,   291,     0,   292,   293,
     294,   295,   296,   297,   298,   299,   300,   301,     0,   302,
     303,   304,     0,   305,   306,     0,   307,     0,   308,   309,
     310,   311,     0,   312,   313,   314,   315,     0,     0,   316,
     317,   318,   319,   320,     0,     0,   321,   322,   323,   324,
     325,   326,     0,   327,   328,   329,     0,     0,   330,   331,
     332,   333,   334,   335,     0,   336,   129,   130,   131,   132,
     133,   134,   135,     0,   136,     0,     0,     0,     0,     0,
       0,   137,   138,   139,     0,   140,   141,   142,  2095,   143,
       0,   144,   145,     0,   146,   147,   148,   149,     0,     0,
     150,   151,   152,   153,     0,   154,   570,   156,   157,   158,
       0,     0,   159,   160,   161,     0,   162,   163,   164,   165,
       0,   166,   167,     0,     0,     0,     0,     0,   168,   169,
     170,   171,   172,   173,   174,   175,     0,     0,   176,   177,
     178,   179,   180,     0,     0,     0,   181,   182,   183,   184,
       0,   185,   186,     0,   187,     0,   188,   189,   190,   191,
     192,   193,     0,   194,   195,     0,   196,     0,   197,     0,
       0,     0,   198,   199,   200,     0,     0,   201,     0,   202,
       0,   203,   204,   205,     0,   206,   207,   208,     0,     0,
     209,   210,   211,   212,   213,   214,   215,     0,   216,     0,
     217,     0,     0,   218,     0,   219,   220,   221,     0,     0,
     222,     0,     0,   223,   224,   225,     0,     0,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,     0,
     237,     0,   238,   239,   240,   241,   242,     0,   243,   244,
       0,     0,   245,   246,   247,     0,     0,   248,     0,     0,
       0,   249,   250,     0,     0,   251,     0,     0,   252,   253,
     254,   255,   256,   257,     0,   258,   259,   260,     0,   261,
     262,   263,   264,   265,   266,   267,     0,   268,   269,   270,
     271,   272,   273,   274,   275,     0,   276,   277,   278,   279,
     280,   281,   282,     0,   283,   284,   285,     0,   286,   287,
     288,   289,     0,   290,   291,     0,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,     0,   302,   303,   304,
       0,   305,   306,     0,   307,     0,   308,   309,   310,   311,
       0,   312,   313,   314,   315,     0,     0,   316,   317,   318,
     319,   320,     0,     0,   321,   322,   323,   324,   325,   326,
       0,   327,   328,   329,     0,     0,   330,   331,   332,   333,
     334,   335,     0,   336,     0,     0,     0,     0,     0,   571,
       0,     0,     0,   572,   573,   574,     0,   575,   576,   577,
     578,   579,   580,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,     0,     0,   137,   138,
     139,     0,   140,   141,   142,     0,   143,     0,   144,   145,
       0,   146,   147,   148,   149,     0,     0,   150,   151,   152,
     153,     0,   154,   611,   156,   157,   158,     0,     0,   159,
     160,   161,     0,   162,   163,   164,   165,     0,   166,   167,
       0,     0,     0,     0,     0,   168,   169,   170,   171,   172,
     173,   174,   175,     0,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   182,   183,   184,     0,   185,   186,
       0,   187,     0,   188,   189,   190,   191,   192,   193,     0,
     194,   195,     0,   196,     0,   197,     0,     0,     0,   198,
     199,   200,     0,     0,   201,     0,   202,     0,   203,   204,
     205,     0,   206,   207,   208,     0,     0,   209,   210,   211,
     212,   213,   214,   215,     0,   216,     0,   217,     0,     0,
     218,     0,   219,   220,   221,     0,     0,   222,     0,     0,
     223,   224,   225,     0,     0,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,     0,   237,     0,   238,
     239,   240,   241,   242,     0,   243,   244,     0,     0,   245,
     246,   247,     0,     0,   248,     0,     0,     0,   249,   250,
       0,     0,   251,     0,     0,   252,   253,   254,   255,   256,
     257,     0,   258,   259,   260,     0,   261,   262,   263,   264,
     265,   266,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,     0,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   285,     0,   286,   287,   288,   289,     0,
     290,   291,     0,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,     0,   302,   303,   304,     0,   305,   306,
       0,   307,     0,   308,   309,   310,   311,     0,   312,   313,
     314,   315,     0,     0,   316,   317,   318,   319,   320,     0,
       0,   321,   322,   323,   324,   325,   326,     0,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     336,     0,     0,     0,     0,     0,   571,     0,     0,     0,
     572,   573,   574,     0,   575,   576,   577,   578,   579,   580,
     129,   130,   131,   132,   133,   134,   135,     0,   136,     0,
       0,     0,     0,     0,     0,   137,   138,   139,     0,   140,
     141,   142,     0,   143,     0,   144,   145,     0,   146,   147,
     148,   149,     0,     0,   150,   151,   152,   153,     0,   154,
     155,   156,   157,   158,     0,     0,   159,   160,   161,     0,
     162,   163,   164,   165,     0,   166,   167,     0,     0,     0,
       0,     0,   168,   169,   170,   171,   172,   173,   174,   175,
       0,     0,   176,   177,   178,   179,   180,     0,     0,     0,
     181,   182,   183,   184,     0,   185,   186,     0,   187,     0,
     188,   189,   190,   191,   192,   193,     0,   194,   195,     0,
     196,     0,   197,     0,     0,     0,   198,   199,   200,     0,
       0,   201,     0,   202,     0,   203,   204,   205,     0,   206,
     207,   208,     0,     0,   209,   210,   211,   212,   213,   214,
     215,     0,   216,     0,   217,     0,     0,   218,     0,   219,
     220,   221,     0,     0,   222,     0,     0,   223,   224,   225,
       0,     0,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,     0,   237,     0,   238,   239,   240,   241,
     242,     0,   243,   244,     0,     0,   245,   246,   247,     0,
       0,   248,     0,     0,     0,   249,   250,     0,     0,   251,
       0,     0,   252,   253,   254,   255,   256,   257,     0,   258,
     259,   260,     0,   261,   262,   263,   264,   265,   266,   267,
       0,   268,   269,   270,   271,   272,   273,   274,   275,     0,
     276,   277,   278,   279,   280,   281,   282,     0,   283,   284,
     285,     0,   286,   287,   288,   289,     0,   290,   291,     0,
     292,   293,   294,   295,   296,   297,   298,   299,   300,   301,
       0,   302,   303,   304,     0,   305,   306,     0,   307,     0,
     308,   309,   310,   311,     0,   312,   313,   314,   315,     0,
       0,   316,   317,   318,   319,   320,     0,     0,   321,   322,
     323,   324,   325,   326,     0,   327,   328,   329,     0,     0,
     330,   331,   332,   333,   334,   335,     0,   336,     0,     0,
       0,     0,     0,   571,     0,     0,     0,   572,   573,   574,
       0,   575,   576,   577,   578,   579,   580,   129,   130,   131,
     132,   133,   134,   135,     0,   136,     0,     0,     0,     0,
       0,     0,   137,   138,   139,     0,   140,   141,   142,     0,
     814,     0,   815,   816,     0,   146,   147,   148,   149,     0,
       0,   150,   817,   818,   153,     0,   154,   155,   156,   157,
       0,     0,     0,   159,   160,   161,     0,   162,   163,     0,
     165,     0,   166,   167,     0,     0,     0,     0,     0,   168,
     169,   170,   171,   172,   819,   820,   175,     0,     0,   176,
     177,   178,   179,   180,     0,     0,     0,   181,   668,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,     0,
     191,   192,     0,     0,   194,   821,     0,   196,     0,   197,
       0,     0,     0,   198,   199,   200,     0,     0,   201,     0,
     202,     0,   203,   204,   205,     0,   206,   207,   208,     0,
       0,   209,   210,   211,   212,   213,   822,   823,     0,   824,
       0,   217,     0,     0,   218,     0,   219,   220,   221,     0,
       0,   222,     0,     0,   223,   224,   225,     0,     0,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   678,
       0,   825,     0,   238,   239,   240,   241,     0,     0,   243,
     244,     0,     0,     0,   826,   247,     0,     0,   248,     0,
       0,     0,  1769,   250,     0,     0,   251,     0,     0,     0,
     253,   254,   255,   256,   257,     0,     0,   259,   260,     0,
     261,   262,   263,   264,   265,   827,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,     0,   276,     0,   278,
     279,   280,   281,   282,     0,   283,   284,   285,     0,   286,
     828,   288,   289,     0,   290,   829,     0,   292,   293,   294,
     295,   296,   297,   298,   299,     0,   301,     0,   302,   303,
     304,     0,   830,   831,     0,   307,     0,   308,     0,   310,
       0,     0,   312,   313,   314,   315,     0,     0,   316,   317,
     318,   319,   320,     0,     0,   321,   322,   323,   324,   832,
     326,     0,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   833,  1044,   444,     0,     0,     0,
     571,   413,     0,     0,   572,   573,   574,     0,   575,  1770,
     577,   578,   579,   580,   129,   130,   131,   132,   133,   134,
     135,     0,   136,     0,     0,     0,     0,     0,     0,   137,
     138,   139,     0,   140,   141,   142,     0,   143,     0,   144,
     145,     0,   146,   147,   148,   149,     0,     0,   150,   151,
     152,   153,     0,   154,   155,   156,   157,   158,     0,     0,
     159,   160,   161,     0,   162,   163,   164,   165,     0,   166,
     167,     0,     0,     0,     0,     0,   168,   169,   170,   171,
     172,   173,   174,   175,     0,     0,   176,   177,   178,   179,
     180,     0,     0,     0,   181,   182,   183,   184,     0,   185,
     186,     0,   187,     0,   188,   189,   190,   191,   192,   193,
       0,   194,   195,     0,   196,     0,   197,     0,     0,     0,
     198,   199,   200,     0,     0,   201,     0,   202,     0,   203,
     204,   205,     0,   206,   207,   208,     0,     0,   209,   210,
     211,   212,   213,   214,   215,     0,   216,     0,   217,     0,
       0,   218,     0,   219,   220,   221,     0,     0,   222,     0,
       0,   223,   224,   225,     0,     0,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,     0,   237,   437,
     238,   239,   240,   241,   242,     0,   243,   244,     0,     0,
     245,   246,   247,     0,     0,   248,   438,     0,     0,   249,
     250,     0,     0,   251,     0,     0,   252,   253,   254,   255,
     256,   257,     0,   258,   259,   260,     0,   261,   262,   263,
     264,   265,   266,   267,     0,   268,   269,   270,   271,   272,
     273,   274,   275,     0,   276,   277,   278,   279,   280,   281,
     282,     0,   283,   284,   285,     0,   286,   287,   288,   289,
       0,   290,   291,     0,   292,   293,   294,   295,   296,   297,
     298,   299,   300,   301,     0,   302,   303,   304,     0,   305,
     306,     0,   307,     0,   308,   309,   310,   311,     0,   312,
     313,   314,   315,     0,     0,   316,   317,   318,   319,   320,
       0,     0,   321,   322,   323,   324,   325,   326,     0,   327,
     328,   329,     0,     0,   330,   331,   332,   333,   334,   335,
       0,   336,     0,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,     0,   485,   137,   138,
     139,     0,   140,   141,   142,     0,   143,     0,   144,   145,
       0,   146,   147,   148,   149,     0,     0,   150,   151,   152,
     153,     0,   154,   155,   156,   157,   158,     0,     0,   159,
     160,   161,     0,   162,   163,   164,   165,     0,   166,   167,
       0,     0,     0,     0,     0,   168,   169,   170,   171,   172,
     173,   174,   175,     0,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   182,   183,   184,     0,   185,   186,
       0,   187,     0,   188,   189,   190,   191,   192,   193,     0,
     194,   195,     0,   196,     0,   197,     0,     0,     0,   198,
     199,   200,     0,     0,   201,     0,   202,     0,   203,   204,
     205,     0,   206,   207,   208,     0,     0,   209,   210,   211,
     212,   213,   214,   215,     0,   216,     0,   217,     0,     0,
     218,     0,   219,   220,   221,     0,     0,   222,     0,     0,
     223,   224,   225,     0,     0,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,     0,   237,     0,   238,
     239,   240,   241,   242,     0,   243,   244,     0,     0,   245,
     246,   247,     0,     0,   248,     0,     0,     0,   249,   250,
       0,     0,   251,     0,     0,   252,   253,   254,   255,   256,
     257,     0,   258,   259,   260,     0,   261,   262,   263,   264,
     265,   266,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,     0,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   285,     0,   286,   287,   288,   289,     0,
     290,   291,     0,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,     0,   302,   303,   304,     0,   305,   306,
       0,   307,     0,   308,   309,   310,   311,     0,   312,   313,
     314,   315,     0,     0,   316,   317,   318,   319,   320,     0,
       0,   321,   322,   323,   324,   325,   326,     0,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     336,     0,   129,   130,   131,   132,   133,   134,   135,     0,
     136,     0,     0,     0,     0,     0,   915,   137,   138,   139,
       0,   140,   141,   142,     0,   814,     0,   815,   816,     0,
     146,   147,   148,   149,     0,     0,   150,   817,   818,   153,
       0,   154,   155,   156,   157,     0,     0,     0,   159,   160,
     161,     0,   162,   163,     0,   165,     0,   166,   167,     0,
       0,     0,     0,     0,   168,   169,   170,   171,   172,   819,
     820,   175,     0,     0,   176,   177,   178,   179,   180,     0,
       0,     0,   181,   668,   183,   184,     0,   185,   186,     0,
     187,     0,   188,   189,     0,   191,   192,     0,     0,   194,
     821,     0,   196,     0,   197,     0,     0,     0,   198,   199,
     200,     0,     0,   201,     0,   202,     0,   203,   204,   205,
       0,   206,   207,   208,     0,     0,   209,   210,   211,   212,
     213,   822,   823,     0,   824,     0,   217,     0,     0,   218,
       0,   219,   220,   221,     0,     0,   222,     0,     0,   223,
     224,   225,     0,     0,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   678,     0,   825,     0,   238,   239,
     240,   241,     0,     0,   243,   244,     0,     0,     0,   826,
     247,     0,     0,   248,     0,     0,     0,   249,   250,     0,
       0,   251,     0,     0,     0,   253,   254,   255,   256,   257,
       0,     0,   259,   260,     0,   261,   262,   263,   264,   265,
     827,   267,     0,   268,   269,   270,   271,   272,   273,   274,
     275,     0,   276,     0,   278,   279,   280,   281,   282,     0,
     283,   284,   285,     0,   286,   828,   288,   289,     0,   290,
     829,     0,   292,   293,   294,   295,   296,   297,   298,   299,
       0,   301,     0,   302,   303,   304,     0,   830,   831,     0,
     307,     0,   308,     0,   310,     0,     0,   312,   313,   314,
     315,     0,     0,   316,   317,   318,   319,   320,     0,     0,
     321,   322,   323,   324,   832,   326,     0,   327,   328,   329,
       0,     0,   330,   331,   332,   333,   334,   335,     0,   833,
       0,   129,   130,   131,   132,   133,   134,   135,     0,   136,
       0,     0,     0,     0,     0,  1250,   137,   138,   139,     0,
     140,   141,   142,     0,   143,     0,   144,   145,     0,   146,
     147,   148,   149,     0,     0,   150,   151,   152,   153,     0,
     154,   155,   156,   157,   158,     0,     0,   159,   160,   161,
       0,   162,   163,   164,   165,     0,   166,   167,     0,     0,
       0,     0,     0,   168,   169,   170,   171,   172,   173,   174,
     175,  1054,     0,   176,   177,   178,   179,   180,     0,     0,
       0,   181,   182,   183,   184,     0,   185,   186,     0,   187,
       0,   188,   189,   190,   191,   192,   193,  1055,   194,   195,
       0,   196,     0,   197,     0,     0,     0,   198,   199,   200,
       0,     0,   201,     0,   202,     0,   203,   204,   205,     0,
     206,   207,   208,     0,     0,   209,   210,   211,   212,   213,
     214,   215,     0,   216,     0,   217,     0,     0,   218,     0,
     219,   220,   221,     0,     0,   222,     0,     0,   223,   224,
     225,     0,     0,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   236,     0,   237,     0,   238,   239,   240,
     241,   242,     0,   243,   244,     0,     0,   245,   246,   247,
    1056,     0,   248,     0,  1057,     0,   249,   250,     0,     0,
     251,     0,     0,   252,   253,   254,   255,   256,   257,     0,
     258,   259,   260,     0,   261,   262,   263,   264,   265,   266,
     267,     0,   268,   269,   270,   271,   272,   273,   274,   275,
       0,   276,   277,   278,   279,   280,   281,   282,     0,   283,
     284,   285,     0,   286,   287,   288,   289,     0,   290,   291,
       0,   292,   293,   294,   295,   296,   297,   298,   299,   300,
     301,     0,   302,   303,   304,     0,   305,   306,     0,   307,
       0,   308,   309,   310,   311,  1058,   312,   313,   314,   315,
       0,     0,   316,   317,   318,   319,   320,     0,     0,   321,
     322,   323,   324,   325,   326,     0,   327,   328,   329,     0,
       0,   330,   331,   332,   333,   334,   335,     0,   336,  1044,
     889,     0,     0,     0,     0,   413,   129,   130,   131,   132,
     133,   134,   135,  1045,   136,     0,     0,     0,     0,     0,
       0,   137,   138,   139,     0,   140,   141,   142,     0,   143,
       0,   144,   145,     0,   146,   147,   148,   149,     0,     0,
     150,   151,   152,   153,     0,   154,   155,   156,   157,   158,
       0,     0,   159,   160,   161,     0,   162,   163,   164,   165,
       0,   166,   167,     0,     0,     0,     0,     0,   168,   169,
     170,   171,   172,   173,   174,   175,     0,     0,   176,   177,
     178,   179,   180,     0,     0,     0,   181,   182,   183,   184,
       0,   185,   186,     0,   187,     0,   188,   189,   190,   191,
     192,   193,  1055,   194,   195,     0,   196,     0,   197,     0,
       0,     0,   198,   199,   200,     0,     0,   201,     0,   202,
       0,   203,   204,   205,     0,   206,   207,   208,     0,     0,
     209,   210,   211,   212,   213,   214,   215,     0,   216,     0,
     217,     0,     0,   218,     0,   219,   220,   221,     0,     0,
     222,     0,     0,   223,   224,   225,     0,     0,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,     0,
     237,     0,   238,   239,   240,   241,   242,     0,   243,   244,
       0,     0,   245,   246,   247,  1056,     0,   248,     0,  1057,
       0,   249,   250,     0,     0,   251,     0,     0,   252,   253,
     254,   255,   256,   257,     0,   258,   259,   260,     0,   261,
     262,   263,   264,   265,   266,   267,     0,   268,   269,   270,
     271,   272,   273,   274,   275,     0,   276,   277,   278,   279,
     280,   281,   282,     0,   283,   284,   285,     0,   286,   287,
     288,   289,     0,   290,   291,     0,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,     0,   302,   303,   304,
       0,   305,   306,     0,   307,     0,   308,   309,   310,   311,
    1058,   312,   313,   314,   315,     0,     0,   316,   317,   318,
     319,   320,     0,     0,   321,   322,   323,   324,   325,   326,
       0,   327,   328,   329,     0,     0,   330,   331,   332,   333,
     334,   335,     0,   336,  1044,   889,     0,     0,     0,     0,
     413,     0,     0,     0,     0,     0,     0,     0,  1045,   129,
     404,   131,   132,   133,   134,   135,   405,   136,     0,     0,
       0,     0,     0,     0,   137,   138,   139,     0,   406,   141,
     142,     0,   143,     0,   144,   145,     0,   146,   147,   148,
     149,     0,     0,   150,   151,   152,   153,     0,   154,   155,
     156,   157,   158,     0,     0,   159,   160,   161,     0,   162,
     163,   164,   165,     0,   166,   167,     0,     0,     0,     0,
       0,   168,   169,   170,   171,   172,   173,   174,   175,     0,
       0,   176,   177,   178,   179,   180,     0,     0,     0,   181,
     182,   183,   184,     0,   185,   186,     0,   187,     0,   188,
     189,   190,   191,   192,   193,     0,   194,   195,     0,   196,
       0,   407,     0,   408,     0,   198,   199,   200,     0,     0,
     201,     0,   202,     0,   203,   204,   205,   409,   206,   207,
     208,     0,     0,   209,   210,   211,   212,   213,   214,   215,
       0,   216,     0,   217,     0,     0,   218,     0,   219,   220,
     221,     0,     0,   222,     0,     0,   223,   224,   225,     0,
       0,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,     0,   237,     0,   410,   239,   240,   241,   242,
       0,   243,   244,     0,     0,   245,   246,   247,     0,     0,
     248,     0,     0,     0,   249,   250,     0,     0,   251,     0,
       0,   252,   253,   254,   255,   256,   257,     0,   258,   259,
     260,     0,   411,   262,   263,   264,   265,   266,   267,     0,
     268,   412,   270,   271,   272,   273,   274,   275,     0,   276,
     277,   278,   279,   280,   281,   282,     0,   283,   284,   285,
       0,   286,   287,   288,   289,     0,   290,   291,     0,   292,
     293,   294,   295,   296,   297,   298,   299,   300,   301,     0,
     302,   303,   304,     0,   305,   306,     0,   307,     0,   308,
     309,   310,   311,     0,   312,   313,   314,   315,     0,     0,
     316,   317,   318,   319,   320,     0,     0,   321,   322,   323,
     324,   325,   326,     0,   327,   328,   329,     0,     0,   330,
     331,   332,   333,   334,   335,  1000,   336,  1669,     0,     0,
       0,  1002,     0,   413,     0,     0,  1003,     0,     0,     0,
       0,   414,     0,     0,     0,  1000,     0,     0,     0,     0,
       0,  1002,     0,     0,     0,     0,  1003,     0,  1004,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1000,     0,
       0,     0,     0,     0,  1002,     0,     0,     0,  1004,  1003,
       0,     0,     0,     0,     0,     0,     0,     0,  1000,     0,
       0,     0,     0,     0,  1002,     0,     0,     0,     0,  1003,
       0,  1004,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1000,     0,     0,     0,     0,     0,  1002,
       0,  1004,     0,     0,  1003,     0,     0,     0,  1005,     0,
       0,     0,  1006,     0,     0,  1002,     0,     0,  1674,     0,
    1003,     0,     0,     0,     0,     0,  1004,     0,  1005,  1007,
    1008,     0,  1006,     0,     0,     0,     0,     0,     0,  1009,
       0,     0,  1004,     0,     0,     0,     0,     0,     0,  1007,
    1008,  1005,     0,     0,     0,  1006,     0,     0,     0,  1009,
       0,     0,     0,     0,     0,  1010,     0,     0,  1011,     0,
       0,  1005,  1007,  1008,     0,  1006,     0,     0,     0,  1012,
       0,  1013,  1009,     0,     0,  1010,  1925,     0,  1011,     0,
       0,     0,  1007,  1008,     0,     0,  1005,     0,     0,  1012,
    1006,  1013,  1009,     0,     0,     0,     0,     0,  1010,     0,
       0,  1011, -1253,     0,     0,     0,  1006,  1007,  1008,     0,
       0,     0,  1012,     0,  1013,     0,     0,  1009,  1010,     0,
    1014,  1011,     0,  1007,  1008,     0,     0,     0,     0,     0,
       0,     0,  1012, -1253,  1013,     0,     0,     0,     0,     0,
    1014,     0,     0,  1010,     0,     0,  1011,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  1012,     0,  1013,
       0,     0,  1011,  1014,     0,     0,     0,     0,     0,     0,
       0,  1000,     0,  1012,     0,     0,     0,  1002,     0,     0,
       0,     0,  1003,  1014,     0,     0,     0,  1015,     0,     0,
       0,  1016,  1017,  1018,     0,  1019,  1020,  1021,  1022,  1023,
    1024,  1871,     0,     0,  1004,     0,  1025,  1015,  1014,     0,
       0,  1016,  1017,  1018,     0,  1019,  1020,  1021,  1022,  1023,
    1024,     0,     0,     0, -1253,     0,  1025,     0,     0,     0,
    1015,     0,     0,     0,  1016,  1017,  1018,     0,  1019,  1020,
    1021,  1022,  1023,  1024,     0,     0,     0,     0,  1777,  1025,
    1015,     0,     0,     0,  1016,  1017,  1018,     0,  1019,  1020,
    1021,  1022,  1023,  1024,     0,  1000,     0,     0,     0,  1025,
       0,  1002,     0,     0,  1005,  1015,  1003,     0,  1006,  1016,
    1017,  1018,     0,  1019,  1020,  1021,  1022,  1023,  1024,     0,
       0,  1015,     0,  1960,  1025,  1007,  1008,     0,  1004,  1019,
    1020,  1021,  1022,  1023,  1024,  1009,     0,     0,     0,     0,
    1025,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1000,     0,     0,     0,     0,     0,
    1002,  1010,     0,     0,  1011,  1003,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1012,     0,  1013,     0,     0,
       0,     0,     0,     0,  1000,     0,     0,  1004,     0,     0,
    1002,     0,     0,     0,     0,  1003,     0,     0,  1005,     0,
       0,     0,  1006,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1000,     0,     0,     0,     0,  1004,  1002,  1007,
    1008,     0,     0,  1003,     0,     0,  1014,     0,     0,  1009,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  1004,     0,     0,  1002,     0,
       0,     0,     0,  1003,     0,  1010,     0,  1005,  1011,     0,
       0,  1006,     0,     0,     0,     0,     0,     0,     0,  1012,
       0,  1013,     0,     0,     0,  1004,     0,     0,  1007,  1008,
       0,     0,     0,     0,     0,     0,     0,  1005,  1009,     0,
       0,  1006,     0,  1015,     0,     0,     0,  1016,  1017,  1018,
       0,  1019,  1020,  1021,  1022,  1023,  1024,     0,  1007,  1008,
       0,  2064,  1025,     0,  1010,  1005,     0,  1011,  1009,  1006,
    1014,     0,     0,     0,     0,     0,     0,     0,  1012,     0,
    1013,     0,     0,     0,     0,     0,  1007,  1008,     0,     0,
       0,     0,     0,  1002,  1010,  1005,  1009,  1011,  1003,  1006,
       0,     0,     0,     0,     0,     0,     0,     0,  1012,     0,
    1013,     0,     0,     0,     0,     0,  1007,  1008,     0,     0,
    1004,     0,  1010,     0,     0,  1011,  1009,     0,     0,  1014,
       0,     0,     0,     0,     0,     0,  1012,  1015,     0,     0,
       0,  1016,  1017,  1018,     0,  1019,  1020,  1021,  1022,  1023,
    1024,     0,  1002,  2170,     0,  1011,  1025,  1003,     0,  1014,
       0,     0,     0,     0,  1926,     0,  1012,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  1004,
       0,     0,     0,     0,     0,     0,  1002,  1014,     0,     0,
   -1253,  1003,     0,     0,  1006,     0,  1015,     0,     0,     0,
    1016,  1017,  1018,     0,  1019,  1020,  1021,  1022,  1023,  1024,
       0,  1007,  1008,  1004,  2200,  1025,     0,  1014,     0,     0,
       0, -1253,     0,  1929,     0,     0,  1015,     0,     0,     0,
    1016,  1017,  1018,     0,  1019,  1020,  1021,  1022,  1023,  1024,
       0,     0,     0,     0,     0,  1025,     0,     0,     0, -1253,
    1011,     0,     0,  1006,  1015,     0,     0,  2079,  1016,  1017,
    1018,  1012,  1019,  1020,  1021,  1022,  1023,  1024,     0,     0,
    1007,  1008,     0,  1025,     0,     0,     0,     0,     0,     0,
   -1253,     0,     0, -1253,  1015,     0,     0,  1006,     0, -1253,
   -1253,     0,  1019,  1020,  1021,  1022,  1023,  1024,     0,     0,
       0,     0,     0,  1025,  1007,  1008,     0,     0,     0,  1011,
       0,     0, -1253,     0, -1253,     0,     0,     0,     0,     0,
    1012,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1011,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  1012,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0, -1253,     0,     0,     0,     0,     0,     0,     0,  1015,
       0,     0,     0,     0,     0,     0,     0,  1019,  1020,  1021,
    1022,  1023,  1024,     0,     0,     0,     0,     0,  1025,     0,
       0,     0,     0,     0,     0, -1253,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  1015,     0,
       0,     0,     0,     0,     0,     0,  1019,  1020,  1021,  1022,
    1023,  1024,     0,     0,     0,     0,     0,  1025,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  1015,     0,     0,     0,     0,     0,     0,     0,
    1019,  1020,  1021,  1022,  1023,  1024,     0,     0,     0,     0,
       0,  1025,   129,   130,   131,   132,   133,   134,   135,     0,
     136,     0,     0,     0,     0,     0,     0,   137,   138,   139,
       0,   140,   141,   142,     0,   143,     0,   144,   145,     0,
     146,   147,   148,   149,     0,     0,   150,   151,   152,   153,
       0,   154,   155,   156,   157,   158,     0,     0,   159,   160,
     161,     0,   162,   163,   164,   165,     0,   166,   167,     0,
       0,     0,     0,     0,   168,   169,   170,   171,   172,   173,
     174,   175,     0,     0,   176,   177,   178,   179,   180,     0,
       0,     0,   181,   182,   183,   184,     0,   185,   186,     0,
     187,     0,   188,   189,   190,   191,   192,   193,     0,   194,
     195,     0,   196,     0,   197,     0,     0,     0,   198,   199,
     200,     0,     0,   201,     0,   202,     0,   203,   204,   205,
       0,   206,   207,   208,     0,     0,   209,   210,   211,   212,
     213,   214,   215,     0,   216,     0,   217,     0,     0,   218,
       0,   219,   220,   221,     0,     0,   222,     0,     0,   223,
     224,   225,     0,     0,   226,   227,   228,   229,   230,   231,
     232,   233,   234,   235,   236,     0,   237,     0,   238,   239,
     240,   241,   242,     0,   243,   244,     0,     0,   245,   246,
     247,     0,     0,   248,     0,     0,     0,   249,   250,     0,
       0,   251,     0,     0,   252,   253,   254,   255,   256,   257,
       0,   258,   259,   260,     0,   261,   262,   263,   264,   265,
     266,   267,     0,   268,   269,   270,   271,   272,   273,   274,
     275,     0,   276,   277,   278,   279,   280,   281,   282,     0,
     283,   284,   285,     0,   286,   287,   288,   289,     0,   290,
     291,     0,   292,   293,   294,   295,   296,   297,   298,   299,
     300,   301,     0,   302,   303,   304,     0,   305,   306,     0,
     307,     0,   308,   309,   310,   311,     0,   312,   313,   314,
     315,     0,     0,   316,   317,   318,   319,   320,     0,     0,
     321,   322,   323,   324,   325,   326,     0,   327,   328,   329,
       0,     0,   330,   331,   332,   333,   334,   335,     0,   336,
    2305,   444,     0,  2306,  2307,     0,  2308,   129,   130,   131,
     132,   133,   134,   135,     0,   136,     0,     0,     0,     0,
       0,     0,   137,   138,   139,     0,   140,   141,   142,     0,
     143,     0,   144,   145,     0,   146,   147,   148,   149,     0,
       0,   150,   151,   152,   153,     0,   154,   155,   156,   157,
     158,     0,     0,   159,   160,   161,     0,   162,   163,   164,
     165,     0,   166,   167,     0,     0,     0,     0,     0,   168,
     169,   170,   171,   172,   173,   174,   175,  1038,     0,   176,
     177,   178,   179,   180,     0,     0,     0,   181,   182,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,   190,
     191,   192,   193,     0,   194,   195,     0,   196,     0,   197,
       0,     0,     0,   198,   199,   200,     0,     0,   201,     0,
     202,     0,   203,   204,   205,     0,   206,   207,   208,     0,
       0,   209,   210,   211,   212,   213,   214,   215,     0,   216,
       0,   217,     0,     0,   218,     0,   219,   220,   221,     0,
       0,   222,     0,     0,   223,   224,   225,     0,     0,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   236,
       0,   237,     0,   238,   239,   240,   241,   242,     0,   243,
     244,     0,     0,   245,   246,   247,     0,     0,   248,     0,
       0,     0,   249,   250,     0,     0,   251,     0,     0,   252,
     253,   254,   255,   256,   257,     0,   258,   259,   260,     0,
     261,   262,   263,   264,   265,   266,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,     0,   276,   277,   278,
     279,   280,   281,   282,     0,   283,   284,   285,     0,   286,
     287,   288,   289,     0,   290,   291,     0,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,     0,   302,   303,
     304,     0,   305,   306,     0,   307,     0,   308,   309,   310,
     311,     0,   312,   313,   314,   315,     0,     0,   316,   317,
     318,   319,   320,     0,     0,   321,   322,   323,   324,   325,
     326,     0,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   336,     0,   889,   129,   130,   131,
     132,   133,   134,   135,     0,   136,     0,     0,     0,     0,
       0,     0,   137,   138,   139,     0,   140,   141,   142,     0,
     143,     0,   144,   145,     0,   146,   147,   148,   149,     0,
       0,   150,   151,   152,   153,     0,   154,   155,   156,   157,
     158,     0,     0,   159,   160,   161,     0,   162,   163,   164,
     165,     0,   166,   167,     0,     0,     0,     0,     0,   168,
     169,   170,   171,   172,   173,   174,   175,     0,     0,   176,
     177,   178,   179,   180,     0,     0,     0,   181,   182,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,   190,
     191,   192,   193,     0,   194,   195,     0,   196,     0,   197,
       0,     0,     0,   198,   199,   200,     0,     0,   201,     0,
     202,     0,   203,   204,   205,     0,   206,   207,   208,     0,
       0,   209,   210,   211,   212,   213,   214,   215,     0,   216,
       0,   217,     0,     0,   218,     0,   219,   220,   221,     0,
       0,   222,     0,     0,   223,   224,   225,     0,     0,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   236,
       0,   237,     0,   238,   239,   240,   241,   242,     0,   243,
     244,     0,     0,   245,   246,   247,     0,     0,   248,     0,
       0,     0,   249,   250,     0,     0,   251,     0,     0,   252,
     253,   254,   255,   256,   257,     0,   258,   259,   260,     0,
     261,   262,   263,   264,   265,   266,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,     0,   276,   277,   278,
     279,   280,   281,   282,     0,   283,   284,   285,     0,   286,
     287,   288,   289,     0,   290,   291,     0,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,     0,   302,   303,
     304,     0,   305,   306,     0,   307,     0,   308,   309,   310,
     311,     0,   312,   313,   314,   315,     0,     0,   316,   317,
     318,   319,   320,     0,     0,   321,   322,   323,   324,   325,
     326,     0,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   336,     0,   889,   129,   130,   131,
     132,   133,   134,   135,  1129,   136,  1130,  1131,  1132,  1133,
    1134,  1135,   137,   138,   139,   529,   140,   141,   142,   530,
     143,   531,   144,   145,  1136,   146,   147,   148,   149,  1137,
    1138,   150,   151,   152,   153,  1139,   154,   155,   156,   157,
     158,  1140,  1141,   159,   160,   161,  1142,   162,   163,   164,
     165,  1143,   166,   167,   532,  1144,  1145,  1146,  1147,   168,
     169,   170,   171,   172,   173,   174,   175,  1148,  1149,   176,
     177,   178,   179,   180,  1150,  1151,  1152,   181,   182,   183,
     184,  1153,   185,   186,  1154,   187,  1155,   188,   189,   190,
     191,   192,   193,  1156,   194,   195,  1157,   196,  1158,   197,
     533,  1159,   534,   198,   199,   200,  1160,  1161,   201,  1162,
     202,   535,   203,   204,   205,   536,   206,   207,   208,  1163,
     537,   209,   210,   211,   212,   213,   214,   215,  1164,   216,
    1165,   217,   538,   539,   218,   540,   219,   220,   221,  1166,
     541,   222,   542,  1167,   223,   224,   225,  1168,  1169,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   236,
     543,   237,  1170,   238,   239,   240,   241,   242,  1171,   243,
     244,   544,  1172,   245,   246,   247,  1173,  1174,   248,  1175,
    1176,  1177,   249,   250,  1178,  1179,   251,   545,   546,   252,
     253,   254,   255,   256,   257,  1180,   258,   259,   260,  1181,
     261,   262,   263,   264,   265,   266,   267,  1182,   268,   269,
     270,   271,   272,   273,   274,   275,   547,   276,   277,   278,
     279,   280,   281,   282,  1183,   283,   284,   285,  1184,   286,
     287,   288,   289,   548,   290,   291,  1185,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,  1186,   302,   303,
     304,  1187,   305,   306,  1188,   307,  1189,   308,   309,   310,
     311,  1190,   312,   313,   314,   315,  1191,  1192,   316,   317,
     318,   319,   320,  1193,  1194,   321,   322,   323,   324,   325,
     326,   549,   327,   328,   329,  1195,  1196,   330,   331,   332,
     333,   334,   335,     0,  1197,   129,   130,   131,   132,   133,
     134,   135,     0,   136,     0,     0,     0,     0,     0,     0,
     137,   138,   139,   529,   140,   141,   142,   530,   143,   531,
     144,   145,     0,   146,   147,   148,   149,     0,     0,   150,
     151,   152,   153,     0,   154,   155,   156,   157,   158,     0,
       0,   159,   160,   161,     0,   162,   163,   164,   165,     0,
     166,   167,   532,     0,     0,     0,     0,   168,   169,   170,
     171,   172,   173,   174,   175,     0,     0,   176,   177,   178,
     179,   180,     0,     0,     0,   181,   182,   183,   184,     0,
     185,   186,     0,   187,     0,   188,   189,   190,   191,   192,
     193,     0,   194,   195,     0,   196,     0,   197,   533,     0,
     534,   198,   199,   200,     0,     0,   201,     0,   202,   535,
     203,   204,   205,   536,   206,   207,   208,     0,   537,   209,
     210,   211,   212,   213,   214,   215,     0,   216,     0,   217,
     538,   539,   218,   540,   219,   220,   221,     0,   541,   222,
     542,     0,   223,   224,   225,     0,     0,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   236,   543,   237,
     437,   238,   239,   240,   241,   242,     0,   243,   244,   544,
       0,   245,   246,   247,     0,     0,   248,   438,     0,     0,
     249,   250,     0,     0,   251,   545,   546,   252,   253,   254,
     255,   256,   257,     0,   258,   259,   260,     0,   261,   262,
     263,   264,   265,   266,   267,     0,   268,   269,   270,   271,
     272,   273,   274,   275,   547,   276,   277,   278,   279,   280,
     281,   282,     0,   283,   284,   285,     0,   286,   287,   288,
     289,   548,   290,   291,     0,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,     0,   302,   303,   304,     0,
     305,   306,     0,   307,     0,   308,   309,   310,   311,     0,
     312,   313,   314,   315,     0,     0,   316,   317,   318,   319,
     320,     0,     0,   321,   322,   323,   324,   325,   326,   549,
     327,   328,   329,     0,     0,   330,   331,   332,   333,   334,
     335,     0,   550,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,     0,     0,   137,   138,
     139,     0,   140,   141,   142,     0,   143,     0,   144,   145,
       0,   146,   147,   148,   149,     0,     0,   150,   151,   152,
     153,  1098,   154,   155,   156,   157,   158,     0,     0,   159,
     160,   161,  1100,   162,   163,   164,   165,     0,   166,   167,
       0,     0,     0,     0,     0,   168,   169,   170,   171,   172,
     173,   174,   175,     0,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   182,   183,   184,     0,   185,   186,
       0,   187,     0,   188,   189,   190,   191,   192,   193,     0,
     194,   195,     0,   196,  1101,   197,     0,     0,     0,   198,
     199,   200,     0,     0,   201,     0,   202,     0,   203,   204,
     205,     0,   206,   207,   208,     0,     0,   209,   210,   211,
     212,   213,   214,   215,     0,   216,     0,   217,     0,     0,
     218,     0,   219,   220,   221,     0,     0,   222,  1550,     0,
     223,   224,   225,     0,     0,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,     0,   237,     0,   238,
     239,   240,   241,   242,     0,   243,   244,     0,     0,   245,
     246,   247,     0,     0,   248,     0,     0,     0,   249,   250,
       0,     0,   251,     0,     0,   252,   253,   254,   255,   256,
     257,     0,   258,   259,   260,  1102,   261,   262,   263,   264,
     265,   266,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,     0,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   285,     0,   286,   287,   288,   289,     0,
     290,   291,     0,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,     0,   302,   303,   304,     0,   305,   306,
       0,   307,     0,   308,   309,   310,   311,     0,   312,   313,
     314,   315,     0,  1103,   316,   317,   318,   319,   320,     0,
       0,   321,   322,   323,   324,   325,   326,     0,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     336,   129,   130,   131,   132,   133,   134,   135,     0,   136,
       3,     4,     0,     0,     0,     0,   137,   138,   139,     0,
     140,   141,   142,     0,   143,     0,   144,   145,     0,   146,
     147,   148,   149,     0,     0,   150,   151,   152,   153,     0,
     154,   155,   156,   157,   158,     0,     0,   159,   160,   161,
       0,   162,   163,   164,   165,     0,   166,   167,     0,     0,
       0,     0,     0,   168,   169,   170,   171,   172,   173,   174,
     175,     0,     0,   176,   177,   178,   179,   180,     0,     0,
       0,   181,   182,   183,   184,     0,   185,   186,     0,   187,
       0,   188,   189,   190,   191,   192,   193,     0,   194,   195,
       0,   196,     0,   197,     0,     0,     0,   198,   199,   200,
       0,     0,   201,     0,   202,     0,   203,   204,   205,     0,
     206,   207,   208,     0,     0,   209,   210,   211,   212,   213,
     214,   215,     0,   216,     0,   217,     0,     0,   218,     0,
     219,   220,   221,     0,     0,   222,     0,     0,   223,   224,
     225,     0,     0,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   236,     0,   237,   437,   238,   239,   240,
     241,   242,     0,   243,   244,     0,     0,   245,   246,   247,
       0,     0,   248,   438,     0,     0,   249,   250,     0,     0,
     251,     0,     0,   252,   253,   254,   255,   256,   257,     0,
     258,   259,   260,     0,   261,   262,   263,   264,   265,   266,
     267,     0,   268,   269,   270,   271,   272,   273,   274,   275,
       0,   276,   277,   278,   279,   280,   281,   282,     0,   283,
     284,   285,     0,   286,   287,   288,   289,     0,   290,   291,
       0,   292,   293,   294,   295,   296,   297,   298,   299,   300,
     301,     0,   302,   303,   304,     0,   305,   306,     0,   307,
       0,   308,   309,   310,   311,     0,   312,   313,   314,   315,
       0,     0,   316,   317,   318,   319,   320,     0,     0,   321,
     322,   323,   324,   325,   326,     0,   327,   328,   329,     0,
       0,   330,   331,   332,   333,   334,   335,     0,   336,   129,
     130,   131,   132,   133,   134,   135,     0,   136,     0,     0,
       0,     0,     0,     0,   137,   138,   139,     0,   140,   141,
     142,     0,   143,     0,   144,   145,     0,   146,   147,   148,
     149,     0,     0,   150,   151,   152,   153,     0,   154,   155,
     156,   157,   158,     0,     0,   159,   160,   161,     0,   162,
     163,   164,   165,     0,   166,   167,     0,     0,     0,     0,
       0,   168,   169,   170,   171,   172,   173,   174,   175,     0,
       0,   176,   177,   178,   179,   180,     0,     0,     0,   181,
     182,   183,   184,     0,   185,   186,     0,   187,     0,   188,
     189,   190,   191,   192,   193,     0,   194,   195,     0,   196,
       0,   197,     0,     0,     0,   198,   199,   200,     0,     0,
     201,     0,   202,     0,   203,   204,   205,     0,   206,   207,
     208,     0,     0,   209,   210,   211,   212,   213,   214,   215,
       0,   216,     0,   217,     0,     0,   218,     0,   219,   220,
     221,     0,     0,   222,     0,     0,   223,   224,   225,     0,
       0,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,     0,   237,   437,   238,   239,   240,   241,   242,
       0,   243,   244,     0,     0,   245,   246,   247,     0,     0,
     248,   438,     0,   487,   249,   250,     0,     0,   251,     0,
       0,   252,   253,   254,   255,   256,   257,     0,   258,   259,
     260,     0,   261,   262,   263,   264,   265,   266,   267,     0,
     268,   269,   270,   271,   272,   273,   274,   275,     0,   276,
     277,   278,   279,   280,   281,   282,     0,   283,   284,   285,
       0,   286,   287,   288,   289,     0,   290,   291,     0,   292,
     293,   294,   295,   296,   297,   298,   299,   300,   301,     0,
     302,   303,   304,     0,   305,   306,     0,   307,     0,   308,
     309,   310,   311,     0,   312,   313,   314,   315,     0,     0,
     316,   317,   318,   319,   320,     0,     0,   321,   322,   323,
     324,   325,   326,     0,   327,   328,   329,     0,     0,   330,
     331,   332,   333,   334,   335,     0,   336,   129,   130,   131,
     132,   133,   134,   135,     0,   136,     0,     0,     0,     0,
       0,     0,   137,   138,   139,     0,   140,   141,   142,     0,
     143,     0,   144,   145,     0,   146,   147,   148,   149,     0,
       0,   150,   151,   152,   153,     0,   154,   155,   156,   157,
     158,     0,     0,   159,   160,   161,     0,   162,   163,   164,
     165,     0,   166,   167,     0,     0,     0,     0,     0,   168,
     169,   902,   171,   172,   173,   174,   175,     0,     0,   176,
     177,   178,   179,   180,     0,     0,     0,   181,   182,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,   190,
     191,   192,   193,     0,   194,   195,     0,   196,     0,   197,
       0,     0,     0,   903,   199,   200,     0,     0,   201,     0,
     202,     0,   203,   204,   205,     0,   206,   207,   208,     0,
       0,   209,   210,   211,   212,   213,   214,   215,     0,   216,
       0,   217,     0,     0,   218,     0,   219,   220,   904,     0,
       0,   222,     0,     0,   223,   224,   225,     0,     0,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   236,
       0,   237,   437,   238,   239,   240,   241,   242,     0,   243,
     244,     0,     0,   245,   246,   247,     0,     0,   248,   438,
       0,     0,   249,   250,     0,     0,   251,     0,     0,   252,
     253,   254,   255,   256,   257,     0,   258,   259,   260,     0,
     261,   262,   263,   264,   265,   266,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,     0,   276,   277,   278,
     905,   280,   281,   282,     0,   283,   284,   285,     0,   286,
     287,   288,   289,     0,   290,   291,     0,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   906,   302,   303,
     304,     0,   305,   306,     0,   307,     0,   308,   309,   310,
     311,     0,   312,   313,   314,   315,     0,     0,   316,   317,
     318,   319,   320,     0,     0,   321,   322,   323,   324,   325,
     326,     0,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   336,   129,   130,   131,   132,   133,
     134,   135,     0,   136,     0,     0,     0,     0,     0,     0,
     137,   138,   139,     0,   140,   141,   142,     0,   143,     0,
     144,   145,     0,   146,   147,   148,   149,     0,     0,   150,
     151,   152,   153,     0,   154,   155,   156,   157,   158,     0,
       0,   159,   160,   161,     0,   162,   163,   164,   165,     0,
     166,   167,     0,     0,     0,     0,     0,   168,   169,   170,
     171,   172,   173,   174,   175,     0,     0,   176,   177,   178,
     179,   180,     0,     0,     0,   181,   182,   183,   184,     0,
     185,   186,     0,   187,     0,   188,   189,   190,   191,   192,
     193,     0,   194,   195,     0,   196,     0,   197,     0,     0,
       0,   198,   199,  1276,     0,     0,   201,     0,   202,     0,
     203,   204,   205,     0,   206,   207,   208,     0,     0,   209,
     210,   211,   212,   213,   214,   215,     0,   216,     0,   217,
       0,     0,   218,     0,   219,   220,   221,     0,     0,   222,
       0,     0,   223,   224,  1277,     0,     0,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   236,     0,   237,
     437,   238,   239,   240,   241,   242,     0,   243,   244,     0,
       0,   245,   246,   247,     0,     0,   248,   438,     0,     0,
     249,   250,     0,     0,   251,     0,     0,   252,   253,   254,
     255,   256,   257,     0,   258,   259,   260,     0,   261,   262,
     263,   264,   265,   266,   267,     0,   268,   269,   270,   271,
     272,   273,   274,   275,     0,   276,   277,   278,   279,   280,
     281,   282,     0,   283,   284,   285,     0,   286,   287,   288,
     289,     0,   290,   291,     0,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,  1278,  1279,   303,  1280,     0,
     305,   306,     0,   307,     0,   308,   309,   310,   311,     0,
     312,   313,   314,   315,     0,     0,   316,   317,   318,   319,
     320,     0,     0,   321,   322,   323,   324,   325,   326,     0,
     327,   328,   329,     0,     0,   330,   331,   332,   333,   334,
     335,     0,   336,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,     0,     0,   137,   138,
     139,     0,   140,   141,   142,     0,   143,     0,   144,   145,
       0,   146,   147,   148,   149,     0,     0,   150,   151,   152,
     153,     0,   154,   155,   156,   157,   158,     0,     0,   159,
     160,   161,     0,   162,   163,   164,   165,     0,   166,   167,
       0,     0,     0,     0,     0,   168,   169,   170,   171,   172,
     173,   174,   175,     0,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   182,   183,   184,     0,   185,   186,
       0,   187,     0,   188,   189,   190,   191,   192,   193,     0,
     194,   195,     0,   196,     0,   197,     0,     0,     0,   198,
     199,   200,     0,     0,   201,     0,   202,     0,   203,   204,
     205,     0,   206,   207,   208,     0,     0,   209,   210,   211,
     212,   213,   214,   215,     0,   216,     0,   217,     0,     0,
     218,     0,   219,   220,   221,     0,     0,   222,     0,     0,
     223,   224,   225,     0,     0,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,     0,   237,   437,   238,
     239,   240,   241,   242,     0,   243,   244,     0,     0,   245,
     246,   247,     0,     0,   248,   438,     0,     0,   249,   250,
       0,     0,   251,     0,     0,   252,   253,   254,   255,   256,
     257,     0,   258,   259,   260,     0,   261,   262,   263,   264,
     265,   266,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,     0,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   285,     0,   286,   287,   288,   289,     0,
     290,   291,     0,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,     0,   302,   303,   304,     0,   305,   306,
       0,   307,     0,   308,   309,   310,   311,     0,   312,   313,
     314,   315,     0,     0,   316,   317,   318,   319,   320,     0,
    2216,   321,   322,   323,   324,   325,   326,     0,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     336,   129,   130,   131,   132,   133,   134,   135,     0,   136,
       0,     0,     0,     0,     0,     0,   137,   138,   139,     0,
     140,   141,   142,     0,   143,     0,   144,   145,     0,   146,
     147,   148,   149,     0,     0,   150,   151,   152,   153,     0,
     154,   155,   156,   157,   158,     0,     0,   159,   160,   161,
       0,   162,   163,   164,   165,     0,   166,   167,     0,     0,
       0,     0,     0,   168,   169,   170,   171,   172,   173,   174,
     175,     0,     0,   176,   177,   178,   179,   180,     0,     0,
       0,   181,   182,   183,   184,     0,   185,   186,     0,   187,
       0,   188,   189,   190,   191,   192,   193,     0,   194,   195,
       0,   196,     0,   197,     0,     0,     0,   198,   199,   200,
       0,     0,   201,     0,   202,     0,   203,   204,   205,     0,
     206,   207,   208,     0,     0,   209,   210,   211,   212,   213,
     214,   215,     0,   216,     0,   217,     0,     0,   218,     0,
     219,   220,   221,     0,     0,   222,     0,     0,   223,   224,
     225,     0,     0,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   236,     0,   237,   437,   238,   239,   240,
     241,   242,     0,   243,   244,     0,     0,   245,   246,   247,
       0,     0,   248,   438,     0,     0,   249,   250,     0,     0,
     251,     0,     0,   252,   253,   254,   255,   256,   257,     0,
     258,   259,   260,     0,   261,   262,   263,   264,   265,   266,
     267,     0,   268,   269,   270,   271,   272,   273,   274,   275,
       0,   276,   277,   278,   279,   280,   281,   282,     0,   283,
     284,   285,     0,   286,   287,   288,   289,     0,   290,   291,
       0,   292,   293,   294,   295,   296,   297,   298,   299,   300,
     301,     0,   302,   303,   304,     0,   305,   306,     0,   307,
       0,   308,   309,   310,   311,     0,   312,   313,   314,   315,
       0,     0,   316,   317,   318,   319,   320,     0,     0,   321,
     322,   323,   324,   325,   326,     0,   327,   328,   329,     0,
       0,   330,   331,   332,   333,   334,   335,     0,   336,   129,
     130,   131,   132,   133,   134,   135,   459,   136,     0,     0,
       0,     0,     0,     0,   137,   138,   139,     0,   140,   141,
     142,     0,   143,     0,   144,   145,     0,   146,   147,   148,
     149,     0,     0,   150,   151,   152,   153,     0,   154,   155,
     156,   157,   158,     0,     0,   159,   160,   161,     0,   162,
     163,   164,   165,     0,   166,   167,     0,     0,     0,     0,
       0,   168,   169,   170,   171,   172,   173,   174,   175,     0,
       0,   176,   177,   178,   179,   180,     0,     0,     0,   181,
     182,   183,   184,     0,   185,   186,     0,   187,     0,   188,
     189,   190,   191,   192,   193,     0,   194,   195,     0,   196,
       0,   197,     0,     0,     0,   198,   199,   200,     0,     0,
     201,     0,   202,     0,   203,   204,   205,     0,   206,   207,
     208,     0,     0,   209,   210,   211,   212,   213,   214,   215,
       0,   216,     0,   217,     0,     0,   218,     0,   219,   220,
     221,     0,     0,   222,     0,     0,   223,   224,   225,     0,
       0,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,     0,   237,     0,   238,   239,   240,   241,   242,
       0,   243,   244,     0,     0,   245,   246,   247,     0,     0,
     248,     0,     0,     0,   249,   250,     0,     0,   251,     0,
       0,   252,   253,   254,   255,   256,   257,     0,   258,   259,
     260,     0,   261,   262,   263,   264,   265,   266,   267,     0,
     268,   269,   270,   271,   272,   273,   274,   275,     0,   276,
     277,   278,   279,   280,   281,   282,     0,   283,   284,   460,
       0,   286,   287,   288,   289,     0,   290,   291,     0,   292,
     293,   294,   295,   296,   297,   298,   299,   300,   301,     0,
     302,   303,   304,     0,   461,   306,     0,   307,     0,   462,
     309,   310,   311,     0,   312,   313,   314,   315,     0,     0,
     316,   317,   318,   319,   320,     0,     0,   321,   322,   323,
     324,   325,   326,     0,   327,   328,   329,     0,     0,   330,
     331,   332,   333,   334,   335,     0,   336,   129,   130,   131,
     132,   133,   134,   135,   478,   136,     0,     0,     0,     0,
       0,     0,   137,   138,   139,     0,   140,   141,   142,     0,
     143,     0,   144,   145,     0,   146,   147,   148,   149,     0,
       0,   150,   151,   152,   153,     0,   154,   155,   156,   157,
     158,     0,     0,   159,   160,   161,     0,   162,   163,   164,
     165,     0,   166,   167,     0,     0,     0,     0,     0,   168,
     169,   170,   171,   172,   173,   174,   175,     0,     0,   176,
     177,   178,   179,   180,     0,     0,     0,   181,   182,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,   190,
     191,   192,   193,     0,   194,   195,     0,   196,     0,   197,
       0,     0,     0,   198,   199,   200,     0,     0,   201,     0,
     202,     0,   203,   204,   205,     0,   206,   207,   208,     0,
       0,   209,   210,   211,   212,   213,   214,   215,     0,   216,
       0,   217,     0,     0,   218,     0,   219,   220,   221,     0,
       0,   222,     0,     0,   223,   224,   225,     0,     0,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   236,
       0,   237,     0,   238,   239,   240,   241,   242,     0,   243,
     244,     0,     0,   245,   246,   247,     0,     0,   248,     0,
       0,     0,   249,   250,     0,     0,   251,     0,     0,   252,
     253,   254,   255,   256,   257,     0,   258,   259,   260,     0,
     261,   262,   263,   264,   265,   266,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,     0,   276,   277,   278,
     279,   280,   281,   282,     0,   283,   284,   479,     0,   286,
     287,   288,   289,     0,   290,   291,     0,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,     0,   302,   303,
     304,     0,   480,   306,     0,   307,     0,   481,   309,   310,
     311,     0,   312,   313,   314,   315,     0,     0,   316,   317,
     318,   319,   320,     0,     0,   321,   322,   323,   324,   325,
     326,     0,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   336,   129,   130,   131,   132,   133,
     134,   135,   742,   136,     0,     0,     0,     0,     0,     0,
     137,   138,   139,     0,   140,   141,   142,     0,   143,     0,
     144,   145,     0,   146,   147,   148,   149,     0,     0,   150,
     151,   152,   153,     0,   154,   155,   156,   157,   158,     0,
       0,   159,   160,   161,     0,   162,   163,   164,   165,     0,
     166,   167,     0,     0,     0,     0,     0,   168,   169,   170,
     171,   172,   173,   174,   175,     0,     0,   176,   177,   178,
     179,   180,     0,     0,     0,   181,   182,   183,   184,     0,
     185,   186,     0,   187,     0,   188,   189,   190,   191,   192,
     193,     0,   194,   195,     0,   196,     0,   197,     0,     0,
       0,   198,   199,   200,     0,     0,   201,     0,   202,     0,
     203,   204,   205,     0,   206,   207,   208,     0,     0,   209,
     210,   211,   212,   213,   214,   215,     0,   216,     0,   217,
       0,     0,   218,     0,   219,   220,   221,     0,     0,   222,
       0,     0,   223,   224,   225,     0,     0,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   236,     0,   237,
       0,   238,   239,   240,   241,   242,     0,   243,   244,     0,
       0,   245,   246,   247,     0,     0,   248,     0,     0,     0,
     249,   250,     0,     0,   251,     0,     0,   252,   253,   254,
     255,   256,   257,     0,   258,   259,   260,     0,   261,   262,
     263,   264,   265,   266,   267,     0,   268,   269,   270,   271,
     272,   273,   274,   275,     0,   276,   277,   278,   279,   280,
     281,   282,     0,   283,   284,   285,     0,   286,   287,   288,
     289,     0,   290,   291,     0,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,     0,   302,   303,   304,     0,
     305,   306,     0,   307,     0,   308,   309,   310,   311,     0,
     312,   313,   314,   315,     0,     0,   316,   317,   318,   319,
     320,     0,     0,   321,   322,   323,   324,   325,   326,     0,
     327,   328,   329,     0,     0,   330,   331,   332,   333,   334,
     335,     0,   336,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,     0,     0,   137,   138,
     139,   751,   140,   141,   142,     0,   143,     0,   144,   145,
       0,   146,   147,   148,   149,     0,     0,   150,   151,   152,
     752,     0,   154,   155,   156,   157,   158,     0,     0,   159,
     160,   161,     0,   162,   163,   164,   165,     0,   166,   167,
       0,     0,     0,     0,     0,   168,   169,   170,   171,   172,
     173,   174,   175,     0,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   182,   183,   184,     0,   185,   186,
       0,   187,     0,   188,   189,   190,   191,   192,   193,     0,
     194,   195,     0,   196,     0,   197,     0,     0,     0,   198,
     199,   200,     0,     0,   201,     0,   202,     0,   203,   204,
     205,     0,   206,   207,   208,     0,     0,   209,   210,   211,
     212,   213,   214,   215,     0,   216,     0,   217,     0,     0,
     218,     0,   219,   220,   221,     0,     0,   222,     0,     0,
     223,   224,   225,     0,     0,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   472,   236,     0,   237,     0,   238,
     239,   240,   241,   242,     0,   243,   244,     0,     0,   245,
     246,   247,     0,     0,   248,     0,     0,     0,   249,   250,
       0,     0,   251,     0,     0,   252,   253,   254,   255,   256,
     257,     0,   258,   259,   260,     0,   261,   262,   263,   264,
     265,   266,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,     0,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   746,     0,   286,   287,   288,   289,     0,
     290,   291,     0,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,     0,   302,   303,   304,     0,   474,   306,
       0,   307,     0,   475,   309,   310,   311,     0,   312,   313,
     314,   315,     0,     0,   316,   317,   318,   319,   320,     0,
       0,   321,   322,   323,   324,   325,   326,     0,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     336,   129,   130,   131,   132,   133,   134,   135,     0,   136,
       0,     0,     0,     0,     0,     0,   137,   138,   139,     0,
     140,   141,   142,     0,   143,     0,   144,   145,     0,   146,
     147,   148,   149,     0,     0,   150,   151,   152,   153,     0,
     154,   155,   156,   157,   158,     0,     0,   159,   160,   161,
       0,   162,   163,   164,   165,     0,   166,   167,     0,     0,
       0,     0,     0,   168,   169,   170,   171,   172,   173,   174,
     175,     0,     0,   176,   177,   178,   179,   180,     0,     0,
       0,   181,   182,   183,   184,     0,   185,   186,     0,   187,
       0,   188,   189,   190,   191,   192,   193,     0,   194,   195,
       0,   196,     0,   197,     0,     0,     0,   198,   199,   200,
       0,  1591,   201,     0,   202,     0,   203,   204,   205,     0,
     206,   207,   208,     0,     0,   209,   210,   211,   212,   213,
     214,   215,     0,   216,     0,   217,     0,     0,   218,     0,
     219,   220,   221,     0,     0,   222,     0,     0,   223,   224,
     225,     0,     0,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   236,     0,   237,     0,   238,   239,   240,
     241,   242,     0,   243,   244,     0,     0,   245,   246,   247,
       0,     0,   248,     0,     0,     0,   249,   250,     0,     0,
     251,     0,     0,   252,   253,   254,   255,   256,   257,     0,
     258,   259,   260,     0,   261,   262,   263,   264,   265,   266,
     267,     0,   268,   269,   270,   271,   272,   273,   274,   275,
       0,   276,   277,   278,   279,   280,   281,   282,     0,   283,
     284,   285,     0,   286,   287,   288,   289,     0,   290,   291,
       0,   292,   293,   294,   295,   296,   297,   298,   299,   300,
     301,     0,   302,   303,   304,     0,   305,   306,     0,   307,
       0,   308,   309,   310,   311,     0,   312,   313,   314,   315,
       0,     0,   316,   317,   318,   319,   320,     0,     0,   321,
     322,   323,   324,   325,   326,     0,   327,   328,   329,     0,
       0,   330,   331,   332,   333,   334,   335,     0,   336,   129,
     130,   131,   132,   133,   134,   135,     0,   136,     0,     0,
       0,     0,  1933,     0,   137,   138,   139,     0,   140,   141,
     142,     0,   143,     0,   144,   145,     0,   146,   147,   148,
     149,     0,     0,   150,   151,   152,   153,     0,   154,   155,
     156,   157,   158,     0,     0,   159,   160,   161,     0,   162,
     163,   164,   165,     0,   166,   167,     0,     0,     0,     0,
       0,   168,   169,   170,   171,   172,   173,   174,   175,     0,
       0,   176,   177,   178,   179,   180,     0,     0,     0,   181,
     182,   183,   184,     0,   185,   186,     0,   187,     0,   188,
     189,   190,   191,   192,   193,     0,   194,   195,     0,   196,
       0,   197,     0,     0,     0,   198,   199,   200,     0,     0,
     201,     0,   202,     0,   203,   204,   205,     0,   206,   207,
     208,     0,     0,   209,   210,   211,   212,   213,   214,   215,
       0,   216,     0,   217,     0,     0,   218,     0,   219,   220,
     221,     0,     0,   222,     0,     0,   223,   224,   225,     0,
       0,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,     0,   237,     0,   238,   239,   240,   241,   242,
       0,   243,   244,     0,     0,   245,   246,   247,     0,     0,
     248,     0,     0,     0,   249,   250,     0,     0,   251,     0,
       0,   252,   253,   254,   255,   256,   257,     0,   258,   259,
     260,     0,   261,   262,   263,   264,   265,   266,   267,     0,
     268,   269,   270,   271,   272,   273,   274,   275,     0,   276,
     277,   278,   279,   280,   281,   282,     0,   283,   284,   285,
       0,   286,   287,   288,   289,     0,   290,   291,     0,   292,
     293,   294,   295,   296,   297,   298,   299,   300,   301,     0,
     302,   303,   304,     0,   305,   306,     0,   307,     0,   308,
     309,   310,   311,     0,   312,   313,   314,   315,     0,     0,
     316,   317,   318,   319,   320,     0,     0,   321,   322,   323,
     324,   325,   326,     0,   327,   328,   329,     0,     0,   330,
     331,   332,   333,   334,   335,     0,   336,   129,   130,   131,
     132,   133,   134,   135,     0,   136,     0,     0,     0,     0,
    1947,     0,   137,   138,   139,     0,   140,   141,   142,     0,
     143,     0,   144,   145,     0,   146,   147,   148,   149,     0,
       0,   150,   151,   152,   153,     0,   154,   155,   156,   157,
     158,     0,     0,   159,   160,   161,     0,   162,   163,   164,
     165,     0,   166,   167,     0,     0,     0,     0,     0,   168,
     169,   170,   171,   172,   173,   174,   175,     0,     0,   176,
     177,   178,   179,   180,     0,     0,     0,   181,   182,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,   190,
     191,   192,   193,     0,   194,   195,     0,   196,     0,   197,
       0,     0,     0,   198,   199,   200,     0,     0,   201,     0,
     202,     0,   203,   204,   205,     0,   206,   207,   208,     0,
       0,   209,   210,   211,   212,   213,   214,   215,     0,   216,
       0,   217,     0,     0,   218,     0,   219,   220,   221,     0,
       0,   222,     0,     0,   223,   224,   225,     0,     0,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   236,
       0,   237,     0,   238,   239,   240,   241,   242,     0,   243,
     244,     0,     0,   245,   246,   247,     0,     0,   248,     0,
       0,     0,   249,   250,     0,     0,   251,     0,     0,   252,
     253,   254,   255,   256,   257,     0,   258,   259,   260,     0,
     261,   262,   263,   264,   265,   266,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,     0,   276,   277,   278,
     279,   280,   281,   282,     0,   283,   284,   285,     0,   286,
     287,   288,   289,     0,   290,   291,     0,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,     0,   302,   303,
     304,     0,   305,   306,     0,   307,     0,   308,   309,   310,
     311,     0,   312,   313,   314,   315,     0,     0,   316,   317,
     318,   319,   320,     0,     0,   321,   322,   323,   324,   325,
     326,     0,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   336,   129,   130,   131,   132,   133,
     134,   135,     0,   136,     0,     0,     0,     0,     0,     0,
     137,   138,   139,     0,   140,   141,   142,     0,   143,     0,
     144,   145,     0,   146,   147,   148,   149,     0,     0,   150,
     151,   152,   153,     0,   154,   155,   156,   157,   158,     0,
       0,   159,   160,   161,     0,   162,   163,   164,   165,     0,
     166,   167,     0,     0,     0,     0,     0,   168,   169,   170,
     171,   172,   173,   174,   175,  2002,     0,   176,   177,   178,
     179,   180,     0,     0,     0,   181,   182,   183,   184,     0,
     185,   186,     0,   187,     0,   188,   189,   190,   191,   192,
     193,     0,   194,   195,     0,   196,     0,   197,     0,     0,
       0,   198,   199,   200,     0,     0,   201,     0,   202,     0,
     203,   204,   205,     0,   206,   207,   208,     0,     0,   209,
     210,   211,   212,   213,   214,   215,     0,   216,     0,   217,
       0,     0,   218,     0,   219,   220,   221,     0,     0,   222,
       0,     0,   223,   224,   225,     0,     0,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   236,     0,   237,
       0,   238,   239,   240,   241,   242,     0,   243,   244,     0,
       0,   245,   246,   247,     0,     0,   248,     0,     0,     0,
     249,   250,     0,     0,   251,     0,     0,   252,   253,   254,
     255,   256,   257,     0,   258,   259,   260,     0,   261,   262,
     263,   264,   265,   266,   267,     0,   268,   269,   270,   271,
     272,   273,   274,   275,     0,   276,   277,   278,   279,   280,
     281,   282,     0,   283,   284,   285,     0,   286,   287,   288,
     289,     0,   290,   291,     0,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,     0,   302,   303,   304,     0,
     305,   306,     0,   307,     0,   308,   309,   310,   311,     0,
     312,   313,   314,   315,     0,     0,   316,   317,   318,   319,
     320,     0,     0,   321,   322,   323,   324,   325,   326,     0,
     327,   328,   329,     0,     0,   330,   331,   332,   333,   334,
     335,     0,   336,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,     0,     0,   137,   138,
     139,     0,   140,   141,   142,     0,   143,     0,   144,   145,
       0,   146,   147,   148,   149,     0,     0,   150,   151,   152,
     153,     0,   154,   155,   156,   157,   158,     0,     0,   159,
     160,   161,     0,   162,   163,   164,   165,     0,   166,   167,
       0,     0,     0,     0,     0,   168,   169,   170,   171,   172,
     173,   174,   175,  2004,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   182,   183,   184,     0,   185,   186,
       0,   187,     0,   188,   189,   190,   191,   192,   193,     0,
     194,   195,     0,   196,     0,   197,     0,     0,     0,   198,
     199,   200,     0,     0,   201,     0,   202,     0,   203,   204,
     205,     0,   206,   207,   208,     0,     0,   209,   210,   211,
     212,   213,   214,   215,     0,   216,     0,   217,     0,     0,
     218,     0,   219,   220,   221,     0,     0,   222,     0,     0,
     223,   224,   225,     0,     0,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,     0,   237,     0,   238,
     239,   240,   241,   242,     0,   243,   244,     0,     0,   245,
     246,   247,     0,     0,   248,     0,     0,     0,   249,   250,
       0,     0,   251,     0,     0,   252,   253,   254,   255,   256,
     257,     0,   258,   259,   260,     0,   261,   262,   263,   264,
     265,   266,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,     0,   276,   277,   278,   279,   280,   281,   282,
       0,   283,   284,   285,     0,   286,   287,   288,   289,     0,
     290,   291,     0,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,     0,   302,   303,   304,     0,   305,   306,
       0,   307,     0,   308,   309,   310,   311,     0,   312,   313,
     314,   315,     0,     0,   316,   317,   318,   319,   320,     0,
       0,   321,   322,   323,   324,   325,   326,     0,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     336,   129,   130,   131,   132,   133,   134,   135,     0,   136,
       0,     0,     0,     0,     0,     0,   137,   138,   139,     0,
     140,   141,   142,     0,   143,     0,   144,   145,     0,   146,
     147,   148,   149,     0,     0,   150,   151,   152,   153,     0,
     154,   155,   156,   157,   158,     0,     0,   159,   160,   161,
       0,   162,   163,   164,   165,     0,   166,   167,     0,     0,
       0,     0,     0,   168,   169,   170,   171,   172,   173,   174,
     175,     0,     0,   176,   177,   178,   179,   180,     0,     0,
       0,   181,   182,   183,   184,     0,   185,   186,     0,   187,
       0,   188,   189,   190,   191,   192,   193,     0,   194,   195,
       0,   196,     0,   197,     0,     0,     0,   198,   199,   200,
       0,     0,   201,     0,   202,     0,   203,   204,   205,     0,
     206,   207,   208,     0,     0,   209,   210,   211,   212,   213,
     214,   215,     0,   216,     0,   217,     0,     0,   218,     0,
     219,   220,   221,     0,     0,   222,     0,     0,   223,   224,
     225,     0,     0,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   236,     0,   237,     0,   238,   239,   240,
     241,   242,     0,   243,   244,     0,     0,   245,   246,   247,
       0,     0,   248,     0,     0,     0,   249,   250,     0,     0,
     251,     0,     0,   252,   253,   254,   255,   256,   257,     0,
     258,   259,   260,     0,   261,   262,   263,   264,   265,   266,
     267,     0,   268,   269,   270,   271,   272,   273,   274,   275,
       0,   276,   277,   278,   279,   280,   281,   282,     0,   283,
     284,   285,     0,   286,   287,   288,   289,     0,   290,   291,
       0,   292,   293,   294,   295,   296,   297,   298,   299,   300,
     301,     0,   302,   303,   304,     0,   305,   306,     0,   307,
       0,   308,   309,   310,   311,     0,   312,   313,   314,   315,
       0,     0,   316,   317,   318,   319,   320,     0,     0,   321,
     322,   323,   324,   325,   326,     0,   327,   328,   329,     0,
       0,   330,   331,   332,   333,   334,   335,     0,   336,   129,
     130,   131,   132,   133,   134,   135,     0,   136,     0,     0,
       0,     0,     0,     0,   137,   138,   139,     0,   140,   141,
     142,     0,   143,     0,   144,   145,     0,   146,   147,   148,
     149,     0,     0,   150,   151,   152,   153,     0,   154,   155,
     156,   157,   158,     0,     0,   159,   160,   161,     0,   162,
     163,   164,   165,     0,   166,   167,     0,     0,     0,     0,
       0,   168,   169,   170,   171,   172,   173,   174,   175,     0,
       0,   176,   177,   178,   179,   180,     0,     0,     0,   181,
     182,   183,   184,     0,   185,   186,     0,   187,     0,   188,
     189,   190,   191,   192,   193,     0,   194,   195,     0,   196,
       0,   197,     0,     0,     0,   198,   199,   200,     0,     0,
     201,     0,   202,     0,   203,   204,   205,     0,   206,   207,
     208,     0,     0,   209,   210,   211,   212,   213,   214,   215,
       0,   216,     0,   217,     0,     0,   218,     0,   219,   220,
     221,     0,     0,   222,     0,     0,   223,   224,   225,     0,
       0,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,     0,   237,     0,   238,   239,   240,   241,   242,
       0,   243,   244,     0,     0,   245,   246,   247,     0,     0,
     248,     0,     0,     0,   249,   250,     0,     0,   251,     0,
       0,   252,   253,   254,   255,   256,   257,     0,   258,   259,
     373,     0,   261,   262,   263,   264,   265,   266,   267,     0,
     268,   269,   270,   271,   272,   273,   274,   275,     0,   276,
     277,   278,   279,   280,   281,   282,     0,   283,   284,   285,
       0,   286,   287,   288,   289,     0,   290,   291,     0,   292,
     293,   294,   295,   296,   297,   298,   299,   300,   301,     0,
     302,   303,   304,     0,   305,   306,     0,   307,     0,   308,
     309,   310,   311,     0,   312,   313,   314,   315,     0,     0,
     316,   317,   318,   319,   320,     0,     0,   321,   322,   323,
     324,   325,   326,     0,   327,   328,   329,     0,     0,   330,
     331,   332,   333,   334,   335,     0,   336,   129,   130,   131,
     132,   133,   134,   135,     0,   136,     0,     0,     0,     0,
       0,     0,   137,   138,   139,     0,   140,   141,   142,     0,
     143,     0,   144,   145,     0,   146,   147,   148,   149,     0,
       0,   150,   151,   152,   153,     0,   154,   155,   156,   157,
     158,     0,     0,   159,   160,   161,     0,   470,   163,   164,
     165,     0,   166,   167,     0,     0,     0,     0,     0,   168,
     169,   170,   171,   172,   173,   174,   175,     0,     0,   176,
     177,   178,   179,   180,     0,     0,     0,   181,   182,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,   190,
     191,   192,   193,     0,   194,   195,     0,   196,     0,   197,
       0,     0,     0,   198,   199,   200,     0,     0,   201,     0,
     202,     0,   203,   204,   205,     0,   206,   207,   208,     0,
       0,   209,   210,   211,   212,   213,   214,   215,     0,   216,
       0,   217,     0,     0,   218,     0,   219,   220,   221,     0,
       0,   222,     0,     0,   223,   224,   471,     0,     0,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   472,   236,
       0,   237,     0,   238,   239,   240,   241,   242,     0,   243,
     244,     0,     0,   245,   246,   247,     0,     0,   248,     0,
       0,     0,   249,   250,     0,     0,   251,     0,     0,   252,
     253,   254,   255,   256,   257,     0,   258,   259,   260,     0,
     261,   262,   263,   264,   265,   266,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,     0,   276,   277,   278,
     279,   280,   281,   282,     0,   283,   284,   473,     0,   286,
     287,   288,   289,     0,   290,   291,     0,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,     0,   302,   303,
     304,     0,   474,   306,     0,   307,     0,   475,   309,   310,
     311,     0,   312,   313,   314,   315,     0,     0,   316,   317,
     318,   319,   320,     0,     0,   321,   322,   323,   324,   325,
     326,     0,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   336,   129,   130,   131,   132,   133,
     134,   135,     0,   136,     0,     0,     0,     0,     0,     0,
     137,   138,   139,     0,   140,   141,   142,     0,   143,     0,
     144,   145,     0,   146,   147,   148,   149,     0,     0,   150,
     151,   152,   153,     0,   154,   155,   156,   157,   158,     0,
       0,   159,   160,   161,     0,   162,   163,   164,   165,     0,
     166,   167,     0,     0,     0,     0,     0,   168,   169,   170,
     171,   172,   173,   174,   175,     0,     0,   176,   177,   178,
     179,   180,     0,     0,     0,   181,   182,   183,   184,     0,
     185,   186,     0,   187,     0,   188,   189,   190,   191,   192,
     193,     0,   194,   195,     0,   196,     0,   197,     0,     0,
       0,   198,   199,   200,     0,     0,   201,     0,   202,     0,
     203,   204,   205,     0,   206,   207,   208,     0,     0,   209,
     210,   211,   212,   213,   214,   215,     0,   216,     0,   217,
       0,     0,   218,     0,   219,   220,   221,     0,     0,   222,
       0,     0,   223,   224,   225,     0,     0,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   472,   236,     0,   237,
       0,   238,   239,   240,   241,   242,     0,   243,   244,     0,
       0,   245,   246,   247,     0,     0,   248,     0,     0,     0,
     249,   250,     0,     0,   251,     0,     0,   252,   253,   254,
     255,   256,   257,     0,   258,   259,   260,     0,   261,   262,
     263,   264,   265,   266,   267,     0,   268,   269,   270,   271,
     272,   273,   274,   275,     0,   276,   277,   278,   279,   280,
     281,   282,     0,   283,   284,   746,     0,   286,   287,   288,
     289,     0,   290,   291,     0,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,     0,   302,   303,   304,     0,
     474,   306,     0,   307,     0,   475,   309,   310,   311,     0,
     312,   313,   314,   315,     0,     0,   316,   317,   318,   319,
     320,     0,     0,   321,   322,   323,   324,   325,   326,     0,
     327,   328,   329,     0,     0,   330,   331,   332,   333,   334,
     335,     0,   336,   129,   130,   131,   132,   133,   134,   135,
       0,   136,     0,     0,     0,     0,     0,     0,   137,   138,
     139,     0,   140,   141,   142,     0,   814,     0,   815,   816,
       0,   146,   147,   148,   149,     0,     0,   150,   817,   818,
     153,     0,   154,   155,   156,   157,     0,     0,     0,   159,
     160,   161,     0,   162,   163,     0,   165,     0,   166,   167,
       0,     0,     0,     0,     0,   168,   169,   170,   171,   172,
     819,   820,   175,     0,     0,   176,   177,   178,   179,   180,
       0,     0,     0,   181,   668,   183,   184,     0,   185,   186,
       0,   187,     0,   188,   189,     0,   191,   192,     0,     0,
     194,   821,     0,   196,     0,   197,     0,     0,     0,   198,
     199,   200,     0,     0,   201,     0,   202,     0,   203,   204,
     205,     0,   206,   207,   208,     0,     0,   209,   210,   211,
     212,   213,   822,   823,     0,   824,     0,   217,     0,     0,
     218,     0,   219,   220,   221,     0,     0,   222,     0,     0,
     223,   224,   225,     0,     0,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   678,     0,   825,     0,   238,
     239,   240,   241,  1266,     0,   243,   244,     0,     0,     0,
     826,   247,     0,     0,   248,     0,     0,     0,   249,   250,
       0,     0,   251,     0,     0,     0,   253,   254,   255,   256,
     257,     0,     0,   259,   260,     0,   261,   262,   263,   264,
     265,   827,   267,     0,   268,   269,   270,   271,   272,   273,
     274,   275,     0,   276,     0,   278,   279,   280,   281,   282,
       0,   283,   284,   285,     0,   286,   828,   288,   289,     0,
     290,   829,     0,   292,   293,   294,   295,   296,   297,   298,
     299,     0,   301,     0,   302,   303,   304,     0,   830,   831,
       0,   307,     0,   308,     0,   310,     0,     0,   312,   313,
     314,   315,     0,     0,   316,   317,   318,   319,   320,     0,
       0,   321,   322,   323,   324,   832,   326,     0,   327,   328,
     329,     0,     0,   330,   331,   332,   333,   334,   335,     0,
     833,   129,   130,   131,   132,   133,   134,   135,     0,   136,
       0,     0,     0,     0,     0,     0,   137,   138,   139,     0,
     140,   141,   142,     0,   814,     0,   815,   816,     0,   146,
     147,   148,   149,     0,     0,   150,   817,   818,   153,     0,
     154,   155,   156,   157,     0,     0,     0,   159,   160,   161,
       0,   162,   163,     0,   165,     0,   166,   167,     0,     0,
       0,     0,     0,   168,   169,   170,   171,   172,   819,   820,
     175,     0,     0,   176,   177,   178,   179,   180,     0,     0,
       0,   181,   668,   183,   184,     0,   185,   186,     0,   187,
       0,   188,   189,     0,   191,   192,     0,     0,   194,   821,
       0,   196,     0,   197,     0,     0,     0,   198,   199,   200,
       0,     0,   201,     0,   202,     0,   203,   204,   205,  1254,
     206,   207,   208,     0,     0,  1255,   210,   211,   212,   213,
     822,   823,     0,   824,     0,   217,     0,     0,   218,     0,
     219,   220,   221,     0,     0,   222,     0,     0,   223,   224,
     225,     0,     0,   226,   227,   228,   229,   230,   231,   232,
     233,   234,   235,   678,     0,   825,     0,   238,   239,   240,
     241,     0,     0,   243,   244,     0,     0,     0,   826,   247,
       0,     0,   248,     0,     0,     0,   249,   250,     0,     0,
    1256,     0,     0,     0,   253,   254,   255,   256,   257,     0,
       0,   259,   260,     0,   261,   262,   263,   264,   265,   827,
     267,     0,   268,   269,   270,   271,   272,   273,   274,   275,
       0,   276,     0,   278,   279,   280,   281,   282,     0,   283,
     284,   285,     0,   286,   828,   288,   289,     0,   290,   829,
       0,   292,   293,   294,   295,   296,   297,   298,   299,     0,
     301,     0,   302,   303,   304,     0,   830,   831,     0,   307,
       0,   308,     0,   310,     0,     0,   312,   313,   314,   315,
       0,     0,   316,   317,   318,   319,   320,     0,     0,   321,
     322,   323,   324,   832,   326,     0,   327,   328,   329,     0,
       0,   330,   331,   332,   333,   334,   335,     0,   833,   129,
     130,   131,   132,   133,   134,   135,     0,   136,     0,     0,
       0,     0,     0,     0,   137,   138,   139,     0,   140,   141,
     142,     0,   814,     0,   815,   816,     0,   146,   147,   148,
     149,     0,     0,   150,   817,   818,   153,     0,   154,   155,
     156,   157,     0,     0,     0,   159,   160,   161,     0,   162,
     163,     0,   165,     0,   166,   167,     0,     0,     0,     0,
       0,   168,   169,   170,   171,   172,   819,   820,   175,     0,
       0,   176,   177,   178,   179,   180,     0,     0,     0,   181,
     668,   183,   184,     0,   185,   186,     0,   187,     0,   188,
     189,     0,   191,   192,     0,     0,   194,   821,     0,   196,
       0,   197,     0,     0,     0,   198,   199,   200,     0,     0,
     201,     0,   202,     0,   203,   204,   205,     0,   206,   207,
     208,     0,     0,   209,   210,   211,   212,   213,   822,   823,
       0,   824,     0,   217,     0,     0,   218,     0,   219,   220,
     221,     0,     0,   222,     0,     0,   223,   224,   225,     0,
       0,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   678,     0,   825,     0,   238,   239,   240,   241,  1849,
       0,   243,   244,     0,     0,     0,   826,   247,     0,     0,
     248,     0,     0,     0,   249,   250,     0,     0,   251,     0,
       0,     0,   253,   254,   255,   256,   257,     0,     0,   259,
     260,     0,   261,   262,   263,   264,   265,   827,   267,     0,
     268,   269,   270,   271,   272,   273,   274,   275,     0,   276,
       0,   278,   279,   280,   281,   282,     0,   283,   284,   285,
       0,   286,   828,   288,   289,     0,   290,   829,     0,   292,
     293,   294,   295,   296,   297,   298,   299,     0,   301,     0,
     302,   303,   304,     0,   830,   831,     0,   307,     0,   308,
       0,   310,     0,     0,   312,   313,   314,   315,     0,     0,
     316,   317,   318,   319,   320,     0,     0,   321,   322,   323,
     324,   832,   326,     0,   327,   328,   329,     0,     0,   330,
     331,   332,   333,   334,   335,     0,   833,   129,   130,   131,
     132,   133,   134,   135,     0,   136,     0,     0,     0,     0,
       0,     0,   137,   138,   139,     0,   140,   141,   142,     0,
     814,     0,   815,   816,     0,   146,   147,   148,   149,     0,
       0,   150,   817,   818,   153,     0,   154,   155,   156,   157,
       0,     0,     0,   159,   160,   161,     0,   162,   163,     0,
     165,     0,   166,   167,     0,     0,     0,     0,     0,   168,
     169,   170,   171,   172,   819,   820,   175,     0,     0,   176,
     177,   178,   179,   180,     0,     0,     0,   181,   668,   183,
     184,     0,   185,   186,     0,   187,     0,   188,   189,     0,
     191,   192,     0,     0,   194,   821,     0,   196,     0,   197,
       0,     0,     0,   198,   199,   200,     0,     0,   201,     0,
     202,     0,   203,   204,   205,     0,   206,   207,   208,     0,
       0,   209,   210,   211,   212,   213,   822,   823,     0,   824,
       0,   217,     0,     0,   218,     0,   219,   220,   221,     0,
       0,   222,     0,     0,   223,   224,   225,     0,     0,   226,
     227,   228,   229,   230,   231,   232,   233,   234,   235,   678,
       0,   825,     0,   238,   239,   240,   241,     0,     0,   243,
     244,     0,     0,     0,   826,   247,     0,     0,   248,     0,
       0,     0,   249,   250,     0,     0,   251,     0,     0,     0,
     253,   254,   255,   256,   257,     0,     0,   259,   260,     0,
     261,   262,   263,   264,   265,   827,   267,     0,   268,   269,
     270,   271,   272,   273,   274,   275,     0,   276,     0,   278,
     279,   280,   281,   282,     0,   283,   284,   285,     0,   286,
     828,   288,   289,     0,   290,   829,     0,   292,   293,   294,
     295,   296,   297,   298,   299,     0,   301,     0,   302,   303,
     304,     0,   830,   831,     0,   307,     0,   308,     0,   310,
       0,     0,   312,   313,   314,   315,     0,     0,   316,   317,
     318,   319,   320,     0,     0,   321,   322,   323,   324,   832,
     326,     0,   327,   328,   329,     0,     0,   330,   331,   332,
     333,   334,   335,     0,   833,   129,   130,   131,   132,   133,
     134,   135,     0,   136,     0,     0,     0,     0,     0,     0,
     137,   138,   139,     0,   140,   141,   142,     0,   814,     0,
     815,   816,     0,   146,   147,   148,   149,     0,     0,   150,
     817,   818,   153,     0,   154,   155,   156,   157,     0,     0,
       0,   159,   160,   161,     0,   162,   163,     0,   165,     0,
     166,   167,     0,     0,     0,     0,     0,   168,   169,   170,
     171,   172,   819,   820,   175,     0,     0,   176,   177,   178,
     179,   180,     0,     0,     0,   181,   668,   183,   184,     0,
     185,   186,     0,   187,     0,   188,   189,     0,   191,   192,
       0,     0,   194,   821,     0,   196,     0,   197,     0,     0,
       0,   198,   199,   200,     0,     0,   201,     0,   202,     0,
     203,   204,   205,     0,   206,   207,   208,     0,     0,   209,
     210,   211,   212,   213,   822,   823,     0,   824,     0,   217,
       0,     0,   218,     0,   219,   220,   221,     0,     0,   222,
       0,     0,   223,   224,   225,     0,     0,   226,   227,   228,
     229,   230,   231,   232,   233,   234,   235,   678,     0,   825,
       0,   238,   239,   240,   241,     0,     0,   243,   244,     0,
       0,     0,   826,   247,     0,     0,   248,     0,     0,     0,
     249,   250,     0,     0,   251,     0,     0,     0,   253,   254,
     255,   256,   257,     0,     0,   259,   260,     0,   261,   262,
     263,   264,   265,   827,   267,     0,   268,   269,   270,   271,
     272,   273,   274,   275,     0,   276,     0,   278,   279,   280,
     281,   282,     0,   283,   284,   285,     0,   286,     0,   288,
     289,     0,   290,   829,     0,   292,   293,   294,   295,   296,
     297,   298,   299,     0,   301,     0,   302,   303,   304,     0,
     830,   831,     0,   307,     0,   308,     0,   310,     0,     0,
     312,   313,   314,   315,     0,     0,   316,   317,   318,   319,
     320,     0,     0,   321,   322,   323,   324,   832,   326,     0,
     327,   328,   329,     0,   347,   330,   331,   332,   333,   334,
     335,     0,   833,   348,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   349,     0,     0,   350,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   351,     0,  -363,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   352,     0,     0,     0,     0,     0,   353,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   354,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   355,     0,   356,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  -459,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  -293,
       0,     0,     0,     0,     0,     0,     0,   357,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   358,     0,   359,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  -293,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   360,     0,     0,     0,     0,  -212,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,  -212,   361,
       0,   362,     0,     0,     0,     0,     0,     0,     0,     0,
     363,     0,     0,     0,   364,   365,     0,     0,   366,     0,
       0,     0,     0,     0,   367
};

static const short yycheck[] =
{
       0,    41,   448,     7,     8,   581,   358,   634,   387,    13,
      14,   562,   617,   589,    18,   804,    20,    37,   872,   561,
     470,   618,    26,  1119,    28,   567,    30,   693,    24,   991,
      34,    35,   354,   124,   732,   387,   127,   735,  1432,  1067,
     811,    41,   811,   365,    39,   754,   858,   858,   590,  1123,
     996,   858,   998,   726,  1097,   104,   403,  1451,   705,   469,
       0,  1589,  1538,  1707,    26,  1712,  1713,    26,     0,     0,
       0,     0,     0,     0,     0,     0,   398,    10,    34,    16,
    1837,   870,    15,    57,    39,  1920,    39,    39,    10,    47,
     471,    60,   473,    15,    72,   107,     5,    41,    73,    77,
    1662,    73,    12,    13,    48,    20,    41,  2126,    52,    20,
      73,   121,    10,     7,  1260,  1789,    20,    11,   620,   123,
     124,   136,   126,   127,    27,    57,    57,    27,    73,   667,
     125,    20,    47,   212,   107,    10,    47,   187,   183,   108,
     519,    34,   178,    47,    10,    79,   751,   658,   659,    15,
      74,  1472,   130,   210,    93,   116,    10,   126,    47,   181,
     104,    15,   181,    81,    77,   831,   102,   519,   679,   104,
     108,   159,   141,    74,   252,   230,    73,   146,    78,    19,
     112,   112,   149,    68,    93,   224,    10,   263,    93,   260,
      85,    85,  2315,    75,   302,   293,   294,   166,   159,   846,
     302,   279,    73,     8,  2327,   527,    20,    87,   324,   107,
      74,   327,    26,   149,   347,   323,   183,   186,    23,   295,
     277,   323,   196,   121,   125,   323,   129,  2350,    13,    14,
    1001,   116,  1001,    18,  2069,    20,   118,    20,   277,   310,
     228,    26,    77,    28,   323,   378,   296,   183,   570,   138,
     139,   384,   230,   222,   178,    73,   174,    81,   230,   197,
     178,   205,   867,   219,    47,   356,   302,   228,   323,   916,
     205,   169,   594,   174,   159,   622,   367,   162,   178,   977,
     120,   178,   820,   328,   184,   260,   883,   260,   177,   611,
    1964,   224,  1936,   890,   385,   130,  1940,  2316,   237,   277,
    1944,   323,   240,   174,   323,    77,   817,   818,   206,   242,
     174,   280,   284,   328,   825,   224,   328,   135,   328,  1881,
     242,    23,   216,    34,   227,    27,   219,   302,   237,   273,
     299,   286,   237,  2168,   152,   310,    38,    39,   273,   302,
     235,   126,   316,   228,   348,   323,   280,   302,   352,   302,
     354,   323,   356,   402,   358,   138,   360,   302,   130,   363,
      20,   365,   307,   367,   277,    25,  1512,   325,   323,   373,
     323,   323,   328,  1071,  2131,   379,   242,   287,   382,   512,
     109,   385,   377,   387,   517,   389,   323,    47,   242,   393,
     323,   395,   324,   324,   398,   327,   327,   327,   327,   327,
     327,   327,   327,   403,   785,   316,   317,   318,   319,   307,
     325,   291,   297,   417,   325,   319,   797,   315,  1564,  1740,
    1741,   325,  1496,   125,    76,   314,   315,   316,   317,   318,
     319,   933,   307,   308,  2081,   109,   325,    57,   323,   941,
     942,  2085,   277,    67,   955,   956,  2090,   451,     7,    77,
    2094,   455,   902,   415,   904,   905,   415,   416,   230,   170,
     906,   121,   186,   596,   966,    81,   470,   471,   224,   473,
      68,    60,   974,   138,    27,   230,   472,   856,   138,   139,
      76,  1443,   300,   301,   302,   137,    77,   449,  1531,   307,
     449,   450,   112,   102,    21,   495,   225,   315,  1287,   123,
      10,   107,   130,    67,   856,   277,   136,  2095,   219,  2097,
     514,   302,    92,    40,   188,   519,   520,   177,   116,   108,
     524,   186,   102,   527,   235,    32,    85,   849,   188,   284,
    1032,   314,   315,   316,   317,   318,   319,   126,  2182,   130,
     149,   137,   325,    75,  2020,   218,    75,   175,   176,   113,
     253,    25,   141,  1635,   134,   495,   560,   146,   174,    66,
     289,   159,   235,   348,   162,   181,   570,   323,   323,   149,
     892,    81,   247,   248,   183,   249,   112,   166,   363,   926,
     286,  1663,    99,   962,    92,   176,   118,     5,   373,   118,
     594,   595,    10,   597,   379,  2123,   302,  2185,  1296,    17,
     414,   415,   230,   183,   389,    48,  2315,   611,   393,    52,
     962,   191,    68,   617,    32,   122,  1263,   323,  2327,  1029,
     293,  1248,   622,  1073,   628,   629,   134,   302,   263,   253,
     228,   635,   417,   222,   634,   449,   640,   641,   108,   230,
      73,  2350,   293,   117,   346,   347,   306,   121,   352,   277,
    2315,   158,   354,   160,   314,   315,   316,   317,   318,   319,
     116,   178,  2327,   365,   181,   325,   451,   186,   627,   669,
     455,   711,  1269,  1270,   148,   377,   378,   328,   382,   302,
     639,    88,   384,   191,  1758,  2350,   277,  1761,  1762,   253,
      81,   231,   272,   107,     0,   323,   398,   697,   302,   297,
     323,   265,   300,   159,   302,   302,   162,   121,    99,  1752,
     299,   711,   302,   253,   324,   279,     0,   713,   328,   323,
     769,    16,  1534,  1534,  1371,   327,   323,  1534,   724,   514,
     293,   294,   323,   323,   436,   520,  1682,   244,    33,   524,
    1511,   174,  1511,   301,   324,   210,   448,   751,   155,   307,
     267,   218,   756,   757,   293,   294,   458,   274,   754,   302,
     323,   307,   766,   302,   272,   239,   857,   232,   235,   315,
     903,   302,   228,    57,   287,   560,   776,   777,   111,   779,
     323,   785,   484,   174,   323,   487,  1459,   178,   323,   196,
     181,   307,   323,   797,   496,  1117,   224,   888,   235,  1121,
    1122,   796,    97,  1512,   503,   809,   322,   217,    92,   511,
     512,   510,   597,   246,    41,   517,   249,   245,   102,   152,
    2214,   293,   294,   107,   119,   527,  1788,   265,   112,   113,
     302,   115,  2226,  1542,   208,  1544,  1545,  1546,  1547,  1512,
     108,   297,    54,   628,   629,   849,    73,   323,   255,   144,
     134,   323,   856,   857,   123,   640,   641,   190,   126,  1361,
    1362,  1363,  1364,   867,   310,   149,   324,   324,   570,   144,
     328,   328,   912,   141,   323,   321,   267,    10,   146,  1476,
    1477,   307,   324,   274,   888,   207,   328,   188,   892,   591,
     592,    57,   594,   186,   596,   899,   598,  1399,   902,   183,
     904,   905,   324,  1977,   301,  1979,   328,   191,   912,   611,
     307,    77,   912,   316,   317,   318,   319,   921,   315,    38,
      39,   254,   325,   256,    57,   220,   926,  1955,    94,   319,
     632,  1433,  1434,  1560,   229,   325,   254,   324,   256,  1566,
     754,   328,   756,   757,    77,   324,  1522,   174,   243,   328,
    1912,   178,   328,   324,   222,   250,   289,   328,   962,   324,
     326,    94,   324,   328,   130,   323,   328,   781,   782,   253,
     324,  1568,  1599,   138,   328,  1464,  1465,  1574,   205,  1677,
    1577,    23,   307,   308,   321,    27,   213,   324,   272,   326,
     324,   328,   992,    21,   328,   290,    38,   130,   998,   140,
    1004,  1667,  1668,  1382,   324,   306,  1006,   327,   292,   310,
     311,   312,  1462,   314,   315,   316,   317,   318,   319,   321,
     298,  1112,   324,   188,   326,   324,   328,   324,   186,   328,
    1382,   328,  1036,   324,   189,    14,  1415,   328,    41,   298,
     324,   324,   326,   327,    47,   328,   273,   213,   324,    52,
     140,   324,   328,   324,  1050,   328,   254,   328,   256,   225,
      21,   324,   764,  1415,   230,   328,   298,    16,   324,  1073,
      73,    74,   328,   324,   324,   324,   138,   328,   328,   328,
     213,   324,   324,   125,    33,   328,   328,   324,   254,   140,
     256,   328,   225,  1097,   796,   140,  1100,   230,   254,   265,
     256,     0,  1106,  1107,  1108,  1109,  1110,  1361,  1112,  1363,
    1364,   277,   278,  1117,   899,   324,   324,  1121,  1122,   328,
     328,   254,   125,   256,  1120,   235,   254,  1123,   256,   943,
     944,   945,   265,  1941,   324,  1943,   921,   951,   328,   953,
     954,   306,  2104,   316,   277,   278,   960,   849,    97,   314,
     315,   316,   317,   318,   319,   969,   106,   971,    57,   138,
     325,  2015,   324,   324,   324,   324,   328,   328,   328,   328,
     119,   174,  1674,   324,   988,   178,   990,   328,    14,   324,
     293,   294,   324,   328,   886,   887,   328,   324,   293,   294,
     892,   328,   324,    92,   896,   144,    31,   776,   777,   324,
     779,   903,   205,   102,   906,   791,   792,   793,   107,   188,
     213,   293,   294,   112,   113,   186,   115,   919,    41,   776,
     777,   323,   779,  1525,  1526,  1527,   558,   323,  1550,   323,
     932,  1045,  1236,    16,   323,   134,  1240,   498,   293,   500,
     326,   326,    21,  2339,    21,    65,  1843,  1243,  1248,   144,
     149,  1036,   314,   315,   316,   317,   318,   319,   227,  1279,
    1280,  1265,   292,   325,   323,   323,   323,   186,     9,   186,
     273,   220,   328,   136,    16,   607,   103,    18,   147,   186,
     229,   102,   323,   302,   183,   302,   323,  1291,   323,   323,
     323,   323,   191,   203,   243,    36,   323,  1619,  1431,   323,
     302,   250,   138,   302,   346,  1345,   302,   323,   323,   323,
     323,   643,   323,    54,   323,  1100,   323,   302,   323,   323,
     328,    16,   323,  1108,   102,  1110,    67,   306,   323,   323,
     147,   310,   311,   312,   147,   314,   315,   316,   317,   318,
     319,   290,    83,   147,   293,  1345,   325,   323,   279,  1389,
      48,   260,   188,   261,   253,   323,   186,   323,   186,  1399,
     293,   323,   138,   286,   323,   323,   323,    16,   109,  1373,
    1072,     8,   113,   272,    73,   323,   102,   186,  1382,   102,
      16,  1381,   123,    16,   280,  2239,   260,   328,   323,  1389,
     284,   138,  1392,   292,   436,   323,   258,   258,   291,  1399,
     321,  1215,   324,   328,   235,   121,   448,   323,   258,   323,
     323,  1415,  1412,   260,     9,  1117,   458,   107,   263,  1121,
    1122,   324,   328,   134,   328,   324,   187,   326,   327,  1429,
     181,  1431,  2037,   323,   149,   142,   142,   323,   253,   184,
     310,  1983,   484,  1447,   216,   487,  1450,   188,  1950,   138,
     321,   110,   260,    48,   496,   260,  1589,    52,  1462,   260,
     260,   102,   186,   190,    16,   220,   114,   208,  1472,   511,
     306,    16,    67,   324,   310,   311,   312,   161,   314,   315,
     316,   317,   318,   319,   225,   226,   328,   324,    83,   325,
     231,   107,   324,  1489,   328,   328,  1310,   107,   324,   324,
    1496,  1505,   324,   298,   328,   324,   324,    23,   324,   298,
     324,    27,   253,  1509,   109,   107,  1512,   324,   324,   107,
     852,   324,    38,    39,   265,   324,   324,  1531,   123,   270,
     324,   324,  2321,   324,   178,   298,   323,  1239,   279,   260,
    1003,   140,  1244,   324,    51,   877,  1550,   210,   289,   591,
     592,   260,   323,   885,   323,   260,   598,  1561,   198,   113,
    1560,   138,  1582,  1583,  1584,  1585,  1566,   314,   315,   316,
     317,   318,   319,   198,  1707,   276,  1278,   138,   325,   138,
     324,   324,   228,   162,   324,  2161,   324,  1591,   186,   270,
     632,   310,   253,   188,   323,   289,  1600,   328,  2100,  1599,
     260,   280,   324,   186,   324,   318,  1610,    93,    93,   125,
     324,    90,   107,   325,   102,  1619,   324,    39,   328,   113,
     324,   324,   324,   323,   147,   138,   138,   324,  1442,   322,
     225,   226,   323,  1447,    47,   323,   231,   324,   142,   102,
     190,   124,   270,   323,   283,   112,   323,   107,   324,   181,
    1464,  1465,  1466,   328,   324,   324,   324,   323,   253,   324,
     324,   323,   193,   141,   141,   323,    31,  1707,   115,   178,
     265,    79,   178,    74,   125,   270,  1490,   109,   109,   107,
     280,    86,    94,   107,   143,  1681,   324,   186,  2315,   323,
    2241,  2242,  2138,  1025,   289,   229,   178,   260,  1512,   189,
    2327,   323,  1516,   323,  1708,   141,   323,  1707,  1712,  1713,
     213,    16,   178,   157,   184,   184,  1530,   209,   324,   328,
     323,   328,   764,  2350,   178,  2175,   323,   138,  1542,  1431,
    1544,  1545,  1546,  1547,   186,  2185,  1740,  1741,   102,    16,
     186,   128,    86,   178,   186,  1749,  1750,   186,  1752,   323,
     128,    82,   224,    77,   131,  1751,   277,   328,    94,  1755,
    1756,     6,  1758,   323,   209,  1761,  1762,   324,   757,  2219,
     495,   212,   864,  1225,  1825,  1447,  1561,   188,    58,    59,
    1828,  1226,  1106,  2233,  1116,  2008,  1743,  1119,  1469,  1505,
    1794,  1795,   790,  1797,  1798,  2271,  1792,  1793,  2291,  2255,
    2254,  2276,  2137,  1936,  1830,  1969,  2028,  1940,  1219,    89,
    1624,  1944,  2351,   369,  1818,  2325,  1990,  1989,  1632,  1511,
    2304,  1825,  2352,  2145,  1828,   854,  1830,    26,   932,  1610,
     346,   347,  1860,  1837,   465,  1537,   633,  2215,   354,  2287,
    1836,   121,  1226,  1571,   886,   887,  1564,  2043,  1550,   365,
    1116,  2195,  2315,  2350,   896,  1072,  1860,    19,   646,  1561,
    1600,   377,   378,  1456,   906,   733,   138,   121,   384,   784,
    1069,  1466,   783,  1707,  1942,  1207,  2183,   919,  1341,  1342,
    1343,  1344,   398,  1346,   138,  1587,  1588,  1589,   828,  1206,
     932,   171,   172,  1680,  2216,   306,   965,  1818,  1027,  2032,
     311,   312,  1450,   314,   315,   316,   317,   318,   319,  1412,
    1312,  2059,  1863,   595,   325,    -1,   188,  1619,   198,    -1,
     436,  1253,  1001,  2302,    -1,    -1,  1930,    -1,    -1,  1933,
      -1,    -1,   448,    -1,   188,    -1,  1936,    -1,    -1,   635,
    1940,   121,   458,  1947,  1944,    -1,    -1,  1410,    -1,    -1,
    2302,    -1,  2085,    -1,    -1,    -1,  1770,  2090,   138,    -1,
    1956,  2094,    -1,    -1,  1749,  1750,  1970,    -1,   484,    -1,
      -1,   487,   252,    -1,  1306,    -1,    -1,    -1,  1792,    -1,
     496,  1977,   964,  1979,    -1,    -1,    -1,    -1,    -1,    -1,
    2123,   271,    -1,    -1,   174,   511,   512,    -1,    -1,    -1,
      -1,   517,   282,    -1,    -1,  1707,    -1,    -1,   188,  1794,
    1795,   527,    -1,  1798,   194,    -1,    -1,    -1,    -1,    -1,
      -1,  1003,    -1,    -1,  2028,    -1,    -1,    -1,  2032,    -1,
    1072,    -1,    -1,  2037,   306,    -1,    -1,  2033,   310,   311,
     312,    -1,   314,   315,   316,   317,   318,   319,    -1,  2182,
      -1,    -1,   306,   325,   570,    -1,   310,   311,   312,    -1,
     314,   315,   316,   317,   318,   319,    -1,    -1,    -1,    -1,
      -1,   325,    -1,    -1,  2207,   591,   592,  2081,   594,  2083,
     596,    -1,   598,    -1,    -1,  2085,    -1,    -1,  1790,    -1,
    2090,  2095,    -1,  2097,  2094,   611,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1805,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1814,    -1,    -1,    -1,   632,    -1,    -1,    -1,
      -1,  2117,    -1,    -1,    -1,    -1,   306,  2131,  2132,    -1,
     310,   311,   312,    -1,   314,   315,   316,   317,   318,   319,
      -1,  2145,  1474,    -1,    -1,    -1,  2150,  2143,    -1,  1851,
    1852,  1853,  1854,    -1,    -1,  1969,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  2301,    -1,
      -1,  2175,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1643,  2185,  2182,  1646,  1647,  1648,  1649,  1650,  1651,  1652,
    1653,  1654,    -1,  1656,    -1,    -1,    -1,  1239,    -1,    -1,
      -1,    -1,  1244,  2336,    -1,    -1,    -1,    -1,    -1,  1541,
      -1,  2215,  2216,    -1,    -1,  2219,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  2220,  1688,    -1,  1559,    -1,  2233,
      -1,    -1,    -1,    -1,  1936,    -1,  1278,    -1,  1940,    -1,
      -1,    -1,  1944,  2028,  1576,    -1,  1578,    -1,   764,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  2272,  2273,    -1,    -1,
     796,    -1,  2286,  2287,    -1,  1617,    -1,  2327,    -1,    -1,
    2286,    -1,    -1,    -1,    -1,    -1,    -1,  2111,  2302,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   558,    -1,
      -1,    -1,    -1,    -1,    -1,  2315,    -1,    -1,    -1,    -1,
      -1,  2325,    -1,  1655,    -1,    -1,  2028,  2327,    -1,  2325,
    2032,    -1,    -1,   849,    -1,    -1,  1799,  1669,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  2351,    -1,    -1,
    2350,    -1,    -1,    -1,    -1,  2351,    -1,   607,    -1,  1341,
    1342,  1343,  1344,    -1,  1346,  1697,    -1,    -1,    -1,    -1,
     886,   887,    -1,    -1,    -1,    -1,   892,    -1,    -1,    -1,
     896,    -1,    -1,  2085,    -1,    -1,    -1,   903,  2090,    -1,
     906,    -1,  2094,   643,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   919,    -1,    -1,    -1,    -1,    -1,    -1,
       3,    -1,    -1,    -1,    -1,    -1,   932,    -1,    11,    12,
      13,  2123,    -1,  2125,    -1,    -1,    -1,    -1,  1410,    -1,
      -1,    24,    -1,    -1,    -1,    -1,  2138,    -1,    -1,    -1,
      -1,    -1,    -1,  2145,    -1,    -1,    -1,    -1,  2150,    42,
      -1,    44,    45,    -1,    -1,    -1,    49,    50,    -1,    -1,
      -1,  1924,  2164,    56,    57,    -1,    -1,  2281,  2282,    -1,
      -1,    -1,    20,    -1,    -1,    -1,    69,    25,    -1,    72,
    2182,  1813,    -1,    -1,    77,    -1,    -1,    -1,    -1,    -1,
    2192,    -1,    85,    -1,    -1,  1537,    -1,    90,    -1,    47,
      -1,    94,    -1,    96,   754,  2207,    -1,   100,    -1,    -1,
      -1,    -1,    -1,    -1,  2216,    -1,    -1,    -1,    -1,   112,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     347,    -1,    -1,    -1,    -1,    -1,    -1,   130,    -1,    -1,
      -1,    -1,    -1,    91,    -1,  1587,  1588,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1072,   150,   151,    -1,
      -1,   378,    -1,   156,    -1,    -1,    -1,   384,    -1,   117,
     163,    -1,    -1,   121,    -1,    -1,    -1,    -1,   828,    -1,
      -1,    -1,    -1,   176,    -1,  2287,    -1,    -1,  1920,    -1,
     138,   139,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  2301,
     148,  1117,   852,    -1,  2067,  1121,  1122,    -1,    -1,    -1,
      -1,   204,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   214,    -1,    -1,    -1,   218,    -1,   877,   221,   177,
     223,    -1,   882,    -1,  2336,   885,    -1,   230,    -1,    -1,
     188,    -1,   235,    -1,    -1,   238,    -1,    -1,    -1,    -1,
      -1,   244,   469,    -1,    -1,    -1,    -1,    -1,    -1,   558,
      -1,  1643,    -1,    -1,  1646,  1647,  1648,  1649,  1650,  1651,
    1652,  1653,  1654,    -1,  1656,   268,    -1,    -1,    -1,    -1,
      -1,    -1,   275,    -1,   277,    -1,    -1,    -1,   281,    -1,
      -1,   239,    -1,    -1,    -1,   512,    -1,    -1,    -1,    -1,
     517,    -1,    -1,    -1,    -1,  1687,  1688,    -1,   607,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1239,    -1,    -1,    -1,    -1,  1244,    -1,
     323,    -1,    -1,    -1,    -1,    -1,    -1,  2069,    -1,    -1,
      -1,   558,    -1,  2075,   643,    -1,    -1,    -1,  1790,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    20,    -1,   306,    -1,
      -1,    25,  1278,  1805,    -1,    -1,   314,   315,   316,   317,
     318,   319,  1814,    -1,    -1,  1025,    -1,   325,    -1,   596,
      -1,    -1,    -1,    47,    -1,    -1,    -1,    -1,    -1,    -1,
     607,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   620,    -1,    -1,    -1,    -1,    -1,  1851,
    1852,  1853,  1854,    -1,    -1,    -1,    -1,  1799,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   643,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  2168,    -1,    -1,   656,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   117,    -1,  2187,    -1,   121,    -1,    -1,
      -1,    -1,    -1,   680,    -1,    -1,  1116,    14,    -1,  1119,
      -1,    -1,    -1,    20,   138,   139,    -1,    -1,    25,    -1,
      -1,    -1,    -1,    -1,   148,    -1,    -1,    -1,    -1,   706,
     707,    -1,   709,   710,   711,    -1,    -1,    -1,    -1,    -1,
      47,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     727,    -1,    -1,   177,    -1,  1431,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   188,    -1,    -1,    -1,    -1,   828,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1924,    -1,    -1,    -1,    -1,    -1,   558,    -1,
      -1,  2283,    -1,   852,    -1,    -1,    -1,  1207,    -1,    -1,
      -1,   778,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     117,    -1,    -1,    -1,   121,   239,    -1,    -1,   877,    -1,
      -1,    -1,    -1,   882,    -1,    -1,   885,    -1,    -1,    -1,
      -1,   138,   139,    -1,   811,    -1,    -1,   607,    -1,    -1,
      -1,   148,    -1,  1253,    -1,    -1,    -1,  2339,    -1,    -1,
    1260,   828,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1537,    -1,    -1,    -1,    -1,    -1,   174,    -1,    -1,
     177,    -1,    -1,   643,  1550,   852,    -1,    -1,    -1,    -1,
      -1,   188,   306,   190,    -1,  1561,   310,   311,   312,    -1,
     314,   315,   316,   317,   318,   319,  1306,    -1,   875,    -1,
     877,   325,    -1,    -1,    -1,   882,    -1,    -1,   885,    -1,
      -1,  1587,  1588,  1589,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  2125,    -1,  2067,   903,    -1,    -1,    -1,
      -1,    -1,   239,    -1,    -1,    -1,  2138,    -1,    -1,    -1,
      -1,    -1,    -1,  1619,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   933,    -1,    -1,    -1,
      -1,   938,  2164,    -1,   941,   942,  1025,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   959,    -1,    -1,    -1,   963,   964,   965,   966,
    2192,    -1,    -1,    -1,    -1,    -1,   973,   974,    -1,   306,
      -1,    -1,    -1,   310,   311,   312,    -1,   314,   315,   316,
     317,   318,   319,    -1,   558,   322,    -1,    -1,   325,    -1,
      -1,    -1,   329,  1000,  1001,    -1,  1003,    -1,  1005,    -1,
      -1,  1707,  1009,    -1,    -1,    -1,  1013,    -1,    -1,  1016,
    1017,  1018,  1019,  1020,  1021,  1022,  1023,  1024,  1025,  1026,
      -1,    -1,  1029,    -1,    -1,  1032,    -1,  1116,   828,    -1,
    1119,    -1,    -1,   607,  1474,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   852,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   643,
      -1,    -1,  1512,    -1,    -1,    -1,    -1,   877,    -1,    -1,
      -1,    -1,   882,    -1,  1790,   885,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1805,
      -1,  1541,    -1,    -1,    -1,    -1,    -1,    -1,  1814,  1116,
      -1,    -1,  1119,    -1,    -1,    -1,    -1,    -1,  1207,  1559,
      -1,    -1,    -1,    -1,  1564,    -1,    -1,    -1,    -1,    -1,
      -1,  1571,    -1,    -1,    -1,    -1,  1576,    -1,  1578,    -1,
      -1,    -1,    -1,    -1,    -1,  1851,  1852,  1853,  1854,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  1253,    -1,    -1,    -1,    -1,    -1,
      -1,  1260,    -1,    -1,    -1,    -1,    -1,  1617,    -1,    -1,
      -1,    -1,    -1,    -1,   558,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1205,    -1,
    1207,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1655,    -1,  1306,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1025,    -1,    -1,    -1,  1669,
    1936,    -1,    -1,   607,  1940,    -1,    -1,    -1,  1944,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1253,    -1,    -1,    -1,
      -1,    -1,    -1,  1260,   828,    -1,    -1,  1697,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   558,    -1,  1275,   643,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   852,   558,
      -1,    -1,    -1,    -1,    -1,    -1,  1293,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1306,
      -1,    -1,    -1,   877,  1311,    -1,    -1,    -1,   882,    -1,
      -1,   885,    -1,    -1,    -1,   607,  1116,    -1,    -1,  1119,
      -1,    -1,  2028,    -1,    -1,    -1,  2032,    -1,   607,    -1,
      -1,    -1,    -1,    -1,  1341,  1342,  1343,  1344,  1345,  1346,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   643,    -1,    -1,  1361,  1362,  1363,  1364,    -1,    -1,
      -1,  1368,    -1,    -1,   643,  1372,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1813,    -1,    -1,    -1,  1384,    -1,  2085,
      -1,    -1,  1389,    -1,  2090,  1474,    -1,    -1,  2094,    -1,
      -1,    -1,  1399,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1410,  1411,    -1,  1413,  1207,    -1,    -1,
    1417,    -1,    -1,    -1,    -1,    -1,    -1,  2123,    -1,  2125,
      -1,    -1,    -1,  1512,  1431,    -1,  1433,  1434,    -1,    -1,
      -1,    -1,  2138,    -1,    -1,    -1,    -1,    -1,    -1,  2145,
      -1,    -1,    -1,    -1,  2150,    -1,    -1,    -1,    -1,  1456,
      -1,  1025,  1541,  1253,   828,    -1,    -1,    -1,  2164,    -1,
    1260,  1468,    -1,    -1,    -1,    -1,    -1,  1474,    -1,    -1,
    1559,    -1,    -1,    -1,    -1,  1564,  2182,    -1,   852,    -1,
    1920,    -1,  1571,    -1,    -1,    -1,  2192,  1576,    -1,  1578,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  2207,    -1,   877,  1511,  1512,  1306,    -1,   882,    -1,
    2216,   885,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1617,    -1,
      -1,    -1,    -1,    -1,  1541,    -1,   828,    -1,    -1,    -1,
      -1,    -1,  1116,    -1,    -1,  1119,    -1,    -1,    -1,   828,
      -1,    -1,  1559,    -1,    -1,    -1,    -1,  1564,    -1,    -1,
     852,    -1,    -1,    -1,  1571,    -1,  1655,    -1,    -1,  1576,
      -1,  1578,    -1,   852,    -1,    -1,    -1,    -1,    -1,    -1,
    1669,  2287,  1589,    -1,    -1,   877,    -1,    -1,    -1,    -1,
     882,    -1,    -1,   885,    -1,  2301,    -1,    -1,   877,    -1,
      -1,    -1,    -1,   882,    -1,    -1,   885,  1614,  1697,    -1,
    1617,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1626,
      -1,    -1,    -1,  1630,    -1,    -1,    -1,  1634,    -1,  2069,
    2336,    -1,    -1,  1207,    -1,  2075,  1643,    -1,    -1,  1646,
    1647,  1648,  1649,  1650,  1651,  1652,  1653,  1654,  1655,  1656,
      -1,  1025,    -1,  1660,  1661,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1669,    -1,   558,   558,    -1,  1674,    -1,    -1,
      -1,    -1,    -1,    -1,  1474,    -1,    -1,    -1,    -1,  1253,
    1687,  1688,  1689,    -1,  1691,    -1,  1260,    -1,    -1,    -1,
    1697,  1698,    -1,    -1,    -1,    -1,  1703,    -1,    -1,    -1,
    1707,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1512,   607,   607,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1730,  1813,    -1,    -1,    -1,  2168,    -1,
      -1,    -1,  1306,  1025,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1541,  1116,    -1,    -1,  1119,  1025,  2187,    -1,   643,
     643,    -1,    20,    -1,    -1,    -1,    -1,    25,    -1,  1559,
      -1,    -1,    -1,    -1,  1564,    -1,    -1,    -1,    -1,    -1,
      -1,  1571,    -1,    -1,    -1,    -1,  1576,    -1,  1578,    47,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1799,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1813,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1617,    -1,    -1,
      -1,    -1,    -1,    91,  1116,    -1,    -1,  1119,    -1,    -1,
      -1,  1920,    -1,  1207,    -1,    -1,    -1,  1116,    -1,    -1,
    1119,    -1,    -1,  2283,    -1,    -1,    -1,    -1,    14,   117,
      -1,    -1,    -1,   121,    20,  1655,  1863,    -1,    -1,    25,
      -1,    -1,    -1,    -1,  1871,    -1,    -1,    -1,    -1,  1669,
     138,   139,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1253,
     148,    47,    -1,    -1,    -1,    -1,  1260,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  1697,    -1,  2339,
    1474,    -1,  1909,    -1,    -1,    -1,    -1,    -1,    -1,   177,
      -1,    -1,    -1,  1920,    -1,  1207,    -1,  1924,  1925,  1926,
     188,    -1,  1929,    -1,    -1,    -1,    -1,    -1,  1207,  1936,
      -1,    -1,  1306,  1940,   828,   828,    -1,  1944,  1512,    -1,
      -1,    -1,    -1,  1950,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   117,    -1,    -1,    -1,   121,    -1,    -1,   852,   852,
    1967,  1253,    -1,    -1,    -1,    -1,    -1,  1541,  1260,    -1,
      -1,   239,   138,   139,  1253,    -1,    -1,    -1,    -1,    -1,
    2069,  1260,   148,   877,   877,  1559,  2075,    -1,   882,   882,
    1564,   885,   885,    -1,    -1,    -1,    -1,  1571,    -1,  2006,
      -1,    -1,  1576,    -1,  1578,    -1,    -1,    -1,   174,    -1,
      -1,   177,    -1,  1813,  1306,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   188,    -1,   190,  2032,    -1,  1306,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   306,    -1,
      -1,    -1,    -1,  1617,    -1,    -1,   314,   315,   316,   317,
     318,   319,  2059,    14,    -1,    -1,    17,   325,    -1,    20,
    2067,    -1,  2069,    -1,    25,    -1,    -1,    -1,  2075,    -1,
      -1,    -1,  2079,   239,    -1,    -1,    -1,    -1,  2085,  2168,
      -1,  1655,    -1,  2090,    -1,    -1,    47,  2094,    -1,    -1,
      -1,    -1,    -1,  2100,  2101,  1669,    -1,    -1,  2187,    -1,
    1474,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  2123,    -1,    -1,    80,
    1920,    -1,    -1,  1697,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1025,  1025,    -1,    -1,    -1,    -1,    -1,  1512,    -1,
     306,    -1,    -1,    -1,   310,   311,   312,    -1,   314,   315,
     316,   317,   318,   319,    -1,    -1,   117,    -1,    -1,   325,
     121,  2168,   328,    -1,    -1,    -1,    -1,  1541,    -1,    -1,
      -1,  2178,    -1,    -1,    -1,  2182,    -1,   138,   139,    -1,
    2187,    -1,  1474,    -1,    -1,  1559,    -1,   148,    -1,    -1,
    1564,    -1,    -1,    -1,  2283,  1474,    -1,  1571,    -1,    -1,
    2207,    -1,  1576,    -1,  1578,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   174,    -1,    -1,   177,    -1,    -1,    -1,
    1512,    -1,  1116,  1116,    -1,  1119,  1119,   188,    -1,   190,
      -1,    -1,    -1,  1512,    -1,    -1,    -1,    -1,    -1,  1813,
      -1,    -1,    -1,  1617,    -1,    -1,    -1,    -1,    -1,  1541,
    2339,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1541,    -1,    -1,    -1,    -1,  1559,    -1,  2069,
      -1,    -1,  1564,    -1,   469,  2075,  2283,    -1,   239,  1571,
    1559,  1655,    -1,    -1,  1576,  1564,  1578,    -1,    -1,    -1,
      -1,    -1,  1571,    -1,  2301,  1669,    -1,  1576,    -1,  1578,
      14,    -1,    -1,    -1,    -1,    -1,    20,    -1,    -1,    -1,
      -1,    25,    -1,  1207,  1207,    -1,    -1,    -1,    -1,   280,
      -1,    -1,    -1,  1697,    -1,  1617,    -1,    -1,    -1,  2336,
      -1,    -1,  2339,    47,    -1,    -1,    -1,    -1,  1617,    -1,
      -1,    -1,    -1,    -1,    -1,   306,  1920,    -1,    -1,   310,
     311,   312,    -1,   314,   315,   316,   317,   318,   319,  1253,
    1253,    -1,    -1,  1655,   325,    -1,  1260,  1260,  2168,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1655,  1669,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,  2187,    -1,    -1,
    1669,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   117,    -1,  1697,    -1,   121,    -1,    -1,
      -1,    -1,  1306,  1306,    -1,    -1,    -1,    -1,  1697,    -1,
      -1,    -1,    -1,    -1,   138,   139,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   148,    -1,    -1,    -1,    -1,  1813,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     174,   656,    -1,   177,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   188,    -1,   190,    -1,    -1,    -1,
      -1,    -1,    -1,  2283,    -1,   680,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  2069,    -1,    -1,    -1,    -1,
      -1,  2075,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   706,   707,    -1,   709,   710,   711,    -1,    -1,    -1,
      -1,  1813,    -1,    -1,    -1,   239,    -1,    -1,    -1,    -1,
      -1,    -1,   727,    -1,  1813,    -1,    -1,    -1,    -1,  2339,
      -1,    -1,    -1,    -1,    -1,    -1,  1920,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1474,  1474,    -1,   778,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   306,    -1,  2168,    -1,   310,   311,   312,    -1,
     314,   315,   316,   317,   318,   319,    -1,    -1,    -1,    -1,
      -1,   325,    -1,  2187,   328,    -1,    -1,    -1,  1512,  1512,
      -1,    -1,    -1,    -1,    -1,    14,    -1,   728,  1920,    -1,
      -1,    20,    -1,    -1,    -1,    -1,    25,    -1,    -1,    -1,
      -1,  1920,    -1,    -1,    -1,    -1,    -1,  1541,  1541,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    47,    -1,
      -1,    -1,    -1,    -1,    -1,  1559,  1559,    -1,    -1,    -1,
    1564,  1564,    -1,    -1,    -1,    -1,    -1,  1571,  1571,    -1,
     875,    -1,  1576,  1576,  1578,  1578,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  2069,    -1,    -1,    -1,    -1,
      -1,  2075,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  2283,
      -1,    -1,    -1,   102,    -1,    -1,    -1,    -1,   107,    -1,
      -1,    -1,    -1,  1617,  1617,    -1,    -1,    -1,   117,    -1,
      -1,    -1,   121,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   938,    -1,    -1,    -1,   942,    -1,   138,
     139,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   148,
      -1,  1655,  1655,    -1,   959,  2339,    -1,    -1,   963,    -1,
     965,   966,    -1,    -1,    -1,  1669,  1669,  2069,   973,   974,
      -1,    -1,    -1,  2075,    -1,   174,    -1,    -1,   177,    -1,
    2069,    -1,    -1,   894,  2168,    -1,  2075,    -1,    -1,   188,
      -1,   190,    -1,  1697,  1697,  1000,    -1,    -1,    -1,    14,
    1005,    16,    -1,  2187,  1009,    20,    -1,    -1,  1013,    -1,
      25,  1016,  1017,  1018,  1019,  1020,  1021,  1022,  1023,  1024,
      -1,  1026,    14,    -1,  1029,   936,    -1,    -1,    20,    -1,
      -1,    -1,    47,    25,    -1,    -1,    -1,    -1,    -1,    -1,
     239,    -1,    -1,    -1,    -1,    -1,    -1,   958,    -1,    -1,
      -1,    -1,    -1,   964,    -1,    47,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  2168,   978,   979,   980,
     981,    -1,    -1,   984,    -1,    -1,    -1,    -1,    -1,  2168,
      -1,    -1,    -1,    -1,    -1,  2187,    -1,    -1,   999,    -1,
      -1,    -1,  1003,    -1,    -1,    -1,    -1,    -1,  2187,  2283,
      -1,    -1,   117,    -1,    -1,    -1,   121,   306,    -1,  1813,
    1813,   310,   311,   312,    -1,   314,   315,   316,   317,   318,
     319,    -1,    -1,   138,   139,   117,   325,    -1,    -1,   121,
      -1,    -1,    -1,   148,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   138,   139,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  2339,   148,    -1,    -1,   174,
      -1,    -1,   177,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1081,    -1,    -1,   188,    -1,   190,    -1,    -1,    -1,    -1,
      -1,  2283,   174,    -1,    -1,   177,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  2283,    -1,   188,    -1,   190,    -1,
    1205,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  1920,  1920,    -1,    -1,
      -1,    -1,    -1,    -1,   239,    -1,    -1,    -1,    14,    -1,
      16,    -1,    -1,    -1,    20,    -1,    -1,  2339,    -1,    25,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   239,    -1,    -1,
    2339,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    47,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    1275,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1293,    -1,
      -1,   306,    -1,    -1,    -1,   310,   311,   312,    -1,   314,
     315,   316,   317,   318,   319,    -1,  1311,    -1,    -1,    -1,
     325,    -1,    -1,    -1,   306,    -1,    -1,    -1,   310,   311,
     312,    -1,   314,   315,   316,   317,   318,   319,    -1,    -1,
      -1,   117,   324,   325,    -1,   121,    -1,    -1,  1249,    -1,
    1345,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   138,   139,    -1,    -1,  1361,    -1,  1363,  1364,
      -1,    -1,   148,  1368,    -1,  2069,  2069,  1372,    -1,    -1,
      -1,  2075,  2075,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   174,    -1,
      -1,   177,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   188,  1314,   190,  1316,  1411,    -1,  1413,    -1,
      -1,    -1,  1417,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1336,    -1,    -1,  1339,    -1,
    1341,  1342,  1343,  1344,    -1,  1346,  1347,    -1,    -1,    -1,
      -1,  1352,  1353,    -1,    -1,    -1,    -1,    -1,    -1,  1360,
      -1,  1456,    -1,   239,  1365,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,  1468,  2168,  2168,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1393,  2187,  2187,  1396,    -1,  1398,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1409,  1410,
      -1,    -1,    -1,    -1,    -1,  1416,    -1,  1418,  1419,  1420,
    1421,  1422,  1423,  1424,  1425,  1426,    -1,  1428,    -1,    -1,
     306,    -1,    -1,    -1,   310,   311,   312,    -1,   314,   315,
     316,   317,   318,   319,    14,    -1,    -1,    -1,    -1,   325,
      20,    -1,    -1,    -1,    -1,    25,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    47,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  2283,
    2283,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,  1513,    -1,    -1,    -1,    -1,    -1,    -1,  1614,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  1626,    -1,    -1,    -1,  1630,    -1,    -1,    -1,  1634,
      -1,    -1,    -1,    -1,    -1,  2339,  2339,   117,    -1,    -1,
      -1,   121,    -1,    -1,    -1,    -1,    14,    -1,    -1,    -1,
      -1,    -1,    20,    -1,    -1,  1660,  1661,    25,   138,   139,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   148,    -1,
    1581,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    47,
      -1,    -1,    -1,    -1,  1689,    -1,  1691,    -1,    -1,    -1,
      -1,    -1,    -1,  1698,   174,    -1,    -1,   177,  1703,    -1,
      -1,    -1,  1613,    -1,    -1,    -1,    -1,    -1,   188,    -1,
     190,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,  1730,  1637,  1638,  1639,  1640,
    1641,  1642,  1643,    -1,    -1,  1646,  1647,  1648,  1649,  1650,
    1651,  1652,  1653,  1654,    -1,  1656,    20,    -1,    -1,   117,
      -1,    25,    -1,   121,    -1,    -1,    -1,    -1,    -1,   239,
      -1,    -1,    -1,    -1,    -1,  1676,    -1,  1678,    -1,    -1,
     138,   139,    -1,    47,    -1,    -1,    -1,  1688,    -1,    -1,
     148,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1699,  1700,
      -1,  1702,    -1,    -1,  1705,    -1,    -1,    -1,    -1,    -1,
     280,    -1,    -1,    -1,    -1,    -1,   174,    -1,    -1,   177,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     188,    -1,   190,    -1,    -1,    -1,   306,  1738,    -1,    -1,
     310,   311,   312,   201,   314,   315,   316,   317,   318,   319,
      -1,    -1,    -1,   117,    -1,   325,    -1,   121,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  1863,    -1,
      -1,    -1,    -1,    -1,   138,   139,  1871,    -1,    -1,    -1,
      -1,   239,    -1,    -1,   148,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    14,    -1,  1799,    -1,
      -1,    -1,    20,    -1,    -1,    -1,    -1,    25,    -1,    -1,
     174,    -1,    -1,   177,  1909,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   188,    -1,    -1,    -1,    -1,    47,
    1925,  1926,    -1,    -1,  1929,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   306,    -1,
      -1,    -1,   310,   311,   312,    -1,   314,   315,   316,   317,
     318,   319,    -1,    -1,    -1,    -1,    -1,   325,    -1,    -1,
      -1,  1872,  1967,    -1,    -1,   239,  1877,  1878,    -1,  1880,
      -1,  1882,    -1,    -1,    -1,  1886,  1887,  1888,  1889,  1890,
    1891,  1892,  1893,  1894,    -1,  1896,  1897,  1898,    -1,   117,
      -1,    -1,    -1,   121,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,  2006,    -1,    -1,    -1,  1916,  1917,    -1,  1919,    -1,
     138,   139,  1923,  1924,    -1,    -1,  1927,    -1,    -1,    -1,
     148,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   306,    -1,    -1,    -1,   310,   311,   312,    -1,
     314,   315,   316,   317,   318,   319,   174,    -1,  1959,   177,
      -1,   325,    -1,    -1,  2059,    -1,    -1,    -1,    -1,    -1,
     188,    -1,   190,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,  2079,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  2101,    -1,  2009,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   239,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,  2060,
      -1,    -1,    -1,    -1,    -1,    -1,  2067,    -1,    -1,    -1,
    2071,    -1,    -1,    -1,    -1,  2076,  2077,  2078,    -1,  2080,
      -1,    -1,    -1,  2178,    -1,    -1,    -1,    -1,   306,    -1,
      -1,    -1,   310,   311,   312,    -1,   314,   315,   316,   317,
     318,   319,    -1,    -1,    -1,    -1,   324,   325,  2109,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  2127,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,  2167,    -1,    -1,    -1,
      -1,    -1,  2173,    -1,    -1,    -1,    -1,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    -1,    -1,    -1,  2190,
      -1,    -1,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    -1,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      46,    -1,    -1,    49,    50,    51,    -1,    53,    54,    55,
      56,  2232,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    -1,    -1,    75,
      76,    77,    78,    79,    -1,    81,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    95,
      96,    97,    98,    99,   100,   101,    -1,   103,    -1,   105,
     106,    -1,   108,   109,   110,   111,    -1,    -1,   114,    -1,
     116,   117,   118,   119,   120,   121,   122,   123,   124,    -1,
     126,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,   138,   139,   140,   141,   142,   143,   144,    -1,
     146,   147,   148,    -1,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
     166,   167,   168,   169,   170,   171,   172,   173,   174,   175,
     176,   177,   178,   179,   180,   181,    -1,    -1,   184,   185,
      -1,    -1,   188,   189,    -1,    -1,   192,   193,   194,   195,
     196,   197,   198,   199,   200,    -1,   202,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,   234,   235,
     236,   237,   238,   239,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,    -1,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,   264,   265,
     266,   267,   268,   269,   270,   271,    -1,   273,   274,   275,
     276,   277,   278,   279,    -1,   281,   282,   283,   284,   285,
     286,   287,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,   301,   302,    -1,   304,   305,
     306,   307,   308,    -1,    -1,    -1,    -1,    -1,   314,   315,
     316,    -1,   318,   319,    -1,    -1,    -1,   323,   324,     3,
       4,     5,     6,     7,     8,     9,    -1,    11,    -1,    -1,
      -1,    -1,    -1,    -1,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    -1,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    -1,    42,    43,
      44,    45,    46,    -1,    -1,    49,    50,    51,    -1,    53,
      54,    55,    56,    -1,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    -1,
      -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,    83,
      84,    85,    86,    -1,    88,    89,    -1,    91,    -1,    93,
      94,    95,    96,    97,    98,    99,   100,   101,    -1,   103,
      -1,   105,   106,    -1,   108,   109,   110,   111,    -1,    -1,
     114,    -1,   116,   117,   118,   119,   120,   121,   122,   123,
     124,    -1,   126,   127,   128,   129,   130,   131,   132,   133,
      -1,   135,    -1,   137,   138,   139,   140,   141,   142,   143,
     144,    -1,   146,   147,   148,    -1,   150,   151,   152,   153,
     154,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,   166,   167,   168,   169,   170,   171,   172,   173,
     174,   175,   176,   177,   178,   179,   180,   181,    -1,    -1,
     184,   185,    -1,    -1,   188,   189,    -1,    -1,   192,   193,
     194,   195,   196,   197,   198,   199,   200,    -1,   202,   203,
     204,    -1,   206,   207,   208,   209,   210,   211,   212,    -1,
     214,   215,   216,   217,   218,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,    -1,   231,   232,   233,
     234,   235,   236,   237,   238,   239,   240,   241,    -1,   243,
     244,   245,   246,   247,   248,   249,   250,   251,   252,    -1,
     254,   255,   256,    -1,   258,   259,    -1,   261,    -1,   263,
     264,   265,   266,   267,   268,   269,   270,   271,    -1,   273,
     274,   275,   276,   277,   278,   279,    -1,   281,   282,   283,
     284,   285,   286,   287,   288,   289,   290,    -1,    -1,   293,
     294,   295,   296,   297,   298,    -1,   300,   301,   302,    -1,
     304,   305,   306,   307,   308,    -1,    -1,    -1,    -1,    -1,
     314,   315,    -1,    -1,   318,   319,    -1,    -1,    -1,   323,
     324,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    -1,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    -1,
      42,    43,    44,    45,    46,    -1,    -1,    49,    50,    51,
      -1,    53,    54,    55,    56,    -1,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    83,    84,    85,    86,    -1,    88,    89,    -1,    91,
      -1,    93,    94,    95,    96,    97,    98,    99,   100,   101,
      -1,   103,    -1,   105,   106,    -1,   108,   109,   110,   111,
      -1,    -1,   114,    -1,   116,   117,   118,   119,   120,   121,
     122,   123,   124,    -1,   126,   127,   128,   129,   130,   131,
     132,   133,    -1,   135,    -1,   137,   138,   139,   140,   141,
     142,   143,   144,    -1,   146,   147,   148,    -1,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,   166,   167,   168,   169,   170,   171,
     172,   173,   174,   175,   176,   177,   178,   179,   180,   181,
      -1,    -1,   184,   185,    -1,    -1,   188,   189,    -1,    -1,
     192,   193,   194,   195,   196,   197,   198,   199,   200,    -1,
     202,   203,   204,    -1,   206,   207,   208,   209,   210,   211,
     212,    -1,   214,   215,   216,   217,   218,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,    -1,   231,
     232,   233,   234,   235,   236,   237,   238,   239,   240,   241,
      -1,   243,   244,   245,   246,   247,   248,   249,   250,   251,
     252,    -1,   254,   255,   256,    -1,   258,   259,    -1,   261,
      -1,   263,   264,   265,   266,   267,   268,   269,   270,   271,
      -1,   273,   274,   275,   276,   277,   278,   279,    -1,   281,
     282,   283,   284,   285,   286,   287,   288,   289,   290,    -1,
      -1,   293,   294,   295,   296,   297,   298,    -1,   300,   301,
     302,    -1,   304,   305,   306,   307,   308,    -1,    -1,    -1,
      -1,    -1,   314,   315,    -1,    -1,   318,   319,    -1,    -1,
      -1,   323,   324,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    16,    -1,    18,    19,
      20,    -1,    22,    23,    24,    -1,    26,    -1,    28,    29,
      -1,    31,    32,    33,    34,    -1,    -1,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    46,    -1,    -1,    49,
      50,    51,    -1,    53,    54,    55,    56,    -1,    58,    59,
      -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,
      70,    71,    72,    -1,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    91,    92,    93,    94,    95,    96,    97,    98,    -1,
     100,   101,   102,   103,    -1,   105,    -1,    -1,    -1,   109,
     110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,
     120,    -1,   122,   123,   124,    -1,    -1,   127,   128,   129,
     130,   131,   132,   133,   134,   135,    -1,   137,    -1,    -1,
     140,    -1,   142,   143,   144,    -1,    -1,   147,    -1,   149,
     150,   151,   152,    -1,    -1,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,    -1,   167,    -1,   169,
     170,   171,   172,   173,    -1,   175,   176,    -1,    -1,   179,
     180,   181,    -1,   183,   184,    -1,    -1,    -1,   188,   189,
      -1,   191,   192,    -1,    -1,   195,   196,   197,   198,   199,
     200,    -1,   202,   203,   204,    -1,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,    -1,   223,   224,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,    -1,   235,   236,   237,   238,    -1,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,   264,   265,   266,    -1,   268,   269,
     270,   271,   272,    -1,   274,   275,   276,   277,   278,    -1,
      -1,   281,   282,   283,   284,   285,   286,    -1,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,    -1,     3,     4,     5,     6,     7,     8,     9,    -1,
      11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,
      -1,    22,    23,    24,   324,    26,    -1,    28,    29,    -1,
      31,    32,    33,    34,    -1,    -1,    37,    38,    39,    40,
      -1,    42,    43,    44,    45,    -1,    -1,    -1,    49,    50,
      51,    -1,    53,    54,    -1,    56,    -1,    58,    59,    -1,
      -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,    70,
      71,    72,    -1,    -1,    75,    76,    77,    78,    79,    -1,
      -1,    -1,    83,    84,    85,    86,    -1,    88,    89,    -1,
      91,    -1,    93,    94,    -1,    96,    97,    -1,    -1,   100,
     101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,
     111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,
     121,   122,   123,   124,    -1,    -1,   127,   128,   129,   130,
     131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,
      -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,
     151,   152,    -1,    -1,   155,   156,   157,   158,   159,   160,
     161,   162,   163,   164,   165,    -1,   167,    -1,   169,   170,
     171,   172,    -1,    -1,   175,   176,    -1,    -1,    -1,   180,
     181,    -1,    -1,   184,    -1,    -1,    -1,   188,   189,    -1,
      -1,   192,    -1,    -1,    -1,   196,   197,   198,   199,   200,
      -1,    -1,   203,   204,    -1,   206,   207,   208,   209,   210,
     211,   212,    -1,   214,   215,   216,   217,   218,   219,   220,
     221,    -1,   223,    -1,   225,   226,   227,   228,   229,    -1,
     231,   232,   233,    -1,   235,   236,   237,   238,    -1,   240,
     241,    -1,   243,   244,   245,   246,   247,   248,   249,   250,
      -1,   252,    -1,   254,   255,   256,    -1,   258,   259,    -1,
     261,    -1,   263,    -1,   265,    -1,    -1,   268,   269,   270,
     271,    -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,
     281,   282,   283,   284,   285,   286,    -1,   288,   289,   290,
      -1,    -1,   293,   294,   295,   296,   297,   298,    -1,   300,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,
       4,     5,     6,     7,     8,     9,    -1,    11,    -1,    -1,
      -1,    -1,    -1,   324,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    -1,    42,    43,
      44,    45,    46,    -1,    -1,    49,    50,    51,    -1,    53,
      54,    55,    56,    -1,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    -1,
      -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,    83,
      84,    85,    86,    -1,    88,    89,    -1,    91,    -1,    93,
      94,    95,    96,    97,    98,    99,   100,   101,    -1,   103,
      -1,   105,   106,   107,   108,   109,   110,   111,    -1,    -1,
     114,    -1,   116,   117,   118,   119,   120,   121,   122,   123,
     124,    -1,   126,   127,   128,   129,   130,   131,   132,   133,
      -1,   135,    -1,   137,   138,   139,   140,   141,   142,   143,
     144,   145,   146,   147,   148,    -1,   150,   151,   152,   153,
     154,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,   166,   167,   168,   169,   170,   171,   172,   173,
     174,   175,   176,   177,   178,   179,   180,   181,    -1,    -1,
     184,   185,    -1,    -1,   188,   189,    -1,    -1,   192,   193,
     194,   195,   196,   197,   198,   199,   200,    -1,   202,   203,
     204,    -1,   206,   207,   208,   209,   210,   211,   212,    -1,
     214,   215,   216,   217,   218,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,    -1,   231,   232,   233,
     234,   235,   236,   237,   238,   239,   240,   241,    -1,   243,
     244,   245,   246,   247,   248,   249,   250,   251,   252,    -1,
     254,   255,   256,    -1,   258,   259,    -1,   261,   262,   263,
     264,   265,   266,   267,   268,   269,   270,   271,    -1,   273,
     274,   275,   276,   277,   278,   279,    -1,   281,   282,   283,
     284,   285,   286,   287,   288,   289,   290,    -1,    -1,   293,
     294,   295,   296,   297,   298,    -1,   300,   301,   302,    -1,
     304,   305,   306,   307,   308,    -1,    -1,    -1,    -1,    -1,
     314,   315,    -1,    -1,   318,   319,    -1,    -1,    -1,   323,
       3,     4,     5,     6,     7,     8,     9,    -1,    11,    -1,
      -1,    -1,    -1,    -1,    -1,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      43,    44,    45,    46,    -1,    -1,    49,    50,    51,    -1,
      53,    54,    55,    56,    -1,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,
      83,    84,    85,    86,    -1,    88,    89,    -1,    91,    -1,
      93,    94,    95,    96,    97,    98,    99,   100,   101,    -1,
     103,    -1,   105,   106,    -1,   108,   109,   110,   111,    -1,
      -1,   114,    -1,   116,   117,   118,   119,   120,   121,   122,
     123,   124,    -1,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   135,    -1,   137,   138,   139,   140,   141,   142,
     143,   144,    -1,   146,   147,   148,    -1,   150,   151,   152,
     153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
     163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
     173,   174,   175,   176,   177,   178,   179,   180,   181,    -1,
      -1,   184,   185,    -1,    -1,   188,   189,    -1,    -1,   192,
     193,   194,   195,   196,   197,   198,   199,   200,    -1,   202,
     203,   204,    -1,   206,   207,   208,   209,   210,   211,   212,
      -1,   214,   215,   216,   217,   218,   219,   220,   221,   222,
     223,   224,   225,   226,   227,   228,   229,    -1,   231,   232,
     233,   234,   235,   236,   237,   238,   239,   240,   241,    -1,
     243,   244,   245,   246,   247,   248,   249,   250,   251,   252,
      -1,   254,   255,   256,    -1,   258,   259,    -1,   261,    -1,
     263,   264,   265,   266,   267,   268,   269,   270,   271,    -1,
     273,   274,   275,   276,   277,   278,   279,    -1,   281,   282,
     283,   284,   285,   286,   287,   288,   289,   290,    -1,    -1,
     293,   294,   295,   296,   297,   298,    -1,   300,   301,   302,
      -1,   304,   305,   306,   307,   308,    -1,    -1,    -1,    -1,
      -1,   314,   315,   316,    -1,   318,   319,    -1,    -1,    -1,
     323,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    29,    -1,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    -1,
      42,    43,    44,    45,    46,    -1,    -1,    49,    50,    51,
      -1,    53,    54,    55,    56,    -1,    58,    59,    60,    61,
      62,    63,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    83,    84,    85,    86,    -1,    88,    89,    -1,    91,
      -1,    93,    94,    95,    96,    97,    98,    99,   100,   101,
      -1,   103,    -1,   105,   106,    -1,   108,   109,   110,   111,
      -1,    -1,   114,    -1,   116,   117,   118,   119,   120,   121,
     122,   123,   124,    -1,   126,   127,   128,   129,   130,   131,
     132,   133,    -1,   135,    -1,   137,   138,   139,   140,   141,
     142,   143,   144,    -1,   146,   147,   148,    -1,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,   166,   167,   168,   169,   170,   171,
     172,   173,   174,   175,   176,   177,   178,   179,   180,   181,
      -1,    -1,   184,   185,    -1,    -1,   188,   189,    -1,    -1,
     192,   193,   194,   195,   196,   197,   198,   199,   200,    -1,
     202,   203,   204,    -1,   206,   207,   208,   209,   210,   211,
     212,    -1,   214,   215,   216,   217,   218,   219,   220,   221,
     222,   223,   224,   225,   226,   227,   228,   229,    -1,   231,
     232,   233,   234,   235,   236,   237,   238,   239,   240,   241,
      -1,   243,   244,   245,   246,   247,   248,   249,   250,   251,
     252,    -1,   254,   255,   256,    -1,   258,   259,    -1,   261,
      -1,   263,   264,   265,   266,   267,   268,   269,   270,   271,
      -1,   273,   274,   275,   276,   277,   278,   279,    -1,   281,
     282,   283,   284,   285,   286,   287,   288,   289,   290,    -1,
      -1,   293,   294,   295,   296,   297,   298,    -1,   300,   301,
     302,    -1,   304,   305,   306,   307,   308,    -1,    -1,    -1,
      -1,    -1,   314,   315,   316,    -1,   318,   319,    -1,    -1,
      -1,   323,     3,     4,     5,     6,     7,     8,     9,    -1,
      11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    28,    29,    -1,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      -1,    42,    43,    44,    45,    46,    -1,    -1,    49,    50,
      51,    -1,    53,    54,    55,    56,    -1,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    -1,    -1,    75,    76,    77,    78,    79,    -1,
      -1,    -1,    83,    84,    85,    86,    -1,    88,    89,    -1,
      91,    -1,    93,    94,    95,    96,    97,    98,    99,   100,
     101,    -1,   103,    -1,   105,   106,    -1,   108,   109,   110,
     111,    -1,    -1,   114,    -1,   116,   117,   118,   119,   120,
     121,   122,   123,   124,    -1,   126,   127,   128,   129,   130,
     131,   132,   133,    -1,   135,    -1,   137,   138,   139,   140,
     141,   142,   143,   144,    -1,   146,   147,   148,    -1,   150,
     151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
     161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
     171,   172,   173,   174,   175,   176,   177,   178,   179,   180,
     181,    -1,    -1,   184,   185,    -1,    -1,   188,   189,    -1,
      -1,   192,   193,   194,   195,   196,   197,   198,   199,   200,
      -1,   202,   203,   204,    -1,   206,   207,   208,   209,   210,
     211,   212,    -1,   214,   215,   216,   217,   218,   219,   220,
     221,   222,   223,   224,   225,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,   237,   238,   239,   240,
     241,    -1,   243,   244,   245,   246,   247,   248,   249,   250,
     251,   252,    -1,   254,   255,   256,    -1,   258,   259,    -1,
     261,    -1,   263,   264,   265,   266,   267,   268,   269,   270,
     271,    -1,   273,   274,   275,   276,   277,   278,   279,    -1,
     281,   282,   283,   284,   285,   286,   287,   288,   289,   290,
      -1,    -1,   293,   294,   295,   296,   297,   298,    -1,   300,
     301,   302,    -1,   304,   305,   306,   307,   308,    -1,    -1,
      -1,    -1,    -1,   314,   315,    -1,    -1,   318,   319,    -1,
      -1,    -1,   323,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    46,    -1,    -1,    49,
      50,    51,    -1,    53,    54,    55,    56,    -1,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    -1,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    91,    -1,    93,    94,    95,    96,    97,    98,    99,
     100,   101,    -1,   103,    -1,   105,   106,   107,   108,   109,
     110,   111,    -1,    -1,   114,    -1,   116,   117,   118,   119,
     120,   121,   122,   123,   124,    -1,   126,   127,   128,   129,
     130,   131,   132,   133,    -1,   135,    -1,   137,   138,   139,
     140,   141,   142,   143,   144,    -1,   146,   147,   148,    -1,
     150,   151,   152,   153,   154,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,   166,   167,   168,   169,
     170,   171,   172,   173,   174,   175,   176,   177,   178,   179,
     180,   181,    -1,    -1,   184,   185,    -1,    -1,   188,   189,
      -1,    -1,   192,   193,   194,   195,   196,   197,   198,   199,
     200,    -1,   202,   203,   204,    -1,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,   234,   235,   236,   237,   238,   239,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,   264,   265,   266,   267,   268,   269,
     270,   271,    -1,   273,   274,   275,   276,   277,   278,   279,
      -1,   281,   282,   283,   284,   285,   286,   287,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,   301,   302,    -1,   304,   305,   306,   307,   308,    -1,
      -1,    -1,    -1,    -1,   314,   315,    -1,    -1,   318,   319,
      -1,    -1,    -1,   323,     3,     4,     5,     6,     7,     8,
       9,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    -1,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    -1,    42,    43,    44,    45,    46,    -1,    -1,
      49,    50,    51,    -1,    53,    54,    55,    56,    -1,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    -1,    -1,    75,    76,    77,    78,
      79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,
      89,    -1,    91,    -1,    93,    94,    95,    96,    97,    98,
      99,   100,   101,    -1,   103,    -1,   105,   106,    -1,   108,
     109,   110,   111,    -1,    -1,   114,    -1,   116,   117,   118,
     119,   120,   121,   122,   123,   124,    -1,   126,   127,   128,
     129,   130,   131,   132,   133,    -1,   135,    -1,   137,   138,
     139,   140,   141,   142,   143,   144,    -1,   146,   147,   148,
      -1,   150,   151,   152,   153,   154,   155,   156,   157,   158,
     159,   160,   161,   162,   163,   164,   165,   166,   167,   168,
     169,   170,   171,   172,   173,   174,   175,   176,   177,   178,
     179,   180,   181,    -1,    -1,   184,   185,    -1,    -1,   188,
     189,    -1,    -1,   192,   193,   194,   195,   196,   197,   198,
     199,   200,    -1,   202,   203,   204,    -1,   206,   207,   208,
     209,   210,   211,   212,    -1,   214,   215,   216,   217,   218,
     219,   220,   221,   222,   223,   224,   225,   226,   227,   228,
     229,    -1,   231,   232,   233,   234,   235,   236,   237,   238,
     239,   240,   241,    -1,   243,   244,   245,   246,   247,   248,
     249,   250,   251,   252,    -1,   254,   255,   256,    -1,   258,
     259,    -1,   261,    -1,   263,   264,   265,   266,   267,   268,
     269,   270,   271,    -1,   273,   274,   275,   276,   277,   278,
     279,    -1,   281,   282,   283,   284,   285,   286,   287,   288,
     289,   290,    -1,    -1,   293,   294,   295,   296,   297,   298,
      -1,   300,   301,   302,    -1,   304,   305,   306,   307,   308,
      -1,    -1,    -1,    -1,    -1,   314,   315,    -1,    -1,   318,
     319,    -1,    -1,    -1,   323,     3,     4,     5,     6,     7,
       8,     9,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    -1,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    -1,    42,    43,    44,    45,    46,    -1,
      -1,    49,    50,    51,    -1,    53,    54,    55,    56,    -1,
      58,    59,    60,    61,    62,    63,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    -1,    -1,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,
      88,    89,    -1,    91,    -1,    93,    94,    95,    96,    97,
      98,    99,   100,   101,    -1,   103,    -1,   105,   106,    -1,
     108,   109,   110,   111,    -1,    -1,   114,    -1,   116,   117,
     118,   119,   120,   121,   122,   123,   124,    -1,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   135,    -1,   137,
     138,   139,   140,   141,   142,   143,   144,    -1,   146,   147,
     148,    -1,   150,   151,   152,   153,   154,   155,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   165,   166,   167,
     168,   169,   170,   171,   172,   173,    -1,   175,   176,   177,
     178,   179,   180,   181,    -1,    -1,   184,   185,    -1,    -1,
     188,   189,    -1,    -1,   192,   193,   194,   195,   196,   197,
     198,   199,   200,    -1,   202,   203,   204,    -1,   206,   207,
     208,   209,   210,   211,   212,    -1,   214,   215,   216,   217,
     218,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,    -1,   231,   232,   233,   234,   235,   236,   237,
     238,   239,   240,   241,    -1,   243,   244,   245,   246,   247,
     248,   249,   250,   251,   252,    -1,   254,   255,   256,    -1,
     258,   259,    -1,   261,    -1,   263,   264,   265,   266,   267,
     268,   269,   270,   271,    -1,    -1,   274,   275,   276,   277,
     278,   279,    -1,   281,   282,   283,   284,   285,   286,   287,
     288,   289,   290,    -1,    -1,   293,   294,   295,   296,   297,
     298,    -1,   300,   301,   302,    -1,   304,   305,   306,   307,
     308,    -1,    -1,    -1,    -1,    -1,   314,   315,    -1,    -1,
     318,   319,    -1,    -1,    -1,   323,     3,     4,     5,     6,
       7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,    -1,
      -1,    18,    19,    20,    21,    22,    23,    24,    -1,    26,
      27,    28,    29,    -1,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    -1,    42,    43,    44,    45,    46,
      -1,    -1,    49,    50,    51,    -1,    53,    54,    55,    56,
      -1,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    -1,    -1,    75,    76,
      77,    78,    79,    -1,    -1,    -1,    83,    84,    85,    86,
      -1,    88,    89,    -1,    -1,    -1,    93,    94,    95,    96,
      97,    98,    99,   100,   101,    -1,   103,    -1,   105,   106,
      -1,   108,   109,   110,   111,    -1,    -1,   114,    -1,   116,
      -1,   118,   119,   120,    -1,   122,   123,   124,    -1,   126,
     127,   128,   129,   130,   131,   132,   133,    -1,   135,    -1,
     137,   138,   139,   140,   141,   142,   143,   144,    -1,   146,
     147,    -1,    -1,   150,   151,   152,   153,   154,   155,   156,
     157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
     167,   168,   169,   170,   171,   172,   173,    -1,   175,   176,
     177,   178,   179,   180,   181,    -1,    -1,   184,   185,    -1,
      -1,   188,   189,    -1,    -1,   192,   193,   194,   195,   196,
     197,   198,   199,   200,    -1,   202,   203,   204,    -1,   206,
     207,   208,   209,   210,   211,   212,    -1,   214,   215,   216,
     217,   218,   219,   220,   221,   222,   223,   224,   225,   226,
     227,   228,   229,    -1,   231,   232,   233,   234,   235,   236,
     237,   238,    -1,   240,   241,    -1,   243,   244,   245,   246,
     247,   248,   249,   250,   251,   252,    -1,   254,   255,   256,
      -1,   258,   259,    -1,   261,    -1,   263,   264,   265,   266,
     267,   268,   269,   270,   271,    -1,   273,   274,   275,   276,
     277,   278,   279,    -1,   281,   282,   283,   284,   285,   286,
     287,   288,   289,   290,    -1,    -1,   293,   294,   295,   296,
     297,   298,    -1,   300,   301,   302,    -1,   304,   305,   306,
     307,   308,    -1,    -1,    -1,    -1,    -1,   314,   315,    -1,
      -1,   318,   319,    -1,    -1,    -1,   323,     3,     4,     5,
       6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    -1,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      46,    -1,    -1,    49,    50,    51,    -1,    53,    54,    55,
      56,    -1,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    -1,    -1,    75,
      76,    77,    78,    79,    -1,    -1,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    95,
      96,    97,    98,    99,   100,   101,    -1,   103,    -1,   105,
     106,    -1,   108,   109,   110,   111,    -1,    -1,   114,    -1,
     116,   117,   118,   119,   120,   121,   122,   123,   124,    -1,
     126,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,   138,   139,   140,   141,   142,   143,   144,    -1,
     146,   147,   148,    -1,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
     166,   167,   168,   169,   170,   171,   172,   173,    -1,   175,
     176,   177,   178,   179,   180,   181,    -1,    -1,   184,   185,
      -1,    -1,   188,   189,    -1,    -1,   192,   193,   194,   195,
     196,   197,   198,   199,   200,    -1,   202,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,   234,   235,
     236,   237,   238,   239,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,    -1,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,   264,   265,
     266,   267,   268,   269,   270,   271,    -1,    -1,   274,   275,
     276,   277,   278,   279,    -1,   281,   282,   283,   284,   285,
     286,   287,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,   301,   302,    -1,   304,   305,
      -1,   307,   308,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    -1,   323,    18,    19,
      20,    21,    22,    23,    24,    -1,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    46,    -1,    -1,    49,
      50,    51,    -1,    53,    54,    55,    56,    -1,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    -1,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    -1,    -1,    93,    94,    95,    96,    97,    98,    99,
     100,   101,    -1,   103,    -1,   105,   106,    -1,   108,   109,
     110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,
     120,    -1,   122,   123,   124,    -1,   126,   127,   128,   129,
     130,   131,   132,   133,    -1,   135,    -1,   137,   138,   139,
     140,   141,   142,   143,   144,    -1,   146,   147,    -1,    -1,
     150,   151,   152,   153,   154,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,   166,   167,   168,   169,
     170,   171,   172,   173,    -1,   175,   176,   177,   178,   179,
     180,   181,    -1,    -1,   184,   185,    -1,    -1,   188,   189,
      -1,    -1,   192,   193,   194,   195,   196,   197,   198,   199,
     200,    -1,   202,   203,   204,    -1,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,   234,   235,   236,   237,   238,    -1,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,   264,   265,   266,   267,   268,   269,
     270,   271,    -1,    -1,   274,   275,   276,   277,   278,   279,
      -1,   281,   282,   283,   284,   285,   286,   287,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,   301,   302,    -1,   304,   305,   306,   307,   308,    -1,
      -1,    -1,    -1,    -1,   314,   315,    -1,    -1,   318,   319,
      -1,    -1,    -1,   323,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    -1,    -1,    -1,    15,    -1,    -1,    18,
      19,    20,    21,    22,    23,    24,    -1,    26,    27,    28,
      29,    -1,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    -1,    42,    43,    44,    45,    46,    -1,    -1,
      49,    50,    51,    -1,    53,    54,    55,    56,    -1,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    -1,    -1,    75,    76,    77,    78,
      79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,
      89,    -1,    -1,    -1,    93,    94,    95,    96,    97,    98,
      99,   100,   101,    -1,   103,    -1,   105,   106,    -1,   108,
     109,   110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,
     119,   120,    -1,   122,   123,   124,    -1,   126,   127,   128,
     129,   130,   131,   132,   133,    -1,   135,    -1,   137,    -1,
      -1,   140,   141,   142,   143,   144,    -1,   146,   147,    -1,
      -1,   150,   151,   152,   153,   154,   155,   156,   157,   158,
     159,   160,   161,   162,   163,   164,   165,   166,   167,   168,
     169,   170,   171,   172,   173,    -1,   175,   176,    -1,   178,
     179,   180,   181,    -1,    -1,   184,   185,    -1,    -1,    -1,
     189,    -1,    -1,   192,   193,   194,   195,   196,   197,   198,
     199,   200,    -1,   202,   203,   204,    -1,   206,   207,   208,
     209,   210,   211,   212,    -1,   214,   215,   216,   217,   218,
     219,   220,   221,   222,   223,   224,   225,   226,   227,   228,
     229,    -1,   231,   232,   233,   234,   235,   236,   237,   238,
      -1,   240,   241,   242,   243,   244,   245,   246,   247,   248,
     249,   250,   251,   252,    -1,   254,   255,   256,    -1,   258,
     259,    -1,   261,    -1,   263,   264,   265,   266,   267,   268,
     269,   270,   271,    -1,   273,   274,   275,   276,   277,   278,
     279,    -1,   281,   282,   283,   284,   285,   286,   287,   288,
     289,   290,    -1,    -1,   293,   294,   295,   296,   297,   298,
      -1,   300,   301,   302,    -1,   304,   305,    -1,   307,   308,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    -1,
     319,    -1,    15,    -1,   323,    18,    19,    20,    21,    22,
      23,    24,    -1,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      43,    44,    45,    46,    -1,    -1,    49,    50,    51,    -1,
      53,    54,    55,    56,    -1,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,
      83,    84,    85,    86,    -1,    88,    89,    -1,    -1,    -1,
      93,    94,    95,    96,    97,    98,    99,   100,   101,    -1,
     103,    -1,   105,   106,    -1,   108,   109,   110,   111,    -1,
      -1,   114,    -1,   116,    -1,   118,   119,   120,    -1,   122,
     123,   124,    -1,   126,   127,   128,   129,   130,   131,   132,
     133,    -1,   135,    -1,   137,    -1,    -1,   140,   141,   142,
     143,   144,    -1,   146,   147,    -1,    -1,   150,   151,   152,
     153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
     163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
     173,    -1,   175,   176,    -1,   178,   179,   180,   181,    -1,
      -1,   184,   185,    -1,    -1,    -1,   189,    -1,    -1,   192,
     193,   194,   195,   196,   197,   198,   199,   200,    -1,   202,
     203,   204,    -1,   206,   207,   208,   209,   210,   211,   212,
      -1,   214,   215,   216,   217,   218,   219,   220,   221,   222,
     223,   224,   225,   226,   227,   228,   229,    -1,   231,   232,
     233,   234,   235,   236,   237,   238,    -1,   240,   241,   242,
     243,   244,   245,   246,   247,   248,   249,   250,   251,   252,
      -1,   254,   255,   256,    -1,   258,   259,    -1,   261,    -1,
     263,   264,   265,   266,   267,   268,   269,   270,   271,    -1,
     273,   274,   275,   276,   277,   278,   279,    -1,   281,   282,
     283,   284,   285,   286,   287,   288,   289,   290,    -1,    -1,
     293,   294,   295,   296,   297,   298,    -1,   300,   301,   302,
      -1,   304,   305,    -1,   307,   308,     3,     4,     5,     6,
       7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,    -1,
     323,    18,    19,    20,    21,    22,    23,    24,    -1,    26,
      27,    28,    29,    -1,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    -1,    42,    43,    44,    45,    46,
      -1,    -1,    49,    50,    51,    -1,    53,    54,    55,    56,
      -1,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    -1,    -1,    75,    76,
      77,    78,    79,    -1,    -1,    -1,    83,    84,    85,    86,
      -1,    88,    89,    -1,    -1,    -1,    93,    94,    95,    96,
      97,    98,    99,   100,   101,    -1,   103,    -1,   105,   106,
      -1,   108,   109,   110,   111,    -1,    -1,   114,    -1,   116,
      -1,   118,   119,   120,    -1,   122,   123,   124,    -1,   126,
     127,   128,   129,   130,   131,   132,   133,    -1,   135,    -1,
     137,    -1,    -1,   140,   141,   142,   143,   144,    -1,   146,
     147,    -1,    -1,   150,   151,   152,   153,   154,   155,   156,
     157,   158,   159,   160,   161,   162,   163,   164,   165,   166,
     167,   168,   169,   170,   171,   172,   173,    -1,   175,   176,
      -1,    -1,   179,   180,   181,    -1,    -1,   184,   185,    -1,
      -1,    -1,   189,    -1,    -1,   192,   193,   194,   195,   196,
     197,   198,   199,   200,    -1,   202,   203,   204,    -1,   206,
     207,   208,   209,   210,   211,   212,    -1,   214,   215,   216,
     217,   218,   219,   220,   221,   222,   223,   224,   225,   226,
     227,   228,   229,    -1,   231,   232,   233,   234,   235,   236,
     237,   238,    -1,   240,   241,    -1,   243,   244,   245,   246,
     247,   248,   249,   250,   251,   252,    -1,   254,   255,   256,
      -1,   258,   259,    -1,   261,    -1,   263,   264,   265,   266,
     267,   268,   269,   270,   271,    -1,    -1,   274,   275,   276,
     277,   278,   279,    -1,   281,   282,   283,   284,   285,   286,
     287,   288,   289,   290,    -1,    -1,   293,   294,   295,   296,
     297,   298,    -1,   300,   301,   302,    -1,   304,   305,    -1,
     307,   308,     3,     4,     5,     6,     7,     8,     9,    -1,
      11,    -1,   319,    -1,    -1,    -1,   323,    18,    19,    20,
      21,    22,    23,    24,    -1,    26,    27,    28,    29,    -1,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      -1,    42,    43,    44,    45,    46,    -1,    -1,    49,    50,
      51,    -1,    53,    54,    55,    56,    -1,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    -1,    -1,    75,    76,    77,    78,    79,    -1,
      -1,    -1,    83,    84,    85,    86,    -1,    88,    89,    -1,
      -1,    -1,    93,    94,    95,    96,    97,    98,    99,   100,
     101,    -1,   103,    -1,   105,   106,    -1,   108,   109,   110,
     111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,
      -1,   122,   123,   124,    -1,   126,   127,   128,   129,   130,
     131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,
     141,   142,   143,   144,    -1,   146,   147,    -1,    -1,   150,
     151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
     161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
     171,   172,   173,    -1,   175,   176,    -1,    -1,   179,   180,
     181,    -1,    -1,   184,   185,    -1,    -1,    -1,   189,    -1,
      -1,   192,   193,   194,   195,   196,   197,   198,   199,   200,
      -1,   202,   203,   204,    -1,   206,   207,   208,   209,   210,
     211,   212,    -1,   214,   215,   216,   217,   218,   219,   220,
     221,   222,   223,   224,   225,   226,   227,   228,   229,    -1,
     231,   232,   233,   234,   235,   236,   237,   238,    -1,   240,
     241,    -1,   243,   244,   245,   246,   247,   248,   249,   250,
     251,   252,    -1,   254,   255,   256,    -1,   258,   259,    -1,
     261,    -1,   263,   264,   265,   266,   267,   268,   269,   270,
     271,    -1,    -1,   274,   275,   276,   277,   278,   279,    -1,
     281,   282,   283,   284,   285,   286,   287,   288,   289,   290,
      -1,    -1,   293,   294,   295,   296,   297,   298,    -1,   300,
     301,   302,    -1,   304,   305,    -1,   307,   308,     3,     4,
       5,     6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,
      -1,    -1,   323,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    -1,    31,    32,    33,    34,
      -1,    -1,    37,    38,    39,    40,    -1,    42,    43,    44,
      45,    46,    -1,    -1,    49,    50,    51,    -1,    53,    54,
      55,    56,    -1,    58,    59,    60,    -1,    -1,    -1,    -1,
      65,    66,    67,    68,    69,    70,    71,    72,    -1,    -1,
      75,    76,    77,    78,    79,    -1,    -1,    -1,    83,    84,
      85,    86,    -1,    88,    89,    -1,    91,    -1,    93,    94,
      95,    96,    97,    98,    -1,   100,   101,    -1,   103,    -1,
     105,   106,    -1,   108,   109,   110,   111,    -1,    -1,   114,
      -1,   116,   117,   118,   119,   120,   121,   122,   123,   124,
      -1,   126,   127,   128,   129,   130,   131,   132,   133,    -1,
     135,    -1,   137,   138,   139,   140,   141,   142,   143,   144,
      -1,   146,   147,   148,    -1,   150,   151,   152,    -1,    -1,
     155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
     165,   166,   167,   168,   169,   170,   171,   172,   173,    -1,
     175,   176,   177,    -1,   179,   180,   181,    -1,    -1,   184,
     185,    -1,   187,   188,   189,    -1,    -1,   192,   193,   194,
     195,   196,   197,   198,   199,   200,    -1,   202,   203,   204,
      -1,   206,   207,   208,   209,   210,   211,   212,    -1,   214,
     215,   216,   217,   218,   219,   220,   221,   222,   223,   224,
     225,   226,   227,   228,   229,   230,   231,   232,   233,    -1,
     235,   236,   237,   238,   239,   240,   241,    -1,   243,   244,
     245,   246,   247,   248,   249,   250,   251,   252,    -1,   254,
     255,   256,    -1,   258,   259,    -1,   261,    -1,   263,   264,
     265,   266,    -1,   268,   269,   270,   271,    -1,    -1,   274,
     275,   276,   277,   278,    -1,    -1,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,    -1,    -1,   293,   294,
     295,   296,   297,   298,    -1,   300,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     3,     4,     5,     6,     7,     8,
       9,    -1,    11,    -1,    -1,    -1,    -1,    -1,   323,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    -1,    31,    32,    33,    34,    -1,    -1,    37,    38,
      39,    40,    -1,    42,    43,    44,    45,    46,    -1,    -1,
      49,    50,    51,    -1,    53,    54,    55,    56,    -1,    58,
      59,    60,    -1,    -1,    -1,    -1,    65,    66,    67,    68,
      69,    70,    71,    72,    -1,    -1,    75,    76,    77,    78,
      79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,
      89,    -1,    91,    -1,    93,    94,    95,    96,    97,    98,
      -1,   100,   101,    -1,   103,    -1,   105,   106,    -1,   108,
     109,   110,   111,    -1,    -1,   114,    -1,   116,   117,   118,
     119,   120,   121,   122,   123,   124,    -1,   126,   127,   128,
     129,   130,   131,   132,   133,    -1,   135,    -1,   137,   138,
     139,   140,   141,   142,   143,   144,    -1,   146,   147,   148,
      -1,   150,   151,   152,    -1,    -1,   155,   156,   157,   158,
     159,   160,   161,   162,   163,   164,   165,   166,   167,   168,
     169,   170,   171,   172,   173,    -1,   175,   176,   177,    -1,
     179,   180,   181,    -1,    -1,   184,   185,    -1,   187,   188,
     189,    -1,    -1,   192,   193,   194,   195,   196,   197,   198,
     199,   200,    -1,   202,   203,   204,    -1,   206,   207,   208,
     209,   210,   211,   212,    -1,   214,   215,   216,   217,   218,
     219,   220,   221,   222,   223,   224,   225,   226,   227,   228,
     229,    -1,   231,   232,   233,    -1,   235,   236,   237,   238,
     239,   240,   241,    -1,   243,   244,   245,   246,   247,   248,
     249,   250,   251,   252,    -1,   254,   255,   256,    -1,   258,
     259,    -1,   261,    -1,   263,   264,   265,   266,    -1,   268,
     269,   270,   271,    -1,    -1,   274,   275,   276,   277,   278,
      -1,    -1,   281,   282,   283,   284,   285,   286,   287,   288,
     289,   290,    -1,    -1,   293,   294,   295,   296,   297,   298,
      -1,   300,     3,     4,     5,     6,     7,     8,     9,    -1,
      11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,
      -1,    22,    23,    24,   323,    26,    -1,    28,    29,    -1,
      31,    32,    33,    34,    -1,    -1,    37,    38,    39,    40,
      -1,    42,    43,    44,    45,    46,    -1,    -1,    49,    50,
      51,    -1,    53,    54,    55,    56,    -1,    58,    59,    -1,
      -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,    70,
      71,    72,    -1,    -1,    75,    76,    77,    78,    79,    -1,
      -1,    -1,    83,    84,    85,    86,    -1,    88,    89,    -1,
      91,    -1,    93,    94,    95,    96,    97,    98,    -1,   100,
     101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,
     111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,
      -1,   122,   123,   124,    -1,    -1,   127,   128,   129,   130,
     131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,
      -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,
     151,   152,    -1,    -1,   155,   156,   157,   158,   159,   160,
     161,   162,   163,   164,   165,    -1,   167,   168,   169,   170,
     171,   172,   173,    -1,   175,   176,    -1,    -1,   179,   180,
     181,    -1,    -1,   184,   185,    -1,    -1,   188,   189,    -1,
      -1,   192,    -1,    -1,   195,   196,   197,   198,   199,   200,
      -1,   202,   203,   204,    -1,   206,   207,   208,   209,   210,
     211,   212,    -1,   214,   215,   216,   217,   218,   219,   220,
     221,    -1,   223,   224,   225,   226,   227,   228,   229,    -1,
     231,   232,   233,    -1,   235,   236,   237,   238,    -1,   240,
     241,    -1,   243,   244,   245,   246,   247,   248,   249,   250,
     251,   252,    -1,   254,   255,   256,    -1,   258,   259,    -1,
     261,    -1,   263,   264,   265,   266,    -1,   268,   269,   270,
     271,    -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,
     281,   282,   283,   284,   285,   286,    -1,   288,   289,   290,
      -1,    -1,   293,   294,   295,   296,   297,   298,    -1,   300,
       3,     4,     5,     6,     7,     8,     9,    -1,    11,    -1,
      -1,    -1,    -1,    -1,    -1,    18,    19,    20,    -1,    22,
      23,    24,   323,    26,    -1,    28,    29,    -1,    31,    32,
      33,    34,    -1,    -1,    37,    38,    39,    40,    -1,    42,
      43,    44,    45,    46,    -1,    -1,    49,    50,    51,    -1,
      53,    54,    55,    56,    -1,    58,    59,    -1,    -1,    -1,
      -1,    -1,    65,    66,    67,    68,    69,    70,    71,    72,
      -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,
      83,    84,    85,    86,    -1,    88,    89,    -1,    91,    -1,
      93,    94,    95,    96,    97,    98,    -1,   100,   101,    -1,
     103,    -1,   105,    -1,    -1,    -1,   109,   110,   111,    -1,
      -1,   114,    -1,   116,    -1,   118,   119,   120,    -1,   122,
     123,   124,    -1,    -1,   127,   128,   129,   130,   131,   132,
     133,    -1,   135,    -1,   137,    -1,    -1,   140,    -1,   142,
     143,   144,    -1,    -1,   147,    -1,    -1,   150,   151,   152,
      -1,    -1,   155,   156,   157,   158,   159,   160,   161,   162,
     163,   164,   165,    -1,   167,    -1,   169,   170,   171,   172,
     173,    -1,   175,   176,    -1,    -1,   179,   180,   181,    -1,
      -1,   184,    -1,    -1,    -1,   188,   189,    -1,    -1,   192,
      -1,    -1,   195,   196,   197,   198,   199,   200,    -1,   202,
     203,   204,    -1,   206,   207,   208,   209,   210,   211,   212,
      -1,   214,   215,   216,   217,   218,   219,   220,   221,    -1,
     223,   224,   225,   226,   227,   228,   229,   230,   231,   232,
     233,    -1,   235,   236,   237,   238,    -1,   240,   241,    -1,
     243,   244,   245,   246,   247,   248,   249,   250,   251,   252,
      -1,   254,   255,   256,    -1,   258,   259,    -1,   261,    -1,
     263,   264,   265,   266,    -1,   268,   269,   270,   271,    -1,
      -1,   274,   275,   276,   277,   278,    -1,    -1,   281,   282,
     283,   284,   285,   286,    -1,   288,   289,   290,    -1,    -1,
     293,   294,   295,   296,   297,   298,    -1,   300,     3,     4,
       5,     6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,
      -1,    -1,    -1,    18,    19,    20,    -1,    22,    23,    24,
     323,    26,    -1,    28,    29,    -1,    31,    32,    33,    34,
      -1,    -1,    37,    38,    39,    40,    -1,    42,    43,    44,
      45,    46,    -1,    -1,    49,    50,    51,    -1,    53,    54,
      55,    56,    -1,    58,    59,    -1,    -1,    -1,    -1,    -1,
      65,    66,    67,    68,    69,    70,    71,    72,    -1,    -1,
      75,    76,    77,    78,    79,    -1,    -1,    -1,    83,    84,
      85,    86,    -1,    88,    89,    -1,    91,    -1,    93,    94,
      95,    96,    97,    98,    -1,   100,   101,    -1,   103,    -1,
     105,    -1,    -1,    -1,   109,   110,   111,    -1,    -1,   114,
      -1,   116,    -1,   118,   119,   120,    -1,   122,   123,   124,
      -1,    -1,   127,   128,   129,   130,   131,   132,   133,    -1,
     135,    -1,   137,    -1,    -1,   140,    -1,   142,   143,   144,
      -1,    -1,   147,    -1,    -1,   150,   151,   152,    -1,    -1,
     155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
     165,    -1,   167,    -1,   169,   170,   171,   172,   173,    -1,
     175,   176,    -1,    -1,   179,   180,   181,    -1,    -1,   184,
      -1,    -1,    -1,   188,   189,    -1,    -1,   192,    -1,    -1,
     195,   196,   197,   198,   199,   200,    -1,   202,   203,   204,
      -1,   206,   207,   208,   209,   210,   211,   212,    -1,   214,
     215,   216,   217,   218,   219,   220,   221,    -1,   223,   224,
     225,   226,   227,   228,   229,    -1,   231,   232,   233,    -1,
     235,   236,   237,   238,    -1,   240,   241,    -1,   243,   244,
     245,   246,   247,   248,   249,   250,   251,   252,    -1,   254,
     255,   256,    -1,   258,   259,    -1,   261,    -1,   263,   264,
     265,   266,    -1,   268,   269,   270,   271,    -1,    -1,   274,
     275,   276,   277,   278,    -1,    -1,   281,   282,   283,   284,
     285,   286,    -1,   288,   289,   290,    -1,    -1,   293,   294,
     295,   296,   297,   298,    -1,   300,     3,     4,     5,     6,
       7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,    -1,
      -1,    18,    19,    20,    -1,    22,    23,    24,   323,    26,
      -1,    28,    29,    -1,    31,    32,    33,    34,    -1,    -1,
      37,    38,    39,    40,    -1,    42,    43,    44,    45,    46,
      -1,    -1,    49,    50,    51,    -1,    53,    54,    55,    56,
      -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,    66,
      67,    68,    69,    70,    71,    72,    -1,    -1,    75,    76,
      77,    78,    79,    -1,    -1,    -1,    83,    84,    85,    86,
      -1,    88,    89,    -1,    91,    -1,    93,    94,    95,    96,
      97,    98,    -1,   100,   101,    -1,   103,    -1,   105,    -1,
      -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,   116,
      -1,   118,   119,   120,    -1,   122,   123,   124,    -1,    -1,
     127,   128,   129,   130,   131,   132,   133,    -1,   135,    -1,
     137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,    -1,
     147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,   156,
     157,   158,   159,   160,   161,   162,   163,   164,   165,    -1,
     167,    -1,   169,   170,   171,   172,   173,    -1,   175,   176,
      -1,    -1,   179,   180,   181,    -1,    -1,   184,    -1,    -1,
      -1,   188,   189,    -1,    -1,   192,    -1,    -1,   195,   196,
     197,   198,   199,   200,    -1,   202,   203,   204,    -1,   206,
     207,   208,   209,   210,   211,   212,    -1,   214,   215,   216,
     217,   218,   219,   220,   221,    -1,   223,   224,   225,   226,
     227,   228,   229,    -1,   231,   232,   233,    -1,   235,   236,
     237,   238,    -1,   240,   241,    -1,   243,   244,   245,   246,
     247,   248,   249,   250,   251,   252,    -1,   254,   255,   256,
      -1,   258,   259,    -1,   261,    -1,   263,   264,   265,   266,
      -1,   268,   269,   270,   271,    -1,    -1,   274,   275,   276,
     277,   278,    -1,    -1,   281,   282,   283,   284,   285,   286,
      -1,   288,   289,   290,    -1,    -1,   293,   294,   295,   296,
     297,   298,    -1,   300,    -1,    -1,    -1,    -1,    -1,   306,
      -1,    -1,    -1,   310,   311,   312,    -1,   314,   315,   316,
     317,   318,   319,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,
      20,    -1,    22,    23,    24,    -1,    26,    -1,    28,    29,
      -1,    31,    32,    33,    34,    -1,    -1,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    46,    -1,    -1,    49,
      50,    51,    -1,    53,    54,    55,    56,    -1,    58,    59,
      -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,
      70,    71,    72,    -1,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    91,    -1,    93,    94,    95,    96,    97,    98,    -1,
     100,   101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,
     110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,
     120,    -1,   122,   123,   124,    -1,    -1,   127,   128,   129,
     130,   131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,
     140,    -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,
     150,   151,   152,    -1,    -1,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,    -1,   167,    -1,   169,
     170,   171,   172,   173,    -1,   175,   176,    -1,    -1,   179,
     180,   181,    -1,    -1,   184,    -1,    -1,    -1,   188,   189,
      -1,    -1,   192,    -1,    -1,   195,   196,   197,   198,   199,
     200,    -1,   202,   203,   204,    -1,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,    -1,   223,   224,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,    -1,   235,   236,   237,   238,    -1,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,   264,   265,   266,    -1,   268,   269,
     270,   271,    -1,    -1,   274,   275,   276,   277,   278,    -1,
      -1,   281,   282,   283,   284,   285,   286,    -1,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,    -1,    -1,    -1,    -1,    -1,   306,    -1,    -1,    -1,
     310,   311,   312,    -1,   314,   315,   316,   317,   318,   319,
       3,     4,     5,     6,     7,     8,     9,    -1,    11,    -1,
      -1,    -1,    -1,    -1,    -1,    18,    19,    20,    -1,    22,
      23,    24,    -1,    26,    -1,    28,    29,    -1,    31,    32,
      33,    34,    -1,    -1,    37,    38,    39,    40,    -1,    42,
      43,    44,    45,    46,    -1,    -1,    49,    50,    51,    -1,
      53,    54,    55,    56,    -1,    58,    59,    -1,    -1,    -1,
      -1,    -1,    65,    66,    67,    68,    69,    70,    71,    72,
      -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,
      83,    84,    85,    86,    -1,    88,    89,    -1,    91,    -1,
      93,    94,    95,    96,    97,    98,    -1,   100,   101,    -1,
     103,    -1,   105,    -1,    -1,    -1,   109,   110,   111,    -1,
      -1,   114,    -1,   116,    -1,   118,   119,   120,    -1,   122,
     123,   124,    -1,    -1,   127,   128,   129,   130,   131,   132,
     133,    -1,   135,    -1,   137,    -1,    -1,   140,    -1,   142,
     143,   144,    -1,    -1,   147,    -1,    -1,   150,   151,   152,
      -1,    -1,   155,   156,   157,   158,   159,   160,   161,   162,
     163,   164,   165,    -1,   167,    -1,   169,   170,   171,   172,
     173,    -1,   175,   176,    -1,    -1,   179,   180,   181,    -1,
      -1,   184,    -1,    -1,    -1,   188,   189,    -1,    -1,   192,
      -1,    -1,   195,   196,   197,   198,   199,   200,    -1,   202,
     203,   204,    -1,   206,   207,   208,   209,   210,   211,   212,
      -1,   214,   215,   216,   217,   218,   219,   220,   221,    -1,
     223,   224,   225,   226,   227,   228,   229,    -1,   231,   232,
     233,    -1,   235,   236,   237,   238,    -1,   240,   241,    -1,
     243,   244,   245,   246,   247,   248,   249,   250,   251,   252,
      -1,   254,   255,   256,    -1,   258,   259,    -1,   261,    -1,
     263,   264,   265,   266,    -1,   268,   269,   270,   271,    -1,
      -1,   274,   275,   276,   277,   278,    -1,    -1,   281,   282,
     283,   284,   285,   286,    -1,   288,   289,   290,    -1,    -1,
     293,   294,   295,   296,   297,   298,    -1,   300,    -1,    -1,
      -1,    -1,    -1,   306,    -1,    -1,    -1,   310,   311,   312,
      -1,   314,   315,   316,   317,   318,   319,     3,     4,     5,
       6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    20,    -1,    22,    23,    24,    -1,
      26,    -1,    28,    29,    -1,    31,    32,    33,    34,    -1,
      -1,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      -1,    -1,    -1,    49,    50,    51,    -1,    53,    54,    -1,
      56,    -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    72,    -1,    -1,    75,
      76,    77,    78,    79,    -1,    -1,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    -1,
      96,    97,    -1,    -1,   100,   101,    -1,   103,    -1,   105,
      -1,    -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,
     116,    -1,   118,   119,   120,    -1,   122,   123,   124,    -1,
      -1,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,
      -1,   147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
      -1,   167,    -1,   169,   170,   171,   172,    -1,    -1,   175,
     176,    -1,    -1,    -1,   180,   181,    -1,    -1,   184,    -1,
      -1,    -1,   188,   189,    -1,    -1,   192,    -1,    -1,    -1,
     196,   197,   198,   199,   200,    -1,    -1,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,    -1,   223,    -1,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,    -1,   235,
     236,   237,   238,    -1,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,    -1,   252,    -1,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,    -1,   265,
      -1,    -1,   268,   269,   270,   271,    -1,    -1,   274,   275,
     276,   277,   278,    -1,    -1,   281,   282,   283,   284,   285,
     286,    -1,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,   301,   302,    -1,    -1,    -1,
     306,   307,    -1,    -1,   310,   311,   312,    -1,   314,   315,
     316,   317,   318,   319,     3,     4,     5,     6,     7,     8,
       9,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    18,
      19,    20,    -1,    22,    23,    24,    -1,    26,    -1,    28,
      29,    -1,    31,    32,    33,    34,    -1,    -1,    37,    38,
      39,    40,    -1,    42,    43,    44,    45,    46,    -1,    -1,
      49,    50,    51,    -1,    53,    54,    55,    56,    -1,    58,
      59,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,
      69,    70,    71,    72,    -1,    -1,    75,    76,    77,    78,
      79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,
      89,    -1,    91,    -1,    93,    94,    95,    96,    97,    98,
      -1,   100,   101,    -1,   103,    -1,   105,    -1,    -1,    -1,
     109,   110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,
     119,   120,    -1,   122,   123,   124,    -1,    -1,   127,   128,
     129,   130,   131,   132,   133,    -1,   135,    -1,   137,    -1,
      -1,   140,    -1,   142,   143,   144,    -1,    -1,   147,    -1,
      -1,   150,   151,   152,    -1,    -1,   155,   156,   157,   158,
     159,   160,   161,   162,   163,   164,   165,    -1,   167,   168,
     169,   170,   171,   172,   173,    -1,   175,   176,    -1,    -1,
     179,   180,   181,    -1,    -1,   184,   185,    -1,    -1,   188,
     189,    -1,    -1,   192,    -1,    -1,   195,   196,   197,   198,
     199,   200,    -1,   202,   203,   204,    -1,   206,   207,   208,
     209,   210,   211,   212,    -1,   214,   215,   216,   217,   218,
     219,   220,   221,    -1,   223,   224,   225,   226,   227,   228,
     229,    -1,   231,   232,   233,    -1,   235,   236,   237,   238,
      -1,   240,   241,    -1,   243,   244,   245,   246,   247,   248,
     249,   250,   251,   252,    -1,   254,   255,   256,    -1,   258,
     259,    -1,   261,    -1,   263,   264,   265,   266,    -1,   268,
     269,   270,   271,    -1,    -1,   274,   275,   276,   277,   278,
      -1,    -1,   281,   282,   283,   284,   285,   286,    -1,   288,
     289,   290,    -1,    -1,   293,   294,   295,   296,   297,   298,
      -1,   300,    -1,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    -1,   316,    18,    19,
      20,    -1,    22,    23,    24,    -1,    26,    -1,    28,    29,
      -1,    31,    32,    33,    34,    -1,    -1,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    46,    -1,    -1,    49,
      50,    51,    -1,    53,    54,    55,    56,    -1,    58,    59,
      -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,
      70,    71,    72,    -1,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    91,    -1,    93,    94,    95,    96,    97,    98,    -1,
     100,   101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,
     110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,
     120,    -1,   122,   123,   124,    -1,    -1,   127,   128,   129,
     130,   131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,
     140,    -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,
     150,   151,   152,    -1,    -1,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,    -1,   167,    -1,   169,
     170,   171,   172,   173,    -1,   175,   176,    -1,    -1,   179,
     180,   181,    -1,    -1,   184,    -1,    -1,    -1,   188,   189,
      -1,    -1,   192,    -1,    -1,   195,   196,   197,   198,   199,
     200,    -1,   202,   203,   204,    -1,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,    -1,   223,   224,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,    -1,   235,   236,   237,   238,    -1,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,   264,   265,   266,    -1,   268,   269,
     270,   271,    -1,    -1,   274,   275,   276,   277,   278,    -1,
      -1,   281,   282,   283,   284,   285,   286,    -1,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,    -1,     3,     4,     5,     6,     7,     8,     9,    -1,
      11,    -1,    -1,    -1,    -1,    -1,   316,    18,    19,    20,
      -1,    22,    23,    24,    -1,    26,    -1,    28,    29,    -1,
      31,    32,    33,    34,    -1,    -1,    37,    38,    39,    40,
      -1,    42,    43,    44,    45,    -1,    -1,    -1,    49,    50,
      51,    -1,    53,    54,    -1,    56,    -1,    58,    59,    -1,
      -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,    70,
      71,    72,    -1,    -1,    75,    76,    77,    78,    79,    -1,
      -1,    -1,    83,    84,    85,    86,    -1,    88,    89,    -1,
      91,    -1,    93,    94,    -1,    96,    97,    -1,    -1,   100,
     101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,
     111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,
      -1,   122,   123,   124,    -1,    -1,   127,   128,   129,   130,
     131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,
      -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,
     151,   152,    -1,    -1,   155,   156,   157,   158,   159,   160,
     161,   162,   163,   164,   165,    -1,   167,    -1,   169,   170,
     171,   172,    -1,    -1,   175,   176,    -1,    -1,    -1,   180,
     181,    -1,    -1,   184,    -1,    -1,    -1,   188,   189,    -1,
      -1,   192,    -1,    -1,    -1,   196,   197,   198,   199,   200,
      -1,    -1,   203,   204,    -1,   206,   207,   208,   209,   210,
     211,   212,    -1,   214,   215,   216,   217,   218,   219,   220,
     221,    -1,   223,    -1,   225,   226,   227,   228,   229,    -1,
     231,   232,   233,    -1,   235,   236,   237,   238,    -1,   240,
     241,    -1,   243,   244,   245,   246,   247,   248,   249,   250,
      -1,   252,    -1,   254,   255,   256,    -1,   258,   259,    -1,
     261,    -1,   263,    -1,   265,    -1,    -1,   268,   269,   270,
     271,    -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,
     281,   282,   283,   284,   285,   286,    -1,   288,   289,   290,
      -1,    -1,   293,   294,   295,   296,   297,   298,    -1,   300,
      -1,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      -1,    -1,    -1,    -1,    -1,   316,    18,    19,    20,    -1,
      22,    23,    24,    -1,    26,    -1,    28,    29,    -1,    31,
      32,    33,    34,    -1,    -1,    37,    38,    39,    40,    -1,
      42,    43,    44,    45,    46,    -1,    -1,    49,    50,    51,
      -1,    53,    54,    55,    56,    -1,    58,    59,    -1,    -1,
      -1,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    -1,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    83,    84,    85,    86,    -1,    88,    89,    -1,    91,
      -1,    93,    94,    95,    96,    97,    98,    99,   100,   101,
      -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,   111,
      -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,    -1,
     122,   123,   124,    -1,    -1,   127,   128,   129,   130,   131,
     132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,    -1,
     142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,   151,
     152,    -1,    -1,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,    -1,   167,    -1,   169,   170,   171,
     172,   173,    -1,   175,   176,    -1,    -1,   179,   180,   181,
     182,    -1,   184,    -1,   186,    -1,   188,   189,    -1,    -1,
     192,    -1,    -1,   195,   196,   197,   198,   199,   200,    -1,
     202,   203,   204,    -1,   206,   207,   208,   209,   210,   211,
     212,    -1,   214,   215,   216,   217,   218,   219,   220,   221,
      -1,   223,   224,   225,   226,   227,   228,   229,    -1,   231,
     232,   233,    -1,   235,   236,   237,   238,    -1,   240,   241,
      -1,   243,   244,   245,   246,   247,   248,   249,   250,   251,
     252,    -1,   254,   255,   256,    -1,   258,   259,    -1,   261,
      -1,   263,   264,   265,   266,   267,   268,   269,   270,   271,
      -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,   281,
     282,   283,   284,   285,   286,    -1,   288,   289,   290,    -1,
      -1,   293,   294,   295,   296,   297,   298,    -1,   300,   301,
     302,    -1,    -1,    -1,    -1,   307,     3,     4,     5,     6,
       7,     8,     9,   315,    11,    -1,    -1,    -1,    -1,    -1,
      -1,    18,    19,    20,    -1,    22,    23,    24,    -1,    26,
      -1,    28,    29,    -1,    31,    32,    33,    34,    -1,    -1,
      37,    38,    39,    40,    -1,    42,    43,    44,    45,    46,
      -1,    -1,    49,    50,    51,    -1,    53,    54,    55,    56,
      -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,    66,
      67,    68,    69,    70,    71,    72,    -1,    -1,    75,    76,
      77,    78,    79,    -1,    -1,    -1,    83,    84,    85,    86,
      -1,    88,    89,    -1,    91,    -1,    93,    94,    95,    96,
      97,    98,    99,   100,   101,    -1,   103,    -1,   105,    -1,
      -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,   116,
      -1,   118,   119,   120,    -1,   122,   123,   124,    -1,    -1,
     127,   128,   129,   130,   131,   132,   133,    -1,   135,    -1,
     137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,    -1,
     147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,   156,
     157,   158,   159,   160,   161,   162,   163,   164,   165,    -1,
     167,    -1,   169,   170,   171,   172,   173,    -1,   175,   176,
      -1,    -1,   179,   180,   181,   182,    -1,   184,    -1,   186,
      -1,   188,   189,    -1,    -1,   192,    -1,    -1,   195,   196,
     197,   198,   199,   200,    -1,   202,   203,   204,    -1,   206,
     207,   208,   209,   210,   211,   212,    -1,   214,   215,   216,
     217,   218,   219,   220,   221,    -1,   223,   224,   225,   226,
     227,   228,   229,    -1,   231,   232,   233,    -1,   235,   236,
     237,   238,    -1,   240,   241,    -1,   243,   244,   245,   246,
     247,   248,   249,   250,   251,   252,    -1,   254,   255,   256,
      -1,   258,   259,    -1,   261,    -1,   263,   264,   265,   266,
     267,   268,   269,   270,   271,    -1,    -1,   274,   275,   276,
     277,   278,    -1,    -1,   281,   282,   283,   284,   285,   286,
      -1,   288,   289,   290,    -1,    -1,   293,   294,   295,   296,
     297,   298,    -1,   300,   301,   302,    -1,    -1,    -1,    -1,
     307,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   315,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    -1,    -1,
      -1,    -1,    -1,    -1,    18,    19,    20,    -1,    22,    23,
      24,    -1,    26,    -1,    28,    29,    -1,    31,    32,    33,
      34,    -1,    -1,    37,    38,    39,    40,    -1,    42,    43,
      44,    45,    46,    -1,    -1,    49,    50,    51,    -1,    53,
      54,    55,    56,    -1,    58,    59,    -1,    -1,    -1,    -1,
      -1,    65,    66,    67,    68,    69,    70,    71,    72,    -1,
      -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,    83,
      84,    85,    86,    -1,    88,    89,    -1,    91,    -1,    93,
      94,    95,    96,    97,    98,    -1,   100,   101,    -1,   103,
      -1,   105,    -1,   107,    -1,   109,   110,   111,    -1,    -1,
     114,    -1,   116,    -1,   118,   119,   120,   121,   122,   123,
     124,    -1,    -1,   127,   128,   129,   130,   131,   132,   133,
      -1,   135,    -1,   137,    -1,    -1,   140,    -1,   142,   143,
     144,    -1,    -1,   147,    -1,    -1,   150,   151,   152,    -1,
      -1,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,    -1,   167,    -1,   169,   170,   171,   172,   173,
      -1,   175,   176,    -1,    -1,   179,   180,   181,    -1,    -1,
     184,    -1,    -1,    -1,   188,   189,    -1,    -1,   192,    -1,
      -1,   195,   196,   197,   198,   199,   200,    -1,   202,   203,
     204,    -1,   206,   207,   208,   209,   210,   211,   212,    -1,
     214,   215,   216,   217,   218,   219,   220,   221,    -1,   223,
     224,   225,   226,   227,   228,   229,    -1,   231,   232,   233,
      -1,   235,   236,   237,   238,    -1,   240,   241,    -1,   243,
     244,   245,   246,   247,   248,   249,   250,   251,   252,    -1,
     254,   255,   256,    -1,   258,   259,    -1,   261,    -1,   263,
     264,   265,   266,    -1,   268,   269,   270,   271,    -1,    -1,
     274,   275,   276,   277,   278,    -1,    -1,   281,   282,   283,
     284,   285,   286,    -1,   288,   289,   290,    -1,    -1,   293,
     294,   295,   296,   297,   298,    14,   300,    16,    -1,    -1,
      -1,    20,    -1,   307,    -1,    -1,    25,    -1,    -1,    -1,
      -1,   315,    -1,    -1,    -1,    14,    -1,    -1,    -1,    -1,
      -1,    20,    -1,    -1,    -1,    -1,    25,    -1,    47,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    14,    -1,
      -1,    -1,    -1,    -1,    20,    -1,    -1,    -1,    47,    25,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    14,    -1,
      -1,    -1,    -1,    -1,    20,    -1,    -1,    -1,    -1,    25,
      -1,    47,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    14,    -1,    -1,    -1,    -1,    -1,    20,
      -1,    47,    -1,    -1,    25,    -1,    -1,    -1,   117,    -1,
      -1,    -1,   121,    -1,    -1,    20,    -1,    -1,   107,    -1,
      25,    -1,    -1,    -1,    -1,    -1,    47,    -1,   117,   138,
     139,    -1,   121,    -1,    -1,    -1,    -1,    -1,    -1,   148,
      -1,    -1,    47,    -1,    -1,    -1,    -1,    -1,    -1,   138,
     139,   117,    -1,    -1,    -1,   121,    -1,    -1,    -1,   148,
      -1,    -1,    -1,    -1,    -1,   174,    -1,    -1,   177,    -1,
      -1,   117,   138,   139,    -1,   121,    -1,    -1,    -1,   188,
      -1,   190,   148,    -1,    -1,   174,    91,    -1,   177,    -1,
      -1,    -1,   138,   139,    -1,    -1,   117,    -1,    -1,   188,
     121,   190,   148,    -1,    -1,    -1,    -1,    -1,   174,    -1,
      -1,   177,   117,    -1,    -1,    -1,   121,   138,   139,    -1,
      -1,    -1,   188,    -1,   190,    -1,    -1,   148,   174,    -1,
     239,   177,    -1,   138,   139,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   188,   148,   190,    -1,    -1,    -1,    -1,    -1,
     239,    -1,    -1,   174,    -1,    -1,   177,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   188,    -1,   190,
      -1,    -1,   177,   239,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    14,    -1,   188,    -1,    -1,    -1,    20,    -1,    -1,
      -1,    -1,    25,   239,    -1,    -1,    -1,   306,    -1,    -1,
      -1,   310,   311,   312,    -1,   314,   315,   316,   317,   318,
     319,   257,    -1,    -1,    47,    -1,   325,   306,   239,    -1,
      -1,   310,   311,   312,    -1,   314,   315,   316,   317,   318,
     319,    -1,    -1,    -1,   239,    -1,   325,    -1,    -1,    -1,
     306,    -1,    -1,    -1,   310,   311,   312,    -1,   314,   315,
     316,   317,   318,   319,    -1,    -1,    -1,    -1,   324,   325,
     306,    -1,    -1,    -1,   310,   311,   312,    -1,   314,   315,
     316,   317,   318,   319,    -1,    14,    -1,    -1,    -1,   325,
      -1,    20,    -1,    -1,   117,   306,    25,    -1,   121,   310,
     311,   312,    -1,   314,   315,   316,   317,   318,   319,    -1,
      -1,   306,    -1,   324,   325,   138,   139,    -1,    47,   314,
     315,   316,   317,   318,   319,   148,    -1,    -1,    -1,    -1,
     325,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    14,    -1,    -1,    -1,    -1,    -1,
      20,   174,    -1,    -1,   177,    25,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   188,    -1,   190,    -1,    -1,
      -1,    -1,    -1,    -1,    14,    -1,    -1,    47,    -1,    -1,
      20,    -1,    -1,    -1,    -1,    25,    -1,    -1,   117,    -1,
      -1,    -1,   121,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    14,    -1,    -1,    -1,    -1,    47,    20,   138,
     139,    -1,    -1,    25,    -1,    -1,   239,    -1,    -1,   148,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    47,    -1,    -1,    20,    -1,
      -1,    -1,    -1,    25,    -1,   174,    -1,   117,   177,    -1,
      -1,   121,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   188,
      -1,   190,    -1,    -1,    -1,    47,    -1,    -1,   138,   139,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   117,   148,    -1,
      -1,   121,    -1,   306,    -1,    -1,    -1,   310,   311,   312,
      -1,   314,   315,   316,   317,   318,   319,    -1,   138,   139,
      -1,   324,   325,    -1,   174,   117,    -1,   177,   148,   121,
     239,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   188,    -1,
     190,    -1,    -1,    -1,    -1,    -1,   138,   139,    -1,    -1,
      -1,    -1,    -1,    20,   174,   117,   148,   177,    25,   121,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   188,    -1,
     190,    -1,    -1,    -1,    -1,    -1,   138,   139,    -1,    -1,
      47,    -1,   174,    -1,    -1,   177,   148,    -1,    -1,   239,
      -1,    -1,    -1,    -1,    -1,    -1,   188,   306,    -1,    -1,
      -1,   310,   311,   312,    -1,   314,   315,   316,   317,   318,
     319,    -1,    20,   322,    -1,   177,   325,    25,    -1,   239,
      -1,    -1,    -1,    -1,    91,    -1,   188,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    47,
      -1,    -1,    -1,    -1,    -1,    -1,    20,   239,    -1,    -1,
     117,    25,    -1,    -1,   121,    -1,   306,    -1,    -1,    -1,
     310,   311,   312,    -1,   314,   315,   316,   317,   318,   319,
      -1,   138,   139,    47,   324,   325,    -1,   239,    -1,    -1,
      -1,   148,    -1,    91,    -1,    -1,   306,    -1,    -1,    -1,
     310,   311,   312,    -1,   314,   315,   316,   317,   318,   319,
      -1,    -1,    -1,    -1,    -1,   325,    -1,    -1,    -1,   117,
     177,    -1,    -1,   121,   306,    -1,    -1,    91,   310,   311,
     312,   188,   314,   315,   316,   317,   318,   319,    -1,    -1,
     138,   139,    -1,   325,    -1,    -1,    -1,    -1,    -1,    -1,
     148,    -1,    -1,   117,   306,    -1,    -1,   121,    -1,   311,
     312,    -1,   314,   315,   316,   317,   318,   319,    -1,    -1,
      -1,    -1,    -1,   325,   138,   139,    -1,    -1,    -1,   177,
      -1,    -1,   239,    -1,   148,    -1,    -1,    -1,    -1,    -1,
     188,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   177,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   188,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   239,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   306,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   314,   315,   316,
     317,   318,   319,    -1,    -1,    -1,    -1,    -1,   325,    -1,
      -1,    -1,    -1,    -1,    -1,   239,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   306,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   314,   315,   316,   317,
     318,   319,    -1,    -1,    -1,    -1,    -1,   325,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   306,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     314,   315,   316,   317,   318,   319,    -1,    -1,    -1,    -1,
      -1,   325,     3,     4,     5,     6,     7,     8,     9,    -1,
      11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,
      -1,    22,    23,    24,    -1,    26,    -1,    28,    29,    -1,
      31,    32,    33,    34,    -1,    -1,    37,    38,    39,    40,
      -1,    42,    43,    44,    45,    46,    -1,    -1,    49,    50,
      51,    -1,    53,    54,    55,    56,    -1,    58,    59,    -1,
      -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,    70,
      71,    72,    -1,    -1,    75,    76,    77,    78,    79,    -1,
      -1,    -1,    83,    84,    85,    86,    -1,    88,    89,    -1,
      91,    -1,    93,    94,    95,    96,    97,    98,    -1,   100,
     101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,
     111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,
      -1,   122,   123,   124,    -1,    -1,   127,   128,   129,   130,
     131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,
      -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,
     151,   152,    -1,    -1,   155,   156,   157,   158,   159,   160,
     161,   162,   163,   164,   165,    -1,   167,    -1,   169,   170,
     171,   172,   173,    -1,   175,   176,    -1,    -1,   179,   180,
     181,    -1,    -1,   184,    -1,    -1,    -1,   188,   189,    -1,
      -1,   192,    -1,    -1,   195,   196,   197,   198,   199,   200,
      -1,   202,   203,   204,    -1,   206,   207,   208,   209,   210,
     211,   212,    -1,   214,   215,   216,   217,   218,   219,   220,
     221,    -1,   223,   224,   225,   226,   227,   228,   229,    -1,
     231,   232,   233,    -1,   235,   236,   237,   238,    -1,   240,
     241,    -1,   243,   244,   245,   246,   247,   248,   249,   250,
     251,   252,    -1,   254,   255,   256,    -1,   258,   259,    -1,
     261,    -1,   263,   264,   265,   266,    -1,   268,   269,   270,
     271,    -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,
     281,   282,   283,   284,   285,   286,    -1,   288,   289,   290,
      -1,    -1,   293,   294,   295,   296,   297,   298,    -1,   300,
     301,   302,    -1,   304,   305,    -1,   307,     3,     4,     5,
       6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    20,    -1,    22,    23,    24,    -1,
      26,    -1,    28,    29,    -1,    31,    32,    33,    34,    -1,
      -1,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      46,    -1,    -1,    49,    50,    51,    -1,    53,    54,    55,
      56,    -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    -1,    75,
      76,    77,    78,    79,    -1,    -1,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    95,
      96,    97,    98,    -1,   100,   101,    -1,   103,    -1,   105,
      -1,    -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,
     116,    -1,   118,   119,   120,    -1,   122,   123,   124,    -1,
      -1,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,
      -1,   147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
      -1,   167,    -1,   169,   170,   171,   172,   173,    -1,   175,
     176,    -1,    -1,   179,   180,   181,    -1,    -1,   184,    -1,
      -1,    -1,   188,   189,    -1,    -1,   192,    -1,    -1,   195,
     196,   197,   198,   199,   200,    -1,   202,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,    -1,   223,   224,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,    -1,   235,
     236,   237,   238,    -1,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,    -1,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,   264,   265,
     266,    -1,   268,   269,   270,   271,    -1,    -1,   274,   275,
     276,   277,   278,    -1,    -1,   281,   282,   283,   284,   285,
     286,    -1,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,    -1,   302,     3,     4,     5,
       6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    20,    -1,    22,    23,    24,    -1,
      26,    -1,    28,    29,    -1,    31,    32,    33,    34,    -1,
      -1,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      46,    -1,    -1,    49,    50,    51,    -1,    53,    54,    55,
      56,    -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    72,    -1,    -1,    75,
      76,    77,    78,    79,    -1,    -1,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    95,
      96,    97,    98,    -1,   100,   101,    -1,   103,    -1,   105,
      -1,    -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,
     116,    -1,   118,   119,   120,    -1,   122,   123,   124,    -1,
      -1,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,
      -1,   147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
      -1,   167,    -1,   169,   170,   171,   172,   173,    -1,   175,
     176,    -1,    -1,   179,   180,   181,    -1,    -1,   184,    -1,
      -1,    -1,   188,   189,    -1,    -1,   192,    -1,    -1,   195,
     196,   197,   198,   199,   200,    -1,   202,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,    -1,   223,   224,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,    -1,   235,
     236,   237,   238,    -1,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,    -1,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,   264,   265,
     266,    -1,   268,   269,   270,   271,    -1,    -1,   274,   275,
     276,   277,   278,    -1,    -1,   281,   282,   283,   284,   285,
     286,    -1,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,    -1,   302,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
      96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,   130,   131,   132,   133,   134,   135,
     136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
     166,   167,   168,   169,   170,   171,   172,   173,   174,   175,
     176,   177,   178,   179,   180,   181,   182,   183,   184,   185,
     186,   187,   188,   189,   190,   191,   192,   193,   194,   195,
     196,   197,   198,   199,   200,   201,   202,   203,   204,   205,
     206,   207,   208,   209,   210,   211,   212,   213,   214,   215,
     216,   217,   218,   219,   220,   221,   222,   223,   224,   225,
     226,   227,   228,   229,   230,   231,   232,   233,   234,   235,
     236,   237,   238,   239,   240,   241,   242,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,   253,   254,   255,
     256,   257,   258,   259,   260,   261,   262,   263,   264,   265,
     266,   267,   268,   269,   270,   271,   272,   273,   274,   275,
     276,   277,   278,   279,   280,   281,   282,   283,   284,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,    -1,   300,     3,     4,     5,     6,     7,
       8,     9,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    -1,    31,    32,    33,    34,    -1,    -1,    37,
      38,    39,    40,    -1,    42,    43,    44,    45,    46,    -1,
      -1,    49,    50,    51,    -1,    53,    54,    55,    56,    -1,
      58,    59,    60,    -1,    -1,    -1,    -1,    65,    66,    67,
      68,    69,    70,    71,    72,    -1,    -1,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,
      88,    89,    -1,    91,    -1,    93,    94,    95,    96,    97,
      98,    -1,   100,   101,    -1,   103,    -1,   105,   106,    -1,
     108,   109,   110,   111,    -1,    -1,   114,    -1,   116,   117,
     118,   119,   120,   121,   122,   123,   124,    -1,   126,   127,
     128,   129,   130,   131,   132,   133,    -1,   135,    -1,   137,
     138,   139,   140,   141,   142,   143,   144,    -1,   146,   147,
     148,    -1,   150,   151,   152,    -1,    -1,   155,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   165,   166,   167,
     168,   169,   170,   171,   172,   173,    -1,   175,   176,   177,
      -1,   179,   180,   181,    -1,    -1,   184,   185,    -1,    -1,
     188,   189,    -1,    -1,   192,   193,   194,   195,   196,   197,
     198,   199,   200,    -1,   202,   203,   204,    -1,   206,   207,
     208,   209,   210,   211,   212,    -1,   214,   215,   216,   217,
     218,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,    -1,   231,   232,   233,    -1,   235,   236,   237,
     238,   239,   240,   241,    -1,   243,   244,   245,   246,   247,
     248,   249,   250,   251,   252,    -1,   254,   255,   256,    -1,
     258,   259,    -1,   261,    -1,   263,   264,   265,   266,    -1,
     268,   269,   270,   271,    -1,    -1,   274,   275,   276,   277,
     278,    -1,    -1,   281,   282,   283,   284,   285,   286,   287,
     288,   289,   290,    -1,    -1,   293,   294,   295,   296,   297,
     298,    -1,   300,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,
      20,    -1,    22,    23,    24,    -1,    26,    -1,    28,    29,
      -1,    31,    32,    33,    34,    -1,    -1,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    -1,    -1,    49,
      50,    51,    52,    53,    54,    55,    56,    -1,    58,    59,
      -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,
      70,    71,    72,    -1,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    91,    -1,    93,    94,    95,    96,    97,    98,    -1,
     100,   101,    -1,   103,   104,   105,    -1,    -1,    -1,   109,
     110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,
     120,    -1,   122,   123,   124,    -1,    -1,   127,   128,   129,
     130,   131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,
     140,    -1,   142,   143,   144,    -1,    -1,   147,   148,    -1,
     150,   151,   152,    -1,    -1,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,    -1,   167,    -1,   169,
     170,   171,   172,   173,    -1,   175,   176,    -1,    -1,   179,
     180,   181,    -1,    -1,   184,    -1,    -1,    -1,   188,   189,
      -1,    -1,   192,    -1,    -1,   195,   196,   197,   198,   199,
     200,    -1,   202,   203,   204,   205,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,    -1,   223,   224,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,    -1,   235,   236,   237,   238,    -1,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,   264,   265,   266,    -1,   268,   269,
     270,   271,    -1,   273,   274,   275,   276,   277,   278,    -1,
      -1,   281,   282,   283,   284,   285,   286,    -1,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      12,    13,    -1,    -1,    -1,    -1,    18,    19,    20,    -1,
      22,    23,    24,    -1,    26,    -1,    28,    29,    -1,    31,
      32,    33,    34,    -1,    -1,    37,    38,    39,    40,    -1,
      42,    43,    44,    45,    46,    -1,    -1,    49,    50,    51,
      -1,    53,    54,    55,    56,    -1,    58,    59,    -1,    -1,
      -1,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
      72,    -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    83,    84,    85,    86,    -1,    88,    89,    -1,    91,
      -1,    93,    94,    95,    96,    97,    98,    -1,   100,   101,
      -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,   111,
      -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,    -1,
     122,   123,   124,    -1,    -1,   127,   128,   129,   130,   131,
     132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,    -1,
     142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,   151,
     152,    -1,    -1,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,    -1,   167,   168,   169,   170,   171,
     172,   173,    -1,   175,   176,    -1,    -1,   179,   180,   181,
      -1,    -1,   184,   185,    -1,    -1,   188,   189,    -1,    -1,
     192,    -1,    -1,   195,   196,   197,   198,   199,   200,    -1,
     202,   203,   204,    -1,   206,   207,   208,   209,   210,   211,
     212,    -1,   214,   215,   216,   217,   218,   219,   220,   221,
      -1,   223,   224,   225,   226,   227,   228,   229,    -1,   231,
     232,   233,    -1,   235,   236,   237,   238,    -1,   240,   241,
      -1,   243,   244,   245,   246,   247,   248,   249,   250,   251,
     252,    -1,   254,   255,   256,    -1,   258,   259,    -1,   261,
      -1,   263,   264,   265,   266,    -1,   268,   269,   270,   271,
      -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,   281,
     282,   283,   284,   285,   286,    -1,   288,   289,   290,    -1,
      -1,   293,   294,   295,   296,   297,   298,    -1,   300,     3,
       4,     5,     6,     7,     8,     9,    -1,    11,    -1,    -1,
      -1,    -1,    -1,    -1,    18,    19,    20,    -1,    22,    23,
      24,    -1,    26,    -1,    28,    29,    -1,    31,    32,    33,
      34,    -1,    -1,    37,    38,    39,    40,    -1,    42,    43,
      44,    45,    46,    -1,    -1,    49,    50,    51,    -1,    53,
      54,    55,    56,    -1,    58,    59,    -1,    -1,    -1,    -1,
      -1,    65,    66,    67,    68,    69,    70,    71,    72,    -1,
      -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,    83,
      84,    85,    86,    -1,    88,    89,    -1,    91,    -1,    93,
      94,    95,    96,    97,    98,    -1,   100,   101,    -1,   103,
      -1,   105,    -1,    -1,    -1,   109,   110,   111,    -1,    -1,
     114,    -1,   116,    -1,   118,   119,   120,    -1,   122,   123,
     124,    -1,    -1,   127,   128,   129,   130,   131,   132,   133,
      -1,   135,    -1,   137,    -1,    -1,   140,    -1,   142,   143,
     144,    -1,    -1,   147,    -1,    -1,   150,   151,   152,    -1,
      -1,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,    -1,   167,   168,   169,   170,   171,   172,   173,
      -1,   175,   176,    -1,    -1,   179,   180,   181,    -1,    -1,
     184,   185,    -1,   187,   188,   189,    -1,    -1,   192,    -1,
      -1,   195,   196,   197,   198,   199,   200,    -1,   202,   203,
     204,    -1,   206,   207,   208,   209,   210,   211,   212,    -1,
     214,   215,   216,   217,   218,   219,   220,   221,    -1,   223,
     224,   225,   226,   227,   228,   229,    -1,   231,   232,   233,
      -1,   235,   236,   237,   238,    -1,   240,   241,    -1,   243,
     244,   245,   246,   247,   248,   249,   250,   251,   252,    -1,
     254,   255,   256,    -1,   258,   259,    -1,   261,    -1,   263,
     264,   265,   266,    -1,   268,   269,   270,   271,    -1,    -1,
     274,   275,   276,   277,   278,    -1,    -1,   281,   282,   283,
     284,   285,   286,    -1,   288,   289,   290,    -1,    -1,   293,
     294,   295,   296,   297,   298,    -1,   300,     3,     4,     5,
       6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    20,    -1,    22,    23,    24,    -1,
      26,    -1,    28,    29,    -1,    31,    32,    33,    34,    -1,
      -1,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      46,    -1,    -1,    49,    50,    51,    -1,    53,    54,    55,
      56,    -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    72,    -1,    -1,    75,
      76,    77,    78,    79,    -1,    -1,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    95,
      96,    97,    98,    -1,   100,   101,    -1,   103,    -1,   105,
      -1,    -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,
     116,    -1,   118,   119,   120,    -1,   122,   123,   124,    -1,
      -1,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,
      -1,   147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
      -1,   167,   168,   169,   170,   171,   172,   173,    -1,   175,
     176,    -1,    -1,   179,   180,   181,    -1,    -1,   184,   185,
      -1,    -1,   188,   189,    -1,    -1,   192,    -1,    -1,   195,
     196,   197,   198,   199,   200,    -1,   202,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,    -1,   223,   224,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,    -1,   235,
     236,   237,   238,    -1,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,   253,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,   264,   265,
     266,    -1,   268,   269,   270,   271,    -1,    -1,   274,   275,
     276,   277,   278,    -1,    -1,   281,   282,   283,   284,   285,
     286,    -1,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,     3,     4,     5,     6,     7,
       8,     9,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    20,    -1,    22,    23,    24,    -1,    26,    -1,
      28,    29,    -1,    31,    32,    33,    34,    -1,    -1,    37,
      38,    39,    40,    -1,    42,    43,    44,    45,    46,    -1,
      -1,    49,    50,    51,    -1,    53,    54,    55,    56,    -1,
      58,    59,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,
      68,    69,    70,    71,    72,    -1,    -1,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,
      88,    89,    -1,    91,    -1,    93,    94,    95,    96,    97,
      98,    -1,   100,   101,    -1,   103,    -1,   105,    -1,    -1,
      -1,   109,   110,   111,    -1,    -1,   114,    -1,   116,    -1,
     118,   119,   120,    -1,   122,   123,   124,    -1,    -1,   127,
     128,   129,   130,   131,   132,   133,    -1,   135,    -1,   137,
      -1,    -1,   140,    -1,   142,   143,   144,    -1,    -1,   147,
      -1,    -1,   150,   151,   152,    -1,    -1,   155,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   165,    -1,   167,
     168,   169,   170,   171,   172,   173,    -1,   175,   176,    -1,
      -1,   179,   180,   181,    -1,    -1,   184,   185,    -1,    -1,
     188,   189,    -1,    -1,   192,    -1,    -1,   195,   196,   197,
     198,   199,   200,    -1,   202,   203,   204,    -1,   206,   207,
     208,   209,   210,   211,   212,    -1,   214,   215,   216,   217,
     218,   219,   220,   221,    -1,   223,   224,   225,   226,   227,
     228,   229,    -1,   231,   232,   233,    -1,   235,   236,   237,
     238,    -1,   240,   241,    -1,   243,   244,   245,   246,   247,
     248,   249,   250,   251,   252,   253,   254,   255,   256,    -1,
     258,   259,    -1,   261,    -1,   263,   264,   265,   266,    -1,
     268,   269,   270,   271,    -1,    -1,   274,   275,   276,   277,
     278,    -1,    -1,   281,   282,   283,   284,   285,   286,    -1,
     288,   289,   290,    -1,    -1,   293,   294,   295,   296,   297,
     298,    -1,   300,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,
      20,    -1,    22,    23,    24,    -1,    26,    -1,    28,    29,
      -1,    31,    32,    33,    34,    -1,    -1,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    46,    -1,    -1,    49,
      50,    51,    -1,    53,    54,    55,    56,    -1,    58,    59,
      -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,
      70,    71,    72,    -1,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    91,    -1,    93,    94,    95,    96,    97,    98,    -1,
     100,   101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,
     110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,
     120,    -1,   122,   123,   124,    -1,    -1,   127,   128,   129,
     130,   131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,
     140,    -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,
     150,   151,   152,    -1,    -1,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,    -1,   167,   168,   169,
     170,   171,   172,   173,    -1,   175,   176,    -1,    -1,   179,
     180,   181,    -1,    -1,   184,   185,    -1,    -1,   188,   189,
      -1,    -1,   192,    -1,    -1,   195,   196,   197,   198,   199,
     200,    -1,   202,   203,   204,    -1,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,    -1,   223,   224,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,    -1,   235,   236,   237,   238,    -1,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,   264,   265,   266,    -1,   268,   269,
     270,   271,    -1,    -1,   274,   275,   276,   277,   278,    -1,
     280,   281,   282,   283,   284,   285,   286,    -1,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,    -1,
      22,    23,    24,    -1,    26,    -1,    28,    29,    -1,    31,
      32,    33,    34,    -1,    -1,    37,    38,    39,    40,    -1,
      42,    43,    44,    45,    46,    -1,    -1,    49,    50,    51,
      -1,    53,    54,    55,    56,    -1,    58,    59,    -1,    -1,
      -1,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
      72,    -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    83,    84,    85,    86,    -1,    88,    89,    -1,    91,
      -1,    93,    94,    95,    96,    97,    98,    -1,   100,   101,
      -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,   111,
      -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,    -1,
     122,   123,   124,    -1,    -1,   127,   128,   129,   130,   131,
     132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,    -1,
     142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,   151,
     152,    -1,    -1,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,    -1,   167,   168,   169,   170,   171,
     172,   173,    -1,   175,   176,    -1,    -1,   179,   180,   181,
      -1,    -1,   184,   185,    -1,    -1,   188,   189,    -1,    -1,
     192,    -1,    -1,   195,   196,   197,   198,   199,   200,    -1,
     202,   203,   204,    -1,   206,   207,   208,   209,   210,   211,
     212,    -1,   214,   215,   216,   217,   218,   219,   220,   221,
      -1,   223,   224,   225,   226,   227,   228,   229,    -1,   231,
     232,   233,    -1,   235,   236,   237,   238,    -1,   240,   241,
      -1,   243,   244,   245,   246,   247,   248,   249,   250,   251,
     252,    -1,   254,   255,   256,    -1,   258,   259,    -1,   261,
      -1,   263,   264,   265,   266,    -1,   268,   269,   270,   271,
      -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,   281,
     282,   283,   284,   285,   286,    -1,   288,   289,   290,    -1,
      -1,   293,   294,   295,   296,   297,   298,    -1,   300,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    -1,    -1,
      -1,    -1,    -1,    -1,    18,    19,    20,    -1,    22,    23,
      24,    -1,    26,    -1,    28,    29,    -1,    31,    32,    33,
      34,    -1,    -1,    37,    38,    39,    40,    -1,    42,    43,
      44,    45,    46,    -1,    -1,    49,    50,    51,    -1,    53,
      54,    55,    56,    -1,    58,    59,    -1,    -1,    -1,    -1,
      -1,    65,    66,    67,    68,    69,    70,    71,    72,    -1,
      -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,    83,
      84,    85,    86,    -1,    88,    89,    -1,    91,    -1,    93,
      94,    95,    96,    97,    98,    -1,   100,   101,    -1,   103,
      -1,   105,    -1,    -1,    -1,   109,   110,   111,    -1,    -1,
     114,    -1,   116,    -1,   118,   119,   120,    -1,   122,   123,
     124,    -1,    -1,   127,   128,   129,   130,   131,   132,   133,
      -1,   135,    -1,   137,    -1,    -1,   140,    -1,   142,   143,
     144,    -1,    -1,   147,    -1,    -1,   150,   151,   152,    -1,
      -1,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,    -1,   167,    -1,   169,   170,   171,   172,   173,
      -1,   175,   176,    -1,    -1,   179,   180,   181,    -1,    -1,
     184,    -1,    -1,    -1,   188,   189,    -1,    -1,   192,    -1,
      -1,   195,   196,   197,   198,   199,   200,    -1,   202,   203,
     204,    -1,   206,   207,   208,   209,   210,   211,   212,    -1,
     214,   215,   216,   217,   218,   219,   220,   221,    -1,   223,
     224,   225,   226,   227,   228,   229,    -1,   231,   232,   233,
      -1,   235,   236,   237,   238,    -1,   240,   241,    -1,   243,
     244,   245,   246,   247,   248,   249,   250,   251,   252,    -1,
     254,   255,   256,    -1,   258,   259,    -1,   261,    -1,   263,
     264,   265,   266,    -1,   268,   269,   270,   271,    -1,    -1,
     274,   275,   276,   277,   278,    -1,    -1,   281,   282,   283,
     284,   285,   286,    -1,   288,   289,   290,    -1,    -1,   293,
     294,   295,   296,   297,   298,    -1,   300,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    20,    -1,    22,    23,    24,    -1,
      26,    -1,    28,    29,    -1,    31,    32,    33,    34,    -1,
      -1,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      46,    -1,    -1,    49,    50,    51,    -1,    53,    54,    55,
      56,    -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    72,    -1,    -1,    75,
      76,    77,    78,    79,    -1,    -1,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    95,
      96,    97,    98,    -1,   100,   101,    -1,   103,    -1,   105,
      -1,    -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,
     116,    -1,   118,   119,   120,    -1,   122,   123,   124,    -1,
      -1,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,
      -1,   147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
      -1,   167,    -1,   169,   170,   171,   172,   173,    -1,   175,
     176,    -1,    -1,   179,   180,   181,    -1,    -1,   184,    -1,
      -1,    -1,   188,   189,    -1,    -1,   192,    -1,    -1,   195,
     196,   197,   198,   199,   200,    -1,   202,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,    -1,   223,   224,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,    -1,   235,
     236,   237,   238,    -1,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,    -1,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,   264,   265,
     266,    -1,   268,   269,   270,   271,    -1,    -1,   274,   275,
     276,   277,   278,    -1,    -1,   281,   282,   283,   284,   285,
     286,    -1,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    20,    -1,    22,    23,    24,    -1,    26,    -1,
      28,    29,    -1,    31,    32,    33,    34,    -1,    -1,    37,
      38,    39,    40,    -1,    42,    43,    44,    45,    46,    -1,
      -1,    49,    50,    51,    -1,    53,    54,    55,    56,    -1,
      58,    59,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,
      68,    69,    70,    71,    72,    -1,    -1,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,
      88,    89,    -1,    91,    -1,    93,    94,    95,    96,    97,
      98,    -1,   100,   101,    -1,   103,    -1,   105,    -1,    -1,
      -1,   109,   110,   111,    -1,    -1,   114,    -1,   116,    -1,
     118,   119,   120,    -1,   122,   123,   124,    -1,    -1,   127,
     128,   129,   130,   131,   132,   133,    -1,   135,    -1,   137,
      -1,    -1,   140,    -1,   142,   143,   144,    -1,    -1,   147,
      -1,    -1,   150,   151,   152,    -1,    -1,   155,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   165,    -1,   167,
      -1,   169,   170,   171,   172,   173,    -1,   175,   176,    -1,
      -1,   179,   180,   181,    -1,    -1,   184,    -1,    -1,    -1,
     188,   189,    -1,    -1,   192,    -1,    -1,   195,   196,   197,
     198,   199,   200,    -1,   202,   203,   204,    -1,   206,   207,
     208,   209,   210,   211,   212,    -1,   214,   215,   216,   217,
     218,   219,   220,   221,    -1,   223,   224,   225,   226,   227,
     228,   229,    -1,   231,   232,   233,    -1,   235,   236,   237,
     238,    -1,   240,   241,    -1,   243,   244,   245,   246,   247,
     248,   249,   250,   251,   252,    -1,   254,   255,   256,    -1,
     258,   259,    -1,   261,    -1,   263,   264,   265,   266,    -1,
     268,   269,   270,   271,    -1,    -1,   274,   275,   276,   277,
     278,    -1,    -1,   281,   282,   283,   284,   285,   286,    -1,
     288,   289,   290,    -1,    -1,   293,   294,   295,   296,   297,
     298,    -1,   300,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,
      20,    21,    22,    23,    24,    -1,    26,    -1,    28,    29,
      -1,    31,    32,    33,    34,    -1,    -1,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    46,    -1,    -1,    49,
      50,    51,    -1,    53,    54,    55,    56,    -1,    58,    59,
      -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,
      70,    71,    72,    -1,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    91,    -1,    93,    94,    95,    96,    97,    98,    -1,
     100,   101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,
     110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,
     120,    -1,   122,   123,   124,    -1,    -1,   127,   128,   129,
     130,   131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,
     140,    -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,
     150,   151,   152,    -1,    -1,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,    -1,   167,    -1,   169,
     170,   171,   172,   173,    -1,   175,   176,    -1,    -1,   179,
     180,   181,    -1,    -1,   184,    -1,    -1,    -1,   188,   189,
      -1,    -1,   192,    -1,    -1,   195,   196,   197,   198,   199,
     200,    -1,   202,   203,   204,    -1,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,    -1,   223,   224,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,    -1,   235,   236,   237,   238,    -1,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,   264,   265,   266,    -1,   268,   269,
     270,   271,    -1,    -1,   274,   275,   276,   277,   278,    -1,
      -1,   281,   282,   283,   284,   285,   286,    -1,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,    -1,
      22,    23,    24,    -1,    26,    -1,    28,    29,    -1,    31,
      32,    33,    34,    -1,    -1,    37,    38,    39,    40,    -1,
      42,    43,    44,    45,    46,    -1,    -1,    49,    50,    51,
      -1,    53,    54,    55,    56,    -1,    58,    59,    -1,    -1,
      -1,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
      72,    -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    83,    84,    85,    86,    -1,    88,    89,    -1,    91,
      -1,    93,    94,    95,    96,    97,    98,    -1,   100,   101,
      -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,   111,
      -1,   113,   114,    -1,   116,    -1,   118,   119,   120,    -1,
     122,   123,   124,    -1,    -1,   127,   128,   129,   130,   131,
     132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,    -1,
     142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,   151,
     152,    -1,    -1,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,    -1,   167,    -1,   169,   170,   171,
     172,   173,    -1,   175,   176,    -1,    -1,   179,   180,   181,
      -1,    -1,   184,    -1,    -1,    -1,   188,   189,    -1,    -1,
     192,    -1,    -1,   195,   196,   197,   198,   199,   200,    -1,
     202,   203,   204,    -1,   206,   207,   208,   209,   210,   211,
     212,    -1,   214,   215,   216,   217,   218,   219,   220,   221,
      -1,   223,   224,   225,   226,   227,   228,   229,    -1,   231,
     232,   233,    -1,   235,   236,   237,   238,    -1,   240,   241,
      -1,   243,   244,   245,   246,   247,   248,   249,   250,   251,
     252,    -1,   254,   255,   256,    -1,   258,   259,    -1,   261,
      -1,   263,   264,   265,   266,    -1,   268,   269,   270,   271,
      -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,   281,
     282,   283,   284,   285,   286,    -1,   288,   289,   290,    -1,
      -1,   293,   294,   295,   296,   297,   298,    -1,   300,     3,
       4,     5,     6,     7,     8,     9,    -1,    11,    -1,    -1,
      -1,    -1,    16,    -1,    18,    19,    20,    -1,    22,    23,
      24,    -1,    26,    -1,    28,    29,    -1,    31,    32,    33,
      34,    -1,    -1,    37,    38,    39,    40,    -1,    42,    43,
      44,    45,    46,    -1,    -1,    49,    50,    51,    -1,    53,
      54,    55,    56,    -1,    58,    59,    -1,    -1,    -1,    -1,
      -1,    65,    66,    67,    68,    69,    70,    71,    72,    -1,
      -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,    83,
      84,    85,    86,    -1,    88,    89,    -1,    91,    -1,    93,
      94,    95,    96,    97,    98,    -1,   100,   101,    -1,   103,
      -1,   105,    -1,    -1,    -1,   109,   110,   111,    -1,    -1,
     114,    -1,   116,    -1,   118,   119,   120,    -1,   122,   123,
     124,    -1,    -1,   127,   128,   129,   130,   131,   132,   133,
      -1,   135,    -1,   137,    -1,    -1,   140,    -1,   142,   143,
     144,    -1,    -1,   147,    -1,    -1,   150,   151,   152,    -1,
      -1,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,    -1,   167,    -1,   169,   170,   171,   172,   173,
      -1,   175,   176,    -1,    -1,   179,   180,   181,    -1,    -1,
     184,    -1,    -1,    -1,   188,   189,    -1,    -1,   192,    -1,
      -1,   195,   196,   197,   198,   199,   200,    -1,   202,   203,
     204,    -1,   206,   207,   208,   209,   210,   211,   212,    -1,
     214,   215,   216,   217,   218,   219,   220,   221,    -1,   223,
     224,   225,   226,   227,   228,   229,    -1,   231,   232,   233,
      -1,   235,   236,   237,   238,    -1,   240,   241,    -1,   243,
     244,   245,   246,   247,   248,   249,   250,   251,   252,    -1,
     254,   255,   256,    -1,   258,   259,    -1,   261,    -1,   263,
     264,   265,   266,    -1,   268,   269,   270,   271,    -1,    -1,
     274,   275,   276,   277,   278,    -1,    -1,   281,   282,   283,
     284,   285,   286,    -1,   288,   289,   290,    -1,    -1,   293,
     294,   295,   296,   297,   298,    -1,   300,     3,     4,     5,
       6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,
      16,    -1,    18,    19,    20,    -1,    22,    23,    24,    -1,
      26,    -1,    28,    29,    -1,    31,    32,    33,    34,    -1,
      -1,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      46,    -1,    -1,    49,    50,    51,    -1,    53,    54,    55,
      56,    -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    72,    -1,    -1,    75,
      76,    77,    78,    79,    -1,    -1,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    95,
      96,    97,    98,    -1,   100,   101,    -1,   103,    -1,   105,
      -1,    -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,
     116,    -1,   118,   119,   120,    -1,   122,   123,   124,    -1,
      -1,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,
      -1,   147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
      -1,   167,    -1,   169,   170,   171,   172,   173,    -1,   175,
     176,    -1,    -1,   179,   180,   181,    -1,    -1,   184,    -1,
      -1,    -1,   188,   189,    -1,    -1,   192,    -1,    -1,   195,
     196,   197,   198,   199,   200,    -1,   202,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,    -1,   223,   224,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,    -1,   235,
     236,   237,   238,    -1,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,    -1,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,   264,   265,
     266,    -1,   268,   269,   270,   271,    -1,    -1,   274,   275,
     276,   277,   278,    -1,    -1,   281,   282,   283,   284,   285,
     286,    -1,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,     3,     4,     5,     6,     7,
       8,     9,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    20,    -1,    22,    23,    24,    -1,    26,    -1,
      28,    29,    -1,    31,    32,    33,    34,    -1,    -1,    37,
      38,    39,    40,    -1,    42,    43,    44,    45,    46,    -1,
      -1,    49,    50,    51,    -1,    53,    54,    55,    56,    -1,
      58,    59,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    -1,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,
      88,    89,    -1,    91,    -1,    93,    94,    95,    96,    97,
      98,    -1,   100,   101,    -1,   103,    -1,   105,    -1,    -1,
      -1,   109,   110,   111,    -1,    -1,   114,    -1,   116,    -1,
     118,   119,   120,    -1,   122,   123,   124,    -1,    -1,   127,
     128,   129,   130,   131,   132,   133,    -1,   135,    -1,   137,
      -1,    -1,   140,    -1,   142,   143,   144,    -1,    -1,   147,
      -1,    -1,   150,   151,   152,    -1,    -1,   155,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   165,    -1,   167,
      -1,   169,   170,   171,   172,   173,    -1,   175,   176,    -1,
      -1,   179,   180,   181,    -1,    -1,   184,    -1,    -1,    -1,
     188,   189,    -1,    -1,   192,    -1,    -1,   195,   196,   197,
     198,   199,   200,    -1,   202,   203,   204,    -1,   206,   207,
     208,   209,   210,   211,   212,    -1,   214,   215,   216,   217,
     218,   219,   220,   221,    -1,   223,   224,   225,   226,   227,
     228,   229,    -1,   231,   232,   233,    -1,   235,   236,   237,
     238,    -1,   240,   241,    -1,   243,   244,   245,   246,   247,
     248,   249,   250,   251,   252,    -1,   254,   255,   256,    -1,
     258,   259,    -1,   261,    -1,   263,   264,   265,   266,    -1,
     268,   269,   270,   271,    -1,    -1,   274,   275,   276,   277,
     278,    -1,    -1,   281,   282,   283,   284,   285,   286,    -1,
     288,   289,   290,    -1,    -1,   293,   294,   295,   296,   297,
     298,    -1,   300,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,
      20,    -1,    22,    23,    24,    -1,    26,    -1,    28,    29,
      -1,    31,    32,    33,    34,    -1,    -1,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    46,    -1,    -1,    49,
      50,    51,    -1,    53,    54,    55,    56,    -1,    58,    59,
      -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    91,    -1,    93,    94,    95,    96,    97,    98,    -1,
     100,   101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,
     110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,
     120,    -1,   122,   123,   124,    -1,    -1,   127,   128,   129,
     130,   131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,
     140,    -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,
     150,   151,   152,    -1,    -1,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,    -1,   167,    -1,   169,
     170,   171,   172,   173,    -1,   175,   176,    -1,    -1,   179,
     180,   181,    -1,    -1,   184,    -1,    -1,    -1,   188,   189,
      -1,    -1,   192,    -1,    -1,   195,   196,   197,   198,   199,
     200,    -1,   202,   203,   204,    -1,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,    -1,   223,   224,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,    -1,   235,   236,   237,   238,    -1,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,   251,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,   264,   265,   266,    -1,   268,   269,
     270,   271,    -1,    -1,   274,   275,   276,   277,   278,    -1,
      -1,   281,   282,   283,   284,   285,   286,    -1,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,    -1,
      22,    23,    24,    -1,    26,    -1,    28,    29,    -1,    31,
      32,    33,    34,    -1,    -1,    37,    38,    39,    40,    -1,
      42,    43,    44,    45,    46,    -1,    -1,    49,    50,    51,
      -1,    53,    54,    55,    56,    -1,    58,    59,    -1,    -1,
      -1,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
      72,    -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    83,    84,    85,    86,    -1,    88,    89,    -1,    91,
      -1,    93,    94,    95,    96,    97,    98,    -1,   100,   101,
      -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,   111,
      -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,    -1,
     122,   123,   124,    -1,    -1,   127,   128,   129,   130,   131,
     132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,    -1,
     142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,   151,
     152,    -1,    -1,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,    -1,   167,    -1,   169,   170,   171,
     172,   173,    -1,   175,   176,    -1,    -1,   179,   180,   181,
      -1,    -1,   184,    -1,    -1,    -1,   188,   189,    -1,    -1,
     192,    -1,    -1,   195,   196,   197,   198,   199,   200,    -1,
     202,   203,   204,    -1,   206,   207,   208,   209,   210,   211,
     212,    -1,   214,   215,   216,   217,   218,   219,   220,   221,
      -1,   223,   224,   225,   226,   227,   228,   229,    -1,   231,
     232,   233,    -1,   235,   236,   237,   238,    -1,   240,   241,
      -1,   243,   244,   245,   246,   247,   248,   249,   250,   251,
     252,    -1,   254,   255,   256,    -1,   258,   259,    -1,   261,
      -1,   263,   264,   265,   266,    -1,   268,   269,   270,   271,
      -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,   281,
     282,   283,   284,   285,   286,    -1,   288,   289,   290,    -1,
      -1,   293,   294,   295,   296,   297,   298,    -1,   300,     3,
       4,     5,     6,     7,     8,     9,    -1,    11,    -1,    -1,
      -1,    -1,    -1,    -1,    18,    19,    20,    -1,    22,    23,
      24,    -1,    26,    -1,    28,    29,    -1,    31,    32,    33,
      34,    -1,    -1,    37,    38,    39,    40,    -1,    42,    43,
      44,    45,    46,    -1,    -1,    49,    50,    51,    -1,    53,
      54,    55,    56,    -1,    58,    59,    -1,    -1,    -1,    -1,
      -1,    65,    66,    67,    68,    69,    70,    71,    72,    -1,
      -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,    83,
      84,    85,    86,    -1,    88,    89,    -1,    91,    -1,    93,
      94,    95,    96,    97,    98,    -1,   100,   101,    -1,   103,
      -1,   105,    -1,    -1,    -1,   109,   110,   111,    -1,    -1,
     114,    -1,   116,    -1,   118,   119,   120,    -1,   122,   123,
     124,    -1,    -1,   127,   128,   129,   130,   131,   132,   133,
      -1,   135,    -1,   137,    -1,    -1,   140,    -1,   142,   143,
     144,    -1,    -1,   147,    -1,    -1,   150,   151,   152,    -1,
      -1,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,    -1,   167,    -1,   169,   170,   171,   172,   173,
      -1,   175,   176,    -1,    -1,   179,   180,   181,    -1,    -1,
     184,    -1,    -1,    -1,   188,   189,    -1,    -1,   192,    -1,
      -1,   195,   196,   197,   198,   199,   200,    -1,   202,   203,
     204,    -1,   206,   207,   208,   209,   210,   211,   212,    -1,
     214,   215,   216,   217,   218,   219,   220,   221,    -1,   223,
     224,   225,   226,   227,   228,   229,    -1,   231,   232,   233,
      -1,   235,   236,   237,   238,    -1,   240,   241,    -1,   243,
     244,   245,   246,   247,   248,   249,   250,   251,   252,    -1,
     254,   255,   256,    -1,   258,   259,    -1,   261,    -1,   263,
     264,   265,   266,    -1,   268,   269,   270,   271,    -1,    -1,
     274,   275,   276,   277,   278,    -1,    -1,   281,   282,   283,
     284,   285,   286,    -1,   288,   289,   290,    -1,    -1,   293,
     294,   295,   296,   297,   298,    -1,   300,     3,     4,     5,
       6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    20,    -1,    22,    23,    24,    -1,
      26,    -1,    28,    29,    -1,    31,    32,    33,    34,    -1,
      -1,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      46,    -1,    -1,    49,    50,    51,    -1,    53,    54,    55,
      56,    -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    72,    -1,    -1,    75,
      76,    77,    78,    79,    -1,    -1,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    95,
      96,    97,    98,    -1,   100,   101,    -1,   103,    -1,   105,
      -1,    -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,
     116,    -1,   118,   119,   120,    -1,   122,   123,   124,    -1,
      -1,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,
      -1,   147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
      -1,   167,    -1,   169,   170,   171,   172,   173,    -1,   175,
     176,    -1,    -1,   179,   180,   181,    -1,    -1,   184,    -1,
      -1,    -1,   188,   189,    -1,    -1,   192,    -1,    -1,   195,
     196,   197,   198,   199,   200,    -1,   202,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,    -1,   223,   224,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,    -1,   235,
     236,   237,   238,    -1,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,   251,   252,    -1,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,   264,   265,
     266,    -1,   268,   269,   270,   271,    -1,    -1,   274,   275,
     276,   277,   278,    -1,    -1,   281,   282,   283,   284,   285,
     286,    -1,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,     3,     4,     5,     6,     7,
       8,     9,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    20,    -1,    22,    23,    24,    -1,    26,    -1,
      28,    29,    -1,    31,    32,    33,    34,    -1,    -1,    37,
      38,    39,    40,    -1,    42,    43,    44,    45,    46,    -1,
      -1,    49,    50,    51,    -1,    53,    54,    55,    56,    -1,
      58,    59,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,
      68,    69,    70,    71,    72,    -1,    -1,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,
      88,    89,    -1,    91,    -1,    93,    94,    95,    96,    97,
      98,    -1,   100,   101,    -1,   103,    -1,   105,    -1,    -1,
      -1,   109,   110,   111,    -1,    -1,   114,    -1,   116,    -1,
     118,   119,   120,    -1,   122,   123,   124,    -1,    -1,   127,
     128,   129,   130,   131,   132,   133,    -1,   135,    -1,   137,
      -1,    -1,   140,    -1,   142,   143,   144,    -1,    -1,   147,
      -1,    -1,   150,   151,   152,    -1,    -1,   155,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   165,    -1,   167,
      -1,   169,   170,   171,   172,   173,    -1,   175,   176,    -1,
      -1,   179,   180,   181,    -1,    -1,   184,    -1,    -1,    -1,
     188,   189,    -1,    -1,   192,    -1,    -1,   195,   196,   197,
     198,   199,   200,    -1,   202,   203,   204,    -1,   206,   207,
     208,   209,   210,   211,   212,    -1,   214,   215,   216,   217,
     218,   219,   220,   221,    -1,   223,   224,   225,   226,   227,
     228,   229,    -1,   231,   232,   233,    -1,   235,   236,   237,
     238,    -1,   240,   241,    -1,   243,   244,   245,   246,   247,
     248,   249,   250,   251,   252,    -1,   254,   255,   256,    -1,
     258,   259,    -1,   261,    -1,   263,   264,   265,   266,    -1,
     268,   269,   270,   271,    -1,    -1,   274,   275,   276,   277,
     278,    -1,    -1,   281,   282,   283,   284,   285,   286,    -1,
     288,   289,   290,    -1,    -1,   293,   294,   295,   296,   297,
     298,    -1,   300,     3,     4,     5,     6,     7,     8,     9,
      -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,
      20,    -1,    22,    23,    24,    -1,    26,    -1,    28,    29,
      -1,    31,    32,    33,    34,    -1,    -1,    37,    38,    39,
      40,    -1,    42,    43,    44,    45,    -1,    -1,    -1,    49,
      50,    51,    -1,    53,    54,    -1,    56,    -1,    58,    59,
      -1,    -1,    -1,    -1,    -1,    65,    66,    67,    68,    69,
      70,    71,    72,    -1,    -1,    75,    76,    77,    78,    79,
      -1,    -1,    -1,    83,    84,    85,    86,    -1,    88,    89,
      -1,    91,    -1,    93,    94,    -1,    96,    97,    -1,    -1,
     100,   101,    -1,   103,    -1,   105,    -1,    -1,    -1,   109,
     110,   111,    -1,    -1,   114,    -1,   116,    -1,   118,   119,
     120,    -1,   122,   123,   124,    -1,    -1,   127,   128,   129,
     130,   131,   132,   133,    -1,   135,    -1,   137,    -1,    -1,
     140,    -1,   142,   143,   144,    -1,    -1,   147,    -1,    -1,
     150,   151,   152,    -1,    -1,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,    -1,   167,    -1,   169,
     170,   171,   172,   173,    -1,   175,   176,    -1,    -1,    -1,
     180,   181,    -1,    -1,   184,    -1,    -1,    -1,   188,   189,
      -1,    -1,   192,    -1,    -1,    -1,   196,   197,   198,   199,
     200,    -1,    -1,   203,   204,    -1,   206,   207,   208,   209,
     210,   211,   212,    -1,   214,   215,   216,   217,   218,   219,
     220,   221,    -1,   223,    -1,   225,   226,   227,   228,   229,
      -1,   231,   232,   233,    -1,   235,   236,   237,   238,    -1,
     240,   241,    -1,   243,   244,   245,   246,   247,   248,   249,
     250,    -1,   252,    -1,   254,   255,   256,    -1,   258,   259,
      -1,   261,    -1,   263,    -1,   265,    -1,    -1,   268,   269,
     270,   271,    -1,    -1,   274,   275,   276,   277,   278,    -1,
      -1,   281,   282,   283,   284,   285,   286,    -1,   288,   289,
     290,    -1,    -1,   293,   294,   295,   296,   297,   298,    -1,
     300,     3,     4,     5,     6,     7,     8,     9,    -1,    11,
      -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,    -1,
      22,    23,    24,    -1,    26,    -1,    28,    29,    -1,    31,
      32,    33,    34,    -1,    -1,    37,    38,    39,    40,    -1,
      42,    43,    44,    45,    -1,    -1,    -1,    49,    50,    51,
      -1,    53,    54,    -1,    56,    -1,    58,    59,    -1,    -1,
      -1,    -1,    -1,    65,    66,    67,    68,    69,    70,    71,
      72,    -1,    -1,    75,    76,    77,    78,    79,    -1,    -1,
      -1,    83,    84,    85,    86,    -1,    88,    89,    -1,    91,
      -1,    93,    94,    -1,    96,    97,    -1,    -1,   100,   101,
      -1,   103,    -1,   105,    -1,    -1,    -1,   109,   110,   111,
      -1,    -1,   114,    -1,   116,    -1,   118,   119,   120,   121,
     122,   123,   124,    -1,    -1,   127,   128,   129,   130,   131,
     132,   133,    -1,   135,    -1,   137,    -1,    -1,   140,    -1,
     142,   143,   144,    -1,    -1,   147,    -1,    -1,   150,   151,
     152,    -1,    -1,   155,   156,   157,   158,   159,   160,   161,
     162,   163,   164,   165,    -1,   167,    -1,   169,   170,   171,
     172,    -1,    -1,   175,   176,    -1,    -1,    -1,   180,   181,
      -1,    -1,   184,    -1,    -1,    -1,   188,   189,    -1,    -1,
     192,    -1,    -1,    -1,   196,   197,   198,   199,   200,    -1,
      -1,   203,   204,    -1,   206,   207,   208,   209,   210,   211,
     212,    -1,   214,   215,   216,   217,   218,   219,   220,   221,
      -1,   223,    -1,   225,   226,   227,   228,   229,    -1,   231,
     232,   233,    -1,   235,   236,   237,   238,    -1,   240,   241,
      -1,   243,   244,   245,   246,   247,   248,   249,   250,    -1,
     252,    -1,   254,   255,   256,    -1,   258,   259,    -1,   261,
      -1,   263,    -1,   265,    -1,    -1,   268,   269,   270,   271,
      -1,    -1,   274,   275,   276,   277,   278,    -1,    -1,   281,
     282,   283,   284,   285,   286,    -1,   288,   289,   290,    -1,
      -1,   293,   294,   295,   296,   297,   298,    -1,   300,     3,
       4,     5,     6,     7,     8,     9,    -1,    11,    -1,    -1,
      -1,    -1,    -1,    -1,    18,    19,    20,    -1,    22,    23,
      24,    -1,    26,    -1,    28,    29,    -1,    31,    32,    33,
      34,    -1,    -1,    37,    38,    39,    40,    -1,    42,    43,
      44,    45,    -1,    -1,    -1,    49,    50,    51,    -1,    53,
      54,    -1,    56,    -1,    58,    59,    -1,    -1,    -1,    -1,
      -1,    65,    66,    67,    68,    69,    70,    71,    72,    -1,
      -1,    75,    76,    77,    78,    79,    -1,    -1,    -1,    83,
      84,    85,    86,    -1,    88,    89,    -1,    91,    -1,    93,
      94,    -1,    96,    97,    -1,    -1,   100,   101,    -1,   103,
      -1,   105,    -1,    -1,    -1,   109,   110,   111,    -1,    -1,
     114,    -1,   116,    -1,   118,   119,   120,    -1,   122,   123,
     124,    -1,    -1,   127,   128,   129,   130,   131,   132,   133,
      -1,   135,    -1,   137,    -1,    -1,   140,    -1,   142,   143,
     144,    -1,    -1,   147,    -1,    -1,   150,   151,   152,    -1,
      -1,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,    -1,   167,    -1,   169,   170,   171,   172,   173,
      -1,   175,   176,    -1,    -1,    -1,   180,   181,    -1,    -1,
     184,    -1,    -1,    -1,   188,   189,    -1,    -1,   192,    -1,
      -1,    -1,   196,   197,   198,   199,   200,    -1,    -1,   203,
     204,    -1,   206,   207,   208,   209,   210,   211,   212,    -1,
     214,   215,   216,   217,   218,   219,   220,   221,    -1,   223,
      -1,   225,   226,   227,   228,   229,    -1,   231,   232,   233,
      -1,   235,   236,   237,   238,    -1,   240,   241,    -1,   243,
     244,   245,   246,   247,   248,   249,   250,    -1,   252,    -1,
     254,   255,   256,    -1,   258,   259,    -1,   261,    -1,   263,
      -1,   265,    -1,    -1,   268,   269,   270,   271,    -1,    -1,
     274,   275,   276,   277,   278,    -1,    -1,   281,   282,   283,
     284,   285,   286,    -1,   288,   289,   290,    -1,    -1,   293,
     294,   295,   296,   297,   298,    -1,   300,     3,     4,     5,
       6,     7,     8,     9,    -1,    11,    -1,    -1,    -1,    -1,
      -1,    -1,    18,    19,    20,    -1,    22,    23,    24,    -1,
      26,    -1,    28,    29,    -1,    31,    32,    33,    34,    -1,
      -1,    37,    38,    39,    40,    -1,    42,    43,    44,    45,
      -1,    -1,    -1,    49,    50,    51,    -1,    53,    54,    -1,
      56,    -1,    58,    59,    -1,    -1,    -1,    -1,    -1,    65,
      66,    67,    68,    69,    70,    71,    72,    -1,    -1,    75,
      76,    77,    78,    79,    -1,    -1,    -1,    83,    84,    85,
      86,    -1,    88,    89,    -1,    91,    -1,    93,    94,    -1,
      96,    97,    -1,    -1,   100,   101,    -1,   103,    -1,   105,
      -1,    -1,    -1,   109,   110,   111,    -1,    -1,   114,    -1,
     116,    -1,   118,   119,   120,    -1,   122,   123,   124,    -1,
      -1,   127,   128,   129,   130,   131,   132,   133,    -1,   135,
      -1,   137,    -1,    -1,   140,    -1,   142,   143,   144,    -1,
      -1,   147,    -1,    -1,   150,   151,   152,    -1,    -1,   155,
     156,   157,   158,   159,   160,   161,   162,   163,   164,   165,
      -1,   167,    -1,   169,   170,   171,   172,    -1,    -1,   175,
     176,    -1,    -1,    -1,   180,   181,    -1,    -1,   184,    -1,
      -1,    -1,   188,   189,    -1,    -1,   192,    -1,    -1,    -1,
     196,   197,   198,   199,   200,    -1,    -1,   203,   204,    -1,
     206,   207,   208,   209,   210,   211,   212,    -1,   214,   215,
     216,   217,   218,   219,   220,   221,    -1,   223,    -1,   225,
     226,   227,   228,   229,    -1,   231,   232,   233,    -1,   235,
     236,   237,   238,    -1,   240,   241,    -1,   243,   244,   245,
     246,   247,   248,   249,   250,    -1,   252,    -1,   254,   255,
     256,    -1,   258,   259,    -1,   261,    -1,   263,    -1,   265,
      -1,    -1,   268,   269,   270,   271,    -1,    -1,   274,   275,
     276,   277,   278,    -1,    -1,   281,   282,   283,   284,   285,
     286,    -1,   288,   289,   290,    -1,    -1,   293,   294,   295,
     296,   297,   298,    -1,   300,     3,     4,     5,     6,     7,
       8,     9,    -1,    11,    -1,    -1,    -1,    -1,    -1,    -1,
      18,    19,    20,    -1,    22,    23,    24,    -1,    26,    -1,
      28,    29,    -1,    31,    32,    33,    34,    -1,    -1,    37,
      38,    39,    40,    -1,    42,    43,    44,    45,    -1,    -1,
      -1,    49,    50,    51,    -1,    53,    54,    -1,    56,    -1,
      58,    59,    -1,    -1,    -1,    -1,    -1,    65,    66,    67,
      68,    69,    70,    71,    72,    -1,    -1,    75,    76,    77,
      78,    79,    -1,    -1,    -1,    83,    84,    85,    86,    -1,
      88,    89,    -1,    91,    -1,    93,    94,    -1,    96,    97,
      -1,    -1,   100,   101,    -1,   103,    -1,   105,    -1,    -1,
      -1,   109,   110,   111,    -1,    -1,   114,    -1,   116,    -1,
     118,   119,   120,    -1,   122,   123,   124,    -1,    -1,   127,
     128,   129,   130,   131,   132,   133,    -1,   135,    -1,   137,
      -1,    -1,   140,    -1,   142,   143,   144,    -1,    -1,   147,
      -1,    -1,   150,   151,   152,    -1,    -1,   155,   156,   157,
     158,   159,   160,   161,   162,   163,   164,   165,    -1,   167,
      -1,   169,   170,   171,   172,    -1,    -1,   175,   176,    -1,
      -1,    -1,   180,   181,    -1,    -1,   184,    -1,    -1,    -1,
     188,   189,    -1,    -1,   192,    -1,    -1,    -1,   196,   197,
     198,   199,   200,    -1,    -1,   203,   204,    -1,   206,   207,
     208,   209,   210,   211,   212,    -1,   214,   215,   216,   217,
     218,   219,   220,   221,    -1,   223,    -1,   225,   226,   227,
     228,   229,    -1,   231,   232,   233,    -1,   235,    -1,   237,
     238,    -1,   240,   241,    -1,   243,   244,   245,   246,   247,
     248,   249,   250,    -1,   252,    -1,   254,   255,   256,    -1,
     258,   259,    -1,   261,    -1,   263,    -1,   265,    -1,    -1,
     268,   269,   270,   271,    -1,    -1,   274,   275,   276,   277,
     278,    -1,    -1,   281,   282,   283,   284,   285,   286,    -1,
     288,   289,   290,    -1,     9,   293,   294,   295,   296,   297,
     298,    -1,   300,    18,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    36,    -1,    -1,    39,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    52,    -1,    54,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    67,    -1,    -1,    -1,    -1,    -1,    73,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    83,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   111,    -1,   113,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   123,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   144,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   152,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   188,    -1,   190,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   208,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   226,    -1,    -1,    -1,    -1,   231,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   253,   254,
      -1,   256,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     265,    -1,    -1,    -1,   269,   270,    -1,    -1,   273,    -1,
      -1,    -1,    -1,    -1,   279
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned short yystos[] =
{
       0,     3,    11,    12,    13,    24,    42,    44,    45,    49,
      50,    56,    57,    69,    72,    77,    85,    90,    94,    96,
     100,   112,   130,   150,   151,   156,   163,   176,   204,   214,
     218,   221,   223,   230,   235,   238,   244,   268,   275,   277,
     281,   323,   331,   332,   333,   334,   336,   337,   338,   342,
     345,   347,   348,   352,   363,   364,   365,   368,   369,   372,
     374,   383,   406,   410,   416,   421,   423,   436,   437,   438,
     439,   444,   449,   450,   454,   455,   458,   462,   463,   474,
     482,   494,   495,   497,   500,   502,   503,   506,   509,   517,
     518,   519,   520,   521,   524,   525,   526,   530,   531,   532,
     534,   535,   536,   537,   538,   543,   544,   547,   549,   550,
     551,   555,   556,   559,   560,   562,   563,   564,   565,   566,
     263,   295,   523,    67,   113,   253,   265,   279,   523,     3,
       4,     5,     6,     7,     8,     9,    11,    18,    19,    20,
      22,    23,    24,    26,    28,    29,    31,    32,    33,    34,
      37,    38,    39,    40,    42,    43,    44,    45,    46,    49,
      50,    51,    53,    54,    55,    56,    58,    59,    65,    66,
      67,    68,    69,    70,    71,    72,    75,    76,    77,    78,
      79,    83,    84,    85,    86,    88,    89,    91,    93,    94,
      95,    96,    97,    98,   100,   101,   103,   105,   109,   110,
     111,   114,   116,   118,   119,   120,   122,   123,   124,   127,
     128,   129,   130,   131,   132,   133,   135,   137,   140,   142,
     143,   144,   147,   150,   151,   152,   155,   156,   157,   158,
     159,   160,   161,   162,   163,   164,   165,   167,   169,   170,
     171,   172,   173,   175,   176,   179,   180,   181,   184,   188,
     189,   192,   195,   196,   197,   198,   199,   200,   202,   203,
     204,   206,   207,   208,   209,   210,   211,   212,   214,   215,
     216,   217,   218,   219,   220,   221,   223,   224,   225,   226,
     227,   228,   229,   231,   232,   233,   235,   236,   237,   238,
     240,   241,   243,   244,   245,   246,   247,   248,   249,   250,
     251,   252,   254,   255,   256,   258,   259,   261,   263,   264,
     265,   266,   268,   269,   270,   271,   274,   275,   276,   277,
     278,   281,   282,   283,   284,   285,   286,   288,   289,   290,
     293,   294,   295,   296,   297,   298,   300,   373,   677,   681,
     682,   670,   677,   186,   523,    27,   379,     9,    18,    36,
      39,    52,    67,    73,    83,   111,   113,   152,   188,   190,
     226,   254,   256,   265,   269,   270,   273,   279,   384,   417,
     447,   475,   483,   204,   666,   677,   666,   107,     9,    18,
      36,    54,    67,    83,   109,   113,   123,   188,   208,   225,
     226,   231,   253,   265,   270,   279,   289,   422,   451,   523,
     666,   287,   538,   539,     4,    10,    22,   105,   107,   121,
     169,   206,   215,   307,   315,   459,   460,   461,   666,   674,
      10,    57,    77,    94,   130,   213,   225,   230,   254,   256,
     265,   277,   278,   464,   465,   466,   136,   168,   185,   654,
     662,   664,   677,   685,   302,   671,   675,   253,   569,   459,
     460,   461,   666,   664,   666,    67,   123,   253,   504,    10,
     233,   258,   263,   677,   112,   471,   523,    10,    81,   571,
      53,   152,   164,   233,   258,   263,   353,   677,    10,   233,
     258,   263,   677,   263,   569,   316,   664,   187,   594,   664,
     108,   540,   563,   564,     0,   327,   539,    92,   134,   191,
     272,   572,   573,   667,   677,   676,   677,   594,   664,   666,
     676,   186,     9,    48,    52,    67,    83,   109,   123,   188,
     225,   226,   231,   253,   265,   270,   289,   456,   664,    21,
      25,    27,    60,   106,   108,   117,   121,   126,   138,   139,
     141,   146,   148,   166,   177,   193,   194,   222,   239,   287,
     300,   654,   662,   672,   679,   681,   683,   666,   323,   235,
     265,   667,   453,   654,   677,   254,   256,   676,   254,   256,
      43,   306,   310,   311,   312,   314,   315,   316,   317,   318,
     319,   499,   628,   629,   677,   217,   349,   677,   666,   453,
     676,   231,   253,   422,    54,   123,   109,   225,   289,   666,
      27,   129,   227,   561,   594,   672,   666,   323,   667,   672,
     676,    43,   499,   666,   666,   341,   676,   144,   452,   453,
     323,   548,   539,   550,   674,   169,   206,   460,   461,   461,
     666,   207,   186,   328,   664,   326,   655,   663,   664,   460,
     461,   461,   666,   323,   545,   666,   664,    21,   298,   140,
     189,   464,   186,    26,    28,    29,    35,    36,    38,    39,
      46,    55,    61,    62,    63,    64,    70,    71,    84,    95,
      98,    99,   101,   132,   133,   135,   153,   154,   165,   167,
     174,   178,   179,   180,   188,   195,   202,   211,   224,   234,
     241,   251,   258,   259,   264,   266,   267,   273,   279,   285,
     300,   301,   304,   305,   306,   308,   314,   315,   316,   318,
     319,   323,   563,   602,   603,   604,   609,   610,   611,   613,
     614,   615,   616,   620,   621,   624,   625,   630,   632,   634,
     648,   653,   654,   656,   657,   662,   672,   673,   674,   675,
     678,   681,    10,   366,   665,   666,   233,   353,    73,   361,
     675,    21,    40,   353,   298,   140,   260,   310,    21,   298,
     140,   140,   522,   664,   323,   664,   235,   316,   106,   541,
     324,   324,   333,   664,    10,    81,   570,   570,    31,   570,
     102,   149,   183,   577,   583,   235,   364,     7,    85,   346,
       7,    11,    85,   216,    57,   196,   186,   235,   293,   335,
     364,   664,   672,   666,   672,   499,   666,   666,   453,   323,
     396,   323,   440,    41,    26,    28,    29,    38,    39,    70,
      71,   101,   132,   133,   135,   167,   180,   211,   236,   241,
     258,   259,   285,   300,   599,   601,   603,   604,   608,   610,
     611,   612,   614,   615,   620,   621,   678,   681,    16,   533,
     666,   335,   533,   335,   453,   440,   326,    21,   350,     8,
      23,   424,    16,   440,   335,   664,   664,   144,   453,   670,
     672,   666,   664,   227,    65,   292,   596,   323,    34,   219,
     371,   599,   323,   484,   453,   323,   186,   186,   328,   302,
     362,   677,   328,   371,   632,   636,   136,   567,   550,   461,
     666,   666,    67,   109,   144,   226,   253,   467,   663,   466,
      73,   284,   323,   552,   562,   316,   669,   677,   121,   328,
     557,   461,   666,   666,   546,   599,    16,   103,   505,   505,
     147,   102,   186,   323,   286,   617,   632,   652,   323,   617,
     617,   323,   323,   323,   323,   323,   607,   607,   203,   563,
     323,   323,   605,   323,   323,    38,    39,   617,   632,   323,
     323,   606,   323,   323,   323,   323,   323,   293,   294,   323,
     622,   323,   622,   323,   323,   563,   635,   655,   632,   632,
     632,   632,   563,   626,   632,   636,   675,    39,   323,   618,
     323,   675,   121,   138,   174,   188,   194,   628,   631,   632,
      14,    16,    20,    25,    47,   117,   121,   138,   139,   148,
     174,   177,   188,   190,   239,   306,   310,   311,   312,   314,
     315,   316,   317,   318,   319,   325,   630,   631,   635,   328,
     567,   635,   323,    75,   118,   367,   328,    40,    73,   362,
      16,    73,   152,   300,   301,   315,   360,   413,   414,   415,
     621,   674,   675,   147,    73,    99,   182,   186,   267,   354,
     355,   356,   359,   362,   413,   354,   147,   147,   664,   658,
     659,   677,   539,   323,   542,   563,   565,   566,   565,   574,
     575,   632,   565,   210,   277,    10,   308,   579,   674,   308,
     580,   674,   583,   584,   577,   578,   353,   279,    41,    48,
      52,   104,   205,   273,   394,   395,   508,   508,    52,   508,
     508,   261,   260,   594,   353,   339,   323,   186,   484,   323,
     138,   186,   186,   138,   397,   398,   677,   293,   380,    10,
      12,    13,    14,    15,    16,    17,    30,    35,    36,    41,
      47,    48,    52,    57,    61,    62,    63,    64,    73,    74,
      80,    81,    82,    87,    90,    92,    99,   102,   104,   107,
     112,   113,   115,   125,   134,   136,   145,   149,   153,   154,
     168,   174,   178,   182,   183,   185,   186,   187,   190,   191,
     201,   205,   213,   230,   234,   242,   253,   257,   260,   262,
     267,   272,   273,   279,   280,   291,   292,   300,   441,   442,
     680,   681,   682,   683,   684,   323,   601,    16,   600,    68,
     116,   159,   162,   228,   297,   323,   623,   655,   453,     8,
     527,   599,   343,   447,   499,   676,    57,   351,   383,   462,
     524,    77,   130,   277,   425,   426,   323,   339,   411,   181,
     323,   407,   362,   102,   186,   484,    16,   396,   102,   632,
     316,   496,   599,    16,   121,   127,   192,   324,   485,   486,
     487,   489,   599,   678,   371,   280,   173,   498,   599,   664,
     664,   676,   371,   453,   324,   328,   111,   152,   253,   254,
     256,   568,   664,   666,   665,   472,   473,   672,   665,   665,
     663,   260,   284,   323,   553,   554,   677,   655,     5,    93,
     224,   237,   558,   664,   666,   324,   328,   550,   467,   636,
     323,   291,   649,   650,   632,   636,   632,   636,   674,   674,
     674,    68,   116,   159,   162,   228,   297,   300,   302,   637,
     639,   674,   674,   674,   617,   617,   632,   674,   499,   632,
     640,   314,   315,   318,   319,   323,   630,   633,   634,   642,
     324,   626,   632,   632,   636,   643,   258,   258,   674,   674,
     632,    30,   107,   145,   262,   632,   636,   646,   321,   635,
     324,   324,   328,   235,   674,   674,   623,   563,    81,   174,
     178,   121,   323,   224,   323,   625,    10,    15,   242,   323,
     563,   625,   627,   632,   680,   258,   633,   677,   632,   323,
     563,   647,    81,    99,   174,   178,   181,   267,   274,   632,
      25,   117,   121,   148,   239,   323,   632,   260,   632,   632,
     632,   632,   632,   632,   632,   632,   632,   599,   632,   627,
     657,   107,   586,    10,    81,   316,   324,   636,   666,   263,
     301,   674,   323,   675,   210,   232,   357,   328,   357,   324,
     328,   586,   635,   537,   664,   665,   328,    17,    80,   280,
     576,   187,   181,   585,   183,   328,   149,   341,   323,   666,
     142,   142,   323,   388,   677,   677,   666,   677,   507,   666,
     253,   676,   216,    58,    59,    89,   121,   171,   172,   198,
     252,   271,   282,   340,   496,   453,   138,   498,   178,   457,
     675,   453,   453,   457,   324,   328,   184,   107,   260,   375,
     324,   328,   310,   632,   600,   599,   321,   260,   260,   260,
     260,   674,   110,   425,    88,   155,   196,   255,   528,   389,
     252,   279,   344,   102,   350,   384,   483,   186,   190,   597,
     598,   677,    32,    66,   122,   158,   160,   244,   412,   664,
     148,   385,   386,   387,   388,   393,   394,   408,   409,   677,
      16,   114,   675,   664,   220,   510,    16,   562,   324,   599,
     324,   328,   489,   655,   668,   677,   328,   324,   328,   371,
     371,   632,   254,   256,   254,   256,   664,   569,   569,   328,
     484,   113,   468,   469,   677,    73,   657,   660,   661,   324,
     328,   635,    93,   237,    93,   237,   224,   277,   161,   599,
     107,   324,   674,   632,    87,   650,   651,    16,   324,   280,
     324,   324,   324,   324,   328,   324,   107,   324,   324,   324,
     328,   324,   328,   324,   201,   641,   324,   633,   633,   633,
     633,   632,   633,   121,   138,   188,   310,   311,   312,   314,
     315,   316,   317,   318,   319,   325,   630,   324,   324,   324,
     102,   107,   644,   645,   324,   298,   298,   324,   324,    16,
     646,   636,   646,   646,   107,   324,   632,   655,   632,   677,
     324,   324,   107,   178,   563,   499,   563,   298,    14,    91,
     636,   107,    99,   178,   181,   267,   274,   323,    91,   633,
     632,   647,   632,   260,   499,   632,   563,   323,   563,   587,
     588,   589,   594,   595,   654,   672,   596,   636,   636,   324,
     324,   140,   674,   623,    51,   210,   358,   356,   659,   596,
     310,   324,   575,   631,   665,   580,   580,   579,   632,   395,
     323,   323,   397,   599,    85,   235,   370,   371,   371,   260,
     260,   198,   113,   675,   674,   198,   276,   324,   138,   457,
     324,   138,   138,   398,   247,   248,   376,   675,   442,   188,
     315,   413,   443,   488,   489,   631,   675,   324,   324,   322,
     674,   116,   159,   228,   159,   228,   228,   162,   324,   440,
     186,   310,   529,   529,   529,   529,    41,    47,    52,    73,
      74,   125,   174,   178,   205,   213,   273,   390,   391,   392,
     619,   674,   341,   270,   253,   664,   426,   324,   328,   599,
     413,   413,   413,   413,   413,   323,   453,   324,   328,   324,
     328,   562,   418,   654,   666,   677,   260,   280,   476,   488,
     186,   562,   371,   324,   486,   318,   371,   599,   371,   173,
     599,   569,   569,   569,   569,   664,   664,   473,   677,   293,
     328,   470,   324,   328,   284,   562,   554,    93,    93,   468,
     324,   257,   632,    90,   599,   453,   674,   632,   632,   674,
     632,   644,   633,    81,   174,   181,   633,   633,   633,   633,
     633,   633,   633,   633,   633,   599,   633,   632,   632,   645,
     644,   622,   622,   599,   324,   324,   324,   636,   322,   329,
     635,   618,   675,   625,   324,   634,   633,   632,   324,   632,
     323,   599,   638,   632,    14,    91,    91,   632,   324,    91,
     563,   588,   589,    16,   590,   677,   328,    60,   108,   126,
     141,   146,   166,   222,   299,   591,   590,    16,   590,   677,
     323,   113,   581,   324,   324,   147,   324,   187,   296,   632,
     324,   397,   397,   324,   389,    73,   174,    73,   174,   246,
     249,   666,   666,   675,   341,   675,   675,   138,   457,   138,
     457,   457,   280,   381,   382,    74,   125,   174,   433,   434,
     435,   293,   294,   322,   623,   619,   664,    73,   674,   675,
      73,   675,    73,   666,    73,   666,   323,   677,   666,   633,
      75,   118,    74,   178,   142,   664,   599,   664,   102,   427,
     190,   598,   385,   124,   404,   387,   409,   677,   283,   420,
     675,   668,   323,    16,    33,    97,   119,   144,   220,   229,
     243,   250,   290,   490,   491,    77,   130,   230,   277,   515,
     371,   270,   664,   664,   664,   664,   112,   469,   661,   323,
     632,   324,   324,   324,   324,   324,   645,   107,   181,   323,
     324,   632,   623,   638,   324,   328,   633,   632,   632,    91,
     632,   324,   677,   323,   588,   141,   193,   592,   588,   592,
     141,   591,   592,   588,   141,   323,   677,   323,   324,   636,
      31,   115,   582,   357,   675,   324,   324,   619,   178,   632,
     178,   315,   415,   677,   457,   457,   335,    79,    75,   118,
      74,   435,   434,   109,   109,   107,   432,   632,   174,   391,
     396,   280,   323,    86,   428,    94,   426,   324,   323,   293,
     294,   405,   418,   143,   419,   107,   477,   478,   479,   480,
     669,   672,   677,   492,   675,   186,   229,   362,   178,    76,
     137,   293,   491,   493,   260,   189,   660,   633,   323,   638,
     322,   324,   599,   632,   590,   323,   665,   588,   186,   280,
     593,   588,   141,   588,   597,   323,   597,   677,   324,   636,
     632,   623,   213,   377,   675,   473,    16,   501,   664,   433,
     324,   157,   399,   668,   224,   245,   429,   209,   405,   663,
     184,   184,   675,   453,   324,   328,   280,   453,   481,   323,
     328,   178,    76,   137,   186,   440,   664,   324,   638,   324,
     665,   324,   632,   323,   588,   593,   324,   597,   324,   664,
      27,    78,   178,   184,   378,   501,    19,   120,   102,   108,
     197,   240,   186,   400,   401,   402,    16,   672,   324,   596,
     480,   453,   665,   675,   128,   178,   596,   324,   324,   665,
     324,   396,   533,   533,    86,    77,   277,   186,   402,   186,
     401,   109,   188,   249,   445,   446,   323,   324,   128,    82,
     324,   399,   675,   675,   224,    34,   170,   219,   235,   403,
     403,   674,   674,   599,   328,   301,   304,   305,   307,   430,
     431,   675,   677,   481,   131,   516,   400,    94,     6,    73,
     178,   672,   499,   446,   324,   328,   175,   323,   511,   513,
     518,   551,   555,   559,   562,   433,   209,   484,   212,   323,
     448,   431,   512,   513,   514,   563,   564,   672,   498,   324,
     327,   323,   324,   514,   430,   448,   324
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1

/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("parse error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)         \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (cinluded).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylineno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylineno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 458 "gram.y"
    { parsetree = yyvsp[0].list; }
    break;

  case 3:
#line 463 "gram.y"
    { if (yyvsp[0].node != (Node *)NULL)
					yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node);
				  else
					yyval.list = yyvsp[-2].list;
				}
    break;

  case 4:
#line 469 "gram.y"
    { if (yyvsp[0].node != (Node *)NULL)
						yyval.list = makeList1(yyvsp[0].node);
					  else
						yyval.list = NIL;
					}
    break;

  case 70:
#line 543 "gram.y"
    { yyval.node = (Node *)NULL; }
    break;

  case 71:
#line 555 "gram.y"
    {
					CreateUserStmt *n = makeNode(CreateUserStmt);
					n->user = yyvsp[-2].str;
					n->options = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 72:
#line 564 "gram.y"
    {}
    break;

  case 73:
#line 565 "gram.y"
    {}
    break;

  case 74:
#line 577 "gram.y"
    {
					AlterUserStmt *n = makeNode(AlterUserStmt);
					n->user = yyvsp[-2].str;
					n->options = yyvsp[0].list;
					yyval.node = (Node *)n;
				 }
    break;

  case 75:
#line 588 "gram.y"
    {
					AlterUserSetStmt *n = makeNode(AlterUserSetStmt);
					n->user = yyvsp[-2].str;
					n->variable = yyvsp[0].vsetstmt->name;
					n->value = yyvsp[0].vsetstmt->args;
					yyval.node = (Node *)n;
				}
    break;

  case 76:
#line 596 "gram.y"
    {
					AlterUserSetStmt *n = makeNode(AlterUserSetStmt);
					n->user = yyvsp[-1].str;
					n->variable = ((VariableResetStmt *)yyvsp[0].node)->name;
					n->value = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 77:
#line 617 "gram.y"
    {
					DropUserStmt *n = makeNode(DropUserStmt);
					n->users = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 78:
#line 628 "gram.y"
    { yyval.list = lappend(yyvsp[-1].list, yyvsp[0].defelt); }
    break;

  case 79:
#line 629 "gram.y"
    { yyval.list = NIL; }
    break;

  case 80:
#line 634 "gram.y"
    {
					yyval.defelt = makeDefElem("password", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 81:
#line 638 "gram.y"
    {
					yyval.defelt = makeDefElem("encryptedPassword", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 82:
#line 642 "gram.y"
    {
					yyval.defelt = makeDefElem("unencryptedPassword", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 83:
#line 646 "gram.y"
    {
					yyval.defelt = makeDefElem("sysid", (Node *)makeInteger(yyvsp[0].ival));
				}
    break;

  case 84:
#line 650 "gram.y"
    {
					yyval.defelt = makeDefElem("createdb", (Node *)makeInteger(TRUE));
				}
    break;

  case 85:
#line 654 "gram.y"
    {
					yyval.defelt = makeDefElem("createdb", (Node *)makeInteger(FALSE));
				}
    break;

  case 86:
#line 658 "gram.y"
    {
					yyval.defelt = makeDefElem("createuser", (Node *)makeInteger(TRUE));
				}
    break;

  case 87:
#line 662 "gram.y"
    {
					yyval.defelt = makeDefElem("createuser", (Node *)makeInteger(FALSE));
				}
    break;

  case 88:
#line 666 "gram.y"
    {
					yyval.defelt = makeDefElem("groupElts", (Node *)yyvsp[0].list);
				}
    break;

  case 89:
#line 670 "gram.y"
    {
					yyval.defelt = makeDefElem("validUntil", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 90:
#line 675 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, makeString(yyvsp[0].str)); }
    break;

  case 91:
#line 676 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 92:
#line 690 "gram.y"
    {
					CreateGroupStmt *n = makeNode(CreateGroupStmt);
					n->name = yyvsp[-2].str;
					n->options = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 93:
#line 702 "gram.y"
    { yyval.list = lappend(yyvsp[-1].list, yyvsp[0].defelt); }
    break;

  case 94:
#line 703 "gram.y"
    { yyval.list = NIL; }
    break;

  case 95:
#line 708 "gram.y"
    {
					yyval.defelt = makeDefElem("userElts", (Node *)yyvsp[0].list);
				}
    break;

  case 96:
#line 712 "gram.y"
    {
					yyval.defelt = makeDefElem("sysid", (Node *)makeInteger(yyvsp[0].ival));
				}
    break;

  case 97:
#line 727 "gram.y"
    {
					AlterGroupStmt *n = makeNode(AlterGroupStmt);
					n->name = yyvsp[-3].str;
					n->action = yyvsp[-2].ival;
					n->listUsers = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 98:
#line 736 "gram.y"
    { yyval.ival = +1; }
    break;

  case 99:
#line 737 "gram.y"
    { yyval.ival = -1; }
    break;

  case 100:
#line 750 "gram.y"
    {
					DropGroupStmt *n = makeNode(DropGroupStmt);
					n->name = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 101:
#line 766 "gram.y"
    {
					CreateSchemaStmt *n = makeNode(CreateSchemaStmt);
					/* One can omit the schema name or the authorization id. */
					if (yyvsp[-3].str != NULL)
						n->schemaname = yyvsp[-3].str;
					else
						n->schemaname = yyvsp[-1].str;
					n->authid = yyvsp[-1].str;
					n->schemaElts = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 102:
#line 778 "gram.y"
    {
					CreateSchemaStmt *n = makeNode(CreateSchemaStmt);
					/* ...but not both */
					n->schemaname = yyvsp[-1].str;
					n->authid = NULL;
					n->schemaElts = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 103:
#line 789 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 104:
#line 790 "gram.y"
    { yyval.str = NULL; }
    break;

  case 105:
#line 794 "gram.y"
    { yyval.list = lappend(yyvsp[-1].list, yyvsp[0].node); }
    break;

  case 106:
#line 795 "gram.y"
    { yyval.list = NIL; }
    break;

  case 110:
#line 820 "gram.y"
    {
					VariableSetStmt *n = yyvsp[0].vsetstmt;
					n->is_local = false;
					yyval.node = (Node *) n;
				}
    break;

  case 111:
#line 826 "gram.y"
    {
					VariableSetStmt *n = yyvsp[0].vsetstmt;
					n->is_local = true;
					yyval.node = (Node *) n;
				}
    break;

  case 112:
#line 832 "gram.y"
    {
					VariableSetStmt *n = yyvsp[0].vsetstmt;
					n->is_local = false;
					yyval.node = (Node *) n;
				}
    break;

  case 113:
#line 840 "gram.y"
    {
					VariableSetStmt *n = makeNode(VariableSetStmt);
					n->name = yyvsp[-2].str;
					n->args = yyvsp[0].list;
					yyval.vsetstmt = n;
				}
    break;

  case 114:
#line 847 "gram.y"
    {
					VariableSetStmt *n = makeNode(VariableSetStmt);
					n->name = yyvsp[-2].str;
					n->args = yyvsp[0].list;
					yyval.vsetstmt = n;
				}
    break;

  case 115:
#line 854 "gram.y"
    {
					VariableSetStmt *n = makeNode(VariableSetStmt);
					n->name = "timezone";
					if (yyvsp[0].node != NULL)
						n->args = makeList1(yyvsp[0].node);
					yyval.vsetstmt = n;
				}
    break;

  case 116:
#line 862 "gram.y"
    {
					VariableSetStmt *n = makeNode(VariableSetStmt);
					n->name = "TRANSACTION ISOLATION LEVEL";
					n->args = makeList1(makeStringConst(yyvsp[-1].str, NULL));
					yyval.vsetstmt = n;
				}
    break;

  case 117:
#line 869 "gram.y"
    {
					VariableSetStmt *n = makeNode(VariableSetStmt);
					n->name = "default_transaction_isolation";
					n->args = makeList1(makeStringConst(yyvsp[0].str, NULL));
					yyval.vsetstmt = n;
				}
    break;

  case 118:
#line 876 "gram.y"
    {
					VariableSetStmt *n = makeNode(VariableSetStmt);
					n->name = "client_encoding";
					if (yyvsp[0].str != NULL)
						n->args = makeList1(makeStringConst(yyvsp[0].str, NULL));
					yyval.vsetstmt = n;
				}
    break;

  case 119:
#line 884 "gram.y"
    {
					VariableSetStmt *n = makeNode(VariableSetStmt);
					n->name = "session_authorization";
					n->args = makeList1(makeStringConst(yyvsp[0].str, NULL));
					yyval.vsetstmt = n;
				}
    break;

  case 120:
#line 891 "gram.y"
    {
					VariableSetStmt *n = makeNode(VariableSetStmt);
					n->name = "session_authorization";
					n->args = NIL;
					yyval.vsetstmt = n;
				}
    break;

  case 121:
#line 900 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 122:
#line 901 "gram.y"
    { yyval.list = NIL; }
    break;

  case 123:
#line 904 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 124:
#line 905 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 125:
#line 909 "gram.y"
    { yyval.node = makeStringConst(yyvsp[0].str, NULL); }
    break;

  case 126:
#line 911 "gram.y"
    { yyval.node = makeStringConst(yyvsp[0].str, NULL); }
    break;

  case 127:
#line 913 "gram.y"
    { yyval.node = makeAConst(yyvsp[0].value); }
    break;

  case 128:
#line 916 "gram.y"
    { yyval.str = "read committed"; }
    break;

  case 129:
#line 917 "gram.y"
    { yyval.str = "serializable"; }
    break;

  case 130:
#line 921 "gram.y"
    {}
    break;

  case 131:
#line 923 "gram.y"
    {
					elog(ERROR, "SET TRANSACTION/READ ONLY not yet supported");
				}
    break;

  case 132:
#line 927 "gram.y"
    {}
    break;

  case 133:
#line 931 "gram.y"
    { yyval.str = "true"; }
    break;

  case 134:
#line 932 "gram.y"
    { yyval.str = "false"; }
    break;

  case 135:
#line 933 "gram.y"
    { yyval.str = "on"; }
    break;

  case 136:
#line 934 "gram.y"
    { yyval.str = "off"; }
    break;

  case 137:
#line 947 "gram.y"
    {
					yyval.node = makeStringConst(yyvsp[0].str, NULL);
				}
    break;

  case 138:
#line 951 "gram.y"
    {
					yyval.node = makeStringConst(yyvsp[0].str, NULL);
				}
    break;

  case 139:
#line 955 "gram.y"
    {
					A_Const *n = (A_Const *) makeStringConst(yyvsp[-1].str, yyvsp[-2].typnam);
					if (yyvsp[0].ival != INTERVAL_FULL_RANGE)
					{
						if ((yyvsp[0].ival & ~(INTERVAL_MASK(HOUR) | INTERVAL_MASK(MINUTE))) != 0)
							elog(ERROR,
								 "Time zone interval"
								 " must be HOUR or HOUR TO MINUTE");
						n->typename->typmod = INTERVAL_TYPMOD(INTERVAL_FULL_PRECISION, yyvsp[0].ival);
					}
					yyval.node = (Node *)n;
				}
    break;

  case 140:
#line 968 "gram.y"
    {
					A_Const *n = (A_Const *) makeStringConst(yyvsp[-1].str, yyvsp[-5].typnam);
					if (yyvsp[-3].ival < 0)
						elog(ERROR,
							 "INTERVAL(%d) precision must not be negative",
							 yyvsp[-3].ival);
					if (yyvsp[-3].ival > MAX_INTERVAL_PRECISION)
					{
						elog(NOTICE,
							 "INTERVAL(%d) precision reduced to maximum allowed, %d",
							 yyvsp[-3].ival, MAX_INTERVAL_PRECISION);
						yyvsp[-3].ival = MAX_INTERVAL_PRECISION;
					}

					if ((yyvsp[0].ival != INTERVAL_FULL_RANGE)
						&& ((yyvsp[0].ival & ~(INTERVAL_MASK(HOUR) | INTERVAL_MASK(MINUTE))) != 0))
						elog(ERROR,
							 "Time zone interval"
							 " must be HOUR or HOUR TO MINUTE");

					n->typename->typmod = INTERVAL_TYPMOD(yyvsp[-3].ival, yyvsp[0].ival);

					yyval.node = (Node *)n;
				}
    break;

  case 141:
#line 992 "gram.y"
    { yyval.node = makeAConst(yyvsp[0].value); }
    break;

  case 142:
#line 993 "gram.y"
    { yyval.node = NULL; }
    break;

  case 143:
#line 994 "gram.y"
    { yyval.node = NULL; }
    break;

  case 144:
#line 998 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 145:
#line 999 "gram.y"
    { yyval.str = NULL; }
    break;

  case 146:
#line 1000 "gram.y"
    { yyval.str = NULL; }
    break;

  case 147:
#line 1004 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 148:
#line 1005 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 149:
#line 1011 "gram.y"
    {
					VariableShowStmt *n = makeNode(VariableShowStmt);
					n->name = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 150:
#line 1017 "gram.y"
    {
					VariableShowStmt *n = makeNode(VariableShowStmt);
					n->name = "timezone";
					yyval.node = (Node *) n;
				}
    break;

  case 151:
#line 1023 "gram.y"
    {
					VariableShowStmt *n = makeNode(VariableShowStmt);
					n->name = "TRANSACTION ISOLATION LEVEL";
					yyval.node = (Node *) n;
				}
    break;

  case 152:
#line 1029 "gram.y"
    {
					VariableShowStmt *n = makeNode(VariableShowStmt);
					n->name = "session_authorization";
					yyval.node = (Node *) n;
				}
    break;

  case 153:
#line 1035 "gram.y"
    {
					VariableShowStmt *n = makeNode(VariableShowStmt);
					n->name = "all";
					yyval.node = (Node *) n;
				}
    break;

  case 154:
#line 1044 "gram.y"
    {
					VariableResetStmt *n = makeNode(VariableResetStmt);
					n->name = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 155:
#line 1050 "gram.y"
    {
					VariableResetStmt *n = makeNode(VariableResetStmt);
					n->name = "timezone";
					yyval.node = (Node *) n;
				}
    break;

  case 156:
#line 1056 "gram.y"
    {
					VariableResetStmt *n = makeNode(VariableResetStmt);
					n->name = "TRANSACTION ISOLATION LEVEL";
					yyval.node = (Node *) n;
				}
    break;

  case 157:
#line 1062 "gram.y"
    {
					VariableResetStmt *n = makeNode(VariableResetStmt);
					n->name = "session_authorization";
					yyval.node = (Node *) n;
				}
    break;

  case 158:
#line 1068 "gram.y"
    {
					VariableResetStmt *n = makeNode(VariableResetStmt);
					n->name = "all";
					yyval.node = (Node *) n;
				}
    break;

  case 159:
#line 1078 "gram.y"
    {
					ConstraintsSetStmt *n = makeNode(ConstraintsSetStmt);
					n->constraints = yyvsp[-1].list;
					n->deferred    = yyvsp[0].boolean;
					yyval.node = (Node *) n;
				}
    break;

  case 160:
#line 1087 "gram.y"
    { yyval.list = NIL; }
    break;

  case 161:
#line 1088 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 162:
#line 1092 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 163:
#line 1093 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 164:
#line 1102 "gram.y"
    {
					CheckPointStmt *n = makeNode(CheckPointStmt);
					yyval.node = (Node *)n;
				}
    break;

  case 165:
#line 1118 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'A';
					n->relation = yyvsp[-3].range;
					n->def = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 166:
#line 1127 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'T';
					n->relation = yyvsp[-4].range;
					n->name = yyvsp[-1].str;
					n->def = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 167:
#line 1137 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'N';
					n->relation = yyvsp[-6].range;
					n->name = yyvsp[-3].str;
					yyval.node = (Node *)n;
				}
    break;

  case 168:
#line 1146 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'O';
					n->relation = yyvsp[-6].range;
					n->name = yyvsp[-3].str;
					yyval.node = (Node *)n;
				}
    break;

  case 169:
#line 1155 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'S';
					n->relation = yyvsp[-6].range;
					n->name = yyvsp[-3].str;
					n->def = (Node *) yyvsp[0].value;
					yyval.node = (Node *)n;
				}
    break;

  case 170:
#line 1166 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'M';
					n->relation = yyvsp[-6].range;
					n->name = yyvsp[-3].str;
					n->def = (Node *) makeString(yyvsp[0].str);
					yyval.node = (Node *)n;
				}
    break;

  case 171:
#line 1176 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'D';
					n->relation = yyvsp[-4].range;
					n->name = yyvsp[-1].str;
					n->behavior = yyvsp[0].dbehavior;
					yyval.node = (Node *)n;
				}
    break;

  case 172:
#line 1186 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'C';
					n->relation = yyvsp[-2].range;
					n->def = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 173:
#line 1195 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'X';
					n->relation = yyvsp[-4].range;
					n->name = yyvsp[-1].str;
					n->behavior = yyvsp[0].dbehavior;
					yyval.node = (Node *)n;
				}
    break;

  case 174:
#line 1205 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'E';
					yyvsp[-3].range->inhOpt = INH_NO;
					n->relation = yyvsp[-3].range;
					yyval.node = (Node *)n;
				}
    break;

  case 175:
#line 1214 "gram.y"
    {
					AlterTableStmt *n = makeNode(AlterTableStmt);
					n->subtype = 'U';
					yyvsp[-3].range->inhOpt = INH_NO;
					n->relation = yyvsp[-3].range;
					n->name = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 176:
#line 1226 "gram.y"
    {
					/* Treat SET DEFAULT NULL the same as DROP DEFAULT */
					if (exprIsNullConstant(yyvsp[0].node))
						yyval.node = NULL;
					else
						yyval.node = yyvsp[0].node;
				}
    break;

  case 177:
#line 1233 "gram.y"
    { yyval.node = NULL; }
    break;

  case 178:
#line 1237 "gram.y"
    { yyval.dbehavior = DROP_CASCADE; }
    break;

  case 179:
#line 1238 "gram.y"
    { yyval.dbehavior = DROP_RESTRICT; }
    break;

  case 180:
#line 1239 "gram.y"
    { yyval.dbehavior = DROP_RESTRICT; /* default */ }
    break;

  case 181:
#line 1253 "gram.y"
    {
					ClosePortalStmt *n = makeNode(ClosePortalStmt);
					n->portalname = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 182:
#line 1260 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 183:
#line 1261 "gram.y"
    { yyval.str = NULL; }
    break;

  case 184:
#line 1277 "gram.y"
    {
					CopyStmt *n = makeNode(CopyStmt);
					n->relation = yyvsp[-7].range;
					n->attlist = yyvsp[-6].list;
					n->is_from = yyvsp[-4].boolean;
					n->filename = yyvsp[-3].str;

					n->options = NIL;
					/* Concatenate user-supplied flags */
					if (yyvsp[-8].defelt)
						n->options = lappend(n->options, yyvsp[-8].defelt);
					if (yyvsp[-5].defelt)
						n->options = lappend(n->options, yyvsp[-5].defelt);
					if (yyvsp[-2].defelt)
						n->options = lappend(n->options, yyvsp[-2].defelt);
					if (yyvsp[0].list)
						n->options = nconc(n->options, yyvsp[0].list);
					yyval.node = (Node *)n;
				}
    break;

  case 185:
#line 1299 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 186:
#line 1300 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 187:
#line 1309 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 188:
#line 1310 "gram.y"
    { yyval.str = NULL; }
    break;

  case 189:
#line 1311 "gram.y"
    { yyval.str = NULL; }
    break;

  case 190:
#line 1317 "gram.y"
    { yyval.list = lappend(yyvsp[-1].list, yyvsp[0].defelt); }
    break;

  case 191:
#line 1318 "gram.y"
    { yyval.list = NIL; }
    break;

  case 192:
#line 1324 "gram.y"
    {
					yyval.defelt = makeDefElem("binary", (Node *)makeInteger(TRUE));
				}
    break;

  case 193:
#line 1328 "gram.y"
    {
					yyval.defelt = makeDefElem("oids", (Node *)makeInteger(TRUE));
				}
    break;

  case 194:
#line 1332 "gram.y"
    {
					yyval.defelt = makeDefElem("delimiter", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 195:
#line 1336 "gram.y"
    {
					yyval.defelt = makeDefElem("null", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 196:
#line 1345 "gram.y"
    {
					yyval.defelt = makeDefElem("binary", (Node *)makeInteger(TRUE));
				}
    break;

  case 197:
#line 1348 "gram.y"
    { yyval.defelt = NULL; }
    break;

  case 198:
#line 1353 "gram.y"
    {
					yyval.defelt = makeDefElem("oids", (Node *)makeInteger(TRUE));
				}
    break;

  case 199:
#line 1356 "gram.y"
    { yyval.defelt = NULL; }
    break;

  case 200:
#line 1362 "gram.y"
    {
					yyval.defelt = makeDefElem("delimiter", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 201:
#line 1365 "gram.y"
    { yyval.defelt = NULL; }
    break;

  case 202:
#line 1369 "gram.y"
    {}
    break;

  case 203:
#line 1370 "gram.y"
    {}
    break;

  case 204:
#line 1383 "gram.y"
    {
					CreateStmt *n = makeNode(CreateStmt);
					yyvsp[-5].range->istemp = yyvsp[-7].boolean;
					n->relation = yyvsp[-5].range;
					n->tableElts = yyvsp[-3].list;
					n->inhRelations = yyvsp[-1].list;
					n->constraints = NIL;
					n->hasoids = yyvsp[0].boolean;
					yyval.node = (Node *)n;
				}
    break;

  case 205:
#line 1395 "gram.y"
    {
					/* SQL99 CREATE TABLE OF <UDT> (cols) seems to be satisfied
					 * by our inheritance capabilities. Let's try it...
					 */
					CreateStmt *n = makeNode(CreateStmt);
					yyvsp[-6].range->istemp = yyvsp[-8].boolean;
					n->relation = yyvsp[-6].range;
					n->tableElts = yyvsp[-2].list;
					n->inhRelations = makeList1(yyvsp[-4].range);
					n->constraints = NIL;
					n->hasoids = yyvsp[0].boolean;
					yyval.node = (Node *)n;
				}
    break;

  case 206:
#line 1417 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 207:
#line 1418 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 208:
#line 1419 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 209:
#line 1420 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 210:
#line 1421 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 211:
#line 1422 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 212:
#line 1423 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 213:
#line 1427 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 214:
#line 1428 "gram.y"
    { yyval.list = NIL; }
    break;

  case 215:
#line 1433 "gram.y"
    {
					yyval.list = makeList1(yyvsp[0].node);
				}
    break;

  case 216:
#line 1437 "gram.y"
    {
					yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node);
				}
    break;

  case 217:
#line 1443 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 218:
#line 1444 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 219:
#line 1445 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 220:
#line 1449 "gram.y"
    {
					ColumnDef *n = makeNode(ColumnDef);
					n->colname = yyvsp[-3].str;
					n->typename = yyvsp[-2].typnam;
					n->constraints = yyvsp[-1].list;
					n->is_local = true;

					if (yyvsp[0].str != NULL)
						elog(NOTICE,
							 "CREATE TABLE / COLLATE %s not yet implemented; "
							 "clause ignored", yyvsp[0].str);

					yyval.node = (Node *)n;
				}
    break;

  case 221:
#line 1466 "gram.y"
    { yyval.list = lappend(yyvsp[-1].list, yyvsp[0].node); }
    break;

  case 222:
#line 1467 "gram.y"
    { yyval.list = NIL; }
    break;

  case 223:
#line 1472 "gram.y"
    {
					switch (nodeTag(yyvsp[0].node))
					{
						case T_Constraint:
							{
								Constraint *n = (Constraint *)yyvsp[0].node;
								n->name = yyvsp[-1].str;
							}
							break;
						case T_FkConstraint:
							{
								FkConstraint *n = (FkConstraint *)yyvsp[0].node;
								n->constr_name = yyvsp[-1].str;
							}
							break;
						default:
							break;
					}
					yyval.node = yyvsp[0].node;
				}
    break;

  case 224:
#line 1492 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 225:
#line 1493 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 226:
#line 1513 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_NOTNULL;
					n->name = NULL;
					n->raw_expr = NULL;
					n->cooked_expr = NULL;
					n->keys = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 227:
#line 1523 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_NULL;
					n->name = NULL;
					n->raw_expr = NULL;
					n->cooked_expr = NULL;
					n->keys = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 228:
#line 1533 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_UNIQUE;
					n->name = NULL;
					n->raw_expr = NULL;
					n->cooked_expr = NULL;
					n->keys = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 229:
#line 1543 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_PRIMARY;
					n->name = NULL;
					n->raw_expr = NULL;
					n->cooked_expr = NULL;
					n->keys = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 230:
#line 1553 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_CHECK;
					n->name = NULL;
					n->raw_expr = yyvsp[-1].node;
					n->cooked_expr = NULL;
					n->keys = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 231:
#line 1563 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_DEFAULT;
					n->name = NULL;
					if (exprIsNullConstant(yyvsp[0].node))
					{
						/* DEFAULT NULL should be reported as empty expr */
						n->raw_expr = NULL;
					}
					else
					{
						n->raw_expr = yyvsp[0].node;
					}
					n->cooked_expr = NULL;
					n->keys = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 232:
#line 1581 "gram.y"
    {
					FkConstraint *n = makeNode(FkConstraint);
					n->constr_name		= NULL;
					n->pktable			= yyvsp[-3].range;
					n->fk_attrs			= NIL;
					n->pk_attrs			= yyvsp[-2].list;
					n->fk_matchtype		= yyvsp[-1].ival;
					n->fk_upd_action	= (char) (yyvsp[0].ival >> 8);
					n->fk_del_action	= (char) (yyvsp[0].ival & 0xFF);
					n->deferrable		= FALSE;
					n->initdeferred		= FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 233:
#line 1609 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_ATTR_DEFERRABLE;
					yyval.node = (Node *)n;
				}
    break;

  case 234:
#line 1615 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_ATTR_NOT_DEFERRABLE;
					yyval.node = (Node *)n;
				}
    break;

  case 235:
#line 1621 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_ATTR_DEFERRED;
					yyval.node = (Node *)n;
				}
    break;

  case 236:
#line 1627 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_ATTR_IMMEDIATE;
					yyval.node = (Node *)n;
				}
    break;

  case 237:
#line 1641 "gram.y"
    {
					elog(ERROR, "LIKE in table definitions not yet supported");
					yyval.node = NULL;
				}
    break;

  case 238:
#line 1654 "gram.y"
    {
					switch (nodeTag(yyvsp[0].node))
					{
						case T_Constraint:
							{
								Constraint *n = (Constraint *)yyvsp[0].node;
								n->name = yyvsp[-1].str;
							}
							break;
						case T_FkConstraint:
							{
								FkConstraint *n = (FkConstraint *)yyvsp[0].node;
								n->constr_name = yyvsp[-1].str;
							}
							break;
						default:
							break;
					}
					yyval.node = yyvsp[0].node;
				}
    break;

  case 239:
#line 1674 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 240:
#line 1679 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_CHECK;
					n->name = NULL;
					n->raw_expr = yyvsp[-1].node;
					n->cooked_expr = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 241:
#line 1688 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_UNIQUE;
					n->name = NULL;
					n->raw_expr = NULL;
					n->cooked_expr = NULL;
					n->keys = yyvsp[-1].list;
					yyval.node = (Node *)n;
				}
    break;

  case 242:
#line 1698 "gram.y"
    {
					Constraint *n = makeNode(Constraint);
					n->contype = CONSTR_PRIMARY;
					n->name = NULL;
					n->raw_expr = NULL;
					n->cooked_expr = NULL;
					n->keys = yyvsp[-1].list;
					yyval.node = (Node *)n;
				}
    break;

  case 243:
#line 1709 "gram.y"
    {
					FkConstraint *n = makeNode(FkConstraint);
					n->constr_name		= NULL;
					n->pktable			= yyvsp[-4].range;
					n->fk_attrs			= yyvsp[-7].list;
					n->pk_attrs			= yyvsp[-3].list;
					n->fk_matchtype		= yyvsp[-2].ival;
					n->fk_upd_action	= (char) (yyvsp[-1].ival >> 8);
					n->fk_del_action	= (char) (yyvsp[-1].ival & 0xFF);
					n->deferrable		= (yyvsp[0].ival & 1) != 0;
					n->initdeferred		= (yyvsp[0].ival & 2) != 0;
					yyval.node = (Node *)n;
				}
    break;

  case 244:
#line 1725 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 245:
#line 1726 "gram.y"
    { yyval.list = NIL; }
    break;

  case 246:
#line 1730 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 247:
#line 1731 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 248:
#line 1735 "gram.y"
    {
					yyval.node = (Node *) makeString(yyvsp[0].str);
				}
    break;

  case 249:
#line 1741 "gram.y"
    {
				yyval.ival = FKCONSTR_MATCH_FULL;
			}
    break;

  case 250:
#line 1745 "gram.y"
    {
				elog(ERROR, "FOREIGN KEY/MATCH PARTIAL not yet implemented");
				yyval.ival = FKCONSTR_MATCH_PARTIAL;
			}
    break;

  case 251:
#line 1750 "gram.y"
    {
				yyval.ival = FKCONSTR_MATCH_UNSPECIFIED;
			}
    break;

  case 252:
#line 1754 "gram.y"
    {
				yyval.ival = FKCONSTR_MATCH_UNSPECIFIED;
			}
    break;

  case 253:
#line 1767 "gram.y"
    { yyval.ival = (yyvsp[0].ival << 8) | (FKCONSTR_ACTION_NOACTION & 0xFF); }
    break;

  case 254:
#line 1769 "gram.y"
    { yyval.ival = (FKCONSTR_ACTION_NOACTION << 8) | (yyvsp[0].ival & 0xFF); }
    break;

  case 255:
#line 1771 "gram.y"
    { yyval.ival = (yyvsp[-1].ival << 8) | (yyvsp[0].ival & 0xFF); }
    break;

  case 256:
#line 1773 "gram.y"
    { yyval.ival = (yyvsp[0].ival << 8) | (yyvsp[-1].ival & 0xFF); }
    break;

  case 257:
#line 1775 "gram.y"
    { yyval.ival = (FKCONSTR_ACTION_NOACTION << 8) | (FKCONSTR_ACTION_NOACTION & 0xFF); }
    break;

  case 258:
#line 1778 "gram.y"
    { yyval.ival = yyvsp[0].ival; }
    break;

  case 259:
#line 1781 "gram.y"
    { yyval.ival = yyvsp[0].ival; }
    break;

  case 260:
#line 1785 "gram.y"
    { yyval.ival = FKCONSTR_ACTION_NOACTION; }
    break;

  case 261:
#line 1786 "gram.y"
    { yyval.ival = FKCONSTR_ACTION_RESTRICT; }
    break;

  case 262:
#line 1787 "gram.y"
    { yyval.ival = FKCONSTR_ACTION_CASCADE; }
    break;

  case 263:
#line 1788 "gram.y"
    { yyval.ival = FKCONSTR_ACTION_SETNULL; }
    break;

  case 264:
#line 1789 "gram.y"
    { yyval.ival = FKCONSTR_ACTION_SETDEFAULT; }
    break;

  case 265:
#line 1792 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 266:
#line 1793 "gram.y"
    { yyval.list = NIL; }
    break;

  case 267:
#line 1797 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 268:
#line 1798 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 269:
#line 1799 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 270:
#line 1810 "gram.y"
    {
					/*
					 * When the SelectStmt is a set-operation tree, we must
					 * stuff the INTO information into the leftmost component
					 * Select, because that's where analyze.c will expect
					 * to find it.	Similarly, the output column names must
					 * be attached to that Select's target list.
					 */
					SelectStmt *n = findLeftmostSelect((SelectStmt *) yyvsp[0].node);
					if (n->into != NULL)
						elog(ERROR, "CREATE TABLE AS may not specify INTO");
					yyvsp[-3].range->istemp = yyvsp[-5].boolean;
					n->into = yyvsp[-3].range;
					n->intoColNames = yyvsp[-2].list;
					yyval.node = yyvsp[0].node;
				}
    break;

  case 271:
#line 1829 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 272:
#line 1830 "gram.y"
    { yyval.list = NIL; }
    break;

  case 273:
#line 1834 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 274:
#line 1835 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 275:
#line 1840 "gram.y"
    {
					ColumnDef *n = makeNode(ColumnDef);
					n->colname = yyvsp[0].str;
					n->typename = NULL;
					n->inhcount = 0;
					n->is_local = true;
					n->is_not_null = false;
					n->raw_default = NULL;
					n->cooked_default = NULL;
					n->constraints = NIL;
					n->support = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 276:
#line 1865 "gram.y"
    {
					CreateSeqStmt *n = makeNode(CreateSeqStmt);
					yyvsp[-1].range->istemp = yyvsp[-3].boolean;
					n->sequence = yyvsp[-1].range;
					n->options = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 277:
#line 1874 "gram.y"
    { yyval.list = lappend(yyvsp[-1].list, yyvsp[0].defelt); }
    break;

  case 278:
#line 1875 "gram.y"
    { yyval.list = NIL; }
    break;

  case 279:
#line 1879 "gram.y"
    {
					yyval.defelt = makeDefElem("cache", (Node *)yyvsp[0].value);
				}
    break;

  case 280:
#line 1883 "gram.y"
    {
					yyval.defelt = makeDefElem("cycle", (Node *)NULL);
				}
    break;

  case 281:
#line 1887 "gram.y"
    {
					yyval.defelt = makeDefElem("increment", (Node *)yyvsp[0].value);
				}
    break;

  case 282:
#line 1891 "gram.y"
    {
					yyval.defelt = makeDefElem("maxvalue", (Node *)yyvsp[0].value);
				}
    break;

  case 283:
#line 1895 "gram.y"
    {
					yyval.defelt = makeDefElem("minvalue", (Node *)yyvsp[0].value);
				}
    break;

  case 284:
#line 1899 "gram.y"
    {
					yyval.defelt = makeDefElem("start", (Node *)yyvsp[0].value);
				}
    break;

  case 285:
#line 1905 "gram.y"
    { yyval.value = yyvsp[0].value; }
    break;

  case 286:
#line 1906 "gram.y"
    { yyval.value = yyvsp[0].value; }
    break;

  case 287:
#line 1909 "gram.y"
    { yyval.value = makeFloat(yyvsp[0].str); }
    break;

  case 288:
#line 1911 "gram.y"
    {
					yyval.value = makeFloat(yyvsp[0].str);
					doNegateFloat(yyval.value);
				}
    break;

  case 289:
#line 1919 "gram.y"
    {
					yyval.value = makeInteger(yyvsp[0].ival);
				}
    break;

  case 290:
#line 1923 "gram.y"
    {
					yyval.value = makeInteger(yyvsp[0].ival);
					yyval.value->val.ival = - yyval.value->val.ival;
				}
    break;

  case 291:
#line 1940 "gram.y"
    {
				CreatePLangStmt *n = makeNode(CreatePLangStmt);
				n->plname = yyvsp[-4].str;
				n->plhandler = yyvsp[-2].list;
				n->plvalidator = yyvsp[-1].list;
				n->pltrusted = yyvsp[-7].boolean;
				yyval.node = (Node *)n;
			}
    break;

  case 292:
#line 1951 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 293:
#line 1952 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 294:
#line 1961 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 295:
#line 1962 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 296:
#line 1966 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 297:
#line 1967 "gram.y"
    { yyval.str = ""; }
    break;

  case 298:
#line 1971 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 299:
#line 1972 "gram.y"
    { yyval.list = NULL; }
    break;

  case 300:
#line 1977 "gram.y"
    {
					DropPLangStmt *n = makeNode(DropPLangStmt);
					n->plname = yyvsp[-1].str;
					n->behavior = yyvsp[0].dbehavior;
					yyval.node = (Node *)n;
				}
    break;

  case 301:
#line 1986 "gram.y"
    {}
    break;

  case 302:
#line 1987 "gram.y"
    {}
    break;

  case 303:
#line 2002 "gram.y"
    {
					CreateTrigStmt *n = makeNode(CreateTrigStmt);
					n->trigname = yyvsp[-11].str;
					n->relation = yyvsp[-7].range;
					n->funcname = yyvsp[-3].list;
					n->args = yyvsp[-1].list;
					n->before = yyvsp[-10].boolean;
					n->row = yyvsp[-6].boolean;
					memcpy (n->actions, yyvsp[-9].str, 4);
					n->lang = NULL;		/* unused */
					n->text = NULL;		/* unused */
					n->attr = NULL;		/* unused */
					n->when = NULL;		/* unused */

					n->isconstraint  = FALSE;
					n->deferrable	 = FALSE;
					n->initdeferred  = FALSE;
					n->constrrel = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 304:
#line 2027 "gram.y"
    {
					CreateTrigStmt *n = makeNode(CreateTrigStmt);
					n->trigname = yyvsp[-15].str;
					n->relation = yyvsp[-11].range;
					n->funcname = yyvsp[-3].list;
					n->args = yyvsp[-1].list;
					n->before = FALSE;
					n->row = TRUE;
					memcpy (n->actions, yyvsp[-13].str, 4);
					n->lang = NULL;		/* unused */
					n->text = NULL;		/* unused */
					n->attr = NULL;		/* unused */
					n->when = NULL;		/* unused */

					n->isconstraint  = TRUE;
					n->deferrable = (yyvsp[-9].ival & 1) != 0;
					n->initdeferred = (yyvsp[-9].ival & 2) != 0;

					n->constrrel = yyvsp[-10].range;
					yyval.node = (Node *)n;
				}
    break;

  case 305:
#line 2051 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 306:
#line 2052 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 307:
#line 2057 "gram.y"
    {
					char *e = palloc (4);
					e[0] = yyvsp[0].chr; e[1] = 0; yyval.str = e;
				}
    break;

  case 308:
#line 2062 "gram.y"
    {
					char *e = palloc (4);
					e[0] = yyvsp[-2].chr; e[1] = yyvsp[0].chr; e[2] = 0; yyval.str = e;
				}
    break;

  case 309:
#line 2067 "gram.y"
    {
					char *e = palloc (4);
					e[0] = yyvsp[-4].chr; e[1] = yyvsp[-2].chr; e[2] = yyvsp[0].chr; e[3] = 0;
					yyval.str = e;
				}
    break;

  case 310:
#line 2075 "gram.y"
    { yyval.chr = 'i'; }
    break;

  case 311:
#line 2076 "gram.y"
    { yyval.chr = 'd'; }
    break;

  case 312:
#line 2077 "gram.y"
    { yyval.chr = 'u'; }
    break;

  case 313:
#line 2082 "gram.y"
    {
					yyval.boolean = yyvsp[0].boolean;
				}
    break;

  case 314:
#line 2088 "gram.y"
    {}
    break;

  case 315:
#line 2089 "gram.y"
    {}
    break;

  case 316:
#line 2093 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 317:
#line 2094 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 318:
#line 2098 "gram.y"
    { yyval.list = makeList1(yyvsp[0].value); }
    break;

  case 319:
#line 2099 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].value); }
    break;

  case 320:
#line 2100 "gram.y"
    { yyval.list = NIL; }
    break;

  case 321:
#line 2105 "gram.y"
    {
					char buf[64];
					snprintf (buf, sizeof(buf), "%d", yyvsp[0].ival);
					yyval.value = makeString(pstrdup(buf));
				}
    break;

  case 322:
#line 2110 "gram.y"
    { yyval.value = makeString(yyvsp[0].str); }
    break;

  case 323:
#line 2111 "gram.y"
    { yyval.value = makeString(yyvsp[0].str); }
    break;

  case 324:
#line 2112 "gram.y"
    { yyval.value = makeString(yyvsp[0].str); }
    break;

  case 325:
#line 2113 "gram.y"
    { yyval.value = makeString(yyvsp[0].str); }
    break;

  case 326:
#line 2114 "gram.y"
    { yyval.value = makeString(yyvsp[0].str); }
    break;

  case 327:
#line 2118 "gram.y"
    { yyval.range = yyvsp[0].range; }
    break;

  case 328:
#line 2119 "gram.y"
    { yyval.range = NULL; }
    break;

  case 329:
#line 2124 "gram.y"
    { yyval.ival = yyvsp[0].ival; }
    break;

  case 330:
#line 2126 "gram.y"
    {
					if (yyvsp[-1].ival == 0 && yyvsp[0].ival != 0)
						elog(ERROR,
						"INITIALLY DEFERRED constraint must be DEFERRABLE");
					yyval.ival = yyvsp[-1].ival | yyvsp[0].ival;
				}
    break;

  case 331:
#line 2133 "gram.y"
    {
					if (yyvsp[0].ival != 0)
						yyval.ival = 3;
					else
						yyval.ival = 0;
				}
    break;

  case 332:
#line 2140 "gram.y"
    {
					if (yyvsp[0].ival == 0 && yyvsp[-1].ival != 0)
						elog(ERROR,
						"INITIALLY DEFERRED constraint must be DEFERRABLE");
					yyval.ival = yyvsp[-1].ival | yyvsp[0].ival;
				}
    break;

  case 333:
#line 2147 "gram.y"
    { yyval.ival = 0; }
    break;

  case 334:
#line 2151 "gram.y"
    { yyval.ival = 0; }
    break;

  case 335:
#line 2152 "gram.y"
    { yyval.ival = 1; }
    break;

  case 336:
#line 2156 "gram.y"
    { yyval.ival = 0; }
    break;

  case 337:
#line 2157 "gram.y"
    { yyval.ival = 2; }
    break;

  case 338:
#line 2163 "gram.y"
    {
					DropPropertyStmt *n = makeNode(DropPropertyStmt);
					n->relation = yyvsp[-1].range;
					n->property = yyvsp[-3].str;
					n->behavior = yyvsp[0].dbehavior;
					n->removeType = DROP_TRIGGER;
					yyval.node = (Node *) n;
				}
    break;

  case 339:
#line 2185 "gram.y"
    {
					CreateTrigStmt *n = makeNode(CreateTrigStmt);
					n->trigname = yyvsp[-5].str;
					n->args = makeList1(yyvsp[-2].node);
					n->isconstraint  = TRUE;
					n->deferrable = (yyvsp[0].ival & 1) != 0;
					n->initdeferred = (yyvsp[0].ival & 2) != 0;

					elog(ERROR, "CREATE ASSERTION is not yet supported");

					yyval.node = (Node *)n;
				}
    break;

  case 340:
#line 2201 "gram.y"
    {
					DropPropertyStmt *n = makeNode(DropPropertyStmt);
					n->relation = NULL;
					n->property = yyvsp[-1].str;
					n->behavior = yyvsp[0].dbehavior;
					n->removeType = DROP_TRIGGER; /* XXX */
					elog(ERROR, "DROP ASSERTION is not yet supported");
					yyval.node = (Node *) n;
				}
    break;

  case 341:
#line 2222 "gram.y"
    {
					DefineStmt *n = makeNode(DefineStmt);
					n->defType = AGGREGATE;
					n->defnames = yyvsp[-1].list;
					n->definition = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 342:
#line 2230 "gram.y"
    {
					DefineStmt *n = makeNode(DefineStmt);
					n->defType = OPERATOR;
					n->defnames = yyvsp[-1].list;
					n->definition = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 343:
#line 2238 "gram.y"
    {
					DefineStmt *n = makeNode(DefineStmt);
					n->defType = TYPE_P;
					n->defnames = yyvsp[-1].list;
					n->definition = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 344:
#line 2246 "gram.y"
    {
					CompositeTypeStmt *n = makeNode(CompositeTypeStmt);
					RangeVar *r = makeNode(RangeVar);

					/* can't use qualified_name, sigh */
					switch (length(yyvsp[-4].list))
					{
						case 1:
							r->catalogname = NULL;
							r->schemaname = NULL;
							r->relname = strVal(lfirst(yyvsp[-4].list));
							break;
						case 2:
							r->catalogname = NULL;
							r->schemaname = strVal(lfirst(yyvsp[-4].list));
							r->relname = strVal(lsecond(yyvsp[-4].list));
							break;
						case 3:
							r->catalogname = strVal(lfirst(yyvsp[-4].list));
							r->schemaname = strVal(lsecond(yyvsp[-4].list));
							r->relname = strVal(lfirst(lnext(lnext(yyvsp[-4].list))));
							break;
						default:
							elog(ERROR,
								 "Improper qualified name (too many dotted names): %s",
								 NameListToString(yyvsp[-4].list));
							break;
					}
					n->typevar = r;
					n->coldeflist = yyvsp[-1].list;
					yyval.node = (Node *)n;
				}
    break;

  case 345:
#line 2279 "gram.y"
    {
					DefineStmt *n = makeNode(DefineStmt);
					n->defType = CHARACTER;
					n->defnames = yyvsp[-3].list;
					n->definition = yyvsp[-1].list;
					yyval.node = (Node *)n;
				}
    break;

  case 346:
#line 2288 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 347:
#line 2291 "gram.y"
    { yyval.list = makeList1(yyvsp[0].defelt); }
    break;

  case 348:
#line 2292 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].defelt); }
    break;

  case 349:
#line 2296 "gram.y"
    {
					yyval.defelt = makeDefElem(yyvsp[-2].str, (Node *)yyvsp[0].node);
				}
    break;

  case 350:
#line 2300 "gram.y"
    {
					yyval.defelt = makeDefElem(yyvsp[0].str, (Node *)NULL);
				}
    break;

  case 351:
#line 2306 "gram.y"
    { yyval.node = (Node *)yyvsp[0].typnam; }
    break;

  case 352:
#line 2307 "gram.y"
    { yyval.node = (Node *)yyvsp[0].list; }
    break;

  case 353:
#line 2308 "gram.y"
    { yyval.node = (Node *)yyvsp[0].value; }
    break;

  case 354:
#line 2309 "gram.y"
    { yyval.node = (Node *)makeString(yyvsp[0].str); }
    break;

  case 355:
#line 2324 "gram.y"
    {
					CreateOpClassStmt *n = makeNode(CreateOpClassStmt);
					n->opclassname = yyvsp[-8].list;
					n->isDefault = yyvsp[-7].boolean;
					n->datatype = yyvsp[-4].typnam;
					n->amname = yyvsp[-2].str;
					n->items = yyvsp[0].list;
					yyval.node = (Node *) n;
				}
    break;

  case 356:
#line 2336 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 357:
#line 2337 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 358:
#line 2342 "gram.y"
    {
					CreateOpClassItem *n = makeNode(CreateOpClassItem);
					n->itemtype = OPCLASS_ITEM_OPERATOR;
					n->name = yyvsp[-1].list;
					n->args = NIL;
					n->number = yyvsp[-2].ival;
					n->recheck = yyvsp[0].boolean;
					yyval.node = (Node *) n;
				}
    break;

  case 359:
#line 2352 "gram.y"
    {
					CreateOpClassItem *n = makeNode(CreateOpClassItem);
					n->itemtype = OPCLASS_ITEM_OPERATOR;
					n->name = yyvsp[-4].list;
					n->args = yyvsp[-2].list;
					n->number = yyvsp[-5].ival;
					n->recheck = yyvsp[0].boolean;
					yyval.node = (Node *) n;
				}
    break;

  case 360:
#line 2362 "gram.y"
    {
					CreateOpClassItem *n = makeNode(CreateOpClassItem);
					n->itemtype = OPCLASS_ITEM_FUNCTION;
					n->name = yyvsp[-1].list;
					n->args = yyvsp[0].list;
					n->number = yyvsp[-2].ival;
					yyval.node = (Node *) n;
				}
    break;

  case 361:
#line 2371 "gram.y"
    {
					CreateOpClassItem *n = makeNode(CreateOpClassItem);
					n->itemtype = OPCLASS_ITEM_STORAGETYPE;
					n->storedtype = yyvsp[0].typnam;
					yyval.node = (Node *) n;
				}
    break;

  case 362:
#line 2379 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 363:
#line 2380 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 364:
#line 2383 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 365:
#line 2384 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 366:
#line 2390 "gram.y"
    {
					RemoveOpClassStmt *n = makeNode(RemoveOpClassStmt);
					n->opclassname = yyvsp[-3].list;
					n->amname = yyvsp[-1].str;
					n->behavior = yyvsp[0].dbehavior;
					yyval.node = (Node *) n;
				}
    break;

  case 367:
#line 2409 "gram.y"
    {
					DropStmt *n = makeNode(DropStmt);
					n->removeType = yyvsp[-2].ival;
					n->objects = yyvsp[-1].list;
					n->behavior = yyvsp[0].dbehavior;
					yyval.node = (Node *)n;
				}
    break;

  case 368:
#line 2418 "gram.y"
    { yyval.ival = DROP_TABLE; }
    break;

  case 369:
#line 2419 "gram.y"
    { yyval.ival = DROP_SEQUENCE; }
    break;

  case 370:
#line 2420 "gram.y"
    { yyval.ival = DROP_VIEW; }
    break;

  case 371:
#line 2421 "gram.y"
    { yyval.ival = DROP_INDEX; }
    break;

  case 372:
#line 2422 "gram.y"
    { yyval.ival = DROP_TYPE; }
    break;

  case 373:
#line 2423 "gram.y"
    { yyval.ival = DROP_DOMAIN; }
    break;

  case 374:
#line 2424 "gram.y"
    { yyval.ival = DROP_CONVERSION; }
    break;

  case 375:
#line 2425 "gram.y"
    { yyval.ival = DROP_SCHEMA; }
    break;

  case 376:
#line 2429 "gram.y"
    { yyval.list = makeList1(yyvsp[0].list); }
    break;

  case 377:
#line 2430 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].list); }
    break;

  case 378:
#line 2433 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 379:
#line 2434 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 380:
#line 2446 "gram.y"
    {
					TruncateStmt *n = makeNode(TruncateStmt);
					n->relation = yyvsp[0].range;
					yyval.node = (Node *)n;
				}
    break;

  case 381:
#line 2468 "gram.y"
    {
					CommentStmt *n = makeNode(CommentStmt);
					n->objtype = yyvsp[-3].ival;
					n->objname = yyvsp[-2].list;
					n->objargs = NIL;
					n->comment = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 382:
#line 2478 "gram.y"
    {
					CommentStmt *n = makeNode(CommentStmt);
					n->objtype = COMMENT_ON_AGGREGATE;
					n->objname = yyvsp[-5].list;
					n->objargs = makeList1(yyvsp[-3].typnam);
					n->comment = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 383:
#line 2487 "gram.y"
    {
					CommentStmt *n = makeNode(CommentStmt);
					n->objtype = COMMENT_ON_FUNCTION;
					n->objname = yyvsp[-3].list;
					n->objargs = yyvsp[-2].list;
					n->comment = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 384:
#line 2497 "gram.y"
    {
					CommentStmt *n = makeNode(CommentStmt);
					n->objtype = COMMENT_ON_OPERATOR;
					n->objname = yyvsp[-5].list;
					n->objargs = yyvsp[-3].list;
					n->comment = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 385:
#line 2506 "gram.y"
    {
					CommentStmt *n = makeNode(CommentStmt);
					n->objtype = COMMENT_ON_CONSTRAINT;
					n->objname = lappend(yyvsp[-2].list, makeString(yyvsp[-4].str));
					n->objargs = NIL;
					n->comment = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 386:
#line 2515 "gram.y"
    {
					CommentStmt *n = makeNode(CommentStmt);
					n->objtype = COMMENT_ON_RULE;
					n->objname = lappend(yyvsp[-2].list, makeString(yyvsp[-4].str));
					n->objargs = NIL;
					n->comment = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 387:
#line 2524 "gram.y"
    {
					/* Obsolete syntax supported for awhile for compatibility */
					CommentStmt *n = makeNode(CommentStmt);
					n->objtype = COMMENT_ON_RULE;
					n->objname = makeList1(makeString(yyvsp[-2].str));
					n->objargs = NIL;
					n->comment = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 388:
#line 2534 "gram.y"
    {
					CommentStmt *n = makeNode(CommentStmt);
					n->objtype = COMMENT_ON_TRIGGER;
					n->objname = lappend(yyvsp[-2].list, makeString(yyvsp[-4].str));
					n->objargs = NIL;
					n->comment = yyvsp[0].str;
					yyval.node = (Node *) n;
				}
    break;

  case 389:
#line 2545 "gram.y"
    { yyval.ival = COMMENT_ON_COLUMN; }
    break;

  case 390:
#line 2546 "gram.y"
    { yyval.ival = COMMENT_ON_DATABASE; }
    break;

  case 391:
#line 2547 "gram.y"
    { yyval.ival = COMMENT_ON_SCHEMA; }
    break;

  case 392:
#line 2548 "gram.y"
    { yyval.ival = COMMENT_ON_INDEX; }
    break;

  case 393:
#line 2549 "gram.y"
    { yyval.ival = COMMENT_ON_SEQUENCE; }
    break;

  case 394:
#line 2550 "gram.y"
    { yyval.ival = COMMENT_ON_TABLE; }
    break;

  case 395:
#line 2551 "gram.y"
    { yyval.ival = COMMENT_ON_TYPE; }
    break;

  case 396:
#line 2552 "gram.y"
    { yyval.ival = COMMENT_ON_TYPE; }
    break;

  case 397:
#line 2553 "gram.y"
    { yyval.ival = COMMENT_ON_VIEW; }
    break;

  case 398:
#line 2557 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 399:
#line 2558 "gram.y"
    { yyval.str = NULL; }
    break;

  case 400:
#line 2571 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					if (yyvsp[-3].ival == RELATIVE)
					{
						if (yyvsp[-2].ival == 0)
							elog(ERROR,
					"FETCH / RELATIVE at current position is not supported");
						yyvsp[-3].ival = FORWARD;
					}
					if (yyvsp[-2].ival < 0)
					{
						yyvsp[-2].ival = -yyvsp[-2].ival;
						yyvsp[-3].ival = ((yyvsp[-3].ival == FORWARD)? BACKWARD: FORWARD);
					}
					n->direction = yyvsp[-3].ival;
					n->howMany = yyvsp[-2].ival;
					n->portalname = yyvsp[0].str;
					n->ismove = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 401:
#line 2592 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					if (yyvsp[-2].ival < 0)
					{
						n->howMany = -yyvsp[-2].ival;
						n->direction = BACKWARD;
					}
					else
					{
						n->direction = FORWARD;
						n->howMany = yyvsp[-2].ival;
					}
					n->portalname = yyvsp[0].str;
					n->ismove = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 402:
#line 2609 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					if (yyvsp[-2].ival == RELATIVE)
					{
						yyvsp[-2].ival = FORWARD;
					}
					n->direction = yyvsp[-2].ival;
					n->howMany = 1;
					n->portalname = yyvsp[0].str;
					n->ismove = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 403:
#line 2622 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					n->direction = FORWARD;
					n->howMany = 1;
					n->portalname = yyvsp[0].str;
					n->ismove = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 404:
#line 2631 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					n->direction = FORWARD;
					n->howMany = 1;
					n->portalname = yyvsp[0].str;
					n->ismove = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 405:
#line 2640 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					if (yyvsp[-2].ival < 0)
					{
						yyvsp[-2].ival = -yyvsp[-2].ival;
						yyvsp[-3].ival = ((yyvsp[-3].ival == FORWARD)? BACKWARD: FORWARD);
					}
					n->direction = yyvsp[-3].ival;
					n->howMany = yyvsp[-2].ival;
					n->portalname = yyvsp[0].str;
					n->ismove = TRUE;
					yyval.node = (Node *)n;
				}
    break;

  case 406:
#line 2654 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					if (yyvsp[-2].ival < 0)
					{
						n->howMany = -yyvsp[-2].ival;
						n->direction = BACKWARD;
					}
					else
					{
						n->direction = FORWARD;
						n->howMany = yyvsp[-2].ival;
					}
					n->portalname = yyvsp[0].str;
					n->ismove = TRUE;
					yyval.node = (Node *)n;
				}
    break;

  case 407:
#line 2671 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					n->direction = yyvsp[-2].ival;
					n->howMany = 1;
					n->portalname = yyvsp[0].str;
					n->ismove = TRUE;
					yyval.node = (Node *)n;
				}
    break;

  case 408:
#line 2680 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					n->direction = FORWARD;
					n->howMany = 1;
					n->portalname = yyvsp[0].str;
					n->ismove = TRUE;
					yyval.node = (Node *)n;
				}
    break;

  case 409:
#line 2689 "gram.y"
    {
					FetchStmt *n = makeNode(FetchStmt);
					n->direction = FORWARD;
					n->howMany = 1;
					n->portalname = yyvsp[0].str;
					n->ismove = TRUE;
					yyval.node = (Node *)n;
				}
    break;

  case 410:
#line 2699 "gram.y"
    { yyval.ival = FORWARD; }
    break;

  case 411:
#line 2700 "gram.y"
    { yyval.ival = BACKWARD; }
    break;

  case 412:
#line 2701 "gram.y"
    { yyval.ival = RELATIVE; }
    break;

  case 413:
#line 2703 "gram.y"
    {
					elog(NOTICE,
					"FETCH / ABSOLUTE not supported, using RELATIVE");
					yyval.ival = RELATIVE;
				}
    break;

  case 414:
#line 2711 "gram.y"
    { yyval.ival = yyvsp[0].ival; }
    break;

  case 415:
#line 2712 "gram.y"
    { yyval.ival = - yyvsp[0].ival; }
    break;

  case 416:
#line 2714 "gram.y"
    { yyval.ival = 0; }
    break;

  case 417:
#line 2715 "gram.y"
    { yyval.ival = 1; }
    break;

  case 418:
#line 2716 "gram.y"
    { yyval.ival = -1; }
    break;

  case 419:
#line 2719 "gram.y"
    {}
    break;

  case 420:
#line 2720 "gram.y"
    {}
    break;

  case 421:
#line 2732 "gram.y"
    {
					GrantStmt *n = makeNode(GrantStmt);
					n->is_grant = true;
					n->privileges = yyvsp[-5].list;
					n->objtype = (yyvsp[-3].privtarget)->objtype;
					n->objects = (yyvsp[-3].privtarget)->objs;
					n->grantees = yyvsp[-1].list;
					yyval.node = (Node*)n;
				}
    break;

  case 422:
#line 2745 "gram.y"
    {
					GrantStmt *n = makeNode(GrantStmt);
					n->is_grant = false;
					n->privileges = yyvsp[-4].list;
					n->objtype = (yyvsp[-2].privtarget)->objtype;
					n->objects = (yyvsp[-2].privtarget)->objs;
					n->grantees = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 423:
#line 2758 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 424:
#line 2759 "gram.y"
    { yyval.list = makeListi1(ACL_ALL_RIGHTS); }
    break;

  case 425:
#line 2760 "gram.y"
    { yyval.list = makeListi1(ACL_ALL_RIGHTS); }
    break;

  case 426:
#line 2764 "gram.y"
    { yyval.list = makeListi1(yyvsp[0].ival); }
    break;

  case 427:
#line 2765 "gram.y"
    { yyval.list = lappendi(yyvsp[-2].list, yyvsp[0].ival); }
    break;

  case 428:
#line 2771 "gram.y"
    { yyval.ival = ACL_SELECT; }
    break;

  case 429:
#line 2772 "gram.y"
    { yyval.ival = ACL_INSERT; }
    break;

  case 430:
#line 2773 "gram.y"
    { yyval.ival = ACL_UPDATE; }
    break;

  case 431:
#line 2774 "gram.y"
    { yyval.ival = ACL_DELETE; }
    break;

  case 432:
#line 2775 "gram.y"
    { yyval.ival = ACL_RULE; }
    break;

  case 433:
#line 2776 "gram.y"
    { yyval.ival = ACL_REFERENCES; }
    break;

  case 434:
#line 2777 "gram.y"
    { yyval.ival = ACL_TRIGGER; }
    break;

  case 435:
#line 2778 "gram.y"
    { yyval.ival = ACL_EXECUTE; }
    break;

  case 436:
#line 2779 "gram.y"
    { yyval.ival = ACL_USAGE; }
    break;

  case 437:
#line 2780 "gram.y"
    { yyval.ival = ACL_CREATE; }
    break;

  case 438:
#line 2781 "gram.y"
    { yyval.ival = ACL_CREATE_TEMP; }
    break;

  case 439:
#line 2782 "gram.y"
    { yyval.ival = ACL_CREATE_TEMP; }
    break;

  case 440:
#line 2790 "gram.y"
    {
					PrivTarget *n = makeNode(PrivTarget);
					n->objtype = ACL_OBJECT_RELATION;
					n->objs = yyvsp[0].list;
					yyval.privtarget = n;
				}
    break;

  case 441:
#line 2797 "gram.y"
    {
					PrivTarget *n = makeNode(PrivTarget);
					n->objtype = ACL_OBJECT_RELATION;
					n->objs = yyvsp[0].list;
					yyval.privtarget = n;
				}
    break;

  case 442:
#line 2804 "gram.y"
    {
					PrivTarget *n = makeNode(PrivTarget);
					n->objtype = ACL_OBJECT_FUNCTION;
					n->objs = yyvsp[0].list;
					yyval.privtarget = n;
				}
    break;

  case 443:
#line 2811 "gram.y"
    {
					PrivTarget *n = makeNode(PrivTarget);
					n->objtype = ACL_OBJECT_DATABASE;
					n->objs = yyvsp[0].list;
					yyval.privtarget = n;
				}
    break;

  case 444:
#line 2818 "gram.y"
    {
					PrivTarget *n = makeNode(PrivTarget);
					n->objtype = ACL_OBJECT_LANGUAGE;
					n->objs = yyvsp[0].list;
					yyval.privtarget = n;
				}
    break;

  case 445:
#line 2825 "gram.y"
    {
					PrivTarget *n = makeNode(PrivTarget);
					n->objtype = ACL_OBJECT_NAMESPACE;
					n->objs = yyvsp[0].list;
					yyval.privtarget = n;
				}
    break;

  case 446:
#line 2835 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 447:
#line 2836 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 448:
#line 2840 "gram.y"
    {
					PrivGrantee *n = makeNode(PrivGrantee);
					/* This hack lets us avoid reserving PUBLIC as a keyword*/
					if (strcmp(yyvsp[0].str, "public") == 0)
						n->username = NULL;
					else
						n->username = yyvsp[0].str;
					n->groupname = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 449:
#line 2851 "gram.y"
    {
					PrivGrantee *n = makeNode(PrivGrantee);
					/* Treat GROUP PUBLIC as a synonym for PUBLIC */
					if (strcmp(yyvsp[0].str, "public") == 0)
						n->groupname = NULL;
					else
						n->groupname = yyvsp[0].str;
					n->username = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 450:
#line 2866 "gram.y"
    {
					elog(ERROR, "grant options are not implemented");
				}
    break;

  case 452:
#line 2874 "gram.y"
    {
					elog(ERROR, "grant options are not implemented");
				}
    break;

  case 454:
#line 2882 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 455:
#line 2884 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 456:
#line 2889 "gram.y"
    {
					FuncWithArgs *n = makeNode(FuncWithArgs);
					n->funcname = yyvsp[-1].list;
					n->funcargs = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 457:
#line 2909 "gram.y"
    {
					IndexStmt *n = makeNode(IndexStmt);
					n->unique = yyvsp[-9].boolean;
					n->idxname = yyvsp[-7].str;
					n->relation = yyvsp[-5].range;
					n->accessMethod = yyvsp[-4].str;
					n->indexParams = yyvsp[-2].list;
					n->whereClause = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 458:
#line 2922 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 459:
#line 2923 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 460:
#line 2927 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 461:
#line 2929 "gram.y"
    { yyval.str = DEFAULT_INDEX_TYPE; }
    break;

  case 462:
#line 2933 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 463:
#line 2934 "gram.y"
    { yyval.list = makeList1(yyvsp[0].ielem); }
    break;

  case 464:
#line 2937 "gram.y"
    { yyval.list = makeList1(yyvsp[0].ielem); }
    break;

  case 465:
#line 2938 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].ielem); }
    break;

  case 466:
#line 2942 "gram.y"
    {
					yyval.ielem = makeNode(IndexElem);
					yyval.ielem->name = NULL;
					yyval.ielem->funcname = yyvsp[-4].list;
					yyval.ielem->args = yyvsp[-2].list;
					yyval.ielem->opclass = yyvsp[0].list;
				}
    break;

  case 467:
#line 2952 "gram.y"
    {
					yyval.ielem = makeNode(IndexElem);
					yyval.ielem->name = yyvsp[-1].str;
					yyval.ielem->funcname = NIL;
					yyval.ielem->args = NIL;
					yyval.ielem->opclass = yyvsp[0].list;
				}
    break;

  case 468:
#line 2962 "gram.y"
    {
					/*
					 * Release 7.0 removed network_ops, timespan_ops, and
					 * datetime_ops, so we suppress it from being passed to
					 * the parser so the default *_ops is used.  This can be
					 * removed in some later release.  bjm 2000/02/07
					 *
					 * Release 7.1 removes lztext_ops, so suppress that too
					 * for a while.  tgl 2000/07/30
					 *
					 * Release 7.2 renames timestamp_ops to timestamptz_ops,
					 * so suppress that too for awhile.  I'm starting to
					 * think we need a better approach.  tgl 2000/10/01
					 */
					if (length(yyvsp[0].list) == 1)
					{
						char   *claname = strVal(lfirst(yyvsp[0].list));

						if (strcmp(claname, "network_ops") != 0 &&
							strcmp(claname, "timespan_ops") != 0 &&
							strcmp(claname, "datetime_ops") != 0 &&
							strcmp(claname, "lztext_ops") != 0 &&
							strcmp(claname, "timestamp_ops") != 0)
							yyval.list = yyvsp[0].list;
						else
							yyval.list = NIL;
					}
					else
						yyval.list = yyvsp[0].list;
				}
    break;

  case 469:
#line 2992 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 470:
#line 2993 "gram.y"
    { yyval.list = NIL; }
    break;

  case 471:
#line 3010 "gram.y"
    {
					CreateFunctionStmt *n = makeNode(CreateFunctionStmt);
					n->replace = yyvsp[-7].boolean;
					n->funcname = yyvsp[-5].list;
					n->argTypes = yyvsp[-4].list;
					n->returnType = yyvsp[-2].typnam;
					n->options = yyvsp[-1].list;
					n->withClause = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 472:
#line 3023 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 473:
#line 3024 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 474:
#line 3027 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 475:
#line 3028 "gram.y"
    { yyval.list = NIL; }
    break;

  case 476:
#line 3032 "gram.y"
    { yyval.list = makeList1(yyvsp[0].typnam); }
    break;

  case 477:
#line 3033 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].typnam); }
    break;

  case 478:
#line 3037 "gram.y"
    {
					/* We can catch over-specified arguments here if we want to,
					 * but for now better to silently swallow typmod, etc.
					 * - thomas 2000-03-22
					 */
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 479:
#line 3044 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 480:
#line 3047 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 481:
#line 3049 "gram.y"
    {
					elog(ERROR,
					"CREATE FUNCTION / OUT parameters are not supported");
					yyval.boolean = TRUE;
				}
    break;

  case 482:
#line 3055 "gram.y"
    {
					elog(ERROR,
					"CREATE FUNCTION / INOUT parameters are not supported");
					yyval.boolean = FALSE;
				}
    break;

  case 483:
#line 3064 "gram.y"
    {
					/* We can catch over-specified arguments here if we want to,
					 * but for now better to silently swallow typmod, etc.
					 * - thomas 2000-03-22
					 */
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 484:
#line 3077 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 485:
#line 3079 "gram.y"
    {
					yyval.typnam = makeNode(TypeName);
					yyval.typnam->names = lcons(makeString(yyvsp[-3].str), yyvsp[-2].list);
					yyval.typnam->pct_type = true;
					yyval.typnam->typmod = -1;
				}
    break;

  case 486:
#line 3090 "gram.y"
    { yyval.list = makeList1(yyvsp[0].defelt); }
    break;

  case 487:
#line 3091 "gram.y"
    { yyval.list = lappend(yyvsp[-1].list, yyvsp[0].defelt); }
    break;

  case 488:
#line 3096 "gram.y"
    {
					yyval.defelt = makeDefElem("as", (Node *)yyvsp[0].list);
				}
    break;

  case 489:
#line 3100 "gram.y"
    {
					yyval.defelt = makeDefElem("language", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 490:
#line 3104 "gram.y"
    {
					yyval.defelt = makeDefElem("volatility", (Node *)makeString("immutable"));
				}
    break;

  case 491:
#line 3108 "gram.y"
    {
					yyval.defelt = makeDefElem("volatility", (Node *)makeString("stable"));
				}
    break;

  case 492:
#line 3112 "gram.y"
    {
					yyval.defelt = makeDefElem("volatility", (Node *)makeString("volatile"));
				}
    break;

  case 493:
#line 3116 "gram.y"
    {
					yyval.defelt = makeDefElem("strict", (Node *)makeInteger(FALSE));
				}
    break;

  case 494:
#line 3120 "gram.y"
    {
					yyval.defelt = makeDefElem("strict", (Node *)makeInteger(TRUE));
				}
    break;

  case 495:
#line 3124 "gram.y"
    {
					yyval.defelt = makeDefElem("strict", (Node *)makeInteger(TRUE));
				}
    break;

  case 496:
#line 3128 "gram.y"
    {
					yyval.defelt = makeDefElem("security", (Node *)makeInteger(TRUE));
				}
    break;

  case 497:
#line 3132 "gram.y"
    {
					yyval.defelt = makeDefElem("security", (Node *)makeInteger(FALSE));
				}
    break;

  case 498:
#line 3136 "gram.y"
    {
					yyval.defelt = makeDefElem("security", (Node *)makeInteger(TRUE));
				}
    break;

  case 499:
#line 3140 "gram.y"
    {
					yyval.defelt = makeDefElem("security", (Node *)makeInteger(FALSE));
				}
    break;

  case 500:
#line 3145 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 501:
#line 3147 "gram.y"
    {
					yyval.list = makeList2(makeString(yyvsp[-2].str), makeString(yyvsp[0].str));
				}
    break;

  case 502:
#line 3153 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 503:
#line 3154 "gram.y"
    { yyval.list = NIL; }
    break;

  case 504:
#line 3170 "gram.y"
    {
					RemoveFuncStmt *n = makeNode(RemoveFuncStmt);
					n->funcname = yyvsp[-2].list;
					n->args = yyvsp[-1].list;
					n->behavior = yyvsp[0].dbehavior;
					yyval.node = (Node *)n;
				}
    break;

  case 505:
#line 3181 "gram.y"
    {
						RemoveAggrStmt *n = makeNode(RemoveAggrStmt);
						n->aggname = yyvsp[-4].list;
						n->aggtype = yyvsp[-2].typnam;
						n->behavior = yyvsp[0].dbehavior;
						yyval.node = (Node *)n;
				}
    break;

  case 506:
#line 3191 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 507:
#line 3192 "gram.y"
    { yyval.typnam = NULL; }
    break;

  case 508:
#line 3197 "gram.y"
    {
					RemoveOperStmt *n = makeNode(RemoveOperStmt);
					n->opname = yyvsp[-4].list;
					n->args = yyvsp[-2].list;
					n->behavior = yyvsp[0].dbehavior;
					yyval.node = (Node *)n;
				}
    break;

  case 509:
#line 3208 "gram.y"
    {
				   elog(ERROR, "parser: argument type missing (use NONE for unary operators)");
				}
    break;

  case 510:
#line 3212 "gram.y"
    { yyval.list = makeList2(yyvsp[-2].typnam, yyvsp[0].typnam); }
    break;

  case 511:
#line 3214 "gram.y"
    { yyval.list = makeList2(NULL, yyvsp[0].typnam); }
    break;

  case 512:
#line 3216 "gram.y"
    { yyval.list = makeList2(yyvsp[-2].typnam, NULL); }
    break;

  case 513:
#line 3221 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 514:
#line 3223 "gram.y"
    { yyval.list = lcons(makeString(yyvsp[-2].str), yyvsp[0].list); }
    break;

  case 515:
#line 3235 "gram.y"
    {
					CreateCastStmt *n = makeNode(CreateCastStmt);
					n->sourcetype = yyvsp[-7].typnam;
					n->targettype = yyvsp[-5].typnam;
					n->func = (FuncWithArgs *) yyvsp[-1].node;
					n->context = (CoercionContext) yyvsp[0].ival;
					yyval.node = (Node *)n;
				}
    break;

  case 516:
#line 3245 "gram.y"
    {
					CreateCastStmt *n = makeNode(CreateCastStmt);
					n->sourcetype = yyvsp[-6].typnam;
					n->targettype = yyvsp[-4].typnam;
					n->func = NULL;
					n->context = (CoercionContext) yyvsp[0].ival;
					yyval.node = (Node *)n;
				}
    break;

  case 517:
#line 3255 "gram.y"
    { yyval.ival = COERCION_IMPLICIT; }
    break;

  case 518:
#line 3256 "gram.y"
    { yyval.ival = COERCION_ASSIGNMENT; }
    break;

  case 519:
#line 3257 "gram.y"
    { yyval.ival = COERCION_EXPLICIT; }
    break;

  case 520:
#line 3262 "gram.y"
    {
					DropCastStmt *n = makeNode(DropCastStmt);
					n->sourcetype = yyvsp[-4].typnam;
					n->targettype = yyvsp[-2].typnam;
					n->behavior = yyvsp[0].dbehavior;
					yyval.node = (Node *)n;
				}
    break;

  case 521:
#line 3283 "gram.y"
    {
					ReindexStmt *n = makeNode(ReindexStmt);
					n->reindexType = yyvsp[-2].ival;
					n->relation = yyvsp[-1].range;
					n->name = NULL;
					n->force = yyvsp[0].boolean;
					yyval.node = (Node *)n;
				}
    break;

  case 522:
#line 3292 "gram.y"
    {
					ReindexStmt *n = makeNode(ReindexStmt);
					n->reindexType = DATABASE;
					n->name = yyvsp[-1].str;
					n->relation = NULL;
					n->force = yyvsp[0].boolean;
					yyval.node = (Node *)n;
				}
    break;

  case 523:
#line 3303 "gram.y"
    { yyval.ival = INDEX; }
    break;

  case 524:
#line 3304 "gram.y"
    { yyval.ival = TABLE; }
    break;

  case 525:
#line 3307 "gram.y"
    {  yyval.boolean = TRUE; }
    break;

  case 526:
#line 3308 "gram.y"
    {  yyval.boolean = FALSE; }
    break;

  case 527:
#line 3321 "gram.y"
    {
					RenameStmt *n = makeNode(RenameStmt);
					n->relation = yyvsp[-5].range;
					n->oldname = yyvsp[-2].str;
					n->newname = yyvsp[0].str;
					if (yyvsp[-2].str == NULL)
						n->renameType = RENAME_TABLE;
					else
						n->renameType = RENAME_COLUMN;
					yyval.node = (Node *)n;
				}
    break;

  case 528:
#line 3333 "gram.y"
    {
					RenameStmt *n = makeNode(RenameStmt);
					n->relation = yyvsp[-3].range;
					n->oldname = yyvsp[-5].str;
					n->newname = yyvsp[0].str;
					n->renameType = RENAME_TRIGGER;
					yyval.node = (Node *)n;
				}
    break;

  case 529:
#line 3343 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 530:
#line 3344 "gram.y"
    { yyval.str = NULL; }
    break;

  case 531:
#line 3347 "gram.y"
    { yyval.ival = COLUMN; }
    break;

  case 532:
#line 3348 "gram.y"
    { yyval.ival = 0; }
    break;

  case 533:
#line 3359 "gram.y"
    { QueryIsRule=TRUE; }
    break;

  case 534:
#line 3362 "gram.y"
    {
					RuleStmt *n = makeNode(RuleStmt);
					n->replace = yyvsp[-12].boolean;
					n->relation = yyvsp[-4].range;
					n->rulename = yyvsp[-10].str;
					n->whereClause = yyvsp[-3].node;
					n->event = yyvsp[-6].ival;
					n->instead = yyvsp[-1].boolean;
					n->actions = yyvsp[0].list;
					yyval.node = (Node *)n;
					QueryIsRule=FALSE;
				}
    break;

  case 535:
#line 3377 "gram.y"
    { yyval.list = NIL; }
    break;

  case 536:
#line 3378 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 537:
#line 3379 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 538:
#line 3385 "gram.y"
    { if (yyvsp[0].node != (Node *) NULL)
					yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node);
				  else
					yyval.list = yyvsp[-2].list;
				}
    break;

  case 539:
#line 3391 "gram.y"
    { if (yyvsp[0].node != (Node *) NULL)
					yyval.list = makeList1(yyvsp[0].node);
				  else
					yyval.list = NIL;
				}
    break;

  case 545:
#line 3407 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 546:
#line 3408 "gram.y"
    { yyval.node = (Node *)NULL; }
    break;

  case 547:
#line 3412 "gram.y"
    { yyval.ival = CMD_SELECT; }
    break;

  case 548:
#line 3413 "gram.y"
    { yyval.ival = CMD_UPDATE; }
    break;

  case 549:
#line 3414 "gram.y"
    { yyval.ival = CMD_DELETE; }
    break;

  case 550:
#line 3415 "gram.y"
    { yyval.ival = CMD_INSERT; }
    break;

  case 551:
#line 3419 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 552:
#line 3420 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 553:
#line 3426 "gram.y"
    {
					DropPropertyStmt *n = makeNode(DropPropertyStmt);
					n->relation = yyvsp[-1].range;
					n->property = yyvsp[-3].str;
					n->behavior = yyvsp[0].dbehavior;
					n->removeType = DROP_RULE;
					yyval.node = (Node *) n;
				}
    break;

  case 554:
#line 3446 "gram.y"
    {
					NotifyStmt *n = makeNode(NotifyStmt);
					n->relation = yyvsp[0].range;
					yyval.node = (Node *)n;
				}
    break;

  case 555:
#line 3454 "gram.y"
    {
					ListenStmt *n = makeNode(ListenStmt);
					n->relation = yyvsp[0].range;
					yyval.node = (Node *)n;
				}
    break;

  case 556:
#line 3463 "gram.y"
    {
					UnlistenStmt *n = makeNode(UnlistenStmt);
					n->relation = yyvsp[0].range;
					yyval.node = (Node *)n;
				}
    break;

  case 557:
#line 3469 "gram.y"
    {
					UnlistenStmt *n = makeNode(UnlistenStmt);
					n->relation = makeNode(RangeVar);
					n->relation->relname = "*";
					n->relation->schemaname = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 558:
#line 3490 "gram.y"
    {
					TransactionStmt *n = makeNode(TransactionStmt);
					n->command = ROLLBACK;
					n->options = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 559:
#line 3497 "gram.y"
    {
					TransactionStmt *n = makeNode(TransactionStmt);
					n->command = BEGIN_TRANS;
					n->options = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 560:
#line 3504 "gram.y"
    {
					TransactionStmt *n = makeNode(TransactionStmt);
					n->command = START;
					n->options = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 561:
#line 3511 "gram.y"
    {
					TransactionStmt *n = makeNode(TransactionStmt);
					n->command = COMMIT;
					n->options = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 562:
#line 3518 "gram.y"
    {
					TransactionStmt *n = makeNode(TransactionStmt);
					n->command = COMMIT;
					n->options = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 563:
#line 3525 "gram.y"
    {
					TransactionStmt *n = makeNode(TransactionStmt);
					n->command = ROLLBACK;
					n->options = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 564:
#line 3534 "gram.y"
    { yyval.list = makeList1(makeStringConst(yyvsp[0].str, NULL)); }
    break;

  case 565:
#line 3535 "gram.y"
    { yyval.list = NIL; }
    break;

  case 566:
#line 3538 "gram.y"
    {}
    break;

  case 567:
#line 3539 "gram.y"
    {}
    break;

  case 568:
#line 3540 "gram.y"
    {}
    break;

  case 569:
#line 3552 "gram.y"
    {
					ViewStmt *n = makeNode(ViewStmt);
					n->replace = yyvsp[-5].boolean;
					n->view = yyvsp[-3].range;
					n->aliases = yyvsp[-2].list;
					n->query = (Query *) yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 570:
#line 3571 "gram.y"
    {
					LoadStmt *n = makeNode(LoadStmt);
					n->filename = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 571:
#line 3587 "gram.y"
    {
					CreatedbStmt *n = makeNode(CreatedbStmt);
					n->dbname = yyvsp[-2].str;
					n->options = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 572:
#line 3596 "gram.y"
    { yyval.list = lappend(yyvsp[-1].list, yyvsp[0].defelt); }
    break;

  case 573:
#line 3597 "gram.y"
    { yyval.list = NIL; }
    break;

  case 574:
#line 3602 "gram.y"
    {
					yyval.defelt = makeDefElem("location", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 575:
#line 3606 "gram.y"
    {
					yyval.defelt = makeDefElem("location", NULL);
				}
    break;

  case 576:
#line 3610 "gram.y"
    {
					yyval.defelt = makeDefElem("template", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 577:
#line 3614 "gram.y"
    {
					yyval.defelt = makeDefElem("template", NULL);
				}
    break;

  case 578:
#line 3618 "gram.y"
    {
					yyval.defelt = makeDefElem("encoding", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 579:
#line 3622 "gram.y"
    {
					yyval.defelt = makeDefElem("encoding", (Node *)makeInteger(yyvsp[0].ival));
				}
    break;

  case 580:
#line 3626 "gram.y"
    {
					yyval.defelt = makeDefElem("encoding", NULL);
				}
    break;

  case 581:
#line 3630 "gram.y"
    {
					yyval.defelt = makeDefElem("owner", (Node *)makeString(yyvsp[0].str));
				}
    break;

  case 582:
#line 3634 "gram.y"
    {
					yyval.defelt = makeDefElem("owner", NULL);
				}
    break;

  case 583:
#line 3644 "gram.y"
    {}
    break;

  case 584:
#line 3645 "gram.y"
    {}
    break;

  case 585:
#line 3657 "gram.y"
    {
					AlterDatabaseSetStmt *n = makeNode(AlterDatabaseSetStmt);
					n->dbname = yyvsp[-2].str;
					n->variable = yyvsp[0].vsetstmt->name;
					n->value = yyvsp[0].vsetstmt->args;
					yyval.node = (Node *)n;
				}
    break;

  case 586:
#line 3665 "gram.y"
    {
					AlterDatabaseSetStmt *n = makeNode(AlterDatabaseSetStmt);
					n->dbname = yyvsp[-1].str;
					n->variable = ((VariableResetStmt *)yyvsp[0].node)->name;
					n->value = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 587:
#line 3683 "gram.y"
    {
					DropdbStmt *n = makeNode(DropdbStmt);
					n->dbname = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 588:
#line 3699 "gram.y"
    {
					CreateDomainStmt *n = makeNode(CreateDomainStmt);
					n->domainname = yyvsp[-4].list;
					n->typename = yyvsp[-2].typnam;
					n->constraints = yyvsp[-1].list;

					if (yyvsp[0].str != NULL)
						elog(NOTICE,"CREATE DOMAIN / COLLATE %s not yet "
							 "implemented; clause ignored", yyvsp[0].str);
					yyval.node = (Node *)n;
				}
    break;

  case 589:
#line 3712 "gram.y"
    {}
    break;

  case 590:
#line 3713 "gram.y"
    {}
    break;

  case 591:
#line 3729 "gram.y"
    {
			  CreateConversionStmt *n = makeNode(CreateConversionStmt);
			  n->conversion_name = yyvsp[-6].list;
			  n->for_encoding_name = yyvsp[-4].str;
			  n->to_encoding_name = yyvsp[-2].str;
			  n->func_name = yyvsp[0].list;
			  n->def = yyvsp[-8].boolean;
			  yyval.node = (Node *)n;
			}
    break;

  case 592:
#line 3749 "gram.y"
    {
				   ClusterStmt *n = makeNode(ClusterStmt);
				   n->relation = yyvsp[0].range;
				   n->indexname = yyvsp[-2].str;
				   yyval.node = (Node*)n;
				}
    break;

  case 593:
#line 3766 "gram.y"
    {
					VacuumStmt *n = makeNode(VacuumStmt);
					n->vacuum = true;
					n->analyze = false;
					n->full = yyvsp[-2].boolean;
					n->freeze = yyvsp[-1].boolean;
					n->verbose = yyvsp[0].boolean;
					n->relation = NULL;
					n->va_cols = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 594:
#line 3778 "gram.y"
    {
					VacuumStmt *n = makeNode(VacuumStmt);
					n->vacuum = true;
					n->analyze = false;
					n->full = yyvsp[-3].boolean;
					n->freeze = yyvsp[-2].boolean;
					n->verbose = yyvsp[-1].boolean;
					n->relation = yyvsp[0].range;
					n->va_cols = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 595:
#line 3790 "gram.y"
    {
					VacuumStmt *n = (VacuumStmt *) yyvsp[0].node;
					n->vacuum = true;
					n->full = yyvsp[-3].boolean;
					n->freeze = yyvsp[-2].boolean;
					n->verbose |= yyvsp[-1].boolean;
					yyval.node = (Node *)n;
				}
    break;

  case 596:
#line 3802 "gram.y"
    {
					VacuumStmt *n = makeNode(VacuumStmt);
					n->vacuum = false;
					n->analyze = true;
					n->full = false;
					n->freeze = false;
					n->verbose = yyvsp[0].boolean;
					n->relation = NULL;
					n->va_cols = NIL;
					yyval.node = (Node *)n;
				}
    break;

  case 597:
#line 3814 "gram.y"
    {
					VacuumStmt *n = makeNode(VacuumStmt);
					n->vacuum = false;
					n->analyze = true;
					n->full = false;
					n->freeze = false;
					n->verbose = yyvsp[-2].boolean;
					n->relation = yyvsp[-1].range;
					n->va_cols = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 598:
#line 3828 "gram.y"
    {}
    break;

  case 599:
#line 3829 "gram.y"
    {}
    break;

  case 600:
#line 3833 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 601:
#line 3834 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 602:
#line 3837 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 603:
#line 3838 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 604:
#line 3841 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 605:
#line 3842 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 606:
#line 3846 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 607:
#line 3847 "gram.y"
    { yyval.list = NIL; }
    break;

  case 608:
#line 3861 "gram.y"
    {
					ExplainStmt *n = makeNode(ExplainStmt);
					n->verbose = yyvsp[-1].boolean;
					n->analyze = FALSE;
					n->query = (Query*)yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 609:
#line 3869 "gram.y"
    {
					ExplainStmt *n = makeNode(ExplainStmt);
					n->verbose = yyvsp[-1].boolean;
					n->analyze = TRUE;
					n->query = (Query*)yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 610:
#line 3886 "gram.y"
    {
					PrepareStmt *n = makeNode(PrepareStmt);
					n->name = yyvsp[-3].str;
					n->argtypes = yyvsp[-2].list;
					n->query = (Query *) yyvsp[0].node;
					yyval.node = (Node *) n;
				}
    break;

  case 611:
#line 3895 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 612:
#line 3896 "gram.y"
    { yyval.list = NIL; }
    break;

  case 613:
#line 3899 "gram.y"
    { yyval.list = makeList1(yyvsp[0].typnam); }
    break;

  case 614:
#line 3901 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].typnam); }
    break;

  case 615:
#line 3912 "gram.y"
    {
					ExecuteStmt *n = makeNode(ExecuteStmt);
					n->name = yyvsp[-2].str;
					n->params = yyvsp[-1].list;
					n->into = yyvsp[0].range;
					yyval.node = (Node *) n;
				}
    break;

  case 616:
#line 3921 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 617:
#line 3922 "gram.y"
    { yyval.list = NIL; }
    break;

  case 618:
#line 3933 "gram.y"
    {
						DeallocateStmt *n = makeNode(DeallocateStmt);
						n->name = yyvsp[0].str;
						yyval.node = (Node *) n;
					}
    break;

  case 619:
#line 3939 "gram.y"
    {
						DeallocateStmt *n = makeNode(DeallocateStmt);
						n->name = yyvsp[0].str;
						yyval.node = (Node *) n;
					}
    break;

  case 625:
#line 3975 "gram.y"
    {
					yyvsp[0].istmt->relation = yyvsp[-1].range;
					yyval.node = (Node *) yyvsp[0].istmt;
				}
    break;

  case 626:
#line 3983 "gram.y"
    {
					yyval.istmt = makeNode(InsertStmt);
					yyval.istmt->cols = NIL;
					yyval.istmt->targetList = yyvsp[-1].list;
					yyval.istmt->selectStmt = NULL;
				}
    break;

  case 627:
#line 3990 "gram.y"
    {
					yyval.istmt = makeNode(InsertStmt);
					yyval.istmt->cols = NIL;
					yyval.istmt->targetList = NIL;
					yyval.istmt->selectStmt = NULL;
				}
    break;

  case 628:
#line 3997 "gram.y"
    {
					yyval.istmt = makeNode(InsertStmt);
					yyval.istmt->cols = NIL;
					yyval.istmt->targetList = NIL;
					yyval.istmt->selectStmt = yyvsp[0].node;
				}
    break;

  case 629:
#line 4004 "gram.y"
    {
					yyval.istmt = makeNode(InsertStmt);
					yyval.istmt->cols = yyvsp[-5].list;
					yyval.istmt->targetList = yyvsp[-1].list;
					yyval.istmt->selectStmt = NULL;
				}
    break;

  case 630:
#line 4011 "gram.y"
    {
					yyval.istmt = makeNode(InsertStmt);
					yyval.istmt->cols = yyvsp[-2].list;
					yyval.istmt->targetList = NIL;
					yyval.istmt->selectStmt = yyvsp[0].node;
				}
    break;

  case 631:
#line 4020 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 632:
#line 4022 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 633:
#line 4027 "gram.y"
    {
					ResTarget *n = makeNode(ResTarget);
					n->name = yyvsp[-1].str;
					n->indirection = yyvsp[0].list;
					n->val = NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 634:
#line 4045 "gram.y"
    {
					DeleteStmt *n = makeNode(DeleteStmt);
					n->relation = yyvsp[-1].range;
					n->whereClause = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 635:
#line 4054 "gram.y"
    {
					LockStmt *n = makeNode(LockStmt);

					n->relations = yyvsp[-1].list;
					n->mode = yyvsp[0].ival;
					yyval.node = (Node *)n;
				}
    break;

  case 636:
#line 4063 "gram.y"
    { yyval.ival = yyvsp[-1].ival; }
    break;

  case 637:
#line 4064 "gram.y"
    { yyval.ival = AccessExclusiveLock; }
    break;

  case 638:
#line 4067 "gram.y"
    { yyval.ival = AccessShareLock; }
    break;

  case 639:
#line 4068 "gram.y"
    { yyval.ival = RowShareLock; }
    break;

  case 640:
#line 4069 "gram.y"
    { yyval.ival = RowExclusiveLock; }
    break;

  case 641:
#line 4070 "gram.y"
    { yyval.ival = ShareUpdateExclusiveLock; }
    break;

  case 642:
#line 4071 "gram.y"
    { yyval.ival = ShareLock; }
    break;

  case 643:
#line 4072 "gram.y"
    { yyval.ival = ShareRowExclusiveLock; }
    break;

  case 644:
#line 4073 "gram.y"
    { yyval.ival = ExclusiveLock; }
    break;

  case 645:
#line 4074 "gram.y"
    { yyval.ival = AccessExclusiveLock; }
    break;

  case 646:
#line 4089 "gram.y"
    {
					UpdateStmt *n = makeNode(UpdateStmt);
					n->relation = yyvsp[-4].range;
					n->targetList = yyvsp[-2].list;
					n->fromClause = yyvsp[-1].list;
					n->whereClause = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 647:
#line 4107 "gram.y"
    {
					SelectStmt *n = (SelectStmt *)yyvsp[0].node;
					n->portalname = yyvsp[-4].str;
					n->binary = yyvsp[-3].boolean;
					yyval.node = yyvsp[0].node;
				}
    break;

  case 648:
#line 4115 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 649:
#line 4116 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 650:
#line 4117 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 651:
#line 4118 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 652:
#line 4119 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 655:
#line 4172 "gram.y"
    { yyval.node = yyvsp[-1].node; }
    break;

  case 656:
#line 4173 "gram.y"
    { yyval.node = yyvsp[-1].node; }
    break;

  case 657:
#line 4183 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 658:
#line 4185 "gram.y"
    {
					insertSelectOptions((SelectStmt *) yyvsp[-1].node, yyvsp[0].list, NIL,
										NULL, NULL);
					yyval.node = yyvsp[-1].node;
				}
    break;

  case 659:
#line 4191 "gram.y"
    {
					insertSelectOptions((SelectStmt *) yyvsp[-3].node, yyvsp[-2].list, yyvsp[-1].list,
										nth(0, yyvsp[0].list), nth(1, yyvsp[0].list));
					yyval.node = yyvsp[-3].node;
				}
    break;

  case 660:
#line 4197 "gram.y"
    {
					insertSelectOptions((SelectStmt *) yyvsp[-3].node, yyvsp[-2].list, yyvsp[0].list,
										nth(0, yyvsp[-1].list), nth(1, yyvsp[-1].list));
					yyval.node = yyvsp[-3].node;
				}
    break;

  case 661:
#line 4205 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 662:
#line 4206 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 663:
#line 4236 "gram.y"
    {
					SelectStmt *n = makeNode(SelectStmt);
					n->distinctClause = yyvsp[-6].list;
					n->targetList = yyvsp[-5].list;
					n->into = yyvsp[-4].range;
					n->intoColNames = NIL;
					n->fromClause = yyvsp[-3].list;
					n->whereClause = yyvsp[-2].node;
					n->groupClause = yyvsp[-1].list;
					n->havingClause = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 664:
#line 4249 "gram.y"
    {
					yyval.node = makeSetOp(SETOP_UNION, yyvsp[-1].boolean, yyvsp[-3].node, yyvsp[0].node);
				}
    break;

  case 665:
#line 4253 "gram.y"
    {
					yyval.node = makeSetOp(SETOP_INTERSECT, yyvsp[-1].boolean, yyvsp[-3].node, yyvsp[0].node);
				}
    break;

  case 666:
#line 4257 "gram.y"
    {
					yyval.node = makeSetOp(SETOP_EXCEPT, yyvsp[-1].boolean, yyvsp[-3].node, yyvsp[0].node);
				}
    break;

  case 667:
#line 4263 "gram.y"
    { yyval.range = yyvsp[0].range; }
    break;

  case 668:
#line 4264 "gram.y"
    { yyval.range = NULL; }
    break;

  case 669:
#line 4273 "gram.y"
    {
					yyval.range = yyvsp[0].range;
					yyval.range->istemp = true;
				}
    break;

  case 670:
#line 4278 "gram.y"
    {
					yyval.range = yyvsp[0].range;
					yyval.range->istemp = true;
				}
    break;

  case 671:
#line 4283 "gram.y"
    {
					yyval.range = yyvsp[0].range;
					yyval.range->istemp = true;
				}
    break;

  case 672:
#line 4288 "gram.y"
    {
					yyval.range = yyvsp[0].range;
					yyval.range->istemp = true;
				}
    break;

  case 673:
#line 4293 "gram.y"
    {
					yyval.range = yyvsp[0].range;
					yyval.range->istemp = true;
				}
    break;

  case 674:
#line 4298 "gram.y"
    {
					yyval.range = yyvsp[0].range;
					yyval.range->istemp = true;
				}
    break;

  case 675:
#line 4303 "gram.y"
    {
					yyval.range = yyvsp[0].range;
					yyval.range->istemp = false;
				}
    break;

  case 676:
#line 4308 "gram.y"
    {
					yyval.range = yyvsp[0].range;
					yyval.range->istemp = false;
				}
    break;

  case 677:
#line 4314 "gram.y"
    {}
    break;

  case 678:
#line 4315 "gram.y"
    {}
    break;

  case 679:
#line 4318 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 680:
#line 4319 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 681:
#line 4320 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 682:
#line 4327 "gram.y"
    { yyval.list = makeList1(NIL); }
    break;

  case 683:
#line 4328 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 684:
#line 4329 "gram.y"
    { yyval.list = NIL; }
    break;

  case 685:
#line 4330 "gram.y"
    { yyval.list = NIL; }
    break;

  case 686:
#line 4334 "gram.y"
    { yyval.list = yyvsp[0].list;}
    break;

  case 687:
#line 4335 "gram.y"
    { yyval.list = NIL; }
    break;

  case 688:
#line 4339 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 689:
#line 4343 "gram.y"
    { yyval.list = makeList1(yyvsp[0].sortgroupby); }
    break;

  case 690:
#line 4344 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].sortgroupby); }
    break;

  case 691:
#line 4348 "gram.y"
    {
					yyval.sortgroupby = makeNode(SortGroupBy);
					yyval.sortgroupby->node = yyvsp[-1].node;
					yyval.sortgroupby->useOp = yyvsp[0].list;
				}
    break;

  case 692:
#line 4355 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 693:
#line 4357 "gram.y"
    { yyval.list = makeList1(makeString("<")); }
    break;

  case 694:
#line 4359 "gram.y"
    { yyval.list = makeList1(makeString(">")); }
    break;

  case 695:
#line 4361 "gram.y"
    { yyval.list = makeList1(makeString("<"));	/*default*/ }
    break;

  case 696:
#line 4367 "gram.y"
    { yyval.list = makeList2(yyvsp[0].node, yyvsp[-2].node); }
    break;

  case 697:
#line 4369 "gram.y"
    { yyval.list = makeList2(yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 698:
#line 4371 "gram.y"
    { yyval.list = makeList2(NULL, yyvsp[0].node); }
    break;

  case 699:
#line 4373 "gram.y"
    { yyval.list = makeList2(yyvsp[0].node, NULL); }
    break;

  case 700:
#line 4376 "gram.y"
    { elog(ERROR,
					"LIMIT #,# syntax not supported.\n\tUse separate LIMIT and OFFSET clauses."); }
    break;

  case 701:
#line 4382 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 702:
#line 4384 "gram.y"
    { yyval.list = makeList2(NULL,NULL); }
    break;

  case 703:
#line 4389 "gram.y"
    {
					Const	*n = makeNode(Const);

					if (yyvsp[0].ival < 0)
						elog(ERROR, "LIMIT must not be negative");

					n->consttype	= INT4OID;
					n->constlen		= sizeof(int4);
					n->constvalue	= Int32GetDatum(yyvsp[0].ival);
					n->constisnull	= FALSE;
					n->constbyval	= TRUE;
					n->constisset	= FALSE;
					n->constiscast	= FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 704:
#line 4405 "gram.y"
    {
					/* LIMIT ALL is represented as a NULL constant */
					Const	*n = makeNode(Const);

					n->consttype	= INT4OID;
					n->constlen		= sizeof(int4);
					n->constvalue	= (Datum) 0;
					n->constisnull	= TRUE;
					n->constbyval	= TRUE;
					n->constisset	= FALSE;
					n->constiscast	= FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 705:
#line 4419 "gram.y"
    {
					Param	*n = makeNode(Param);

					n->paramkind	= PARAM_NUM;
					n->paramid		= yyvsp[0].ival;
					n->paramtype	= INT4OID;
					yyval.node = (Node *)n;
				}
    break;

  case 706:
#line 4431 "gram.y"
    {
					Const	*n = makeNode(Const);

					if (yyvsp[0].ival < 0)
						elog(ERROR, "OFFSET must not be negative");

					n->consttype	= INT4OID;
					n->constlen		= sizeof(int4);
					n->constvalue	= Int32GetDatum(yyvsp[0].ival);
					n->constisnull	= FALSE;
					n->constbyval	= TRUE;
					n->constisset	= FALSE;
					n->constiscast	= FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 707:
#line 4447 "gram.y"
    {
					Param	*n = makeNode(Param);

					n->paramkind	= PARAM_NUM;
					n->paramid		= yyvsp[0].ival;
					n->paramtype	= INT4OID;
					yyval.node = (Node *)n;
				}
    break;

  case 708:
#line 4466 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 709:
#line 4467 "gram.y"
    { yyval.list = NIL; }
    break;

  case 710:
#line 4471 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 711:
#line 4472 "gram.y"
    { yyval.node = NULL; }
    break;

  case 712:
#line 4476 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 713:
#line 4477 "gram.y"
    { yyval.list = NULL; }
    break;

  case 714:
#line 4481 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 715:
#line 4482 "gram.y"
    { yyval.list = NULL; }
    break;

  case 716:
#line 4486 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 717:
#line 4487 "gram.y"
    { yyval.list = makeList1(NULL); }
    break;

  case 718:
#line 4499 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 719:
#line 4500 "gram.y"
    { yyval.list = NIL; }
    break;

  case 720:
#line 4504 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 721:
#line 4505 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 722:
#line 4516 "gram.y"
    {
					yyval.node = (Node *) yyvsp[0].range;
				}
    break;

  case 723:
#line 4520 "gram.y"
    {
					yyvsp[-1].range->alias = yyvsp[0].alias;
					yyval.node = (Node *) yyvsp[-1].range;
				}
    break;

  case 724:
#line 4525 "gram.y"
    {
					RangeFunction *n = makeNode(RangeFunction);
					n->funccallnode = yyvsp[0].node;
					n->coldeflist = NIL;
					yyval.node = (Node *) n;
				}
    break;

  case 725:
#line 4532 "gram.y"
    {
					RangeFunction *n = makeNode(RangeFunction);
					n->funccallnode = yyvsp[-1].node;
					n->alias = yyvsp[0].alias;
					n->coldeflist = NIL;
					yyval.node = (Node *) n;
				}
    break;

  case 726:
#line 4540 "gram.y"
    {
					RangeFunction *n = makeNode(RangeFunction);
					n->funccallnode = yyvsp[-4].node;
					n->coldeflist = yyvsp[-1].list;
					yyval.node = (Node *) n;
				}
    break;

  case 727:
#line 4547 "gram.y"
    {
					RangeFunction *n = makeNode(RangeFunction);
					Alias *a = makeNode(Alias);
					n->funccallnode = yyvsp[-5].node;
					a->aliasname = yyvsp[-3].str;
					n->alias = a;
					n->coldeflist = yyvsp[-1].list;
					yyval.node = (Node *) n;
				}
    break;

  case 728:
#line 4557 "gram.y"
    {
					RangeFunction *n = makeNode(RangeFunction);
					Alias *a = makeNode(Alias);
					n->funccallnode = yyvsp[-4].node;
					a->aliasname = yyvsp[-3].str;
					n->alias = a;
					n->coldeflist = yyvsp[-1].list;
					yyval.node = (Node *) n;
				}
    break;

  case 729:
#line 4567 "gram.y"
    {
					/*
					 * The SQL spec does not permit a subselect
					 * (<derived_table>) without an alias clause,
					 * so we don't either.  This avoids the problem
					 * of needing to invent a unique refname for it.
					 * That could be surmounted if there's sufficient
					 * popular demand, but for now let's just implement
					 * the spec and see if anyone complains.
					 * However, it does seem like a good idea to emit
					 * an error message that's better than "parse error".
					 */
					elog(ERROR, "sub-SELECT in FROM must have an alias"
						 "\n\tFor example, FROM (SELECT ...) [AS] foo");
					yyval.node = NULL;
				}
    break;

  case 730:
#line 4584 "gram.y"
    {
					RangeSubselect *n = makeNode(RangeSubselect);
					n->subquery = yyvsp[-1].node;
					n->alias = yyvsp[0].alias;
					yyval.node = (Node *) n;
				}
    break;

  case 731:
#line 4591 "gram.y"
    {
					yyval.node = (Node *) yyvsp[0].jexpr;
				}
    break;

  case 732:
#line 4595 "gram.y"
    {
					yyvsp[-2].jexpr->alias = yyvsp[0].alias;
					yyval.node = (Node *) yyvsp[-2].jexpr;
				}
    break;

  case 733:
#line 4621 "gram.y"
    {
					yyval.jexpr = yyvsp[-1].jexpr;
				}
    break;

  case 734:
#line 4625 "gram.y"
    {
					/* CROSS JOIN is same as unqualified inner join */
					JoinExpr *n = makeNode(JoinExpr);
					n->jointype = JOIN_INNER;
					n->isNatural = FALSE;
					n->larg = yyvsp[-3].node;
					n->rarg = yyvsp[0].node;
					n->using = NIL;
					n->quals = NULL;
					yyval.jexpr = n;
				}
    break;

  case 735:
#line 4637 "gram.y"
    {
					/* UNION JOIN is made into 1 token to avoid shift/reduce
					 * conflict against regular UNION keyword.
					 */
					JoinExpr *n = makeNode(JoinExpr);
					n->jointype = JOIN_UNION;
					n->isNatural = FALSE;
					n->larg = yyvsp[-2].node;
					n->rarg = yyvsp[0].node;
					n->using = NIL;
					n->quals = NULL;
					yyval.jexpr = n;
				}
    break;

  case 736:
#line 4651 "gram.y"
    {
					JoinExpr *n = makeNode(JoinExpr);
					n->jointype = yyvsp[-3].jtype;
					n->isNatural = FALSE;
					n->larg = yyvsp[-4].node;
					n->rarg = yyvsp[-1].node;
					if (yyvsp[0].node != NULL && IsA(yyvsp[0].node, List))
						n->using = (List *) yyvsp[0].node; /* USING clause */
					else
						n->quals = yyvsp[0].node; /* ON clause */
					yyval.jexpr = n;
				}
    break;

  case 737:
#line 4664 "gram.y"
    {
					/* letting join_type reduce to empty doesn't work */
					JoinExpr *n = makeNode(JoinExpr);
					n->jointype = JOIN_INNER;
					n->isNatural = FALSE;
					n->larg = yyvsp[-3].node;
					n->rarg = yyvsp[-1].node;
					if (yyvsp[0].node != NULL && IsA(yyvsp[0].node, List))
						n->using = (List *) yyvsp[0].node; /* USING clause */
					else
						n->quals = yyvsp[0].node; /* ON clause */
					yyval.jexpr = n;
				}
    break;

  case 738:
#line 4678 "gram.y"
    {
					JoinExpr *n = makeNode(JoinExpr);
					n->jointype = yyvsp[-2].jtype;
					n->isNatural = TRUE;
					n->larg = yyvsp[-4].node;
					n->rarg = yyvsp[0].node;
					n->using = NIL; /* figure out which columns later... */
					n->quals = NULL; /* fill later */
					yyval.jexpr = n;
				}
    break;

  case 739:
#line 4689 "gram.y"
    {
					/* letting join_type reduce to empty doesn't work */
					JoinExpr *n = makeNode(JoinExpr);
					n->jointype = JOIN_INNER;
					n->isNatural = TRUE;
					n->larg = yyvsp[-3].node;
					n->rarg = yyvsp[0].node;
					n->using = NIL; /* figure out which columns later... */
					n->quals = NULL; /* fill later */
					yyval.jexpr = n;
				}
    break;

  case 740:
#line 4704 "gram.y"
    {
					yyval.alias = makeNode(Alias);
					yyval.alias->aliasname = yyvsp[-3].str;
					yyval.alias->colnames = yyvsp[-1].list;
				}
    break;

  case 741:
#line 4710 "gram.y"
    {
					yyval.alias = makeNode(Alias);
					yyval.alias->aliasname = yyvsp[0].str;
				}
    break;

  case 742:
#line 4715 "gram.y"
    {
					yyval.alias = makeNode(Alias);
					yyval.alias->aliasname = yyvsp[-3].str;
					yyval.alias->colnames = yyvsp[-1].list;
				}
    break;

  case 743:
#line 4721 "gram.y"
    {
					yyval.alias = makeNode(Alias);
					yyval.alias->aliasname = yyvsp[0].str;
				}
    break;

  case 744:
#line 4727 "gram.y"
    { yyval.jtype = JOIN_FULL; }
    break;

  case 745:
#line 4728 "gram.y"
    { yyval.jtype = JOIN_LEFT; }
    break;

  case 746:
#line 4729 "gram.y"
    { yyval.jtype = JOIN_RIGHT; }
    break;

  case 747:
#line 4730 "gram.y"
    { yyval.jtype = JOIN_INNER; }
    break;

  case 748:
#line 4734 "gram.y"
    { yyval.node = NULL; }
    break;

  case 749:
#line 4735 "gram.y"
    { yyval.node = NULL; }
    break;

  case 750:
#line 4747 "gram.y"
    { yyval.node = (Node *) yyvsp[-1].list; }
    break;

  case 751:
#line 4748 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 752:
#line 4754 "gram.y"
    {
					/* default inheritance */
					yyval.range = yyvsp[0].range;
					yyval.range->inhOpt = INH_DEFAULT;
					yyval.range->alias = NULL;
				}
    break;

  case 753:
#line 4761 "gram.y"
    {
					/* inheritance query */
					yyval.range = yyvsp[-1].range;
					yyval.range->inhOpt = INH_YES;
					yyval.range->alias = NULL;
				}
    break;

  case 754:
#line 4768 "gram.y"
    {
					/* no inheritance */
					yyval.range = yyvsp[0].range;
					yyval.range->inhOpt = INH_NO;
					yyval.range->alias = NULL;
				}
    break;

  case 755:
#line 4775 "gram.y"
    {
					/* no inheritance, SQL99-style syntax */
					yyval.range = yyvsp[-1].range;
					yyval.range->inhOpt = INH_NO;
					yyval.range->alias = NULL;
				}
    break;

  case 756:
#line 4785 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = yyvsp[-2].list;
					n->args = NIL;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 757:
#line 4794 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = yyvsp[-3].list;
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 758:
#line 4806 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 759:
#line 4807 "gram.y"
    { yyval.node = NULL; }
    break;

  case 760:
#line 4813 "gram.y"
    {
					yyval.list = makeList1(yyvsp[0].node);
				}
    break;

  case 761:
#line 4817 "gram.y"
    {
					yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node);
				}
    break;

  case 762:
#line 4823 "gram.y"
    {
					ColumnDef *n = makeNode(ColumnDef);
					n->colname = yyvsp[-1].str;
					n->typename = yyvsp[0].typnam;
					n->constraints = NIL;
					n->is_local = true;
					yyval.node = (Node *)n;
				}
    break;

  case 763:
#line 4844 "gram.y"
    {
					yyval.typnam = yyvsp[-1].typnam;
					yyval.typnam->arrayBounds = yyvsp[0].list;
				}
    break;

  case 764:
#line 4849 "gram.y"
    {
					yyval.typnam = yyvsp[-1].typnam;
					yyval.typnam->arrayBounds = yyvsp[0].list;
					yyval.typnam->setof = TRUE;
				}
    break;

  case 765:
#line 4858 "gram.y"
    {  yyval.list = lappend(yyvsp[-2].list, makeInteger(-1)); }
    break;

  case 766:
#line 4860 "gram.y"
    {  yyval.list = lappend(yyvsp[-3].list, makeInteger(yyvsp[-1].ival)); }
    break;

  case 767:
#line 4862 "gram.y"
    {  yyval.list = NIL; }
    break;

  case 768:
#line 4874 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 769:
#line 4875 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 770:
#line 4876 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 771:
#line 4877 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 772:
#line 4878 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 773:
#line 4880 "gram.y"
    {
					yyval.typnam = yyvsp[-1].typnam;
					if (yyvsp[0].ival != INTERVAL_FULL_RANGE)
						yyval.typnam->typmod = INTERVAL_TYPMOD(INTERVAL_FULL_PRECISION, yyvsp[0].ival);
				}
    break;

  case 774:
#line 4886 "gram.y"
    {
					yyval.typnam = yyvsp[-4].typnam;
					if (yyvsp[-2].ival < 0)
						elog(ERROR,
							 "INTERVAL(%d) precision must not be negative",
							 yyvsp[-2].ival);
					if (yyvsp[-2].ival > MAX_INTERVAL_PRECISION)
					{
						elog(NOTICE,
							 "INTERVAL(%d) precision reduced to maximum allowed, %d",
							 yyvsp[-2].ival, MAX_INTERVAL_PRECISION);
						yyvsp[-2].ival = MAX_INTERVAL_PRECISION;
					}
					yyval.typnam->typmod = INTERVAL_TYPMOD(yyvsp[-2].ival, yyvsp[0].ival);
				}
    break;

  case 775:
#line 4902 "gram.y"
    {
					yyval.typnam = makeNode(TypeName);
					yyval.typnam->names = lcons(makeString(yyvsp[-1].str), yyvsp[0].list);
					yyval.typnam->typmod = -1;
				}
    break;

  case 776:
#line 4919 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 777:
#line 4920 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 778:
#line 4921 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 779:
#line 4922 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 780:
#line 4923 "gram.y"
    { yyval.typnam = yyvsp[0].typnam; }
    break;

  case 781:
#line 4928 "gram.y"
    {
					yyval.typnam = makeTypeName(yyvsp[0].str);
				}
    break;

  case 782:
#line 4939 "gram.y"
    {
					yyval.typnam = SystemTypeName("int4");
				}
    break;

  case 783:
#line 4943 "gram.y"
    {
					yyval.typnam = SystemTypeName("int4");
				}
    break;

  case 784:
#line 4947 "gram.y"
    {
					yyval.typnam = SystemTypeName("int2");
				}
    break;

  case 785:
#line 4951 "gram.y"
    {
					yyval.typnam = SystemTypeName("int8");
				}
    break;

  case 786:
#line 4955 "gram.y"
    {
					yyval.typnam = SystemTypeName("float4");
				}
    break;

  case 787:
#line 4959 "gram.y"
    {
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 788:
#line 4963 "gram.y"
    {
					yyval.typnam = SystemTypeName("float8");
				}
    break;

  case 789:
#line 4967 "gram.y"
    {
					yyval.typnam = SystemTypeName("numeric");
					yyval.typnam->typmod = yyvsp[0].ival;
				}
    break;

  case 790:
#line 4972 "gram.y"
    {
					yyval.typnam = SystemTypeName("numeric");
					yyval.typnam->typmod = yyvsp[0].ival;
				}
    break;

  case 791:
#line 4977 "gram.y"
    {
					yyval.typnam = SystemTypeName("numeric");
					yyval.typnam->typmod = yyvsp[0].ival;
				}
    break;

  case 792:
#line 4982 "gram.y"
    {
					yyval.typnam = SystemTypeName("bool");
				}
    break;

  case 793:
#line 4988 "gram.y"
    {
					if (yyvsp[-1].ival < 1)
						elog(ERROR,
							"precision for FLOAT must be at least 1");
					else if (yyvsp[-1].ival < 7)
						yyval.typnam = SystemTypeName("float4");
					else if (yyvsp[-1].ival < 16)
						yyval.typnam = SystemTypeName("float8");
					else
						elog(ERROR,
							"precision for FLOAT must be less than 16");
				}
    break;

  case 794:
#line 5001 "gram.y"
    {
					yyval.typnam = SystemTypeName("float8");
				}
    break;

  case 795:
#line 5008 "gram.y"
    {
					if (yyvsp[-3].ival < 1 || yyvsp[-3].ival > NUMERIC_MAX_PRECISION)
						elog(ERROR,
							"NUMERIC precision %d must be between 1 and %d",
							 yyvsp[-3].ival, NUMERIC_MAX_PRECISION);
					if (yyvsp[-1].ival < 0 || yyvsp[-1].ival > yyvsp[-3].ival)
						elog(ERROR,
						"NUMERIC scale %d must be between 0 and precision %d",
							 yyvsp[-1].ival,yyvsp[-3].ival);

					yyval.ival = ((yyvsp[-3].ival << 16) | yyvsp[-1].ival) + VARHDRSZ;
				}
    break;

  case 796:
#line 5021 "gram.y"
    {
					if (yyvsp[-1].ival < 1 || yyvsp[-1].ival > NUMERIC_MAX_PRECISION)
						elog(ERROR,
							"NUMERIC precision %d must be between 1 and %d",
							 yyvsp[-1].ival, NUMERIC_MAX_PRECISION);

					yyval.ival = (yyvsp[-1].ival << 16) + VARHDRSZ;
				}
    break;

  case 797:
#line 5030 "gram.y"
    {
					/* Insert "-1" meaning "no limit" */
					yyval.ival = -1;
				}
    break;

  case 798:
#line 5038 "gram.y"
    {
					if (yyvsp[-3].ival < 1 || yyvsp[-3].ival > NUMERIC_MAX_PRECISION)
						elog(ERROR,
							"DECIMAL precision %d must be between 1 and %d",
									yyvsp[-3].ival, NUMERIC_MAX_PRECISION);
					if (yyvsp[-1].ival < 0 || yyvsp[-1].ival > yyvsp[-3].ival)
						elog(ERROR,
							"DECIMAL scale %d must be between 0 and precision %d",
									yyvsp[-1].ival,yyvsp[-3].ival);

					yyval.ival = ((yyvsp[-3].ival << 16) | yyvsp[-1].ival) + VARHDRSZ;
				}
    break;

  case 799:
#line 5051 "gram.y"
    {
					if (yyvsp[-1].ival < 1 || yyvsp[-1].ival > NUMERIC_MAX_PRECISION)
						elog(ERROR,
							"DECIMAL precision %d must be between 1 and %d",
									yyvsp[-1].ival, NUMERIC_MAX_PRECISION);

					yyval.ival = (yyvsp[-1].ival << 16) + VARHDRSZ;
				}
    break;

  case 800:
#line 5060 "gram.y"
    {
					/* Insert "-1" meaning "no limit" */
					yyval.ival = -1;
				}
    break;

  case 801:
#line 5072 "gram.y"
    {
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 802:
#line 5076 "gram.y"
    {
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 803:
#line 5084 "gram.y"
    {
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 804:
#line 5088 "gram.y"
    {
					yyval.typnam->typmod = -1;
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 805:
#line 5096 "gram.y"
    {
					char *typname;

					typname = yyvsp[-3].boolean ? "varbit" : "bit";
					yyval.typnam = SystemTypeName(typname);
					if (yyvsp[-1].ival < 1)
						elog(ERROR, "length for type '%s' must be at least 1",
							 typname);
					else if (yyvsp[-1].ival > (MaxAttrSize * BITS_PER_BYTE))
						elog(ERROR, "length for type '%s' cannot exceed %d",
							 typname, (MaxAttrSize * BITS_PER_BYTE));
					yyval.typnam->typmod = yyvsp[-1].ival;
				}
    break;

  case 806:
#line 5113 "gram.y"
    {
					/* bit defaults to bit(1), varbit to no limit */
					if (yyvsp[0].boolean)
					{
						yyval.typnam = SystemTypeName("varbit");
						yyval.typnam->typmod = -1;
					}
					else
					{
						yyval.typnam = SystemTypeName("bit");
						yyval.typnam->typmod = 1;
					}
				}
    break;

  case 807:
#line 5134 "gram.y"
    {
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 808:
#line 5138 "gram.y"
    {
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 809:
#line 5144 "gram.y"
    {
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 810:
#line 5148 "gram.y"
    {
					/* Length was not specified so allow to be unrestricted.
					 * This handles problems with fixed-length (bpchar) strings
					 * which in column definitions must default to a length
					 * of one, but should not be constrained if the length
					 * was not specified.
					 */
					yyvsp[0].typnam->typmod = -1;
					yyval.typnam = yyvsp[0].typnam;
				}
    break;

  case 811:
#line 5161 "gram.y"
    {
					if ((yyvsp[0].str != NULL) && (strcmp(yyvsp[0].str, "sql_text") != 0))
					{
						char *type;

						type = palloc(strlen(yyvsp[-4].str) + 1 + strlen(yyvsp[0].str) + 1);
						strcpy(type, yyvsp[-4].str);
						strcat(type, "_");
						strcat(type, yyvsp[0].str);
						yyvsp[-4].str = type;
					}

					yyval.typnam = SystemTypeName(yyvsp[-4].str);

					if (yyvsp[-2].ival < 1)
						elog(ERROR, "length for type '%s' must be at least 1",
							 yyvsp[-4].str);
					else if (yyvsp[-2].ival > MaxAttrSize)
						elog(ERROR, "length for type '%s' cannot exceed %d",
							 yyvsp[-4].str, MaxAttrSize);

					/* we actually implement these like a varlen, so
					 * the first 4 bytes is the length. (the difference
					 * between these and "text" is that we blank-pad and
					 * truncate where necessary)
					 */
					yyval.typnam->typmod = VARHDRSZ + yyvsp[-2].ival;
				}
    break;

  case 812:
#line 5192 "gram.y"
    {
					if ((yyvsp[0].str != NULL) && (strcmp(yyvsp[0].str, "sql_text") != 0))
					{
						char *type;

						type = palloc(strlen(yyvsp[-1].str) + 1 + strlen(yyvsp[0].str) + 1);
						strcpy(type, yyvsp[-1].str);
						strcat(type, "_");
						strcat(type, yyvsp[0].str);
						yyvsp[-1].str = type;
					}

					yyval.typnam = SystemTypeName(yyvsp[-1].str);

					/* char defaults to char(1), varchar to no limit */
					if (strcmp(yyvsp[-1].str, "bpchar") == 0)
						yyval.typnam->typmod = VARHDRSZ + 1;
					else
						yyval.typnam->typmod = -1;
				}
    break;

  case 813:
#line 5215 "gram.y"
    { yyval.str = yyvsp[0].boolean ? "varchar": "bpchar"; }
    break;

  case 814:
#line 5217 "gram.y"
    { yyval.str = yyvsp[0].boolean ? "varchar": "bpchar"; }
    break;

  case 815:
#line 5219 "gram.y"
    { yyval.str = "varchar"; }
    break;

  case 816:
#line 5221 "gram.y"
    { yyval.str = yyvsp[0].boolean ? "varchar": "bpchar"; }
    break;

  case 817:
#line 5223 "gram.y"
    { yyval.str = yyvsp[0].boolean ? "varchar": "bpchar"; }
    break;

  case 818:
#line 5225 "gram.y"
    { yyval.str = yyvsp[0].boolean ? "varchar": "bpchar"; }
    break;

  case 819:
#line 5229 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 820:
#line 5230 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 821:
#line 5234 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 822:
#line 5235 "gram.y"
    { yyval.str = NULL; }
    break;

  case 823:
#line 5239 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 824:
#line 5240 "gram.y"
    { yyval.str = NULL; }
    break;

  case 825:
#line 5245 "gram.y"
    {
					if (yyvsp[0].boolean)
						yyval.typnam = SystemTypeName("timestamptz");
					else
						yyval.typnam = SystemTypeName("timestamp");
					/* XXX the timezone field seems to be unused
					 * - thomas 2001-09-06
					 */
					yyval.typnam->timezone = yyvsp[0].boolean;
					if (yyvsp[-2].ival < 0)
						elog(ERROR,
							 "TIMESTAMP(%d)%s precision must not be negative",
							 yyvsp[-2].ival, (yyvsp[0].boolean ? " WITH TIME ZONE": ""));
					if (yyvsp[-2].ival > MAX_TIMESTAMP_PRECISION)
					{
						elog(NOTICE,
							 "TIMESTAMP(%d)%s precision reduced to maximum allowed, %d",
							 yyvsp[-2].ival, (yyvsp[0].boolean ? " WITH TIME ZONE": ""),
							 MAX_TIMESTAMP_PRECISION);
						yyvsp[-2].ival = MAX_TIMESTAMP_PRECISION;
					}
					yyval.typnam->typmod = yyvsp[-2].ival;
				}
    break;

  case 826:
#line 5269 "gram.y"
    {
					if (yyvsp[0].boolean)
						yyval.typnam = SystemTypeName("timestamptz");
					else
						yyval.typnam = SystemTypeName("timestamp");
					/* XXX the timezone field seems to be unused
					 * - thomas 2001-09-06
					 */
					yyval.typnam->timezone = yyvsp[0].boolean;
					/* SQL99 specified a default precision of six
					 * for schema definitions. But for timestamp
					 * literals we don't want to throw away precision
					 * so leave this as unspecified for now.
					 * Later, we may want a different production
					 * for schemas. - thomas 2001-12-07
					 */
					yyval.typnam->typmod = -1;
				}
    break;

  case 827:
#line 5288 "gram.y"
    {
					if (yyvsp[0].boolean)
						yyval.typnam = SystemTypeName("timetz");
					else
						yyval.typnam = SystemTypeName("time");
					if (yyvsp[-2].ival < 0)
						elog(ERROR,
							 "TIME(%d)%s precision must not be negative",
							 yyvsp[-2].ival, (yyvsp[0].boolean ? " WITH TIME ZONE": ""));
					if (yyvsp[-2].ival > MAX_TIME_PRECISION)
					{
						elog(NOTICE,
							 "TIME(%d)%s precision reduced to maximum allowed, %d",
							 yyvsp[-2].ival, (yyvsp[0].boolean ? " WITH TIME ZONE": ""),
							 MAX_TIME_PRECISION);
						yyvsp[-2].ival = MAX_TIME_PRECISION;
					}
					yyval.typnam->typmod = yyvsp[-2].ival;
				}
    break;

  case 828:
#line 5308 "gram.y"
    {
					if (yyvsp[0].boolean)
						yyval.typnam = SystemTypeName("timetz");
					else
						yyval.typnam = SystemTypeName("time");
					/* SQL99 specified a default precision of zero.
					 * See comments for timestamp above on why we will
					 * leave this unspecified for now. - thomas 2001-12-07
					 */
					yyval.typnam->typmod = -1;
				}
    break;

  case 829:
#line 5322 "gram.y"
    { yyval.typnam = SystemTypeName("interval"); }
    break;

  case 830:
#line 5326 "gram.y"
    { yyval.boolean = TRUE; }
    break;

  case 831:
#line 5327 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 832:
#line 5328 "gram.y"
    { yyval.boolean = FALSE; }
    break;

  case 833:
#line 5332 "gram.y"
    { yyval.ival = INTERVAL_MASK(YEAR); }
    break;

  case 834:
#line 5333 "gram.y"
    { yyval.ival = INTERVAL_MASK(MONTH); }
    break;

  case 835:
#line 5334 "gram.y"
    { yyval.ival = INTERVAL_MASK(DAY); }
    break;

  case 836:
#line 5335 "gram.y"
    { yyval.ival = INTERVAL_MASK(HOUR); }
    break;

  case 837:
#line 5336 "gram.y"
    { yyval.ival = INTERVAL_MASK(MINUTE); }
    break;

  case 838:
#line 5337 "gram.y"
    { yyval.ival = INTERVAL_MASK(SECOND); }
    break;

  case 839:
#line 5339 "gram.y"
    { yyval.ival = INTERVAL_MASK(YEAR) | INTERVAL_MASK(MONTH); }
    break;

  case 840:
#line 5341 "gram.y"
    { yyval.ival = INTERVAL_MASK(DAY) | INTERVAL_MASK(HOUR); }
    break;

  case 841:
#line 5343 "gram.y"
    { yyval.ival = INTERVAL_MASK(DAY) | INTERVAL_MASK(HOUR)
						| INTERVAL_MASK(MINUTE); }
    break;

  case 842:
#line 5346 "gram.y"
    { yyval.ival = INTERVAL_MASK(DAY) | INTERVAL_MASK(HOUR)
						| INTERVAL_MASK(MINUTE) | INTERVAL_MASK(SECOND); }
    break;

  case 843:
#line 5349 "gram.y"
    { yyval.ival = INTERVAL_MASK(HOUR) | INTERVAL_MASK(MINUTE); }
    break;

  case 844:
#line 5351 "gram.y"
    { yyval.ival = INTERVAL_MASK(HOUR) | INTERVAL_MASK(MINUTE)
						| INTERVAL_MASK(SECOND); }
    break;

  case 845:
#line 5354 "gram.y"
    { yyval.ival = INTERVAL_MASK(MINUTE) | INTERVAL_MASK(SECOND); }
    break;

  case 846:
#line 5355 "gram.y"
    { yyval.ival = INTERVAL_FULL_RANGE; }
    break;

  case 847:
#line 5371 "gram.y"
    {
					SubLink *n = makeNode(SubLink);
					n->lefthand = yyvsp[-2].list;
					n->oper = (List *) makeSimpleA_Expr(OP, "=", NULL, NULL);
					n->useor = FALSE;
					n->subLinkType = ANY_SUBLINK;
					n->subselect = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 848:
#line 5381 "gram.y"
    {
					SubLink *n = makeNode(SubLink);
					n->lefthand = yyvsp[-3].list;
					n->oper = (List *) makeSimpleA_Expr(OP, "<>", NULL, NULL);
					n->useor = TRUE;
					n->subLinkType = ALL_SUBLINK;
					n->subselect = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 849:
#line 5392 "gram.y"
    {
					SubLink *n = makeNode(SubLink);
					n->lefthand = yyvsp[-3].list;
					n->oper = (List *) makeA_Expr(OP, yyvsp[-2].list, NULL, NULL);
					if (strcmp(strVal(llast(yyvsp[-2].list)), "<>") == 0)
						n->useor = TRUE;
					else
						n->useor = FALSE;
					n->subLinkType = yyvsp[-1].ival;
					n->subselect = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 850:
#line 5406 "gram.y"
    {
					SubLink *n = makeNode(SubLink);
					n->lefthand = yyvsp[-2].list;
					n->oper = (List *) makeA_Expr(OP, yyvsp[-1].list, NULL, NULL);
					if (strcmp(strVal(llast(yyvsp[-1].list)), "<>") == 0)
						n->useor = TRUE;
					else
						n->useor = FALSE;
					n->subLinkType = MULTIEXPR_SUBLINK;
					n->subselect = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 851:
#line 5420 "gram.y"
    {
					yyval.node = makeRowExpr(yyvsp[-1].list, yyvsp[-2].list, yyvsp[0].list);
				}
    break;

  case 852:
#line 5424 "gram.y"
    {
					yyval.node = makeRowNullTest(IS_NULL, yyvsp[-2].list);
				}
    break;

  case 853:
#line 5428 "gram.y"
    {
					yyval.node = makeRowNullTest(IS_NOT_NULL, yyvsp[-3].list);
				}
    break;

  case 854:
#line 5432 "gram.y"
    {
					yyval.node = (Node *)makeOverlaps(yyvsp[-2].list, yyvsp[0].list);
				}
    break;

  case 855:
#line 5437 "gram.y"
    {
					/* IS DISTINCT FROM has the following rules for non-array types:
					 * a) the row lengths must be equal
					 * b) if both rows are zero-length, then they are not distinct
					 * c) if any element is distinct, the rows are distinct
					 * The rules for an element being distinct:
					 * a) if the elements are both NULL, then they are not distinct
					 * b) if the elements compare to be equal, then they are not distinct
					 * c) otherwise, they are distinct
					 */
					List *largs = yyvsp[-4].list;
					List *rargs = yyvsp[0].list;
					/* lengths don't match? then complain */
					if (length(largs) != length(rargs))
					{
						elog(ERROR, "Unequal number of entries in row expression");
					}
					/* both are zero-length rows? then they are not distinct */
					else if (length(largs) <= 0)
					{
						yyval.node = (Node *)makeBoolConst(FALSE);
					}
					/* otherwise, we need to compare each element */
					else
					{
						yyval.node = (Node *)makeDistinctExpr(largs, rargs);
					}
				}
    break;

  case 856:
#line 5471 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 857:
#line 5472 "gram.y"
    { yyval.list = makeList1(yyvsp[-1].node); }
    break;

  case 858:
#line 5473 "gram.y"
    { yyval.list = NULL; }
    break;

  case 859:
#line 5474 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 860:
#line 5477 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 861:
#line 5480 "gram.y"
    { yyval.ival = ANY_SUBLINK; }
    break;

  case 862:
#line 5481 "gram.y"
    { yyval.ival = ANY_SUBLINK; }
    break;

  case 863:
#line 5482 "gram.y"
    { yyval.ival = ALL_SUBLINK; }
    break;

  case 864:
#line 5485 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 865:
#line 5486 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 866:
#line 5489 "gram.y"
    { yyval.str = "+"; }
    break;

  case 867:
#line 5490 "gram.y"
    { yyval.str = "-"; }
    break;

  case 868:
#line 5491 "gram.y"
    { yyval.str = "*"; }
    break;

  case 869:
#line 5492 "gram.y"
    { yyval.str = "/"; }
    break;

  case 870:
#line 5493 "gram.y"
    { yyval.str = "%"; }
    break;

  case 871:
#line 5494 "gram.y"
    { yyval.str = "^"; }
    break;

  case 872:
#line 5495 "gram.y"
    { yyval.str = "<"; }
    break;

  case 873:
#line 5496 "gram.y"
    { yyval.str = ">"; }
    break;

  case 874:
#line 5497 "gram.y"
    { yyval.str = "="; }
    break;

  case 875:
#line 5501 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 876:
#line 5502 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 877:
#line 5507 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 878:
#line 5508 "gram.y"
    { yyval.list = yyvsp[-1].list; }
    break;

  case 879:
#line 5527 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 880:
#line 5529 "gram.y"
    { yyval.node = makeTypeCast(yyvsp[-2].node, yyvsp[0].typnam); }
    break;

  case 881:
#line 5531 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName(yyvsp[0].str);
					n->args = makeList1(yyvsp[-2].node);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) n;
				}
    break;

  case 882:
#line 5540 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("timezone");
					n->args = makeList2(yyvsp[0].node, yyvsp[-4].node);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) n;
				}
    break;

  case 883:
#line 5558 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "+", NULL, yyvsp[0].node); }
    break;

  case 884:
#line 5560 "gram.y"
    { yyval.node = doNegate(yyvsp[0].node); }
    break;

  case 885:
#line 5562 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "%", NULL, yyvsp[0].node); }
    break;

  case 886:
#line 5564 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "^", NULL, yyvsp[0].node); }
    break;

  case 887:
#line 5566 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "%", yyvsp[-1].node, NULL); }
    break;

  case 888:
#line 5568 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "^", yyvsp[-1].node, NULL); }
    break;

  case 889:
#line 5570 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "+", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 890:
#line 5572 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "-", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 891:
#line 5574 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "*", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 892:
#line 5576 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "/", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 893:
#line 5578 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "%", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 894:
#line 5580 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "^", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 895:
#line 5582 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "<", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 896:
#line 5584 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, ">", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 897:
#line 5586 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "=", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 898:
#line 5589 "gram.y"
    { yyval.node = (Node *) makeA_Expr(OP, yyvsp[-1].list, yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 899:
#line 5591 "gram.y"
    { yyval.node = (Node *) makeA_Expr(OP, yyvsp[-1].list, NULL, yyvsp[0].node); }
    break;

  case 900:
#line 5593 "gram.y"
    { yyval.node = (Node *) makeA_Expr(OP, yyvsp[0].list, yyvsp[-1].node, NULL); }
    break;

  case 901:
#line 5596 "gram.y"
    { yyval.node = (Node *) makeA_Expr(AND, NIL, yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 902:
#line 5598 "gram.y"
    { yyval.node = (Node *) makeA_Expr(OR, NIL, yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 903:
#line 5600 "gram.y"
    { yyval.node = (Node *) makeA_Expr(NOT, NIL, NULL, yyvsp[0].node); }
    break;

  case 904:
#line 5603 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "~~", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 905:
#line 5605 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("like_escape");
					n->args = makeList2(yyvsp[-2].node, yyvsp[0].node);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) makeSimpleA_Expr(OP, "~~", yyvsp[-4].node, (Node *) n);
				}
    break;

  case 906:
#line 5614 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "!~~", yyvsp[-3].node, yyvsp[0].node); }
    break;

  case 907:
#line 5616 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("like_escape");
					n->args = makeList2(yyvsp[-2].node, yyvsp[0].node);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) makeSimpleA_Expr(OP, "!~~", yyvsp[-5].node, (Node *) n);
				}
    break;

  case 908:
#line 5625 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "~~*", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 909:
#line 5627 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("like_escape");
					n->args = makeList2(yyvsp[-2].node, yyvsp[0].node);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) makeSimpleA_Expr(OP, "~~*", yyvsp[-4].node, (Node *) n);
				}
    break;

  case 910:
#line 5636 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "!~~*", yyvsp[-3].node, yyvsp[0].node); }
    break;

  case 911:
#line 5638 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("like_escape");
					n->args = makeList2(yyvsp[-2].node, yyvsp[0].node);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) makeSimpleA_Expr(OP, "!~~*", yyvsp[-5].node, (Node *) n);
				}
    break;

  case 912:
#line 5648 "gram.y"
    {
					A_Const *c = makeNode(A_Const);
					FuncCall *n = makeNode(FuncCall);
					c->val.type = T_Null;
					n->funcname = SystemFuncName("similar_escape");
					n->args = makeList2(yyvsp[0].node, (Node *) c);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) makeSimpleA_Expr(OP, "~", yyvsp[-3].node, (Node *) n);
				}
    break;

  case 913:
#line 5659 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("similar_escape");
					n->args = makeList2(yyvsp[-2].node, yyvsp[0].node);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) makeSimpleA_Expr(OP, "~", yyvsp[-5].node, (Node *) n);
				}
    break;

  case 914:
#line 5668 "gram.y"
    {
					A_Const *c = makeNode(A_Const);
					FuncCall *n = makeNode(FuncCall);
					c->val.type = T_Null;
					n->funcname = SystemFuncName("similar_escape");
					n->args = makeList2(yyvsp[0].node, (Node *) c);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) makeSimpleA_Expr(OP, "!~", yyvsp[-4].node, (Node *) n);
				}
    break;

  case 915:
#line 5679 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("similar_escape");
					n->args = makeList2(yyvsp[-2].node, yyvsp[0].node);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *) makeSimpleA_Expr(OP, "!~", yyvsp[-6].node, (Node *) n);
				}
    break;

  case 916:
#line 5698 "gram.y"
    {
					NullTest *n = makeNode(NullTest);
					n->arg = yyvsp[-1].node;
					n->nulltesttype = IS_NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 917:
#line 5705 "gram.y"
    {
					NullTest *n = makeNode(NullTest);
					n->arg = yyvsp[-2].node;
					n->nulltesttype = IS_NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 918:
#line 5712 "gram.y"
    {
					NullTest *n = makeNode(NullTest);
					n->arg = yyvsp[-1].node;
					n->nulltesttype = IS_NOT_NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 919:
#line 5719 "gram.y"
    {
					NullTest *n = makeNode(NullTest);
					n->arg = yyvsp[-3].node;
					n->nulltesttype = IS_NOT_NULL;
					yyval.node = (Node *)n;
				}
    break;

  case 920:
#line 5726 "gram.y"
    {
					BooleanTest *b = makeNode(BooleanTest);
					b->arg = yyvsp[-2].node;
					b->booltesttype = IS_TRUE;
					yyval.node = (Node *)b;
				}
    break;

  case 921:
#line 5733 "gram.y"
    {
					BooleanTest *b = makeNode(BooleanTest);
					b->arg = yyvsp[-3].node;
					b->booltesttype = IS_NOT_TRUE;
					yyval.node = (Node *)b;
				}
    break;

  case 922:
#line 5740 "gram.y"
    {
					BooleanTest *b = makeNode(BooleanTest);
					b->arg = yyvsp[-2].node;
					b->booltesttype = IS_FALSE;
					yyval.node = (Node *)b;
				}
    break;

  case 923:
#line 5747 "gram.y"
    {
					BooleanTest *b = makeNode(BooleanTest);
					b->arg = yyvsp[-3].node;
					b->booltesttype = IS_NOT_FALSE;
					yyval.node = (Node *)b;
				}
    break;

  case 924:
#line 5754 "gram.y"
    {
					BooleanTest *b = makeNode(BooleanTest);
					b->arg = yyvsp[-2].node;
					b->booltesttype = IS_UNKNOWN;
					yyval.node = (Node *)b;
				}
    break;

  case 925:
#line 5761 "gram.y"
    {
					BooleanTest *b = makeNode(BooleanTest);
					b->arg = yyvsp[-3].node;
					b->booltesttype = IS_NOT_UNKNOWN;
					yyval.node = (Node *)b;
				}
    break;

  case 926:
#line 5768 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(DISTINCT, "=", yyvsp[-4].node, yyvsp[0].node); }
    break;

  case 927:
#line 5770 "gram.y"
    {
					yyval.node = (Node *) makeSimpleA_Expr(OF, "=", yyvsp[-5].node, (Node *) yyvsp[-1].list);
				}
    break;

  case 928:
#line 5774 "gram.y"
    {
					yyval.node = (Node *) makeSimpleA_Expr(OF, "!=", yyvsp[-6].node, (Node *) yyvsp[-1].list);
				}
    break;

  case 929:
#line 5778 "gram.y"
    {
					yyval.node = (Node *) makeA_Expr(AND, NIL,
						(Node *) makeSimpleA_Expr(OP, ">=", yyvsp[-4].node, yyvsp[-2].node),
						(Node *) makeSimpleA_Expr(OP, "<=", yyvsp[-4].node, yyvsp[0].node));
				}
    break;

  case 930:
#line 5784 "gram.y"
    {
					yyval.node = (Node *) makeA_Expr(OR, NIL,
						(Node *) makeSimpleA_Expr(OP, "<", yyvsp[-5].node, yyvsp[-2].node),
						(Node *) makeSimpleA_Expr(OP, ">", yyvsp[-5].node, yyvsp[0].node));
				}
    break;

  case 931:
#line 5790 "gram.y"
    {
					/* in_expr returns a SubLink or a list of a_exprs */
					if (IsA(yyvsp[0].node, SubLink))
					{
							SubLink *n = (SubLink *)yyvsp[0].node;
							n->lefthand = makeList1(yyvsp[-2].node);
							n->oper = (List *) makeSimpleA_Expr(OP, "=", NULL, NULL);
							n->useor = FALSE;
							n->subLinkType = ANY_SUBLINK;
							yyval.node = (Node *)n;
					}
					else
					{
						Node *n = NULL;
						List *l;
						foreach(l, (List *) yyvsp[0].node)
						{
							Node *cmp;
							cmp = (Node *) makeSimpleA_Expr(OP, "=", yyvsp[-2].node, lfirst(l));
							if (n == NULL)
								n = cmp;
							else
								n = (Node *) makeA_Expr(OR, NIL, n, cmp);
						}
						yyval.node = n;
					}
				}
    break;

  case 932:
#line 5818 "gram.y"
    {
					/* in_expr returns a SubLink or a list of a_exprs */
					if (IsA(yyvsp[0].node, SubLink))
					{
						SubLink *n = (SubLink *)yyvsp[0].node;
						n->lefthand = makeList1(yyvsp[-3].node);
						n->oper = (List *) makeSimpleA_Expr(OP, "<>", NULL, NULL);
						n->useor = FALSE;
						n->subLinkType = ALL_SUBLINK;
						yyval.node = (Node *)n;
					}
					else
					{
						Node *n = NULL;
						List *l;
						foreach(l, (List *) yyvsp[0].node)
						{
							Node *cmp;
							cmp = (Node *) makeSimpleA_Expr(OP, "<>", yyvsp[-3].node, lfirst(l));
							if (n == NULL)
								n = cmp;
							else
								n = (Node *) makeA_Expr(AND, NIL, n, cmp);
						}
						yyval.node = n;
					}
				}
    break;

  case 933:
#line 5846 "gram.y"
    {
					SubLink *n = makeNode(SubLink);
					n->lefthand = makeList1(yyvsp[-3].node);
					n->oper = (List *) makeA_Expr(OP, yyvsp[-2].list, NULL, NULL);
					n->useor = FALSE; /* doesn't matter since only one col */
					n->subLinkType = yyvsp[-1].ival;
					n->subselect = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 934:
#line 5856 "gram.y"
    {
					/* Not sure how to get rid of the parentheses
					 * but there are lots of shift/reduce errors without them.
					 *
					 * Should be able to implement this by plopping the entire
					 * select into a node, then transforming the target expressions
					 * from whatever they are into count(*), and testing the
					 * entire result equal to one.
					 * But, will probably implement a separate node in the executor.
					 */
					elog(ERROR, "UNIQUE predicate is not yet implemented");
				}
    break;

  case 935:
#line 5869 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 936:
#line 5882 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 937:
#line 5884 "gram.y"
    { yyval.node = makeTypeCast(yyvsp[-2].node, yyvsp[0].typnam); }
    break;

  case 938:
#line 5886 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "+", NULL, yyvsp[0].node); }
    break;

  case 939:
#line 5888 "gram.y"
    { yyval.node = doNegate(yyvsp[0].node); }
    break;

  case 940:
#line 5890 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "%", NULL, yyvsp[0].node); }
    break;

  case 941:
#line 5892 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "^", NULL, yyvsp[0].node); }
    break;

  case 942:
#line 5894 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "%", yyvsp[-1].node, NULL); }
    break;

  case 943:
#line 5896 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "^", yyvsp[-1].node, NULL); }
    break;

  case 944:
#line 5898 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "+", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 945:
#line 5900 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "-", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 946:
#line 5902 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "*", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 947:
#line 5904 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "/", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 948:
#line 5906 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "%", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 949:
#line 5908 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "^", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 950:
#line 5910 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "<", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 951:
#line 5912 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, ">", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 952:
#line 5914 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(OP, "=", yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 953:
#line 5916 "gram.y"
    { yyval.node = (Node *) makeA_Expr(OP, yyvsp[-1].list, yyvsp[-2].node, yyvsp[0].node); }
    break;

  case 954:
#line 5918 "gram.y"
    { yyval.node = (Node *) makeA_Expr(OP, yyvsp[-1].list, NULL, yyvsp[0].node); }
    break;

  case 955:
#line 5920 "gram.y"
    { yyval.node = (Node *) makeA_Expr(OP, yyvsp[0].list, yyvsp[-1].node, NULL); }
    break;

  case 956:
#line 5922 "gram.y"
    { yyval.node = (Node *) makeSimpleA_Expr(DISTINCT, "=", yyvsp[-4].node, yyvsp[0].node); }
    break;

  case 957:
#line 5924 "gram.y"
    {
					yyval.node = (Node *) makeSimpleA_Expr(OF, "=", yyvsp[-5].node, (Node *) yyvsp[-1].list);
				}
    break;

  case 958:
#line 5928 "gram.y"
    {
					yyval.node = (Node *) makeSimpleA_Expr(OF, "!=", yyvsp[-6].node, (Node *) yyvsp[-1].list);
				}
    break;

  case 959:
#line 5941 "gram.y"
    { yyval.node = (Node *) yyvsp[0].columnref; }
    break;

  case 960:
#line 5942 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 961:
#line 5944 "gram.y"
    {
					/*
					 * PARAM without field names is considered a constant,
					 * but with 'em, it is not.  Not very consistent ...
					 */
					ParamRef *n = makeNode(ParamRef);
					n->number = yyvsp[-2].ival;
					n->fields = yyvsp[-1].list;
					n->indirection = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 962:
#line 5955 "gram.y"
    { yyval.node = yyvsp[-1].node; }
    break;

  case 963:
#line 5957 "gram.y"
    {
					ExprFieldSelect *n = makeNode(ExprFieldSelect);
					n->arg = yyvsp[-3].node;
					n->fields = yyvsp[-1].list;
					n->indirection = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 964:
#line 5965 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 965:
#line 5967 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = yyvsp[-2].list;
					n->args = NIL;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 966:
#line 5976 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = yyvsp[-3].list;
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 967:
#line 5985 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = yyvsp[-4].list;
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					/* Ideally we'd mark the FuncCall node to indicate
					 * "must be an aggregate", but there's no provision
					 * for that in FuncCall at the moment.
					 */
					yyval.node = (Node *)n;
				}
    break;

  case 968:
#line 5998 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = yyvsp[-4].list;
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = TRUE;
					yyval.node = (Node *)n;
				}
    break;

  case 969:
#line 6007 "gram.y"
    {
					/*
					 * For now, we transform AGGREGATE(*) into AGGREGATE(1).
					 *
					 * This does the right thing for COUNT(*) (in fact,
					 * any certainly-non-null expression would do for COUNT),
					 * and there are no other aggregates in SQL92 that accept
					 * '*' as parameter.
					 *
					 * The FuncCall node is also marked agg_star = true,
					 * so that later processing can detect what the argument
					 * really was.
					 */
					FuncCall *n = makeNode(FuncCall);
					A_Const *star = makeNode(A_Const);

					star->val.type = T_Integer;
					star->val.val.ival = 1;
					n->funcname = yyvsp[-3].list;
					n->args = makeList1(star);
					n->agg_star = TRUE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 970:
#line 6032 "gram.y"
    {
					/*
					 * Translate as "'now'::text::date".
					 *
					 * We cannot use "'now'::date" because coerce_type() will
					 * immediately reduce that to a constant representing
					 * today's date.  We need to delay the conversion until
					 * runtime, else the wrong things will happen when
					 * CURRENT_DATE is used in a column default value or rule.
					 *
					 * This could be simplified if we had a way to generate
					 * an expression tree representing runtime application
					 * of type-input conversion functions...
					 */
					A_Const *s = makeNode(A_Const);
					TypeName *d;

					s->val.type = T_String;
					s->val.val.str = "now";
					s->typename = SystemTypeName("text");

					d = SystemTypeName("date");

					yyval.node = (Node *)makeTypeCast((Node *)s, d);
				}
    break;

  case 971:
#line 6058 "gram.y"
    {
					/*
					 * Translate as "'now'::text::timetz".
					 * See comments for CURRENT_DATE.
					 */
					A_Const *s = makeNode(A_Const);
					TypeName *d;

					s->val.type = T_String;
					s->val.val.str = "now";
					s->typename = SystemTypeName("text");

					d = SystemTypeName("timetz");
					/* SQL99 mandates a default precision of zero for TIME
					 * fields in schemas. However, for CURRENT_TIME
					 * let's preserve the microsecond precision we
					 * might see from the system clock. - thomas 2001-12-07
					 */
					d->typmod = 6;

					yyval.node = (Node *)makeTypeCast((Node *)s, d);
				}
    break;

  case 972:
#line 6081 "gram.y"
    {
					/*
					 * Translate as "'now'::text::timetz(n)".
					 * See comments for CURRENT_DATE.
					 */
					A_Const *s = makeNode(A_Const);
					TypeName *d;

					s->val.type = T_String;
					s->val.val.str = "now";
					s->typename = SystemTypeName("text");
					d = SystemTypeName("timetz");
					if (yyvsp[-1].ival < 0)
						elog(ERROR,
							 "CURRENT_TIME(%d) precision must not be negative",
							 yyvsp[-1].ival);
					if (yyvsp[-1].ival > MAX_TIME_PRECISION)
					{
						elog(NOTICE,
							 "CURRENT_TIME(%d) precision reduced to maximum allowed, %d",
							 yyvsp[-1].ival, MAX_TIME_PRECISION);
						yyvsp[-1].ival = MAX_TIME_PRECISION;
					}
					d->typmod = yyvsp[-1].ival;

					yyval.node = (Node *)makeTypeCast((Node *)s, d);
				}
    break;

  case 973:
#line 6109 "gram.y"
    {
					/*
					 * Translate as "'now'::text::timestamptz".
					 * See comments for CURRENT_DATE.
					 */
					A_Const *s = makeNode(A_Const);
					TypeName *d;

					s->val.type = T_String;
					s->val.val.str = "now";
					s->typename = SystemTypeName("text");

					d = SystemTypeName("timestamptz");
					/* SQL99 mandates a default precision of 6 for timestamp.
					 * Also, that is about as precise as we will get since
					 * we are using a microsecond time interface.
					 * - thomas 2001-12-07
					 */
					d->typmod = 6;

					yyval.node = (Node *)makeTypeCast((Node *)s, d);
				}
    break;

  case 974:
#line 6132 "gram.y"
    {
					/*
					 * Translate as "'now'::text::timestamptz(n)".
					 * See comments for CURRENT_DATE.
					 */
					A_Const *s = makeNode(A_Const);
					TypeName *d;

					s->val.type = T_String;
					s->val.val.str = "now";
					s->typename = SystemTypeName("text");

					d = SystemTypeName("timestamptz");
					if (yyvsp[-1].ival < 0)
						elog(ERROR,
							 "CURRENT_TIMESTAMP(%d) precision must not be negative",
							 yyvsp[-1].ival);
					if (yyvsp[-1].ival > MAX_TIMESTAMP_PRECISION)
					{
						elog(NOTICE,
							 "CURRENT_TIMESTAMP(%d) precision reduced to maximum allowed, %d",
							 yyvsp[-1].ival, MAX_TIMESTAMP_PRECISION);
						yyvsp[-1].ival = MAX_TIMESTAMP_PRECISION;
					}
					d->typmod = yyvsp[-1].ival;

					yyval.node = (Node *)makeTypeCast((Node *)s, d);
				}
    break;

  case 975:
#line 6161 "gram.y"
    {
					/*
					 * Translate as "'now'::text::time".
					 * See comments for CURRENT_DATE.
					 */
					A_Const *s = makeNode(A_Const);
					TypeName *d;

					s->val.type = T_String;
					s->val.val.str = "now";
					s->typename = SystemTypeName("text");

					d = SystemTypeName("time");
					/* SQL99 mandates a default precision of zero for TIME
					 * fields in schemas. However, for LOCALTIME
					 * let's preserve the microsecond precision we
					 * might see from the system clock. - thomas 2001-12-07
					 */
					d->typmod = 6;

					yyval.node = (Node *)makeTypeCast((Node *)s, d);
				}
    break;

  case 976:
#line 6184 "gram.y"
    {
					/*
					 * Translate as "'now'::text::time(n)".
					 * See comments for CURRENT_DATE.
					 */
					A_Const *s = makeNode(A_Const);
					TypeName *d;

					s->val.type = T_String;
					s->val.val.str = "now";
					s->typename = SystemTypeName("text");
					d = SystemTypeName("time");
					if (yyvsp[-1].ival < 0)
						elog(ERROR,
							 "LOCALTIME(%d) precision must not be negative",
							 yyvsp[-1].ival);
					if (yyvsp[-1].ival > MAX_TIME_PRECISION)
					{
						elog(NOTICE,
							 "LOCALTIME(%d) precision reduced to maximum allowed, %d",
							 yyvsp[-1].ival, MAX_TIME_PRECISION);
						yyvsp[-1].ival = MAX_TIME_PRECISION;
					}
					d->typmod = yyvsp[-1].ival;

					yyval.node = (Node *)makeTypeCast((Node *)s, d);
				}
    break;

  case 977:
#line 6212 "gram.y"
    {
					/*
					 * Translate as "'now'::text::timestamp".
					 * See comments for CURRENT_DATE.
					 */
					A_Const *s = makeNode(A_Const);
					TypeName *d;

					s->val.type = T_String;
					s->val.val.str = "now";
					s->typename = SystemTypeName("text");

					d = SystemTypeName("timestamp");
					/* SQL99 mandates a default precision of 6 for timestamp.
					 * Also, that is about as precise as we will get since
					 * we are using a microsecond time interface.
					 * - thomas 2001-12-07
					 */
					d->typmod = 6;

					yyval.node = (Node *)makeTypeCast((Node *)s, d);
				}
    break;

  case 978:
#line 6235 "gram.y"
    {
					/*
					 * Translate as "'now'::text::timestamp(n)".
					 * See comments for CURRENT_DATE.
					 */
					A_Const *s = makeNode(A_Const);
					TypeName *d;

					s->val.type = T_String;
					s->val.val.str = "now";
					s->typename = SystemTypeName("text");

					d = SystemTypeName("timestamp");
					if (yyvsp[-1].ival < 0)
						elog(ERROR,
							 "LOCALTIMESTAMP(%d) precision must not be negative",
							 yyvsp[-1].ival);
					if (yyvsp[-1].ival > MAX_TIMESTAMP_PRECISION)
					{
						elog(NOTICE,
							 "LOCALTIMESTAMP(%d) precision reduced to maximum allowed, %d",
							 yyvsp[-1].ival, MAX_TIMESTAMP_PRECISION);
						yyvsp[-1].ival = MAX_TIMESTAMP_PRECISION;
					}
					d->typmod = yyvsp[-1].ival;

					yyval.node = (Node *)makeTypeCast((Node *)s, d);
				}
    break;

  case 979:
#line 6264 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("current_user");
					n->args = NIL;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 980:
#line 6273 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("session_user");
					n->args = NIL;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 981:
#line 6282 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("current_user");
					n->args = NIL;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 982:
#line 6291 "gram.y"
    { yyval.node = makeTypeCast(yyvsp[-3].node, yyvsp[-1].typnam); }
    break;

  case 983:
#line 6293 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("date_part");
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 984:
#line 6302 "gram.y"
    {
					/* overlay(A PLACING B FROM C FOR D) is converted to
					 * substring(A, 1, C-1) || B || substring(A, C+1, C+D)
					 * overlay(A PLACING B FROM C) is converted to
					 * substring(A, 1, C-1) || B || substring(A, C+1, C+char_length(B))
					 */
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("overlay");
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 985:
#line 6316 "gram.y"
    {
					/* position(A in B) is converted to position(B, A) */
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("position");
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 986:
#line 6326 "gram.y"
    {
					/* substring(A from B for C) is converted to
					 * substring(A, B, C) - thomas 2000-11-28
					 */
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("substring");
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 987:
#line 6338 "gram.y"
    {
					/* TREAT(expr AS target) converts expr of a particular type to target,
					 * which is defined to be a subtype of the original expression.
					 * In SQL99, this is intended for use with structured UDTs,
					 * but let's make this a generally useful form allowing stronger
					 * coersions than are handled by implicit casting.
					 */
					FuncCall *n = makeNode(FuncCall);
					/* Convert SystemTypeName() to SystemFuncName() even though
					 * at the moment they result in the same thing.
					 */
					n->funcname = SystemFuncName(((Value *)llast(yyvsp[-1].typnam->names))->val.str);
					n->args = makeList1(yyvsp[-3].node);
					yyval.node = (Node *)n;
				}
    break;

  case 988:
#line 6354 "gram.y"
    {
					/* various trim expressions are defined in SQL92
					 * - thomas 1997-07-19
					 */
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("btrim");
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 989:
#line 6366 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("ltrim");
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 990:
#line 6375 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("rtrim");
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 991:
#line 6384 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("btrim");
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 992:
#line 6393 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					A_Const *c = makeNode(A_Const);

					c->val.type = T_String;
					c->val.val.str = NameListToQuotedString(yyvsp[-1].list);

					n->funcname = SystemFuncName("convert_using");
					n->args = makeList2(yyvsp[-3].node, c);
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 993:
#line 6407 "gram.y"
    {
					FuncCall *n = makeNode(FuncCall);
					n->funcname = SystemFuncName("convert");
					n->args = yyvsp[-1].list;
					n->agg_star = FALSE;
					n->agg_distinct = FALSE;
					yyval.node = (Node *)n;
				}
    break;

  case 994:
#line 6416 "gram.y"
    {
					SubLink *n = makeNode(SubLink);
					n->lefthand = NIL;
					n->oper = NIL;
					n->useor = FALSE;
					n->subLinkType = EXPR_SUBLINK;
					n->subselect = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 995:
#line 6426 "gram.y"
    {
					SubLink *n = makeNode(SubLink);
					n->lefthand = NIL;
					n->oper = NIL;
					n->useor = FALSE;
					n->subLinkType = EXISTS_SUBLINK;
					n->subselect = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 996:
#line 6443 "gram.y"
    {
					A_Indices *ai = makeNode(A_Indices);
					ai->lidx = NULL;
					ai->uidx = yyvsp[-1].node;
					yyval.list = lappend(yyvsp[-3].list, ai);
				}
    break;

  case 997:
#line 6450 "gram.y"
    {
					A_Indices *ai = makeNode(A_Indices);
					ai->lidx = yyvsp[-3].node;
					ai->uidx = yyvsp[-1].node;
					yyval.list = lappend(yyvsp[-5].list, ai);
				}
    break;

  case 998:
#line 6457 "gram.y"
    { yyval.list = NIL; }
    break;

  case 999:
#line 6460 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 1000:
#line 6461 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].node); }
    break;

  case 1001:
#line 6466 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->val.type = T_String;
					n->val.val.str = yyvsp[-2].str;
					yyval.list = makeList2((Node *) n, yyvsp[0].node);
				}
    break;

  case 1002:
#line 6472 "gram.y"
    { yyval.list = NIL; }
    break;

  case 1003:
#line 6476 "gram.y"
    {
					yyval.list = lappend(yyvsp[-2].list, yyvsp[0].typnam);
				}
    break;

  case 1004:
#line 6480 "gram.y"
    {
					yyval.list = makeList1(yyvsp[0].typnam);
				}
    break;

  case 1005:
#line 6490 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1006:
#line 6491 "gram.y"
    { yyval.str = "year"; }
    break;

  case 1007:
#line 6492 "gram.y"
    { yyval.str = "month"; }
    break;

  case 1008:
#line 6493 "gram.y"
    { yyval.str = "day"; }
    break;

  case 1009:
#line 6494 "gram.y"
    { yyval.str = "hour"; }
    break;

  case 1010:
#line 6495 "gram.y"
    { yyval.str = "minute"; }
    break;

  case 1011:
#line 6496 "gram.y"
    { yyval.str = "second"; }
    break;

  case 1012:
#line 6497 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1013:
#line 6507 "gram.y"
    {
					yyval.list = makeList4(yyvsp[-3].node, yyvsp[-2].node, yyvsp[-1].node, yyvsp[0].node);
				}
    break;

  case 1014:
#line 6511 "gram.y"
    {
					yyval.list = makeList3(yyvsp[-2].node, yyvsp[-1].node, yyvsp[0].node);
				}
    break;

  case 1015:
#line 6518 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 1016:
#line 6524 "gram.y"
    { yyval.list = makeList2(yyvsp[0].node, yyvsp[-2].node); }
    break;

  case 1017:
#line 6525 "gram.y"
    { yyval.list = NIL; }
    break;

  case 1018:
#line 6541 "gram.y"
    {
					yyval.list = makeList3(yyvsp[-2].node, yyvsp[-1].node, yyvsp[0].node);
				}
    break;

  case 1019:
#line 6545 "gram.y"
    {
					yyval.list = makeList3(yyvsp[-2].node, yyvsp[0].node, yyvsp[-1].node);
				}
    break;

  case 1020:
#line 6549 "gram.y"
    {
					yyval.list = makeList2(yyvsp[-1].node, yyvsp[0].node);
				}
    break;

  case 1021:
#line 6553 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->val.type = T_Integer;
					n->val.val.ival = 1;
					yyval.list = makeList3(yyvsp[-1].node, (Node *)n, yyvsp[0].node);
				}
    break;

  case 1022:
#line 6560 "gram.y"
    {
					yyval.list = yyvsp[0].list;
				}
    break;

  case 1023:
#line 6564 "gram.y"
    { yyval.list = NIL; }
    break;

  case 1024:
#line 6568 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 1025:
#line 6571 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 1026:
#line 6574 "gram.y"
    { yyval.list = lappend(yyvsp[0].list, yyvsp[-2].node); }
    break;

  case 1027:
#line 6575 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 1028:
#line 6576 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 1029:
#line 6580 "gram.y"
    {
					SubLink *n = makeNode(SubLink);
					n->subselect = yyvsp[0].node;
					yyval.node = (Node *)n;
				}
    break;

  case 1030:
#line 6585 "gram.y"
    { yyval.node = (Node *)yyvsp[-1].list; }
    break;

  case 1031:
#line 6604 "gram.y"
    {
					CaseExpr *c = makeNode(CaseExpr);
					c->arg = yyvsp[-3].node;
					c->args = yyvsp[-2].list;
					c->defresult = yyvsp[-1].node;
					yyval.node = (Node *)c;
				}
    break;

  case 1032:
#line 6612 "gram.y"
    {
					CaseExpr *c = makeNode(CaseExpr);
					CaseWhen *w = makeNode(CaseWhen);

					w->expr = (Node *) makeSimpleA_Expr(OP, "=", yyvsp[-3].node, yyvsp[-1].node);
					/* w->result is left NULL */
					c->args = makeList1(w);
					c->defresult = yyvsp[-3].node;
					yyval.node = (Node *)c;
				}
    break;

  case 1033:
#line 6623 "gram.y"
    {
					CaseExpr *c = makeNode(CaseExpr);
					List *l;
					foreach (l,yyvsp[-1].list)
					{
						CaseWhen *w = makeNode(CaseWhen);
						NullTest *n = makeNode(NullTest);
						n->arg = lfirst(l);
						n->nulltesttype = IS_NOT_NULL;
						w->expr = (Node *) n;
						w->result = lfirst(l);
						c->args = lappend(c->args, w);
					}
					yyval.node = (Node *)c;
				}
    break;

  case 1034:
#line 6642 "gram.y"
    { yyval.list = makeList1(yyvsp[0].node); }
    break;

  case 1035:
#line 6643 "gram.y"
    { yyval.list = lappend(yyvsp[-1].list, yyvsp[0].node); }
    break;

  case 1036:
#line 6648 "gram.y"
    {
					CaseWhen *w = makeNode(CaseWhen);
					w->expr = yyvsp[-2].node;
					w->result = yyvsp[0].node;
					yyval.node = (Node *)w;
				}
    break;

  case 1037:
#line 6657 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 1038:
#line 6658 "gram.y"
    { yyval.node = NULL; }
    break;

  case 1039:
#line 6661 "gram.y"
    { yyval.node = yyvsp[0].node; }
    break;

  case 1040:
#line 6662 "gram.y"
    { yyval.node = NULL; }
    break;

  case 1041:
#line 6671 "gram.y"
    {
					yyval.columnref = makeNode(ColumnRef);
					yyval.columnref->fields = makeList1(makeString(yyvsp[-1].str));
					yyval.columnref->indirection = yyvsp[0].list;
				}
    break;

  case 1042:
#line 6677 "gram.y"
    {
					yyval.columnref = makeNode(ColumnRef);
					yyval.columnref->fields = yyvsp[-1].list;
					yyval.columnref->indirection = yyvsp[0].list;
				}
    break;

  case 1043:
#line 6686 "gram.y"
    { yyval.list = lcons(makeString(yyvsp[-1].str), yyvsp[0].list); }
    break;

  case 1044:
#line 6690 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 1045:
#line 6692 "gram.y"
    { yyval.list = makeList1(makeString("*")); }
    break;

  case 1046:
#line 6694 "gram.y"
    { yyval.list = lcons(makeString(yyvsp[-1].str), yyvsp[0].list); }
    break;

  case 1047:
#line 6707 "gram.y"
    { yyval.list = makeList1(yyvsp[0].target); }
    break;

  case 1048:
#line 6708 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].target); }
    break;

  case 1049:
#line 6713 "gram.y"
    {
					yyval.target = makeNode(ResTarget);
					yyval.target->name = yyvsp[0].str;
					yyval.target->indirection = NIL;
					yyval.target->val = (Node *)yyvsp[-2].node;
				}
    break;

  case 1050:
#line 6720 "gram.y"
    {
					yyval.target = makeNode(ResTarget);
					yyval.target->name = NULL;
					yyval.target->indirection = NIL;
					yyval.target->val = (Node *)yyvsp[0].node;
				}
    break;

  case 1051:
#line 6727 "gram.y"
    {
					ColumnRef *n = makeNode(ColumnRef);
					n->fields = makeList1(makeString("*"));
					n->indirection = NIL;
					yyval.target = makeNode(ResTarget);
					yyval.target->name = NULL;
					yyval.target->indirection = NIL;
					yyval.target->val = (Node *)n;
				}
    break;

  case 1052:
#line 6745 "gram.y"
    { yyval.list = makeList1(yyvsp[0].target); }
    break;

  case 1053:
#line 6746 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list,yyvsp[0].target); }
    break;

  case 1054:
#line 6751 "gram.y"
    {
					yyval.target = makeNode(ResTarget);
					yyval.target->name = yyvsp[-3].str;
					yyval.target->indirection = yyvsp[-2].list;
					yyval.target->val = (Node *)yyvsp[0].node;
				}
    break;

  case 1055:
#line 6760 "gram.y"
    { yyval.list = makeList1(yyvsp[0].target); }
    break;

  case 1056:
#line 6761 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].target); }
    break;

  case 1057:
#line 6765 "gram.y"
    { yyval.target = yyvsp[0].target; }
    break;

  case 1058:
#line 6767 "gram.y"
    {
					InsertDefault *def = makeNode(InsertDefault);
					yyval.target = makeNode(ResTarget);
					yyval.target->name = NULL;
					yyval.target->indirection = NULL;
					yyval.target->val = (Node *)def;
				}
    break;

  case 1059:
#line 6784 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1060:
#line 6785 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1061:
#line 6789 "gram.y"
    { yyval.list = makeList1(yyvsp[0].range); }
    break;

  case 1062:
#line 6790 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, yyvsp[0].range); }
    break;

  case 1063:
#line 6795 "gram.y"
    {
					yyval.range = makeNode(RangeVar);
					yyval.range->catalogname = NULL;
					yyval.range->schemaname = NULL;
					yyval.range->relname = yyvsp[0].str;
				}
    break;

  case 1064:
#line 6802 "gram.y"
    {
					yyval.range = makeNode(RangeVar);
					switch (length(yyvsp[0].list))
					{
						case 2:
							yyval.range->catalogname = NULL;
							yyval.range->schemaname = strVal(lfirst(yyvsp[0].list));
							yyval.range->relname = strVal(lsecond(yyvsp[0].list));
							break;
						case 3:
							yyval.range->catalogname = strVal(lfirst(yyvsp[0].list));
							yyval.range->schemaname = strVal(lsecond(yyvsp[0].list));
							yyval.range->relname = strVal(lfirst(lnext(lnext(yyvsp[0].list))));
							break;
						default:
							elog(ERROR,
								 "Improper qualified name "
								 "(too many dotted names): %s",
								 NameListToString(yyvsp[0].list));
							break;
					}
				}
    break;

  case 1065:
#line 6827 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 1066:
#line 6829 "gram.y"
    { yyval.list = lappend(yyvsp[-2].list, makeString(yyvsp[0].str)); }
    break;

  case 1067:
#line 6833 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1068:
#line 6836 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1069:
#line 6839 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1070:
#line 6841 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1071:
#line 6843 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1072:
#line 6845 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1073:
#line 6848 "gram.y"
    { yyval.list = makeList1(makeString(yyvsp[0].str)); }
    break;

  case 1074:
#line 6849 "gram.y"
    { yyval.list = yyvsp[0].list; }
    break;

  case 1075:
#line 6857 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->val.type = T_Integer;
					n->val.val.ival = yyvsp[0].ival;
					yyval.node = (Node *)n;
				}
    break;

  case 1076:
#line 6864 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->val.type = T_Float;
					n->val.val.str = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 1077:
#line 6871 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->val.type = T_String;
					n->val.val.str = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 1078:
#line 6878 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->val.type = T_BitString;
					n->val.val.str = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 1079:
#line 6885 "gram.y"
    {
					/* This is a bit constant per SQL99:
					 * Without Feature F511, "BIT data type",
					 * a <general literal> shall not be a
					 * <bit string literal> or a <hex string literal>.
					 */
					A_Const *n = makeNode(A_Const);
					n->val.type = T_BitString;
					n->val.val.str = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 1080:
#line 6897 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->typename = yyvsp[-1].typnam;
					n->val.type = T_String;
					n->val.val.str = yyvsp[0].str;
					yyval.node = (Node *)n;
				}
    break;

  case 1081:
#line 6905 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->typename = yyvsp[-2].typnam;
					n->val.type = T_String;
					n->val.val.str = yyvsp[-1].str;
					/* precision is not specified, but fields may be... */
					if (yyvsp[0].ival != INTERVAL_FULL_RANGE)
						n->typename->typmod = INTERVAL_TYPMOD(INTERVAL_FULL_PRECISION, yyvsp[0].ival);
					yyval.node = (Node *)n;
				}
    break;

  case 1082:
#line 6916 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->typename = yyvsp[-5].typnam;
					n->val.type = T_String;
					n->val.val.str = yyvsp[-1].str;
					/* precision specified, and fields may be... */
					if (yyvsp[-3].ival < 0)
						elog(ERROR,
							 "INTERVAL(%d) precision must not be negative",
							 yyvsp[-3].ival);
					if (yyvsp[-3].ival > MAX_INTERVAL_PRECISION)
					{
						elog(NOTICE,
							"INTERVAL(%d) precision reduced to maximum allowed, %d",
							yyvsp[-3].ival, MAX_INTERVAL_PRECISION);
						yyvsp[-3].ival = MAX_INTERVAL_PRECISION;
					}
					n->typename->typmod = INTERVAL_TYPMOD(yyvsp[-3].ival, yyvsp[0].ival);
					yyval.node = (Node *)n;
				}
    break;

  case 1083:
#line 6937 "gram.y"
    {
					ParamRef *n = makeNode(ParamRef);
					n->number = yyvsp[-1].ival;
					n->fields = NIL;
					n->indirection = yyvsp[0].list;
					yyval.node = (Node *)n;
				}
    break;

  case 1084:
#line 6945 "gram.y"
    {
					yyval.node = (Node *)makeBoolConst(TRUE);
				}
    break;

  case 1085:
#line 6949 "gram.y"
    {
					yyval.node = (Node *)makeBoolConst(FALSE);
				}
    break;

  case 1086:
#line 6953 "gram.y"
    {
					A_Const *n = makeNode(A_Const);
					n->val.type = T_Null;
					yyval.node = (Node *)n;
				}
    break;

  case 1087:
#line 6960 "gram.y"
    { yyval.ival = yyvsp[0].ival; }
    break;

  case 1088:
#line 6961 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1089:
#line 6962 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1090:
#line 6977 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1091:
#line 6978 "gram.y"
    { yyval.str = pstrdup(yyvsp[0].keyword); }
    break;

  case 1092:
#line 6979 "gram.y"
    { yyval.str = pstrdup(yyvsp[0].keyword); }
    break;

  case 1093:
#line 6984 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1094:
#line 6985 "gram.y"
    { yyval.str = pstrdup(yyvsp[0].keyword); }
    break;

  case 1095:
#line 6991 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1096:
#line 6992 "gram.y"
    { yyval.str = pstrdup(yyvsp[0].keyword); }
    break;

  case 1097:
#line 6993 "gram.y"
    { yyval.str = pstrdup(yyvsp[0].keyword); }
    break;

  case 1098:
#line 6999 "gram.y"
    { yyval.str = yyvsp[0].str; }
    break;

  case 1099:
#line 7000 "gram.y"
    { yyval.str = pstrdup(yyvsp[0].keyword); }
    break;

  case 1100:
#line 7001 "gram.y"
    { yyval.str = pstrdup(yyvsp[0].keyword); }
    break;

  case 1101:
#line 7002 "gram.y"
    { yyval.str = pstrdup(yyvsp[0].keyword); }
    break;

  case 1102:
#line 7003 "gram.y"
    { yyval.str = pstrdup(yyvsp[0].keyword); }
    break;

  case 1399:
#line 7355 "gram.y"
    {
					if (QueryIsRule)
						yyval.str = "*OLD*";
					else
						elog(ERROR, "OLD used in non-rule query");
				}
    break;

  case 1400:
#line 7362 "gram.y"
    {
					if (QueryIsRule)
						yyval.str = "*NEW*";
					else
						elog(ERROR, "NEW used in non-rule query");
				}
    break;


    }

/* Line 991 of yacc.c.  */
#line 17205 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("parse error, unexpected ") + 1;
	  yysize += yystrlen (yytname[yytype]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "parse error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("parse error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyss < yyssp)
	    {
	      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
	      yydestruct (yystos[*yyssp], yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
      yydestruct (yytoken, &yylval);
      yychar = YYEMPTY;

    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab2;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:

  /* Suppress GCC warning that yyerrlab1 is unused when no action
     invokes YYERROR.  */
#if defined (__GNUC_MINOR__) && 2093 <= (__GNUC__ * 1000 + __GNUC_MINOR__)
  __attribute__ ((__unused__))
#endif


  goto yyerrlab2;


/*---------------------------------------------------------------.
| yyerrlab2 -- pop states until the error token can be shifted.  |
`---------------------------------------------------------------*/
yyerrlab2:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      yyvsp--;
      yystate = *--yyssp;

      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 7370 "gram.y"


static Node *
makeTypeCast(Node *arg, TypeName *typename)
{
	/*
	 * Simply generate a TypeCast node.
	 *
	 * Earlier we would determine whether an A_Const would
	 * be acceptable, however Domains require coerce_type()
	 * to process them -- applying constraints as required.
	 */
	TypeCast *n = makeNode(TypeCast);
	n->arg = arg;
	n->typename = typename;
	return (Node *) n;
}

static Node *
makeStringConst(char *str, TypeName *typename)
{
	A_Const *n = makeNode(A_Const);

	n->val.type = T_String;
	n->val.val.str = str;
	n->typename = typename;

	return (Node *)n;
}

static Node *
makeIntConst(int val)
{
	A_Const *n = makeNode(A_Const);
	n->val.type = T_Integer;
	n->val.val.ival = val;
	n->typename = SystemTypeName("int4");

	return (Node *)n;
}

static Node *
makeFloatConst(char *str)
{
	A_Const *n = makeNode(A_Const);

	n->val.type = T_Float;
	n->val.val.str = str;
	n->typename = SystemTypeName("float8");

	return (Node *)n;
}

static Node *
makeAConst(Value *v)
{
	Node *n;

	switch (v->type)
	{
		case T_Float:
			n = makeFloatConst(v->val.str);
			break;

		case T_Integer:
			n = makeIntConst(v->val.ival);
			break;

		case T_String:
		default:
			n = makeStringConst(v->val.str, NULL);
			break;
	}

	return n;
}

/* makeDefElem()
 * Create a DefElem node and set contents.
 * Could be moved to nodes/makefuncs.c if this is useful elsewhere.
 */
static DefElem *
makeDefElem(char *name, Node *arg)
{
	DefElem *f = makeNode(DefElem);
	f->defname = name;
	f->arg = arg;
	return f;
}

/* makeBoolConst()
 * Create an A_Const node and initialize to a boolean constant.
 */
static A_Const *
makeBoolConst(bool state)
{
	A_Const *n = makeNode(A_Const);
	n->val.type = T_String;
	n->val.val.str = (state? "t": "f");
	n->typename = SystemTypeName("bool");
	return n;
}

/* makeRowExpr()
 * Generate separate operator nodes for a single row descriptor expression.
 * Perhaps this should go deeper in the parser someday...
 * - thomas 1997-12-22
 */
static Node *
makeRowExpr(List *opr, List *largs, List *rargs)
{
	Node *expr = NULL;
	Node *larg, *rarg;
	char *oprname;

	if (length(largs) != length(rargs))
		elog(ERROR, "Unequal number of entries in row expression");

	if (lnext(largs) != NIL)
		expr = makeRowExpr(opr, lnext(largs), lnext(rargs));

	larg = lfirst(largs);
	rarg = lfirst(rargs);

	oprname = strVal(llast(opr));

	if ((strcmp(oprname, "=") == 0) ||
		(strcmp(oprname, "<") == 0) ||
		(strcmp(oprname, "<=") == 0) ||
		(strcmp(oprname, ">") == 0) ||
		(strcmp(oprname, ">=") == 0))
	{
		if (expr == NULL)
			expr = (Node *) makeA_Expr(OP, opr, larg, rarg);
		else
			expr = (Node *) makeA_Expr(AND, NIL, expr,
									   (Node *) makeA_Expr(OP, opr,
														   larg, rarg));
	}
	else if (strcmp(oprname, "<>") == 0)
	{
		if (expr == NULL)
			expr = (Node *) makeA_Expr(OP, opr, larg, rarg);
		else
			expr = (Node *) makeA_Expr(OR, NIL, expr,
									   (Node *) makeA_Expr(OP, opr,
														   larg, rarg));
	}
	else
	{
		elog(ERROR, "Operator '%s' not implemented for row expressions",
			 oprname);
	}

	return expr;
}

/* makeDistinctExpr()
 * Generate separate operator nodes for a single row descriptor expression.
 * Same comments as for makeRowExpr().
 */
static Node *
makeDistinctExpr(List *largs, List *rargs)
{
	Node *expr = NULL;
	Node *larg, *rarg;

	if (length(largs) != length(rargs))
		elog(ERROR, "Unequal number of entries in row expression");

	if (lnext(largs) != NIL)
		expr = makeDistinctExpr(lnext(largs), lnext(rargs));

	larg = lfirst(largs);
	rarg = lfirst(rargs);

	if (expr == NULL)
		expr = (Node *) makeSimpleA_Expr(DISTINCT, "=", larg, rarg);
	else
		expr = (Node *) makeA_Expr(OR, NIL, expr,
								   (Node *) makeSimpleA_Expr(DISTINCT, "=",
															 larg, rarg));

	return expr;
}

/* makeRowNullTest()
 * Generate separate operator nodes for a single row descriptor test.
 */
static Node *
makeRowNullTest(NullTestType test, List *args)
{
	Node *expr = NULL;
	Node *arg;
	NullTest *n;

	if (lnext(args) != NIL)
		expr = makeRowNullTest(test, lnext(args));

	arg = lfirst(args);

	n = makeNode(NullTest);
	n->arg = arg;
	n->nulltesttype = test;

	if (expr == NULL)
		expr = (Node *)n;
	else if (test == IS_NOT_NULL)
		expr = (Node *) makeA_Expr(OR, NIL, expr, (Node *)n);
	else
		expr = (Node *) makeA_Expr(AND, NIL, expr, (Node *)n);

	return expr;
}

/* makeOverlaps()
 * Create and populate a FuncCall node to support the OVERLAPS operator.
 */
static FuncCall *
makeOverlaps(List *largs, List *rargs)
{
	FuncCall *n = makeNode(FuncCall);
	n->funcname = SystemFuncName("overlaps");
	if (length(largs) == 1)
		largs = lappend(largs, largs);
	else if (length(largs) != 2)
		elog(ERROR, "Wrong number of parameters"
			 " on left side of OVERLAPS expression");
	if (length(rargs) == 1)
		rargs = lappend(rargs, rargs);
	else if (length(rargs) != 2)
		elog(ERROR, "Wrong number of parameters"
			 " on right side of OVERLAPS expression");
	n->args = nconc(largs, rargs);
	n->agg_star = FALSE;
	n->agg_distinct = FALSE;
	return n;
}

/* findLeftmostSelect()
 * Find the leftmost component SelectStmt in a set-operation parsetree.
 */
static SelectStmt *
findLeftmostSelect(SelectStmt *node)
{
	while (node && node->op != SETOP_NONE)
		node = node->larg;
	Assert(node && IsA(node, SelectStmt) && node->larg == NULL);
	return node;
}

/* insertSelectOptions()
 * Insert ORDER BY, etc into an already-constructed SelectStmt.
 *
 * This routine is just to avoid duplicating code in SelectStmt productions.
 */
static void
insertSelectOptions(SelectStmt *stmt,
					List *sortClause, List *forUpdate,
					Node *limitOffset, Node *limitCount)
{
	/*
	 * Tests here are to reject constructs like
	 *	(SELECT foo ORDER BY bar) ORDER BY baz
	 */
	if (sortClause)
	{
		if (stmt->sortClause)
			elog(ERROR, "Multiple ORDER BY clauses not allowed");
		stmt->sortClause = sortClause;
	}
	if (forUpdate)
	{
		if (stmt->forUpdate)
			elog(ERROR, "Multiple FOR UPDATE clauses not allowed");
		stmt->forUpdate = forUpdate;
	}
	if (limitOffset)
	{
		if (stmt->limitOffset)
			elog(ERROR, "Multiple OFFSET clauses not allowed");
		stmt->limitOffset = limitOffset;
	}
	if (limitCount)
	{
		if (stmt->limitCount)
			elog(ERROR, "Multiple LIMIT clauses not allowed");
		stmt->limitCount = limitCount;
	}
}

static Node *
makeSetOp(SetOperation op, bool all, Node *larg, Node *rarg)
{
	SelectStmt *n = makeNode(SelectStmt);

	n->op = op;
	n->all = all;
	n->larg = (SelectStmt *) larg;
	n->rarg = (SelectStmt *) rarg;
	return (Node *) n;
}

/* SystemFuncName()
 * Build a properly-qualified reference to a built-in function.
 */
List *
SystemFuncName(char *name)
{
	return makeList2(makeString("pg_catalog"), makeString(name));
}

/* SystemTypeName()
 * Build a properly-qualified reference to a built-in type.
 *
 * typmod is defaulted, but may be changed afterwards by caller.
 */
TypeName *
SystemTypeName(char *name)
{
	TypeName   *n = makeNode(TypeName);

	n->names = makeList2(makeString("pg_catalog"), makeString(name));
	n->typmod = -1;
	return n;
}

/* parser_init()
 * Initialize to parse one query string
 */
void
parser_init(void)
{
	QueryIsRule = FALSE;
}

/* exprIsNullConstant()
 * Test whether an a_expr is a plain NULL constant or not.
 */
bool
exprIsNullConstant(Node *arg)
{
	if (arg && IsA(arg, A_Const))
	{
		A_Const *con = (A_Const *) arg;

		if (con->val.type == T_Null &&
			con->typename == NULL)
			return TRUE;
	}
	return FALSE;
}

/* doNegate()
 * Handle negation of a numeric constant.
 *
 * Formerly, we did this here because the optimizer couldn't cope with
 * indexquals that looked like "var = -4" --- it wants "var = const"
 * and a unary minus operator applied to a constant didn't qualify.
 * As of Postgres 7.0, that problem doesn't exist anymore because there
 * is a constant-subexpression simplifier in the optimizer.  However,
 * there's still a good reason for doing this here, which is that we can
 * postpone committing to a particular internal representation for simple
 * negative constants.	It's better to leave "-123.456" in string form
 * until we know what the desired type is.
 */
static Node *
doNegate(Node *n)
{
	if (IsA(n, A_Const))
	{
		A_Const *con = (A_Const *)n;

		if (con->val.type == T_Integer)
		{
			con->val.val.ival = -con->val.val.ival;
			return n;
		}
		if (con->val.type == T_Float)
		{
			doNegateFloat(&con->val);
			return n;
		}
	}

	return (Node *) makeSimpleA_Expr(OP, "-", NULL, n);
}

static void
doNegateFloat(Value *v)
{
	char   *oldval = v->val.str;

	Assert(IsA(v, Float));
	if (*oldval == '+')
		oldval++;
	if (*oldval == '-')
		v->val.str = oldval+1;	/* just strip the '-' */
	else
	{
		char   *newval = (char *) palloc(strlen(oldval) + 2);

		*newval = '-';
		strcpy(newval+1, oldval);
		v->val.str = newval;
	}
}

#include "scan.c"

