/* A Bison parser, made by GNU Bison 1.875.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ABORT_TRANS = 258,
     ABSOLUTE = 259,
     ACCESS = 260,
     ACTION = 261,
     ADD = 262,
     AFTER = 263,
     AGGREGATE = 264,
     ALL = 265,
     ALTER = 266,
     ANALYSE = 267,
     ANALYZE = 268,
     AND = 269,
     ANY = 270,
     AS = 271,
     ASC = 272,
     ASSERTION = 273,
     ASSIGNMENT = 274,
     AT = 275,
     AUTHORIZATION = 276,
     BACKWARD = 277,
     BEFORE = 278,
     BEGIN_TRANS = 279,
     BETWEEN = 280,
     BIGINT = 281,
     BINARY = 282,
     BIT = 283,
     BOOLEAN = 284,
     BOTH = 285,
     BY = 286,
     CACHE = 287,
     CALLED = 288,
     CASCADE = 289,
     CASE = 290,
     CAST = 291,
     CHAIN = 292,
     CHAR_P = 293,
     CHARACTER = 294,
     CHARACTERISTICS = 295,
     CHECK = 296,
     CHECKPOINT = 297,
     CLASS = 298,
     CLOSE = 299,
     CLUSTER = 300,
     COALESCE = 301,
     COLLATE = 302,
     COLUMN = 303,
     COMMENT = 304,
     COMMIT = 305,
     COMMITTED = 306,
     CONSTRAINT = 307,
     CONSTRAINTS = 308,
     CONVERSION_P = 309,
     CONVERT = 310,
     COPY = 311,
     CREATE = 312,
     CREATEDB = 313,
     CREATEUSER = 314,
     CROSS = 315,
     CURRENT_DATE = 316,
     CURRENT_TIME = 317,
     CURRENT_TIMESTAMP = 318,
     CURRENT_USER = 319,
     CURSOR = 320,
     CYCLE = 321,
     DATABASE = 322,
     DAY_P = 323,
     DEALLOCATE = 324,
     DEC = 325,
     DECIMAL = 326,
     DECLARE = 327,
     DEFAULT = 328,
     DEFERRABLE = 329,
     DEFERRED = 330,
     DEFINER = 331,
     DELETE_P = 332,
     DELIMITER = 333,
     DELIMITERS = 334,
     DESC = 335,
     DISTINCT = 336,
     DO = 337,
     DOMAIN_P = 338,
     DOUBLE = 339,
     DROP = 340,
     EACH = 341,
     ELSE = 342,
     ENCODING = 343,
     ENCRYPTED = 344,
     END_TRANS = 345,
     ESCAPE = 346,
     EXCEPT = 347,
     EXCLUSIVE = 348,
     EXECUTE = 349,
     EXISTS = 350,
     EXPLAIN = 351,
     EXTERNAL = 352,
     EXTRACT = 353,
     FALSE_P = 354,
     FETCH = 355,
     FLOAT_P = 356,
     FOR = 357,
     FORCE = 358,
     FOREIGN = 359,
     FORWARD = 360,
     FREEZE = 361,
     FROM = 362,
     FULL = 363,
     FUNCTION = 364,
     GET = 365,
     GLOBAL = 366,
     GRANT = 367,
     GROUP_P = 368,
     HANDLER = 369,
     HAVING = 370,
     HOUR_P = 371,
     ILIKE = 372,
     IMMEDIATE = 373,
     IMMUTABLE = 374,
     IMPLICIT_P = 375,
     IN_P = 376,
     INCREMENT = 377,
     INDEX = 378,
     INHERITS = 379,
     INITIALLY = 380,
     INNER_P = 381,
     INOUT = 382,
     INPUT = 383,
     INSENSITIVE = 384,
     INSERT = 385,
     INSTEAD = 386,
     INT = 387,
     INTEGER = 388,
     INTERSECT = 389,
     INTERVAL = 390,
     INTO = 391,
     INVOKER = 392,
     IS = 393,
     ISNULL = 394,
     ISOLATION = 395,
     JOIN = 396,
     KEY = 397,
     LANCOMPILER = 398,
     LANGUAGE = 399,
     LEADING = 400,
     LEFT = 401,
     LEVEL = 402,
     LIKE = 403,
     LIMIT = 404,
     LISTEN = 405,
     LOAD = 406,
     LOCAL = 407,
     LOCALTIME = 408,
     LOCALTIMESTAMP = 409,
     LOCATION = 410,
     LOCK_P = 411,
     MATCH = 412,
     MAXVALUE = 413,
     MINUTE_P = 414,
     MINVALUE = 415,
     MODE = 416,
     MONTH_P = 417,
     MOVE = 418,
     NAMES = 419,
     NATIONAL = 420,
     NATURAL = 421,
     NCHAR = 422,
     NEW = 423,
     NEXT = 424,
     NO = 425,
     NOCREATEDB = 426,
     NOCREATEUSER = 427,
     NONE = 428,
     NOT = 429,
     NOTHING = 430,
     NOTIFY = 431,
     NOTNULL = 432,
     NULL_P = 433,
     NULLIF = 434,
     NUMERIC = 435,
     OF = 436,
     OFF = 437,
     OFFSET = 438,
     OIDS = 439,
     OLD = 440,
     ON = 441,
     ONLY = 442,
     OPERATOR = 443,
     OPTION = 444,
     OR = 445,
     ORDER = 446,
     OUT_P = 447,
     OUTER_P = 448,
     OVERLAPS = 449,
     OVERLAY = 450,
     OWNER = 451,
     PARTIAL = 452,
     PASSWORD = 453,
     PATH_P = 454,
     PENDANT = 455,
     PLACING = 456,
     POSITION = 457,
     PRECISION = 458,
     PREPARE = 459,
     PRIMARY = 460,
     PRIOR = 461,
     PRIVILEGES = 462,
     PROCEDURAL = 463,
     PROCEDURE = 464,
     READ = 465,
     REAL = 466,
     RECHECK = 467,
     REFERENCES = 468,
     REINDEX = 469,
     RELATIVE = 470,
     RENAME = 471,
     REPLACE = 472,
     RESET = 473,
     RESTRICT = 474,
     RETURNS = 475,
     REVOKE = 476,
     RIGHT = 477,
     ROLLBACK = 478,
     ROW = 479,
     RULE = 480,
     SCHEMA = 481,
     SCROLL = 482,
     SECOND_P = 483,
     SECURITY = 484,
     SELECT = 485,
     SEQUENCE = 486,
     SERIALIZABLE = 487,
     SESSION = 488,
     SESSION_USER = 489,
     SET = 490,
     SETOF = 491,
     SHARE = 492,
     SHOW = 493,
     SIMILAR = 494,
     SIMPLE = 495,
     SMALLINT = 496,
     SOME = 497,
     STABLE = 498,
     START = 499,
     STATEMENT = 500,
     STATISTICS = 501,
     STDIN = 502,
     STDOUT = 503,
     STORAGE = 504,
     STRICT = 505,
     SUBSTRING = 506,
     SYSID = 507,
     TABLE = 508,
     TEMP = 509,
     TEMPLATE = 510,
     TEMPORARY = 511,
     THEN = 512,
     TIME = 513,
     TIMESTAMP = 514,
     TO = 515,
     TOAST = 516,
     TRAILING = 517,
     TRANSACTION = 518,
     TREAT = 519,
     TRIGGER = 520,
     TRIM = 521,
     TRUE_P = 522,
     TRUNCATE = 523,
     TRUSTED = 524,
     TYPE_P = 525,
     UNENCRYPTED = 526,
     UNION = 527,
     UNIQUE = 528,
     UNKNOWN = 529,
     UNLISTEN = 530,
     UNTIL = 531,
     UPDATE = 532,
     USAGE = 533,
     USER = 534,
     USING = 535,
     VACUUM = 536,
     VALID = 537,
     VALIDATOR = 538,
     VALUES = 539,
     VARCHAR = 540,
     VARYING = 541,
     VERBOSE = 542,
     VERSION = 543,
     VIEW = 544,
     VOLATILE = 545,
     WHEN = 546,
     WHERE = 547,
     WITH = 548,
     WITHOUT = 549,
     WORK = 550,
     WRITE = 551,
     YEAR_P = 552,
     ZONE = 553,
     UNIONJOIN = 554,
     IDENT = 555,
     FCONST = 556,
     SCONST = 557,
     NCONST = 558,
     BCONST = 559,
     XCONST = 560,
     Op = 561,
     ICONST = 562,
     PARAM = 563,
     OP = 564,
     POSTFIXOP = 565,
     UMINUS = 566,
     TYPECAST = 567
   };
#endif
#define ABORT_TRANS 258
#define ABSOLUTE 259
#define ACCESS 260
#define ACTION 261
#define ADD 262
#define AFTER 263
#define AGGREGATE 264
#define ALL 265
#define ALTER 266
#define ANALYSE 267
#define ANALYZE 268
#define AND 269
#define ANY 270
#define AS 271
#define ASC 272
#define ASSERTION 273
#define ASSIGNMENT 274
#define AT 275
#define AUTHORIZATION 276
#define BACKWARD 277
#define BEFORE 278
#define BEGIN_TRANS 279
#define BETWEEN 280
#define BIGINT 281
#define BINARY 282
#define BIT 283
#define BOOLEAN 284
#define BOTH 285
#define BY 286
#define CACHE 287
#define CALLED 288
#define CASCADE 289
#define CASE 290
#define CAST 291
#define CHAIN 292
#define CHAR_P 293
#define CHARACTER 294
#define CHARACTERISTICS 295
#define CHECK 296
#define CHECKPOINT 297
#define CLASS 298
#define CLOSE 299
#define CLUSTER 300
#define COALESCE 301
#define COLLATE 302
#define COLUMN 303
#define COMMENT 304
#define COMMIT 305
#define COMMITTED 306
#define CONSTRAINT 307
#define CONSTRAINTS 308
#define CONVERSION_P 309
#define CONVERT 310
#define COPY 311
#define CREATE 312
#define CREATEDB 313
#define CREATEUSER 314
#define CROSS 315
#define CURRENT_DATE 316
#define CURRENT_TIME 317
#define CURRENT_TIMESTAMP 318
#define CURRENT_USER 319
#define CURSOR 320
#define CYCLE 321
#define DATABASE 322
#define DAY_P 323
#define DEALLOCATE 324
#define DEC 325
#define DECIMAL 326
#define DECLARE 327
#define DEFAULT 328
#define DEFERRABLE 329
#define DEFERRED 330
#define DEFINER 331
#define DELETE_P 332
#define DELIMITER 333
#define DELIMITERS 334
#define DESC 335
#define DISTINCT 336
#define DO 337
#define DOMAIN_P 338
#define DOUBLE 339
#define DROP 340
#define EACH 341
#define ELSE 342
#define ENCODING 343
#define ENCRYPTED 344
#define END_TRANS 345
#define ESCAPE 346
#define EXCEPT 347
#define EXCLUSIVE 348
#define EXECUTE 349
#define EXISTS 350
#define EXPLAIN 351
#define EXTERNAL 352
#define EXTRACT 353
#define FALSE_P 354
#define FETCH 355
#define FLOAT_P 356
#define FOR 357
#define FORCE 358
#define FOREIGN 359
#define FORWARD 360
#define FREEZE 361
#define FROM 362
#define FULL 363
#define FUNCTION 364
#define GET 365
#define GLOBAL 366
#define GRANT 367
#define GROUP_P 368
#define HANDLER 369
#define HAVING 370
#define HOUR_P 371
#define ILIKE 372
#define IMMEDIATE 373
#define IMMUTABLE 374
#define IMPLICIT_P 375
#define IN_P 376
#define INCREMENT 377
#define INDEX 378
#define INHERITS 379
#define INITIALLY 380
#define INNER_P 381
#define INOUT 382
#define INPUT 383
#define INSENSITIVE 384
#define INSERT 385
#define INSTEAD 386
#define INT 387
#define INTEGER 388
#define INTERSECT 389
#define INTERVAL 390
#define INTO 391
#define INVOKER 392
#define IS 393
#define ISNULL 394
#define ISOLATION 395
#define JOIN 396
#define KEY 397
#define LANCOMPILER 398
#define LANGUAGE 399
#define LEADING 400
#define LEFT 401
#define LEVEL 402
#define LIKE 403
#define LIMIT 404
#define LISTEN 405
#define LOAD 406
#define LOCAL 407
#define LOCALTIME 408
#define LOCALTIMESTAMP 409
#define LOCATION 410
#define LOCK_P 411
#define MATCH 412
#define MAXVALUE 413
#define MINUTE_P 414
#define MINVALUE 415
#define MODE 416
#define MONTH_P 417
#define MOVE 418
#define NAMES 419
#define NATIONAL 420
#define NATURAL 421
#define NCHAR 422
#define NEW 423
#define NEXT 424
#define NO 425
#define NOCREATEDB 426
#define NOCREATEUSER 427
#define NONE 428
#define NOT 429
#define NOTHING 430
#define NOTIFY 431
#define NOTNULL 432
#define NULL_P 433
#define NULLIF 434
#define NUMERIC 435
#define OF 436
#define OFF 437
#define OFFSET 438
#define OIDS 439
#define OLD 440
#define ON 441
#define ONLY 442
#define OPERATOR 443
#define OPTION 444
#define OR 445
#define ORDER 446
#define OUT_P 447
#define OUTER_P 448
#define OVERLAPS 449
#define OVERLAY 450
#define OWNER 451
#define PARTIAL 452
#define PASSWORD 453
#define PATH_P 454
#define PENDANT 455
#define PLACING 456
#define POSITION 457
#define PRECISION 458
#define PREPARE 459
#define PRIMARY 460
#define PRIOR 461
#define PRIVILEGES 462
#define PROCEDURAL 463
#define PROCEDURE 464
#define READ 465
#define REAL 466
#define RECHECK 467
#define REFERENCES 468
#define REINDEX 469
#define RELATIVE 470
#define RENAME 471
#define REPLACE 472
#define RESET 473
#define RESTRICT 474
#define RETURNS 475
#define REVOKE 476
#define RIGHT 477
#define ROLLBACK 478
#define ROW 479
#define RULE 480
#define SCHEMA 481
#define SCROLL 482
#define SECOND_P 483
#define SECURITY 484
#define SELECT 485
#define SEQUENCE 486
#define SERIALIZABLE 487
#define SESSION 488
#define SESSION_USER 489
#define SET 490
#define SETOF 491
#define SHARE 492
#define SHOW 493
#define SIMILAR 494
#define SIMPLE 495
#define SMALLINT 496
#define SOME 497
#define STABLE 498
#define START 499
#define STATEMENT 500
#define STATISTICS 501
#define STDIN 502
#define STDOUT 503
#define STORAGE 504
#define STRICT 505
#define SUBSTRING 506
#define SYSID 507
#define TABLE 508
#define TEMP 509
#define TEMPLATE 510
#define TEMPORARY 511
#define THEN 512
#define TIME 513
#define TIMESTAMP 514
#define TO 515
#define TOAST 516
#define TRAILING 517
#define TRANSACTION 518
#define TREAT 519
#define TRIGGER 520
#define TRIM 521
#define TRUE_P 522
#define TRUNCATE 523
#define TRUSTED 524
#define TYPE_P 525
#define UNENCRYPTED 526
#define UNION 527
#define UNIQUE 528
#define UNKNOWN 529
#define UNLISTEN 530
#define UNTIL 531
#define UPDATE 532
#define USAGE 533
#define USER 534
#define USING 535
#define VACUUM 536
#define VALID 537
#define VALIDATOR 538
#define VALUES 539
#define VARCHAR 540
#define VARYING 541
#define VERBOSE 542
#define VERSION 543
#define VIEW 544
#define VOLATILE 545
#define WHEN 546
#define WHERE 547
#define WITH 548
#define WITHOUT 549
#define WORK 550
#define WRITE 551
#define YEAR_P 552
#define ZONE 553
#define UNIONJOIN 554
#define IDENT 555
#define FCONST 556
#define SCONST 557
#define NCONST 558
#define BCONST 559
#define XCONST 560
#define Op 561
#define ICONST 562
#define PARAM 563
#define OP 564
#define POSTFIXOP 565
#define UMINUS 566
#define TYPECAST 567




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 100 "gram.y"
typedef union YYSTYPE {
	int					ival;
	char				chr;
	char				*str;
	const char			*keyword;
	bool				boolean;
	JoinType			jtype;
	DropBehavior		dbehavior;
	List				*list;
	Node				*node;
	Value				*value;
	ColumnRef			*columnref;

	TypeName			*typnam;
	DefElem				*defelt;
	SortGroupBy			*sortgroupby;
	JoinExpr			*jexpr;
	IndexElem			*ielem;
	Alias				*alias;
	RangeVar			*range;
	A_Indices			*aind;
	ResTarget			*target;
	PrivTarget			*privtarget;

	InsertStmt			*istmt;
	VariableSetStmt		*vsetstmt;
} YYSTYPE;
/* Line 1248 of yacc.c.  */
#line 688 "y.tab.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;



