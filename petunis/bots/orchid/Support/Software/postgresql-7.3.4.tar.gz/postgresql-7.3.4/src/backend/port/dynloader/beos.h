/*-------------------------------------------------------------------------
 *
 * port_protos.h
 *	  port-specific prototypes for BeOS
 *
 *
 * Portions Copyright (c) 1996-2002, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * $Id: beos.h,v 1.7 2002/06/20 20:29:33 momjian Exp $
 *
 *-------------------------------------------------------------------------
 */
#ifndef PORT_PROTOS_H
#define PORT_PROTOS_H

#endif   /* PORT_PROTOS_H */
