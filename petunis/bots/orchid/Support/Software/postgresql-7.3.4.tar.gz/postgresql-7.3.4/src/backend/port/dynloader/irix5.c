/* Dummy file used for nothing at this point
 *
 * see irix5.h
 */
