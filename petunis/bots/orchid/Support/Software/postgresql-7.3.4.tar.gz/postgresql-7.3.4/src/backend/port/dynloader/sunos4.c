/* Dummy file used for nothing at this point
 *
 * see sunos4.h
 */
